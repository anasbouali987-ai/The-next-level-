package com.gtavmobile.runtime

import android.content.Context
import androidx.documentfile.provider.DocumentFile
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedInputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.security.MessageDigest
import java.util.Locale

object PeInspector {
    private const val MAX_FILE_BYTES = 96 * 1024 * 1024

    fun inspect(context: Context, file: DocumentFile): JSONObject {
        val name = file.name ?: "(unnamed)"
        val result = JSONObject()
            .put("name", name)
            .put("size_bytes", file.length())
            .put("uri", file.uri.toString())

        if (file.length() <= 0 || file.length() > MAX_FILE_BYTES) {
            return result
                .put("status", "SKIPPED")
                .put("reason", "unsupported_size")
        }

        val bytes = context.contentResolver.openInputStream(file.uri)?.use { input ->
            BufferedInputStream(input, 1024 * 1024).readBytes()
        } ?: return result.put("status", "ERROR").put("reason", "open_failed")

        result.put("sha256", sha256(bytes))

        if (bytes.size < 0x100 || bytes[0] != 'M'.code.toByte() || bytes[1] != 'Z'.code.toByte()) {
            return result.put("status", "NOT_PE")
        }

        try {
            val buffer = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
            val peOffset = buffer.getInt(0x3C)
            if (peOffset <= 0 || peOffset + 24 >= bytes.size) {
                return result.put("status", "INVALID_PE").put("reason", "bad_pe_offset")
            }
            if (
                bytes[peOffset] != 'P'.code.toByte() ||
                bytes[peOffset + 1] != 'E'.code.toByte() ||
                bytes[peOffset + 2] != 0.toByte() ||
                bytes[peOffset + 3] != 0.toByte()
            ) {
                return result.put("status", "INVALID_PE").put("reason", "missing_signature")
            }

            val coff = peOffset + 4
            val machine = u16(buffer, coff)
            val sectionCount = u16(buffer, coff + 2)
            val timestamp = u32(buffer, coff + 4)
            val optionalSize = u16(buffer, coff + 16)
            val characteristics = u16(buffer, coff + 18)
            val optional = coff + 20
            val magic = u16(buffer, optional)
            val is64 = magic == 0x20B
            val is32 = magic == 0x10B

            val dataDirectoryBase = when {
                is64 -> optional + 112
                is32 -> optional + 96
                else -> -1
            }

            val sections = mutableListOf<Section>()
            val sectionTable = optional + optionalSize
            for (i in 0 until sectionCount.coerceAtMost(96)) {
                val off = sectionTable + i * 40
                if (off + 40 > bytes.size) break
                val sectionName = bytes.copyOfRange(off, off + 8)
                    .takeWhile { it != 0.toByte() }
                    .toByteArray()
                    .toString(Charsets.US_ASCII)
                sections.add(
                    Section(
                        sectionName,
                        u32(buffer, off + 12).toLong(),
                        u32(buffer, off + 8).toLong(),
                        u32(buffer, off + 20).toLong(),
                        u32(buffer, off + 16).toLong()
                    )
                )
            }

            val imports = JSONArray()
            val exports = JSONArray()

            if (dataDirectoryBase > 0 && dataDirectoryBase + 16 * 8 <= bytes.size) {
                parseImports(bytes, buffer, sections, dataDirectoryBase + 1 * 8, is64, imports)
                parseExports(bytes, buffer, sections, dataDirectoryBase + 0 * 8, exports)
            }

            return result
                .put("status", "OK")
                .put("format", if (is64) "PE32+" else if (is32) "PE32" else "UNKNOWN")
                .put("machine_code", String.format(Locale.US, "0x%04X", machine))
                .put("architecture", machineName(machine))
                .put("section_count", sectionCount)
                .put("timestamp_unix", timestamp)
                .put("characteristics", String.format(Locale.US, "0x%04X", characteristics))
                .put("imports", imports)
                .put("import_dll_count", imports.length())
                .put("exports", exports)
                .put("export_count", exports.length())
        } catch (e: Exception) {
            return result
                .put("status", "ERROR")
                .put("reason", e.message ?: e.javaClass.simpleName)
        }
    }

    private fun parseImports(
        bytes: ByteArray,
        buffer: ByteBuffer,
        sections: List<Section>,
        directoryOffset: Int,
        is64: Boolean,
        output: JSONArray
    ) {
        val rva = u32(buffer, directoryOffset).toLong()
        val size = u32(buffer, directoryOffset + 4).toLong()
        if (rva == 0L || size == 0L) return
        var off = rvaToOffset(rva, sections) ?: return

        var count = 0
        while (off + 20 <= bytes.size && count < 512) {
            val originalFirstThunk = u32(buffer, off).toLong()
            val nameRva = u32(buffer, off + 12).toLong()
            val firstThunk = u32(buffer, off + 16).toLong()
            if (originalFirstThunk == 0L && nameRva == 0L && firstThunk == 0L) break

            val nameOff = rvaToOffset(nameRva, sections)
            val dllName = nameOff?.let { readCString(bytes, it, 512) } ?: "(invalid)"
            val item = JSONObject().put("dll", dllName)

            val functions = JSONArray()
            val thunkRva = if (originalFirstThunk != 0L) originalFirstThunk else firstThunk
            parseThunkTable(bytes, buffer, sections, thunkRva, is64, functions)
            item.put("functions", functions)
            item.put("function_count", functions.length())
            output.put(item)

            off += 20
            count++
        }
    }

    private fun parseThunkTable(
        bytes: ByteArray,
        buffer: ByteBuffer,
        sections: List<Section>,
        thunkRva: Long,
        is64: Boolean,
        output: JSONArray
    ) {
        var off = rvaToOffset(thunkRva, sections) ?: return
        val step = if (is64) 8 else 4
        var count = 0

        while (off + step <= bytes.size && count < 2048) {
            val value = if (is64) buffer.getLong(off) else u32(buffer, off).toLong()
            if (value == 0L) break

            val ordinalMask = if (is64) Long.MIN_VALUE else 0x80000000L
            if ((value and ordinalMask) != 0L) {
                output.put(JSONObject().put("ordinal", value and 0xFFFF))
            } else {
                val nameOff = rvaToOffset(value, sections)
                if (nameOff != null && nameOff + 2 < bytes.size) {
                    output.put(JSONObject().put("name", readCString(bytes, nameOff + 2, 512)))
                }
            }

            off += step
            count++
        }
    }

    private fun parseExports(
        bytes: ByteArray,
        buffer: ByteBuffer,
        sections: List<Section>,
        directoryOffset: Int,
        output: JSONArray
    ) {
        val rva = u32(buffer, directoryOffset).toLong()
        val size = u32(buffer, directoryOffset + 4).toLong()
        if (rva == 0L || size == 0L) return
        val off = rvaToOffset(rva, sections) ?: return
        if (off + 40 > bytes.size) return

        val ordinalBase = u32(buffer, off + 16).toLong()
        val numberOfFunctions = u32(buffer, off + 20)
        val numberOfNames = u32(buffer, off + 24)
        val addressOfNamesRva = u32(buffer, off + 32).toLong()
        val addressOfOrdinalsRva = u32(buffer, off + 36).toLong()

        val namesOff = rvaToOffset(addressOfNamesRva, sections)
        val ordinalsOff = rvaToOffset(addressOfOrdinalsRva, sections)

        if (namesOff != null && ordinalsOff != null) {
            for (i in 0 until numberOfNames.coerceAtMost(4096)) {
                val nameRva = u32(buffer, namesOff + i * 4).toLong()
                val nameOff = rvaToOffset(nameRva, sections) ?: continue
                val ordinalIndex = u16(buffer, ordinalsOff + i * 2)
                output.put(
                    JSONObject()
                        .put("name", readCString(bytes, nameOff, 512))
                        .put("ordinal", ordinalBase + ordinalIndex)
                )
            }
        } else {
            for (i in 0 until numberOfFunctions.coerceAtMost(4096)) {
                output.put(JSONObject().put("ordinal", ordinalBase + i))
            }
        }
    }

    private fun rvaToOffset(rva: Long, sections: List<Section>): Int? {
        for (section in sections) {
            val span = maxOf(section.virtualSize, section.rawSize)
            if (rva >= section.virtualAddress && rva < section.virtualAddress + span) {
                return (section.rawOffset + (rva - section.virtualAddress)).toInt()
            }
        }
        return null
    }

    private fun readCString(bytes: ByteArray, start: Int, max: Int): String {
        if (start < 0 || start >= bytes.size) return ""
        var end = start
        val limit = minOf(bytes.size, start + max)
        while (end < limit && bytes[end] != 0.toByte()) end++
        return bytes.copyOfRange(start, end).toString(Charsets.US_ASCII)
    }

    private fun u16(buffer: ByteBuffer, offset: Int): Int =
        buffer.getShort(offset).toInt() and 0xFFFF

    private fun u32(buffer: ByteBuffer, offset: Int): Int = buffer.getInt(offset)

    private fun machineName(code: Int): String = when (code) {
        0x8664 -> "x86-64"
        0x014C -> "x86"
        0xAA64 -> "ARM64"
        0x01C4 -> "ARMv7"
        else -> "UNKNOWN"
    }

    private fun sha256(bytes: ByteArray): String {
        return MessageDigest.getInstance("SHA-256")
            .digest(bytes)
            .joinToString("") { "%02x".format(it) }
    }

    private data class Section(
        val name: String,
        val virtualAddress: Long,
        val virtualSize: Long,
        val rawOffset: Long,
        val rawSize: Long
    )
}
