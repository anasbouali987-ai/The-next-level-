package com.gtavmobile.runtime

import android.content.Context
import android.net.Uri
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.security.MessageDigest
import kotlin.math.max

object StorageBenchmark {
    private const val BLOCK_SIZE = 1024 * 1024
    private const val PRIVATE_TEST_SIZE = 64L * 1024L * 1024L

    fun run(context: Context, gta5Uri: Uri): JSONObject {
        val result = JSONObject()
        result.put("shared_saf_read", benchmarkSafRead(context, gta5Uri))
        result.put("app_private", benchmarkPrivate(context))
        return result
    }

    private fun benchmarkSafRead(context: Context, uri: Uri): JSONObject {
        val digest = MessageDigest.getInstance("SHA-256")
        var bytes = 0L
        val buffer = ByteArray(BLOCK_SIZE)
        val start = System.nanoTime()

        context.contentResolver.openInputStream(uri)?.use { raw ->
            BufferedInputStream(raw, BLOCK_SIZE).use { input ->
                while (true) {
                    val read = input.read(buffer)
                    if (read <= 0) break
                    bytes += read
                    digest.update(buffer, 0, read)
                }
            }
        } ?: error("Unable to open GTA5.exe through SAF")

        val elapsedNs = max(1L, System.nanoTime() - start)
        return JSONObject()
            .put("bytes_read", bytes)
            .put("elapsed_ms", elapsedNs / 1_000_000.0)
            .put("throughput_mib_s", throughput(bytes, elapsedNs))
            .put("sha256", digest.digest().joinToString("") { "%02x".format(it) })
            .put("source", "Storage Access Framework / shared storage")
    }

    private fun benchmarkPrivate(context: Context): JSONObject {
        val file = File(context.cacheDir, "gtav_storage_benchmark_64m.bin")
        val buffer = ByteArray(BLOCK_SIZE) { index -> (index and 0xFF).toByte() }

        val writeStart = System.nanoTime()
        BufferedOutputStream(file.outputStream(), BLOCK_SIZE).use { output ->
            var remaining = PRIVATE_TEST_SIZE
            while (remaining > 0) {
                val count = minOf(buffer.size.toLong(), remaining).toInt()
                output.write(buffer, 0, count)
                remaining -= count
            }
            output.flush()
        }
        val writeElapsed = max(1L, System.nanoTime() - writeStart)

        var readBytes = 0L
        val readBuffer = ByteArray(BLOCK_SIZE)
        val readStart = System.nanoTime()
        BufferedInputStream(file.inputStream(), BLOCK_SIZE).use { input ->
            while (true) {
                val read = input.read(readBuffer)
                if (read <= 0) break
                readBytes += read
            }
        }
        val readElapsed = max(1L, System.nanoTime() - readStart)
        val deleted = file.delete()

        return JSONObject()
            .put("test_size_bytes", PRIVATE_TEST_SIZE)
            .put("write_elapsed_ms", writeElapsed / 1_000_000.0)
            .put("write_mib_s", throughput(PRIVATE_TEST_SIZE, writeElapsed))
            .put("read_elapsed_ms", readElapsed / 1_000_000.0)
            .put("read_mib_s", throughput(readBytes, readElapsed))
            .put("temporary_file_deleted", deleted)
            .put("location", context.cacheDir.absolutePath)
    }

    private fun throughput(bytes: Long, elapsedNs: Long): Double {
        val seconds = elapsedNs / 1_000_000_000.0
        return (bytes / 1048576.0) / seconds
    }
}
