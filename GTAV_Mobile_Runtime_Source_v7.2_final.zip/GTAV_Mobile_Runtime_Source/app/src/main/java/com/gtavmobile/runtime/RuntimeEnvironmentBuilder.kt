package com.gtavmobile.runtime

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.security.MessageDigest

object RuntimeEnvironmentBuilder {
    private const val SCHEMA_VERSION = 1

    fun create(context: Context): JSONObject {
        val root = File(context.filesDir, "runtime")
        val prefix = File(root, "prefix")
        val driveC = File(prefix, "drive_c")
        val user = File(driveC, "users/player")

        val directories = listOf(
            root,
            File(root, "components"),
            File(root, "packages"),
            File(root, "logs"),
            File(root, "cache"),
            File(root, "tmp"),
            prefix,
            driveC,
            File(driveC, "windows"),
            File(driveC, "windows/system32"),
            File(driveC, "windows/syswow64"),
            File(driveC, "windows/temp"),
            File(driveC, "Program Files"),
            File(driveC, "Program Files (x86)"),
            File(driveC, "ProgramData"),
            user,
            File(user, "Desktop"),
            File(user, "Documents"),
            File(user, "Downloads"),
            File(user, "AppData/Local"),
            File(user, "AppData/Local/Temp"),
            File(user, "AppData/Roaming"),
            File(prefix, "dosdevices"),
            File(root, "profiles"),
            File(root, "licenses")
        )

        val created = JSONArray()
        val existing = JSONArray()
        val failed = JSONArray()

        directories.forEach { dir ->
            when {
                dir.exists() -> existing.put(dir.relativeTo(context.filesDir).path)
                dir.mkdirs() -> created.put(dir.relativeTo(context.filesDir).path)
                else -> failed.put(dir.relativeTo(context.filesDir).path)
            }
        }

        val systemReg = File(prefix, "system.reg")
        val userReg = File(prefix, "user.reg")
        val userdefReg = File(prefix, "userdef.reg")
        val runtimeState = File(root, "runtime_state.json")
        val launchProfile = File(root, "profiles/gtav_4631_safe.json")

        writeIfMissing(
            systemReg,
            """
            WINE REGISTRY Version 2

            [Software\\Microsoft\\Windows NT\\CurrentVersion]
            "ProductName"="Windows 10"
            "CurrentVersion"="10.0"
            "CurrentBuild"="19045"
            """.trimIndent() + "\n"
        )

        writeIfMissing(
            userReg,
            """
            WINE REGISTRY Version 2

            [Software\\Wine]
            "Version"="win10"

            [Software\\Wine\\Direct3D]
            "VideoMemorySize"="4096"
            """.trimIndent() + "\n"
        )

        writeIfMissing(
            userdefReg,
            """
            WINE REGISTRY Version 2
            """.trimIndent() + "\n"
        )

        val profile = JSONObject()
            .put("profile_id", "GTAV_4631_REDMAGIC10S_SAFE_BOOT_001")
            .put("game_version", "1.0.463.1")
            .put("architecture", "win64")
            .put("cpu_translation", "box64")
            .put("resolution", "960x540")
            .put("refresh_rate", 60)
            .put("fps_limit", 30)
            .put("graphics", "dxvk")
            .put("asi_enabled", false)
            .put("save_profile", "empty")
            .put("game_data_mode", "read_only")
            .put("activation", "official_licensed_launcher_only")

        launchProfile.writeText(profile.toString(2), Charsets.UTF_8)

        val state = JSONObject()
            .put("schema_version", SCHEMA_VERSION)
            .put("environment_created", failed.length() == 0)
            .put("runtime_components_installed", false)
            .put("prefix_initialized_by_wine", false)
            .put("ready_for_binary_self_test", false)
            .put("ready_for_gtav", false)
            .put("root_path", root.absolutePath)
            .put("prefix_path", prefix.absolutePath)
            .put("profile_path", launchProfile.absolutePath)
            .put("required_components", JSONArray(listOf(
                "box64",
                "wine64",
                "wineserver",
                "wineboot",
                "turnip_or_system_vulkan",
                "dxvk"
            )))
        runtimeState.writeText(state.toString(2), Charsets.UTF_8)

        return JSONObject()
            .put("builder", "Runtime Environment Builder v0.5")
            .put("root_path", root.absolutePath)
            .put("prefix_path", prefix.absolutePath)
            .put("created_directories", created)
            .put("existing_directories", existing)
            .put("failed_directories", failed)
            .put("environment_created", failed.length() == 0)
            .put("registry_templates", JSONArray(listOf(
                fileInfo(systemReg),
                fileInfo(userReg),
                fileInfo(userdefReg)
            )))
            .put("launch_profile", fileInfo(launchProfile))
            .put("runtime_state", state)
    }

    fun inspect(context: Context): JSONObject {
        val root = File(context.filesDir, "runtime")
        val stateFile = File(root, "runtime_state.json")
        val manifestFile = File(root, "components/runtime_manifest.json")

        return JSONObject()
            .put("root_exists", root.isDirectory)
            .put("state_exists", stateFile.isFile)
            .put("component_manifest_exists", manifestFile.isFile)
            .put(
                "runtime_state",
                if (stateFile.isFile) {
                    runCatching { JSONObject(stateFile.readText(Charsets.UTF_8)) }
                        .getOrElse { JSONObject().put("error", it.message) }
                } else {
                    JSONObject.NULL
                }
            )
            .put(
                "component_manifest",
                if (manifestFile.isFile) {
                    runCatching { JSONObject(manifestFile.readText(Charsets.UTF_8)) }
                        .getOrElse { JSONObject().put("error", it.message) }
                } else {
                    JSONObject.NULL
                }
            )
    }

    private fun writeIfMissing(file: File, content: String) {
        file.parentFile?.mkdirs()
        if (!file.exists()) file.writeText(content, Charsets.UTF_8)
    }

    private fun fileInfo(file: File): JSONObject {
        return JSONObject()
            .put("path", file.absolutePath)
            .put("size_bytes", file.length())
            .put("sha256", if (file.isFile) sha256(file) else JSONObject.NULL)
    }

    private fun sha256(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        file.inputStream().buffered(1024 * 1024).use { input ->
            val buffer = ByteArray(1024 * 1024)
            while (true) {
                val count = input.read(buffer)
                if (count <= 0) break
                digest.update(buffer, 0, count)
            }
        }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }
}
