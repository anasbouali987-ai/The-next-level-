package com.gtavmobile.runtime

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.concurrent.TimeUnit

object RuntimeSelfTest {
    private const val TIMEOUT_SECONDS = 15L
    private const val MAX_OUTPUT_CHARS = 32_000

    fun run(context: Context): JSONObject {
        val runtimeRoot = File(context.filesDir, "runtime")
        val components = File(runtimeRoot, "components")
        val stateFile = File(runtimeRoot, "runtime_state.json")
        val logsDir = File(runtimeRoot, "logs/self_test")
        logsDir.mkdirs()

        val nativeBox64 = File(context.applicationInfo.nativeLibraryDir, "libbox64.so")
        val tests = JSONArray()

        tests.put(runNativeBox64(nativeBox64, components, logsDir))
        tests.put(runThroughBox64("wine64", nativeBox64, components, logsDir,
            listOf("bin/wine64", "wine/bin/wine64", "wine/bin/wine"), listOf("--version")))
        tests.put(runThroughBox64("wineserver", nativeBox64, components, logsDir,
            listOf("bin/wineserver", "wine/bin/wineserver"), listOf("--version")))
        tests.put(runThroughBox64("wineboot", nativeBox64, components, logsDir,
            listOf("wine/bin/wineboot", "wine/lib/wine/x86_64-windows/wineboot.exe", "wine/share/wine/wine/x86_64-windows/wineboot.exe"), listOf("--help")))

        var passCount = 0
        var failCount = 0
        var blockedCount = 0
        for (i in 0 until tests.length()) {
            when (tests.optJSONObject(i)?.optString("status")) {
                "PASS" -> passCount++
                "FAIL" -> failCount++
                else -> blockedCount++
            }
        }

        val allPassed = passCount == tests.length()
        val state = if (stateFile.isFile) {
            runCatching { JSONObject(stateFile.readText(Charsets.UTF_8)) }.getOrElse { JSONObject() }
        } else JSONObject()

        state.put("binary_self_test_completed", true)
            .put("binary_self_test_passed", allPassed)
            .put("binary_self_test_pass_count", passCount)
            .put("binary_self_test_fail_count", failCount)
            .put("binary_self_test_blocked_count", blockedCount)
            .put("native_box64_path", nativeBox64.absolutePath)
            .put("native_box64_present", nativeBox64.isFile)
            .put("ready_for_wineboot_test", allPassed)
            .put("ready_for_gtav", false)

        stateFile.parentFile?.mkdirs()
        stateFile.writeText(state.toString(2), Charsets.UTF_8)

        return JSONObject()
            .put("engine", "Runtime Binary Self-Test v0.7.2")
            .put("execution_strategy", "APK nativeLibraryDir Box64 + imported Wine runtime")
            .put("native_library_dir", context.applicationInfo.nativeLibraryDir)
            .put("native_box64", nativeBox64.absolutePath)
            .put("native_box64_exists", nativeBox64.isFile)
            .put("components_path", components.absolutePath)
            .put("tests", tests)
            .put("summary", JSONObject()
                .put("test_count", tests.length())
                .put("pass_count", passCount)
                .put("fail_count", failCount)
                .put("blocked_count", blockedCount)
                .put("all_passed", allPassed))
            .put("runtime_state", state)
    }

    private fun runNativeBox64(box64: File, components: File, logsDir: File): JSONObject {
        if (!box64.isFile) {
            return JSONObject()
                .put("id", "box64")
                .put("status", "BLOCKED")
                .put("reason", "native_box64_missing_from_apk")
                .put("expected_path", box64.absolutePath)
                .put("fix", "Inject bin/box64 as app/src/main/jniLibs/arm64-v8a/libbox64.so before Gradle build")
        }
        return execute("box64", listOf(box64.absolutePath, "--version"), components, logsDir, buildEnvironment(components))
    }

    private fun runThroughBox64(
        id: String,
        box64: File,
        components: File,
        logsDir: File,
        possiblePaths: List<String>,
        args: List<String>
    ): JSONObject {
        if (!box64.isFile) {
            return JSONObject()
                .put("id", id)
                .put("status", "BLOCKED")
                .put("reason", "native_box64_missing_from_apk")
                .put("expected_path", box64.absolutePath)
        }

        val guest = possiblePaths.asSequence().map { File(components, it) }.firstOrNull { it.isFile }
            ?: return JSONObject()
                .put("id", id)
                .put("status", "BLOCKED")
                .put("reason", "guest_binary_not_found")
                .put("searched_paths", JSONArray(possiblePaths))

        val command = mutableListOf(box64.absolutePath, guest.absolutePath)
        command.addAll(args)
        return execute(id, command, components, logsDir, buildEnvironment(components))
            .put("guest_binary", guest.absolutePath)
    }

    private fun execute(
        id: String,
        command: List<String>,
        workingDir: File,
        logsDir: File,
        environment: Map<String, String>
    ): JSONObject {
        val startedAt = System.nanoTime()
        return try {
            val pb = ProcessBuilder(command).directory(workingDir).redirectErrorStream(false)
            pb.environment().putAll(environment)
            val process = pb.start()
            val stdoutThread = StreamCollector(process.inputStream, MAX_OUTPUT_CHARS)
            val stderrThread = StreamCollector(process.errorStream, MAX_OUTPUT_CHARS)
            stdoutThread.start(); stderrThread.start()
            val finished = process.waitFor(TIMEOUT_SECONDS, TimeUnit.SECONDS)
            if (!finished) {
                process.destroy()
                if (!process.waitFor(2, TimeUnit.SECONDS)) process.destroyForcibly()
            }
            stdoutThread.join(2_000); stderrThread.join(2_000)
            val stdout = stdoutThread.text()
            val stderr = stderrThread.text()
            val exitCode = if (finished) process.exitValue() else -1
            val elapsedMs = (System.nanoTime() - startedAt) / 1_000_000.0
            val logFile = File(logsDir, "$id.log")
            logFile.writeText(buildString {
                appendLine("COMMAND: ${command.joinToString(" ")}")
                appendLine("FINISHED: $finished")
                appendLine("EXIT_CODE: $exitCode")
                appendLine("ELAPSED_MS: $elapsedMs")
                appendLine("----- STDOUT -----"); appendLine(stdout)
                appendLine("----- STDERR -----"); appendLine(stderr)
            })
            JSONObject()
                .put("id", id)
                .put("status", if (finished && exitCode == 0) "PASS" else "FAIL")
                .put("command", JSONArray(command))
                .put("finished_before_timeout", finished)
                .put("timeout_seconds", TIMEOUT_SECONDS)
                .put("exit_code", exitCode)
                .put("elapsed_ms", elapsedMs)
                .put("stdout", stdout)
                .put("stderr", stderr)
                .put("log_path", logFile.absolutePath)
        } catch (e: Exception) {
            JSONObject()
                .put("id", id)
                .put("status", "FAIL")
                .put("command", JSONArray(command))
                .put("exception", e.javaClass.name)
                .put("message", e.message ?: "unknown")
        }
    }

    private fun buildEnvironment(components: File): Map<String, String> {
        val runtimeRoot = components.parentFile ?: components
        val prefix = File(runtimeRoot, "prefix")
        val tmp = File(runtimeRoot, "tmp")
        tmp.mkdirs(); prefix.mkdirs()
        val paths = listOf(File(components, "bin"), File(components, "wine/bin"))
            .filter { it.isDirectory }.joinToString(":") { it.absolutePath }
        val libs = listOf(
            File(components, "lib"), File(components, "lib64"),
            File(components, "wine/lib"), File(components, "wine/lib64"),
            File(components, "wine/lib/wine/x86_64-unix")
        ).filter { it.isDirectory }.joinToString(":") { it.absolutePath }
        return mapOf(
            "HOME" to File(prefix, "drive_c/users/player").absolutePath,
            "TMPDIR" to tmp.absolutePath,
            "WINEPREFIX" to prefix.absolutePath,
            "WINEARCH" to "win64",
            "WINEDEBUG" to "-all",
            "BOX64_LOG" to "1",
            "BOX64_NOBANNER" to "0",
            "PATH" to paths,
            "LD_LIBRARY_PATH" to libs
        )
    }

    private enum class LaunchMode { DIRECT, THROUGH_BOX64 }
    private data class BinaryCandidate(val id: String, val possiblePaths: List<String>, val args: List<String>, val mode: LaunchMode)
}

private class StreamCollector(
    private val input: java.io.InputStream,
    private val maxChars: Int
) : Thread() {
    private val buffer = StringBuilder()
    override fun run() {
        input.bufferedReader().useLines { lines ->
            for (line in lines) {
                if (buffer.length >= maxChars) break
                buffer.appendLine(line.take(maxChars - buffer.length))
            }
        }
    }
    fun text(): String = buffer.toString()
}
