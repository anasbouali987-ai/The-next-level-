package com.gtavmobile.runtime

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.documentfile.provider.DocumentFile
import androidx.lifecycle.lifecycleScope
import com.gtavmobile.runtime.databinding.ActivityMainBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private val report = JSONObject()
    private var selectedTreeUri: Uri? = null
    private var activeJob: Job? = null

    private val folderPicker =
        registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
            if (uri != null) {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                selectedTreeUri = uri
                binding.txtGameValue.text = DocumentFile.fromTreeUri(this, uri)?.name ?: uri.lastPathSegment
                binding.btnPreflight.isEnabled = true
                setStatus("تم اختيار مجلد اللعبة.")
            }
        }

    private val runtimePackagePicker =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) importRuntimePackage(uri)
        }

    private val diagnosticBundleLauncher =
        registerForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri ->
            if (uri != null) createDiagnosticBundle(uri)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnImportRuntime.setOnClickListener {
            runtimePackagePicker.launch(arrayOf("application/zip", "application/octet-stream"))
        }
        binding.btnRuntimeSelfTest.setOnClickListener { runRuntimeSelfTest() }
        binding.btnSelectGame.setOnClickListener { folderPicker.launch(selectedTreeUri) }
        binding.btnPreflight.setOnClickListener { runStartupPreflight() }
        binding.btnDiagnostic.setOnClickListener {
            diagnosticBundleLauncher.launch("gtav_runtime_diagnostic_v0.7.2.zip")
        }
        binding.btnCancel.setOnClickListener {
            activeJob?.cancel()
            activeJob = null
            setBusy(false, "تم إلغاء العملية من الواجهة.")
        }

        refreshRuntimeStatus()
        recoverLastImportState()
    }

    private fun importRuntimePackage(uri: Uri) {
        if (activeJob?.isActive == true) return
        setBusy(true, "بدء استيراد Runtime…")
        binding.progressImport.isIndeterminate = true

        activeJob = lifecycleScope.launch {
            try {
                val result = withContext(Dispatchers.IO) {
                    RuntimePackageManager.importPackage(this@MainActivity, uri) { progress ->
                        runOnUiThread {
                            val mib = progress.bytes / (1024L * 1024L)
                            val phase = when (progress.phase) {
                                "EXTRACTING" -> "استخراج"
                                "VALIDATING" -> "تحقق"
                                "INSTALLING" -> "تثبيت"
                                else -> progress.phase
                            }
                            setStatus("$phase — ${progress.entries} عنصر — ${mib}MB\n${progress.currentPath.takeLast(80)}")
                        }
                    }
                }

                report.put("runtime_package_import_v0_7_2", result)
                refreshRuntimeStatus()
                setBusy(
                    false,
                    if (result.optString("status") == "INSTALLED")
                        "تم تثبيت Runtime بنجاح. يمكنك الآن تشغيل الاختبار."
                    else
                        "رُفضت الحزمة. افتح حزمة التشخيص لمعرفة السبب."
                )
            } catch (t: Throwable) {
                setBusy(false, "فشل الاستيراد: ${t.message ?: t.javaClass.simpleName}")
            } finally {
                activeJob = null
            }
        }
    }

    private fun runRuntimeSelfTest() {
        if (activeJob?.isActive == true) return
        setBusy(true, "اختبار Box64 وWine…")
        activeJob = lifecycleScope.launch {
            try {
                val result = withContext(Dispatchers.IO) { RuntimeSelfTest.run(this@MainActivity) }
                report.put("runtime_self_test_v0_7_2", result)
                val summary = result.optJSONObject("summary")
                val passed = summary?.optInt("pass_count", 0) ?: 0
                val total = summary?.optInt("test_count", 0) ?: 0
                binding.txtLastResult.text = result.toString(2).take(6000)
                setBusy(false, "اكتمل الاختبار: $passed من $total نجح.")
            } catch (t: Throwable) {
                setBusy(false, "فشل اختبار Runtime: ${t.message}")
            } finally {
                activeJob = null
            }
        }
    }

    private fun runStartupPreflight() {
        val uri = selectedTreeUri ?: return
        if (activeJob?.isActive == true) return
        setBusy(true, "تحليل جاهزية الإقلاع…")
        activeJob = lifecycleScope.launch {
            try {
                val result = withContext(Dispatchers.IO) {
                    val root = DocumentFile.fromTreeUri(this@MainActivity, uri)
                        ?: error("تعذر فتح مجلد اللعبة")
                    StartupPreflightEngine(this@MainActivity, root, report) { stage ->
                        runOnUiThread { setStatus(stage) }
                    }.run()
                }
                report.put("startup_preflight_v0_7_2", result)
                binding.txtLastResult.text = result.toString(2).take(6000)
                val blockers = result.optJSONObject("summary")?.optInt("blocker_count", 0) ?: 0
                setBusy(false, "اكتمل التحليل: $blockers عائق.")
            } catch (t: Throwable) {
                setBusy(false, "فشل التحليل: ${t.message}")
            } finally {
                activeJob = null
            }
        }
    }

    private fun createDiagnosticBundle(uri: Uri) {
        if (activeJob?.isActive == true) return
        setBusy(true, "إنشاء حزمة التشخيص…")
        activeJob = lifecycleScope.launch {
            try {
                val result = withContext(Dispatchers.IO) {
                    contentResolver.openOutputStream(uri)?.use { output ->
                        DiagnosticBundleCreator.create(this@MainActivity, report, output)
                    } ?: error("تعذر فتح ملف الحفظ")
                }
                setBusy(false, "تم إنشاء حزمة التشخيص: ${result.optInt("added_file_count")} ملف.")
            } catch (t: Throwable) {
                setBusy(false, "فشل إنشاء التشخيص: ${t.message}")
            } finally {
                activeJob = null
            }
        }
    }

    private fun refreshRuntimeStatus() {
        val status = RuntimeEnvironmentBuilder.inspect(this)
        val installed = status.optBoolean("root_exists") && status.optBoolean("component_manifest_exists")
        binding.txtRuntimeValue.text = if (installed) "مثبّت" else "غير مثبّت"
        binding.btnRuntimeSelfTest.isEnabled = installed && activeJob?.isActive != true
    }

    private fun recoverLastImportState() {
        val file = File(filesDir, "runtime/import_state.json")
        if (!file.isFile) return
        runCatching { JSONObject(file.readText()) }.getOrNull()?.let { state ->
            val status = state.optString("status")
            if (status == "FAILED" || status == "REJECTED") {
                setStatus("آخر استيراد: $status — ${state.optString("detail")}")
            }
        }
    }

    private fun setBusy(busy: Boolean, message: String) {
        binding.progressImport.visibility = if (busy) View.VISIBLE else View.GONE
        binding.btnCancel.visibility = if (busy) View.VISIBLE else View.GONE
        binding.btnImportRuntime.isEnabled = !busy
        binding.btnSelectGame.isEnabled = !busy
        binding.btnPreflight.isEnabled = !busy && selectedTreeUri != null
        binding.btnDiagnostic.isEnabled = !busy
        binding.btnRuntimeSelfTest.isEnabled = !busy && binding.txtRuntimeValue.text == "مثبّت"
        setStatus(message)
    }

    private fun setStatus(message: String) {
        binding.txtStatus.text = message
    }
}
