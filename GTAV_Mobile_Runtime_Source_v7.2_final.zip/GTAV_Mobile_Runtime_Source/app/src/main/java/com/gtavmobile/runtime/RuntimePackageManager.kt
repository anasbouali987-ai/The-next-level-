package com.gtavmobile.runtime

import android.content.Context
import android.net.Uri
import android.system.Os
import android.system.OsConstants
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileOutputStream
import java.security.MessageDigest
import java.util.UUID
import java.util.zip.ZipInputStream

object RuntimePackageManager {
    private const val MAX_ENTRIES = 20_000
    private const val MAX_UNCOMPRESSED_BYTES = 2L * 1024L * 1024L * 1024L
    private const val BUFFER_SIZE = 256 * 1024

    data class Progress(
        val phase: String,
        val entries: Int,
        val bytes: Long,
        val currentPath: String
    )

    fun importPackage(
        context: Context,
        uri: Uri,
        onProgress: (Progress) -> Unit = {}
    ): JSONObject {
        val runtimeRoot = File(context.filesDir, "runtime")
        val packagesRoot = File(runtimeRoot, "packages")
        val components = File(runtimeRoot, "components")
        val staging = File(packagesRoot, "staging-${UUID.randomUUID()}")
        val previous = File(packagesRoot, "previous")
        val stateFile = File(runtimeRoot, "runtime_state.json")
        val importState = File(runtimeRoot, "import_state.json")

        packagesRoot.mkdirs()
        staging.deleteRecursively()
        staging.mkdirs()

        writeImportState(importState, "EXTRACTING", 0, 0L, "")

        var entries = 0
        var totalBytes = 0L
        val buffer = ByteArray(BUFFER_SIZE)

        try {
            val source = context.contentResolver.openInputStream(uri)
                ?: error("تعذر فتح حزمة Runtime")

            BufferedInputStream(source, BUFFER_SIZE).use { raw ->
                ZipInputStream(raw).use { zip ->
                    while (true) {
                        val entry = zip.nextEntry ?: break
                        entries++
                        if (entries > MAX_ENTRIES) error("Runtime ZIP has too many entries")

                        val target = safeTarget(staging, entry.name)
                        if (entry.isDirectory) {
                            if (!target.exists() && !target.mkdirs()) {
                                error("تعذر إنشاء المجلد: ${entry.name}")
                            }
                        } else {
                            target.parentFile?.mkdirs()
                            BufferedOutputStream(FileOutputStream(target), BUFFER_SIZE).use { output ->
                                while (true) {
                                    val count = zip.read(buffer)
                                    if (count <= 0) break
                                    totalBytes += count
                                    if (totalBytes > MAX_UNCOMPRESSED_BYTES) {
                                        error("Runtime ZIP exceeds size limit")
                                    }
                                    output.write(buffer, 0, count)
                                }
                            }
                        }
                        zip.closeEntry()

                        if (entries == 1 || entries % 20 == 0) {
                            writeImportState(importState, "EXTRACTING", entries, totalBytes, entry.name)
                            onProgress(Progress("EXTRACTING", entries, totalBytes, entry.name))
                        }
                    }
                }
            }

            onProgress(Progress("VALIDATING", entries, totalBytes, "runtime_manifest.json"))
            writeImportState(importState, "VALIDATING", entries, totalBytes, "runtime_manifest.json")

            val manifestFile = findManifest(staging)
                ?: error("runtime_manifest.json was not found")
            val manifest = JSONObject(manifestFile.readText(Charsets.UTF_8))
            val validation = validateManifest(staging, manifest) { index, path ->
                if (index == 1 || index % 10 == 0) {
                    onProgress(Progress("VALIDATING", index, totalBytes, path))
                    writeImportState(importState, "VALIDATING", index, totalBytes, path)
                }
            }

            if (!validation.getBoolean("valid")) {
                staging.deleteRecursively()
                writeImportState(importState, "REJECTED", entries, totalBytes, "")
                return JSONObject()
                    .put("status", "REJECTED")
                    .put("reason", "manifest_validation_failed")
                    .put("entries", entries)
                    .put("total_uncompressed_bytes", totalBytes)
                    .put("validation", validation)
            }

            onProgress(Progress("PERMISSIONS", entries, totalBytes, ""))
            writeImportState(importState, "PERMISSIONS", entries, totalBytes, "")
            val permissions = applyManifestPermissions(staging, manifest)
            if (!permissions.getBoolean("valid")) {
                staging.deleteRecursively()
                writeImportState(importState, "REJECTED", entries, totalBytes, "permissions")
                return JSONObject()
                    .put("status", "REJECTED")
                    .put("reason", "executable_permissions_failed")
                    .put("entries", entries)
                    .put("total_uncompressed_bytes", totalBytes)
                    .put("permissions", permissions)
            }

            onProgress(Progress("INSTALLING", entries, totalBytes, ""))
            writeImportState(importState, "INSTALLING", entries, totalBytes, "")

            previous.deleteRecursively()
            if (components.exists() && !components.renameTo(previous)) {
                error("تعذر تأمين النسخة السابقة من Runtime")
            }

            if (!staging.renameTo(components)) {
                if (previous.exists()) previous.renameTo(components)
                error("تعذر تثبيت Runtime ذرّيًا")
            }
            previous.deleteRecursively()

            val state = JSONObject()
                .put("runtime_components_installed", true)
                .put("installed_runtime_id", manifest.optString("runtime_id"))
                .put("installed_runtime_version", manifest.optString("version"))
                .put("ready_for_binary_self_test", true)
                .put("ready_for_gtav", false)
                .put("installed_at_epoch_ms", System.currentTimeMillis())
                .put("installed_entry_count", entries)
                .put("installed_uncompressed_bytes", totalBytes)

            stateFile.parentFile?.mkdirs()
            stateFile.writeText(state.toString(2), Charsets.UTF_8)
            writeImportState(importState, "INSTALLED", entries, totalBytes, "")

            return JSONObject()
                .put("status", "INSTALLED")
                .put("entries", entries)
                .put("total_uncompressed_bytes", totalBytes)
                .put("runtime_id", manifest.optString("runtime_id"))
                .put("runtime_version", manifest.optString("version"))
                .put("verified_file_count", validation.optInt("verified_file_count"))
                .put("executable_file_count", permissions.optInt("executable_file_count"))
                .put("components_path", components.absolutePath)
                .put("runtime_state", state)
        } catch (t: Throwable) {
            staging.deleteRecursively()
            writeImportState(importState, "FAILED", entries, totalBytes, t.message.orEmpty())
            throw t
        }
    }

    fun repairInstalledPermissions(context: Context): JSONObject {
        val components = File(context.filesDir, "runtime/components")
        if (!components.isDirectory) {
            return JSONObject()
                .put("valid", false)
                .put("reason", "runtime_not_installed")
        }
        val manifestFile = findManifest(components)
            ?: return JSONObject()
                .put("valid", false)
                .put("reason", "runtime_manifest_missing")
        return applyManifestPermissions(
            components,
            JSONObject(manifestFile.readText(Charsets.UTF_8))
        )
    }

    private fun applyManifestPermissions(root: File, manifest: JSONObject): JSONObject {
        val errors = JSONArray()
        val files = manifest.optJSONArray("files")
        var executableCount = 0
        var repairedCount = 0

        // Directories need search permission before binaries beneath them can execute.
        root.walkTopDown()
            .filter { it.isDirectory }
            .forEach { directory ->
                runCatching { Os.chmod(directory.absolutePath, 0x1ED) } // 0755
                    .onFailure { errors.put("chmod_directory_failed:${directory.relativeTo(root).path}:${it.message}") }
            }

        if (files != null) {
            for (i in 0 until files.length()) {
                val item = files.optJSONObject(i) ?: continue
                if (!item.optBoolean("executable", false)) continue

                executableCount++
                val path = item.optString("path")
                val file = try {
                    safeTarget(root, path)
                } catch (_: Throwable) {
                    errors.put("unsafe_executable_path:$path")
                    continue
                }

                if (!file.isFile) {
                    errors.put("missing_executable:$path")
                    continue
                }

                val changed = runCatching {
                    Os.chmod(
                        file.absolutePath,
                        OsConstants.S_IRUSR or OsConstants.S_IWUSR or OsConstants.S_IXUSR or
                            OsConstants.S_IRGRP or OsConstants.S_IXGRP or
                            OsConstants.S_IROTH or OsConstants.S_IXOTH
                    )
                    file.canExecute()
                }.getOrElse {
                    errors.put("chmod_failed:$path:${it.message}")
                    false
                }

                if (changed) repairedCount++ else errors.put("not_executable_after_chmod:$path")
            }
        }

        return JSONObject()
            .put("valid", errors.length() == 0)
            .put("errors", errors)
            .put("executable_file_count", executableCount)
            .put("repaired_file_count", repairedCount)
    }

    private fun validateManifest(
        root: File,
        manifest: JSONObject,
        onFile: (Int, String) -> Unit
    ): JSONObject {
        val errors = JSONArray()
        var verifiedCount = 0

        val runtimeId = manifest.optString("runtime_id")
        val version = manifest.optString("version")
        val architecture = manifest.optString("architecture")
        val licenseFiles = manifest.optJSONArray("license_files")
        val files = manifest.optJSONArray("files")

        if (runtimeId.isBlank()) errors.put("runtime_id_missing")
        if (version.isBlank()) errors.put("version_missing")
        if (architecture != "arm64-v8a") errors.put("architecture_must_be_arm64-v8a")
        if (licenseFiles == null || licenseFiles.length() == 0) errors.put("license_files_missing")
        if (files == null || files.length() == 0) errors.put("files_manifest_missing")

        if (licenseFiles != null) {
            for (i in 0 until licenseFiles.length()) {
                val path = licenseFiles.optString(i)
                if (!safeTarget(root, path).isFile) errors.put("missing_license:$path")
            }
        }

        val logicalComponents = mutableSetOf<String>()
        if (files != null) {
            for (i in 0 until files.length()) {
                val item = files.optJSONObject(i) ?: continue
                val path = item.optString("path")
                val expectedSha = item.optString("sha256").lowercase()
                val required = item.optBoolean("required", true)
                val file = safeTarget(root, path)
                item.optString("component").takeIf { it.isNotBlank() }?.let(logicalComponents::add)
                onFile(i + 1, path)

                if (!file.isFile) {
                    if (required) errors.put("missing_file:$path")
                    continue
                }
                val actualSha = sha256(file)
                if (expectedSha.isBlank() || actualSha != expectedSha) {
                    errors.put("sha256_mismatch:$path")
                } else {
                    verifiedCount++
                }
            }
        }

        setOf("box64", "wine64", "wineserver", "wineboot").forEach {
            if (!logicalComponents.contains(it)) errors.put("required_component_missing:$it")
        }

        return JSONObject()
            .put("valid", errors.length() == 0)
            .put("errors", errors)
            .put("verified_file_count", verifiedCount)
    }

    private fun writeImportState(file: File, status: String, entries: Int, bytes: Long, detail: String) {
        runCatching {
            file.parentFile?.mkdirs()
            val temp = File(file.parentFile, file.name + ".tmp")
            temp.writeText(
                JSONObject()
                    .put("status", status)
                    .put("entries", entries)
                    .put("bytes", bytes)
                    .put("detail", detail)
                    .put("updated_at_epoch_ms", System.currentTimeMillis())
                    .toString(2),
                Charsets.UTF_8
            )
            if (file.exists()) file.delete()
            temp.renameTo(file)
        }
    }

    private fun findManifest(root: File): File? =
        root.walkTopDown().firstOrNull { it.isFile && it.name == "runtime_manifest.json" }

    private fun safeTarget(root: File, relative: String): File {
        val normalized = relative.replace('\\', '/').removePrefix("/")
        val target = File(root, normalized)
        val rootCanonical = root.canonicalFile
        val targetCanonical = target.canonicalFile
        if (targetCanonical.path != rootCanonical.path &&
            !targetCanonical.path.startsWith(rootCanonical.path + File.separator)
        ) error("Unsafe ZIP path: $relative")
        return targetCanonical
    }

    private fun sha256(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        file.inputStream().buffered(BUFFER_SIZE).use { input ->
            val buffer = ByteArray(BUFFER_SIZE)
            while (true) {
                val count = input.read(buffer)
                if (count <= 0) break
                digest.update(buffer, 0, count)
            }
        }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }
}
