package com.gtavmobile.runtime

import android.content.Context
import androidx.documentfile.provider.DocumentFile
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

class StartupPreflightEngine(
    private val context: Context,
    private val root: DocumentFile,
    private val existingReport: JSONObject,
    private val progress: (String) -> Unit
) {
    private val criticalNames = listOf(
        "GTA5.exe",
        "xinput1_3.dll",
        "bink2w64.dll",
        "socialclub.dll",
        "launc.dll",
        "asiloader.dll",
        "D3DCompiler_43.dll",
        "d3dcompiler_46.dll",
        "d3d11.dll",
        "dxgi.dll"
    )

    fun run(): JSONObject {
        val stages = JSONArray()
        val peReports = JSONArray()
        val warnings = JSONArray()
        val blockers = JSONArray()

        progress("STAGE 01 — التحقق من الهاتف")
        stage(
            stages,
            "DEVICE_PROFILE",
            existingReport.has("device"),
            "تم العثور على ملف الجهاز."
        )

        progress("STAGE 02 — التحقق من اللعبة")
        val gta5 = findByName(root, "GTA5.exe")
        val gtaVerified = existingReport
            .optJSONObject("game_quick_check")
            ?.optBoolean("matches_expected", false) == true
        stage(
            stages,
            "GTA5_IDENTITY",
            gta5 != null && gtaVerified,
            if (gta5 != null && gtaVerified)
                "GTA5.exe مطابق للبصمة المعتمدة."
            else "GTA5.exe غير مفقود أو لم يتم توثيق مطابقته."
        )
        if (gta5 == null || !gtaVerified) blockers.put("GTA5_EXECUTABLE_NOT_VERIFIED")

        progress("STAGE 03 — تحليل ملفات PE")
        for (name in criticalNames) {
            val file = findByName(root, name)
            if (file == null) {
                warnings.put("MISSING_$name")
                continue
            }
            peReports.put(PeInspector.inspect(context, file))
        }
        stage(
            stages,
            "PE_ANALYSIS",
            peReports.length() > 0,
            "تم تحليل ${peReports.length()} ملف Windows."
        )

        progress("STAGE 04 — فحص المعمارية")
        val gtaPe = findPe(peReports, "GTA5.exe")
        val architectureOk = gtaPe?.optString("architecture") == "x86-64"
        stage(
            stages,
            "ARCHITECTURE",
            architectureOk,
            if (architectureOk)
                "GTA5.exe x86-64؛ يتطلب Box64 وWine64."
            else "تعذر تأكيد x86-64."
        )
        if (!architectureOk) blockers.put("UNSUPPORTED_OR_UNKNOWN_EXECUTABLE_ARCHITECTURE")

        progress("STAGE 05 — فحص XInput")
        val xinput = findPe(peReports, "xinput1_3.dll")
        val xinputExports = xinput?.optJSONArray("exports")
        val hasOrdinal2 = containsOrdinal(xinputExports, 2)
        val hasOrdinal3 = containsOrdinal(xinputExports, 3)
        val xinputOk = xinput != null && hasOrdinal2 && hasOrdinal3
        stage(
            stages,
            "XINPUT_EXPORTS",
            xinputOk,
            if (xinputOk)
                "xinput1_3.dll يصدّر Ordinal 2 و3."
            else "ملف XInput يحتاج builtin fallback أو DLL بديل."
        )
        if (!xinputOk) warnings.put("PACKAGE_XINPUT_INCOMPLETE_USE_WINE_BUILTIN_FIRST")

        progress("STAGE 06 — فحص Bink/Media")
        val bink = findPe(peReports, "bink2w64.dll")
        val binkOk = bink?.optString("status") == "OK"
        stage(
            stages,
            "BINK_MEDIA",
            binkOk,
            if (binkOk) "bink2w64.dll صالح بنيويًا." else "تعذر تأكيد Bink."
        )
        if (!binkOk) warnings.put("BINK_MEDIA_COMPONENT_UNVERIFIED")

        progress("STAGE 07 — فحص DXVK")
        val d3d11 = findByPathSuffix(root, "dxvk/d3d11.dll")
        val dxgi = findByPathSuffix(root, "dxvk/dxgi.dll")
        val dxvkConf = findByName(root, "dxvk.conf")
        val dxvkReady = d3d11 != null && dxgi != null
        stage(
            stages,
            "DXVK_PACKAGE",
            dxvkReady,
            if (dxvkReady)
                "ملفا d3d11.dll وdxgi.dll موجودان في مجلد dxvk."
            else "طبقة DXVK غير مكتملة."
        )
        if (!dxvkReady) blockers.put("DXVK_PACKAGE_INCOMPLETE")

        progress("STAGE 08 — فحص ملفات البيانات")
        val packageSummary = existingReport
            .optJSONObject("game_package_v0_2")
            ?.optJSONObject("summary")
        val fileCount = packageSummary?.optInt("file_count", 0) ?: 0
        val packageKnown = fileCount > 0
        stage(
            stages,
            "GAME_DATA_MANIFEST",
            packageKnown,
            if (packageKnown) "تمت فهرسة $fileCount ملف." else "Manifest اللعبة غير متوفر."
        )
        if (!packageKnown) blockers.put("GAME_PACKAGE_MANIFEST_MISSING")

        val x64w = findByName(root, "x64w.rpf")
        if (x64w != null && x64w.length() <= 512L) {
            warnings.put("X64W_RPF_PLACEHOLDER_${x64w.length()}_BYTES")
        }

        progress("STAGE 09 — فحص ASI")
        val asiFiles = listOf(
            "OpenIV.asi",
            "savepath.asi",
            "skipintro.asi",
            "optiprojects.asi"
        )
        val asiPresent = JSONArray()
        asiFiles.forEach { name ->
            findByName(root, name)?.let { asiPresent.put(name) }
        }
        stage(
            stages,
            "ASI_LAYER",
            true,
            "تم اكتشاف ${asiPresent.length()} إضافات ASI؛ تُعطل في Safe Profile أولًا.",
            "WARN"
        )
        if (asiPresent.length() > 0) warnings.put("ASI_SAFE_PROFILE_REQUIRED")

        progress("STAGE 10 — فحص التفعيل")
        val socialClubPresent = findByName(root, "socialclub.dll") != null
        val launcherPresent =
            findByName(root, "GTAVLauncher.exe") != null ||
            findByName(root, "PlayGTAV.exe") != null
        stage(
            stages,
            "LEGAL_ENTITLEMENT_PATH",
            launcherPresent,
            if (launcherPresent)
                "مسار Launcher موجود ويجب استخدام ترخيص قانوني."
            else "لم يُعثر على Launcher رسمي كامل؛ لا يمكن تنفيذ التفعيل القانوني حاليًا.",
            if (launcherPresent) "PASS" else "BLOCKED"
        )
        if (!launcherPresent) blockers.put("OFFICIAL_LAUNCHER_ENTITLEMENT_PATH_MISSING")
        if (socialClubPresent) warnings.put("PACKAGE_SOCIALCLUB_DLL_PRESENT_BUT_UNTRUSTED")

        progress("STAGE 11 — فحص Runtime")
        val runtimeManifest = findByName(root, "gtav_runtime_components.json")
        val runtimeReady = runtimeManifest != null
        stage(
            stages,
            "WINDOWS_RUNTIME",
            runtimeReady,
            if (runtimeReady)
                "تم العثور على runtime component manifest."
            else "Wine/Box64 runtime غير مضمّن بعد؛ التشغيل الحقيقي غير ممكن في V4.",
            if (runtimeReady) "PASS" else "BLOCKED"
        )
        if (!runtimeReady) blockers.put("WINE_BOX64_RUNTIME_NOT_INSTALLED")

        val launchPlan = JSONObject()
            .put("profile_id", "GTAV_4631_REDMAGIC10S_SAFE_BOOT_001")
            .put("target_resolution", "960x540")
            .put("target_refresh_rate", 60)
            .put("target_fps", 30)
            .put("wine_arch", "win64")
            .put("cpu_translation", "box64")
            .put("graphics_primary", "dxvk")
            .put("xinput_policy", if (xinputOk) "package_candidate_then_builtin_compare" else "wine_builtin")
            .put("asi_policy", "disabled_first_boot")
            .put("save_policy", "empty_profile_first")
            .put("game_data_policy", "read_only")
            .put("runtime_storage", "app_private")
            .put("activation_policy", "official_licensed_launcher_only")
            .put("ready_to_execute", blockers.length() == 0)

        return JSONObject()
            .put("engine", "Startup Preflight Engine v0.4")
            .put("stages", stages)
            .put("pe_reports", peReports)
            .put("warnings", warnings)
            .put("blockers", blockers)
            .put("launch_plan", launchPlan)
            .put(
                "summary",
                JSONObject()
                    .put("stage_count", stages.length())
                    .put("warning_count", warnings.length())
                    .put("blocker_count", blockers.length())
                    .put("ready_to_execute", blockers.length() == 0)
            )
    }

    private fun stage(
        stages: JSONArray,
        id: String,
        ok: Boolean,
        message: String,
        forcedStatus: String? = null
    ) {
        stages.put(
            JSONObject()
                .put("id", id)
                .put("status", forcedStatus ?: if (ok) "PASS" else "BLOCKED")
                .put("message", message)
        )
    }

    private fun findPe(array: JSONArray, name: String): JSONObject? {
        for (i in 0 until array.length()) {
            val item = array.optJSONObject(i) ?: continue
            if (item.optString("name").equals(name, ignoreCase = true)) return item
        }
        return null
    }

    private fun containsOrdinal(array: JSONArray?, ordinal: Int): Boolean {
        if (array == null) return false
        for (i in 0 until array.length()) {
            val item = array.optJSONObject(i) ?: continue
            if (item.optLong("ordinal", -1) == ordinal.toLong()) return true
        }
        return false
    }

    private fun findByName(node: DocumentFile, target: String): DocumentFile? {
        node.listFiles().forEach { child ->
            if (child.isFile && child.name.equals(target, ignoreCase = true)) return child
        }
        node.listFiles().filter { it.isDirectory }.forEach { dir ->
            findByName(dir, target)?.let { return it }
        }
        return null
    }

    private fun findByPathSuffix(node: DocumentFile, suffix: String): DocumentFile? {
        fun walk(current: DocumentFile, path: String): DocumentFile? {
            current.listFiles().forEach { child ->
                val childPath = if (path.isEmpty()) {
                    child.name.orEmpty()
                } else {
                    "$path/${child.name.orEmpty()}"
                }

                if (child.isFile && childPath.lowercase(Locale.ROOT)
                        .endsWith(suffix.lowercase(Locale.ROOT))) {
                    return child
                }

                if (child.isDirectory) {
                    walk(child, childPath)?.let { return it }
                }
            }
            return null
        }
        return walk(node, "")
    }
}
