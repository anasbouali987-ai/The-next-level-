package com.gtavmobile.runtime

import android.content.Context
import org.json.JSONObject
import java.io.File
import java.io.OutputStream
import java.security.MessageDigest
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

object DiagnosticBundleCreator {
    private const val MAX_LOG_FILE_BYTES = 5L * 1024L * 1024L
    private const val MAX_TOTAL_LOG_BYTES = 50L * 1024L * 1024L

    fun create(
        context: Context,
        report: JSONObject,
        output: OutputStream
    ): JSONObject {
        val runtimeRoot = File(context.filesDir, "runtime")
        var addedFiles = 0
        var skippedFiles = 0
        var totalBytes = 0L
        val digest = MessageDigest.getInstance("SHA-256")

        val digestingOutput = object : java.io.FilterOutputStream(output) {
            override fun write(b: Int) {
                out.write(b)
                digest.update(b.toByte())
            }

            override fun write(b: ByteArray, off: Int, len: Int) {
                out.write(b, off, len)
                digest.update(b, off, len)
            }
        }

        ZipOutputStream(digestingOutput.buffered(1024 * 1024)).use { zip ->
            val reportBytes = report.toString(2).toByteArray(Charsets.UTF_8)
            zip.putNextEntry(ZipEntry("gtav_runtime_report_v0.6.json"))
            zip.write(reportBytes)
            zip.closeEntry()
            totalBytes += reportBytes.size
            addedFiles++

            val metadata = JSONObject()
                .put("bundle_version", 1)
                .put("app_version", BuildConfig.VERSION_NAME)
                .put("runtime_root", runtimeRoot.absolutePath)
                .put("contains_game_files", false)
                .put("contains_account_credentials", false)
                .put("note", "Bundle contains application reports, runtime state, manifests and logs only.")

            val metadataBytes = metadata.toString(2).toByteArray(Charsets.UTF_8)
            zip.putNextEntry(ZipEntry("bundle_metadata.json"))
            zip.write(metadataBytes)
            zip.closeEntry()
            totalBytes += metadataBytes.size
            addedFiles++

            val candidates = listOf(
                File(runtimeRoot, "runtime_state.json"),
                File(runtimeRoot, "components/runtime_manifest.json"),
                File(runtimeRoot, "profiles/gtav_4631_safe.json"),
                File(runtimeRoot, "prefix/system.reg"),
                File(runtimeRoot, "prefix/user.reg"),
                File(runtimeRoot, "prefix/userdef.reg")
            )

            candidates.filter { it.isFile }.forEach { file ->
                val size = file.length()
                if (size > MAX_LOG_FILE_BYTES || totalBytes + size > MAX_TOTAL_LOG_BYTES) {
                    skippedFiles++
                } else {
                    addFile(
                        zip,
                        file,
                        "runtime/${file.relativeTo(runtimeRoot).path.replace('\\', '/')}"
                    )
                    totalBytes += size
                    addedFiles++
                }
            }

            val logsDir = File(runtimeRoot, "logs")
            if (logsDir.isDirectory) {
                logsDir.walkTopDown()
                    .filter { it.isFile }
                    .forEach { file ->
                        val size = file.length()
                        if (
                            size > MAX_LOG_FILE_BYTES ||
                            totalBytes + size > MAX_TOTAL_LOG_BYTES
                        ) {
                            skippedFiles++
                        } else {
                            addFile(
                                zip,
                                file,
                                "runtime/logs/${file.relativeTo(logsDir).path.replace('\\', '/')}"
                            )
                            totalBytes += size
                            addedFiles++
                        }
                    }
            }
        }

        return JSONObject()
            .put("creator", "Diagnostic Bundle Creator v0.6")
            .put("added_file_count", addedFiles)
            .put("skipped_file_count", skippedFiles)
            .put("uncompressed_source_bytes", totalBytes)
            .put("sha256", digest.digest().joinToString("") { "%02x".format(it) })
            .put("contains_game_files", false)
            .put("contains_credentials", false)
    }

    private fun addFile(
        zip: ZipOutputStream,
        file: File,
        entryName: String
    ) {
        zip.putNextEntry(ZipEntry(entryName))
        file.inputStream().buffered(1024 * 1024).use { input ->
            input.copyTo(zip, 1024 * 1024)
        }
        zip.closeEntry()
    }
}
