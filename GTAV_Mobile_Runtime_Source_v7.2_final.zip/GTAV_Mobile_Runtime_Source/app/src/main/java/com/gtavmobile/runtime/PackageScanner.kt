package com.gtavmobile.runtime

import android.content.Context
import androidx.documentfile.provider.DocumentFile
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedInputStream
import java.security.MessageDigest
import java.util.Locale

class PackageScanner(
    private val context: Context,
    private val root: DocumentFile,
    private val progress: (Int, String) -> Unit
) {
    private var fileCount = 0
    private var directoryCount = 0
    private var totalBytes = 0L
    private var zeroByteFiles = 0
    private var truncated = false

    private val allFiles = JSONArray()
    private val criticalFiles = JSONArray()
    private val rpfFiles = JSONArray()
    private val binaryFiles = JSONArray()
    private val textFiles = JSONArray()
    private val duplicateNames = mutableMapOf<String, MutableList<String>>()

    private val maxItems = 20_000
    private val textLimit = 256 * 1024
    private val hashLimit = 64L * 1024L * 1024L

    private val textTargets = setOf(
        "commandline.txt",
        "commandline_superoptimizado.txt",
        "dxvk.conf",
        "settings.xml",
        "settings_ultra.xml",
        "openiv.log",
        "version.txt",
        "launcher.log",
        "gta5_d3d9.log",
        "gta5_d3d11.log",
        "gta5_dxgi.log"
    )

    private val criticalNames = setOf(
        "gta5.exe",
        "xinput1_3.dll",
        "bink2w64.dll",
        "socialclub.dll",
        "launc.dll",
        "asiloader.dll",
        "openiv.asi",
        "savepath.asi",
        "skipintro.asi",
        "optiprojects.asi",
        "d3d11.dll",
        "dxgi.dll",
        "update.rpf",
        "x64w.rpf"
    )

    fun scan(): JSONObject {
        walk(root, "", 0)

        val duplicates = JSONArray()
        duplicateNames
            .filterValues { it.size > 1 }
            .toSortedMap()
            .forEach { (name, paths) ->
                duplicates.put(JSONObject()
                    .put("name", name)
                    .put("paths", JSONArray(paths)))
            }

        val summary = JSONObject()
            .put("root_name", root.name)
            .put("file_count", fileCount)
            .put("directory_count", directoryCount)
            .put("total_bytes", totalBytes)
            .put("zero_byte_files", zeroByteFiles)
            .put("truncated", truncated)
            .put("scan_item_limit", maxItems)
            .put("critical_file_count", criticalFiles.length())
            .put("rpf_file_count", rpfFiles.length())
            .put("binary_file_count", binaryFiles.length())
            .put("text_file_count", textFiles.length())

        return JSONObject()
            .put("schema_version", 2)
            .put("scanner", "GTAV Package Inspector v0.2")
            .put("summary", summary)
            .put("file_count", fileCount)
            .put("directory_count", directoryCount)
            .put("critical_files", criticalFiles)
            .put("rpf_files", rpfFiles)
            .put("binary_files", binaryFiles)
            .put("text_previews", textFiles)
            .put("duplicate_names", duplicates)
            .put("all_files", allFiles)
    }

    private fun walk(node: DocumentFile, relativePath: String, depth: Int) {
        if (fileCount + directoryCount >= maxItems) {
            truncated = true
            return
        }

        val children = runCatching { node.listFiles().toList() }.getOrDefault(emptyList())
            .sortedWith(compareBy({ !it.isDirectory }, { it.name?.lowercase(Locale.ROOT) ?: "" }))

        for (child in children) {
            if (fileCount + directoryCount >= maxItems) {
                truncated = true
                return
            }

            val name = child.name ?: "(unnamed)"
            val path = if (relativePath.isEmpty()) name else "$relativePath/$name"

            if (child.isDirectory) {
                directoryCount++
                progress(fileCount + directoryCount, path)
                walk(child, path, depth + 1)
                continue
            }

            if (!child.isFile) continue
            fileCount++
            val size = child.length()
            totalBytes += size
            if (size == 0L) zeroByteFiles++
            progress(fileCount + directoryCount, path)

            val lower = name.lowercase(Locale.ROOT)
            duplicateNames.getOrPut(lower) { mutableListOf() }.add(path)

            val ext = lower.substringAfterLast('.', "")
            val category = classify(ext, lower)
            val base = JSONObject()
                .put("path", path)
                .put("name", name)
                .put("size_bytes", size)
                .put("last_modified", child.lastModified())
                .put("mime_type", child.type)
                .put("extension", ext)
                .put("category", category)
                .put("zero_bytes", size == 0L)

            allFiles.put(base)

            if (ext == "rpf") {
                rpfFiles.put(JSONObject(base.toString()))
            }

            if (ext in setOf("dll", "exe", "asi")) {
                val binary = JSONObject(base.toString())
                if (size in 1..hashLimit || lower in criticalNames) {
                    binary.put("sha256", safeSha256(child))
                } else {
                    binary.put("sha256", JSONObject.NULL)
                    binary.put("hash_skipped_reason", "file_larger_than_64MiB")
                }
                binaryFiles.put(binary)
            }

            if (lower in criticalNames) {
                val critical = JSONObject(base.toString())
                if (size in 1..hashLimit) {
                    critical.put("sha256", safeSha256(child))
                } else {
                    critical.put("sha256", JSONObject.NULL)
                    critical.put("hash_skipped_reason", "large_file_metadata_only")
                }
                criticalFiles.put(critical)
            }

            if (lower in textTargets || ext in setOf("txt", "xml", "conf", "log")) {
                val preview = JSONObject(base.toString())
                preview.put("text", safeReadText(child))
                preview.put("preview_limit_bytes", textLimit)
                textFiles.put(preview)
            }
        }
    }

    private fun classify(ext: String, lowerName: String): String = when {
        ext == "rpf" -> "RPF_ARCHIVE"
        ext == "dll" -> "WINDOWS_DLL"
        ext == "exe" -> "WINDOWS_EXECUTABLE"
        ext == "asi" -> "ASI_PLUGIN"
        ext in setOf("txt", "xml", "conf", "log") -> "TEXT_CONFIGURATION"
        lowerName.startsWith("sgta") -> "SAVE_FILE"
        else -> "OTHER"
    }

    private fun safeSha256(file: DocumentFile): Any = try {
        val digest = MessageDigest.getInstance("SHA-256")
        context.contentResolver.openInputStream(file.uri)?.use { raw ->
            BufferedInputStream(raw, 1024 * 1024).use { input ->
                val buffer = ByteArray(1024 * 1024)
                while (true) {
                    val count = input.read(buffer)
                    if (count <= 0) break
                    digest.update(buffer, 0, count)
                }
            }
        } ?: error("open failed")
        digest.digest().joinToString("") { "%02x".format(it) }
    } catch (e: Exception) {
        JSONObject().put("error", e.message ?: e.javaClass.simpleName)
    }

    private fun safeReadText(file: DocumentFile): Any = try {
        context.contentResolver.openInputStream(file.uri)?.use { input ->
            val bytes = input.readNBytes(textLimit)
            String(bytes, Charsets.UTF_8)
                .replace("\u0000", "")
        } ?: ""
    } catch (e: Exception) {
        JSONObject().put("error", e.message ?: e.javaClass.simpleName)
    }
}
