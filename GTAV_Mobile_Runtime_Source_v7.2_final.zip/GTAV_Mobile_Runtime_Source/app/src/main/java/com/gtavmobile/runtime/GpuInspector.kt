package com.gtavmobile.runtime

import android.app.Activity
import android.content.pm.PackageManager
import android.opengl.EGL14
import android.opengl.EGLConfig
import android.opengl.GLES20
import android.os.Build
import org.json.JSONArray
import org.json.JSONObject

object GpuInspector {
    private const val FEATURE_VULKAN_LEVEL = "android.hardware.vulkan.level"
    private const val FEATURE_VULKAN_VERSION = "android.hardware.vulkan.version"
    private const val FEATURE_VULKAN_COMPUTE = "android.hardware.vulkan.compute"

    fun inspect(activity: Activity): JSONObject {
        return JSONObject()
            .put("android_declared_features", declaredFeatures(activity.packageManager))
            .put("display", inspectDisplay(activity))
            .put("egl_gl", inspectEgl())
    }

    private fun declaredFeatures(pm: PackageManager): JSONObject {
        val features = JSONArray()
        var encodedGles = 0

        pm.systemAvailableFeatures
            .sortedBy { it.name ?: "" }
            .forEach { feature ->
                if (feature.reqGlEsVersion != 0) {
                    encodedGles = maxOf(encodedGles, feature.reqGlEsVersion)
                }

                val name = feature.name ?: return@forEach
                if (
                    name.contains("vulkan", ignoreCase = true) ||
                    name.contains("opengles", ignoreCase = true) ||
                    name.contains("graphics", ignoreCase = true)
                ) {
                    features.put(
                        JSONObject()
                            .put("name", name)
                            .put("version", feature.version)
                            .put("required_gl_es_version", feature.reqGlEsVersion)
                    )
                }
            }

        return JSONObject()
            .put("gles_version_encoded", encodedGles)
            .put("features", features)
            .put("vulkan_level_0", pm.hasSystemFeature(FEATURE_VULKAN_LEVEL, 0))
            .put("vulkan_level_1", pm.hasSystemFeature(FEATURE_VULKAN_LEVEL, 1))
            .put("vulkan_version_1_0", pm.hasSystemFeature(FEATURE_VULKAN_VERSION, 0x00400000))
            .put("vulkan_compute_feature", pm.hasSystemFeature(FEATURE_VULKAN_COMPUTE))
    }

    private fun inspectDisplay(activity: Activity): JSONObject {
        val display = if (Build.VERSION.SDK_INT >= 30) {
            activity.display
        } else {
            @Suppress("DEPRECATION")
            activity.windowManager.defaultDisplay
        }

        if (display == null) {
            return JSONObject().put("error", "Display unavailable")
        }

        val modes = JSONArray()
        display.supportedModes.forEach { mode ->
            modes.put(
                JSONObject()
                    .put("mode_id", mode.modeId)
                    .put("width", mode.physicalWidth)
                    .put("height", mode.physicalHeight)
                    .put("refresh_rate", mode.refreshRate)
            )
        }

        val hdrTypes = JSONArray()
        if (Build.VERSION.SDK_INT >= 24) {
            display.hdrCapabilities.supportedHdrTypes.forEach { hdrTypes.put(it) }
        }

        return JSONObject()
            .put("current_refresh_rate", display.refreshRate)
            .put("current_mode_id", display.mode.modeId)
            .put("supported_modes", modes)
            .put("hdr_capabilities", hdrTypes)
    }

    private fun inspectEgl(): JSONObject {
        val eglDisplay = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY)
        if (eglDisplay == EGL14.EGL_NO_DISPLAY) {
            return JSONObject().put("error", "EGL_NO_DISPLAY")
        }

        val major = IntArray(1)
        val minor = IntArray(1)
        if (!EGL14.eglInitialize(eglDisplay, major, 0, minor, 0)) {
            return JSONObject().put("error", "eglInitialize failed")
        }

        var surface = EGL14.EGL_NO_SURFACE
        var context = EGL14.EGL_NO_CONTEXT

        try {
            val configAttributes = intArrayOf(
                EGL14.EGL_RENDERABLE_TYPE, 0x0040, // EGL_OPENGL_ES3_BIT_KHR
                EGL14.EGL_RED_SIZE, 8,
                EGL14.EGL_GREEN_SIZE, 8,
                EGL14.EGL_BLUE_SIZE, 8,
                EGL14.EGL_ALPHA_SIZE, 8,
                EGL14.EGL_NONE
            )

            val configs = arrayOfNulls<EGLConfig>(1)
            val configCount = IntArray(1)

            val configFound = EGL14.eglChooseConfig(
                eglDisplay,
                configAttributes,
                0,
                configs,
                0,
                configs.size,
                configCount,
                0
            )

            val config = configs.firstOrNull()
            if (!configFound || configCount[0] == 0 || config == null) {
                return JSONObject()
                    .put("egl_major", major[0])
                    .put("egl_minor", minor[0])
                    .put("error", "No OpenGL ES 3 EGL config")
            }

            context = EGL14.eglCreateContext(
                eglDisplay,
                config,
                EGL14.EGL_NO_CONTEXT,
                intArrayOf(
                    EGL14.EGL_CONTEXT_CLIENT_VERSION, 3,
                    EGL14.EGL_NONE
                ),
                0
            )

            if (context == EGL14.EGL_NO_CONTEXT) {
                return JSONObject().put("error", "eglCreateContext failed")
            }

            surface = EGL14.eglCreatePbufferSurface(
                eglDisplay,
                config,
                intArrayOf(
                    EGL14.EGL_WIDTH, 1,
                    EGL14.EGL_HEIGHT, 1,
                    EGL14.EGL_NONE
                ),
                0
            )

            if (surface == EGL14.EGL_NO_SURFACE) {
                return JSONObject().put("error", "eglCreatePbufferSurface failed")
            }

            if (!EGL14.eglMakeCurrent(eglDisplay, surface, surface, context)) {
                return JSONObject().put("error", "eglMakeCurrent failed")
            }

            val glExtensions = splitExtensions(
                GLES20.glGetString(GLES20.GL_EXTENSIONS)
            )
            val eglExtensions = splitExtensions(
                EGL14.eglQueryString(eglDisplay, EGL14.EGL_EXTENSIONS)
            )

            return JSONObject()
                .put("egl_major", major[0])
                .put("egl_minor", minor[0])
                .put("egl_vendor", EGL14.eglQueryString(eglDisplay, EGL14.EGL_VENDOR))
                .put("egl_version", EGL14.eglQueryString(eglDisplay, EGL14.EGL_VERSION))
                .put("egl_extensions", JSONArray(eglExtensions))
                .put("gl_vendor", GLES20.glGetString(GLES20.GL_VENDOR))
                .put("gl_renderer", GLES20.glGetString(GLES20.GL_RENDERER))
                .put("gl_version", GLES20.glGetString(GLES20.GL_VERSION))
                .put(
                    "glsl_version",
                    GLES20.glGetString(GLES20.GL_SHADING_LANGUAGE_VERSION)
                )
                .put("gl_extensions", JSONArray(glExtensions))
                .put("gl_extension_count", glExtensions.size)
        } finally {
            EGL14.eglMakeCurrent(
                eglDisplay,
                EGL14.EGL_NO_SURFACE,
                EGL14.EGL_NO_SURFACE,
                EGL14.EGL_NO_CONTEXT
            )

            if (surface != EGL14.EGL_NO_SURFACE) {
                EGL14.eglDestroySurface(eglDisplay, surface)
            }
            if (context != EGL14.EGL_NO_CONTEXT) {
                EGL14.eglDestroyContext(eglDisplay, context)
            }
            EGL14.eglTerminate(eglDisplay)
        }
    }

    private fun splitExtensions(value: String?): List<String> {
        return value
            ?.split(' ')
            ?.filter { it.isNotBlank() }
            ?.distinct()
            ?.sorted()
            ?: emptyList()
    }
}
