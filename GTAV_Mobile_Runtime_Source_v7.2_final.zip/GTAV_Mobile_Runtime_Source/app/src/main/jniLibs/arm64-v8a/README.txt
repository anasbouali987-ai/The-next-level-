The APK workflow must place the ARM64 Android Box64 binary here as:
libbox64.so

Source inside GTAV_Runtime_Package.zip:
bin/box64

Do not ship this README as a native library. The workflow should delete it after injection.
