\
    #!/usr/bin/env bash
    set -Eeuo pipefail

    PROJECT_DIR="${1:?Usage: $0 PROJECT_DIR BOX64_BUNDLE_ZIP BOX64_BUNDLE_JSON}"
    BUNDLE_ZIP="${2:?Usage: $0 PROJECT_DIR BOX64_BUNDLE_ZIP BOX64_BUNDLE_JSON}"
    BUNDLE_JSON="${3:?Usage: $0 PROJECT_DIR BOX64_BUNDLE_ZIP BOX64_BUNDLE_JSON}"

    for file in "$BUNDLE_ZIP" "$BUNDLE_JSON"; do
      [[ -f "$file" ]] || {
        echo "ERROR: Required file not found: $file"
        exit 1
      }
    done

    DEST_DIR="$PROJECT_DIR/app/src/main/jniLibs/arm64-v8a"
    DEST="$DEST_DIR/libbox64.so"
    TMP_DIR="$(mktemp -d)"
    trap 'rm -rf "$TMP_DIR"' EXIT

    python3 - "$BUNDLE_ZIP" "$BUNDLE_JSON" "$TMP_DIR" <<'PY'
    import hashlib
    import json
    import sys
    import zipfile
    from pathlib import Path

    bundle_zip = Path(sys.argv[1])
    bundle_json = Path(sys.argv[2])
    temp_dir = Path(sys.argv[3])

    def sha256(path: Path) -> str:
        h = hashlib.sha256()
        with path.open("rb") as f:
            for chunk in iter(lambda: f.read(1024 * 1024), b""):
                h.update(chunk)
        return h.hexdigest()

    manifest = json.loads(bundle_json.read_text(encoding="utf-8"))

    expected_archive_hash = manifest.get("archive_sha256")
    if expected_archive_hash:
        actual_archive_hash = sha256(bundle_zip)
        if actual_archive_hash.lower() != expected_archive_hash.lower():
            raise SystemExit(
                f"ERROR: bundle archive SHA-256 mismatch: "
                f"{actual_archive_hash} != {expected_archive_hash}"
            )

    with zipfile.ZipFile(bundle_zip) as zf:
        names = set(zf.namelist())
        if "libbox64.so" not in names:
            raise SystemExit("ERROR: libbox64.so is missing from box64_bundle.zip")
        zf.extract("libbox64.so", temp_dir)

    payload = temp_dir / "libbox64.so"
    expected_size = int(manifest["payload_size_bytes"])
    expected_hash = manifest["payload_sha256"]
    actual_size = payload.stat().st_size
    actual_hash = sha256(payload)

    if actual_size != expected_size:
        raise SystemExit(
            f"ERROR: Box64 size mismatch: {actual_size} != {expected_size}"
        )
    if actual_hash.lower() != expected_hash.lower():
        raise SystemExit(
            f"ERROR: Box64 SHA-256 mismatch: {actual_hash} != {expected_hash}"
        )

    header = payload.read_bytes()[:20]
    if len(header) < 20 or header[:4] != b"\x7fELF":
        raise SystemExit("ERROR: Box64 payload is not a valid ELF file")
    machine = int.from_bytes(header[18:20], "little")
    if machine != 183:
        raise SystemExit(f"ERROR: Box64 payload is not AArch64; e_machine={machine}")

    print(f"Verified Box64: {actual_size} bytes")
    print(f"SHA-256: {actual_hash}")
    PY

    mkdir -p "$DEST_DIR"
    install -m 0755 "$TMP_DIR/libbox64.so" "$DEST"
    rm -f "$DEST_DIR/README.txt"

    test -s "$DEST"
    file "$DEST"

    echo "Injected verified Box64 into:"
    echo "$DEST"

