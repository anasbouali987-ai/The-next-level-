# GTA V Runtime Inspector v7.2

هذا الإصدار يعالج خطأ Android `Permission denied (error=13)` معماريًا، وليس عبر chmod.

## التغيير الأساسي

- لم يعد التطبيق يشغّل `runtime/components/bin/box64` من مجلد التطبيق القابل للكتابة.
- يبحث عن Box64 المضمّن داخل APK في `applicationInfo.nativeLibraryDir/libbox64.so`.
- يشغّل Wine وwineserver وwineboot عبر Box64 الأصلي المضمّن.
- يعطي تشخيصًا صريحًا `native_box64_missing_from_apk` إذا لم يحقن Workflow الملف.

## خطوة إلزامية قبل Gradle

شغّل:

```bash
./INJECT_BOX64_BEFORE_BUILD.sh "$PROJECT_DIR" "$RUNTIME_ZIP"
```

ثم ابنِ APK. بدون هذه الخطوة سيُبنى التطبيق، لكن اختبار Box64 سيظهر BLOCKED بدل Permission denied.
