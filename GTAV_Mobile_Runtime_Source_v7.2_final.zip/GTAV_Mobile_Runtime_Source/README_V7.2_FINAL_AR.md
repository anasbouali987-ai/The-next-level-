# GTA V Runtime Inspector v7.2 — Box64 Bundle Final

هذه النسخة تستخدم ناتج تطبيق 121 مباشرة:

- `box64_bundle.zip`
- `box64_bundle.json`

أثناء بناء APK، يقوم الـWorkflow بما يلي:

1. يفك مشروع التطبيق.
2. يتحقق من بصمة أرشيف Box64.
3. يستخرج `libbox64.so`.
4. يتحقق من الحجم وSHA-256 وELF AArch64.
5. يضعه في:
   `app/src/main/jniLibs/arm64-v8a/libbox64.so`
6. يبني APK.
7. يفتح APK ويتأكد أن Box64 موجود داخله وبنفس البصمة.

الملفات المطلوبة في جذر المستودع:

- `GTAV_Mobile_Runtime_Source_v7.2_final.zip`
- `box64_bundle.zip`
- `box64_bundle.json`
- `.github/workflows/main.yml`

هذه النسخة لا تحتاج Personal Access Token ولا تنزيل Artifact من مستودع آخر.

