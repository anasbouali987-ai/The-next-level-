package com.vx.runtime;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import androidx.core.content.FileProvider;
import android.widget.Button;
import android.widget.TextView;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

public final class MainActivity extends Activity {
    static { System.loadLibrary("vxdiagnostic"); }
    private native String nativeRunDiagnostics(String filesDir, String nativeLibraryDir, String reportDir);
    private TextView output;
    private Button runButton;
    private Button shareButton;
    private File bundleFile;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        setContentView(R.layout.activity_main);
        TextView runtimeStatus = findViewById(R.id.runtimeStatus);
        output = findViewById(R.id.output);
        runButton = findViewById(R.id.runButton);
        shareButton = findViewById(R.id.shareButton);
        File rootfs = new File(getFilesDir(), "vx/runtime/rootfs");
        runtimeStatus.setText("Package: " + getPackageName() + "\nRuntime: " + (rootfs.isDirectory() ? "DETECTED" : "NOT FOUND") + "\nPath: " + rootfs.getAbsolutePath());
        runButton.setOnClickListener(v -> runDiagnostics());
        shareButton.setOnClickListener(v -> shareReport());
    }

    private void runDiagnostics() {
        runButton.setEnabled(false);
        shareButton.setEnabled(false);
        output.setText("Preparing VX 201 diagnostics…\n");
        new Thread(() -> {
            try {
                File base = new File(getFilesDir(), "diagnostic-v2");
                File bin = new File(base, "bin");
                File reports = new File(base, "reports");
                File shared = new File(getCacheDir(), "vx201-share");
                ensureDir(bin); ensureDir(reports); ensureDir(shared);
                extractAsset("diagnostic/hello_static", new File(bin, "hello_static"));
                extractAsset("diagnostic/hello_dynamic_glibc", new File(bin, "hello_dynamic_glibc"));
                extractAsset("diagnostic/hello_x86_64", new File(bin, "hello_x86_64"));

                long started = System.currentTimeMillis();
                String json = nativeRunDiagnostics(getFilesDir().getAbsolutePath(), getApplicationInfo().nativeLibraryDir, reports.getAbsolutePath());
                File jsonFile = new File(reports, "vx_diagnostic_report.json");
                File txtFile = new File(reports, "vx_diagnostic_report.txt");
                File logFile = new File(reports, "android_logcat_best_effort.txt");
                write(jsonFile, json);
                write(txtFile, buildTextSummary(json));
                write(logFile, collectOwnLogcat(started));

                String stamp = new SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(new Date());
                bundleFile = new File(shared, "vx_runtime_diagnostic_" + stamp + ".zip");
                zip(bundleFile, jsonFile, txtFile, logFile);
                runOnUiThread(() -> { output.setText(json); shareButton.setEnabled(true); runButton.setEnabled(true); });
            } catch (Exception ex) {
                runOnUiThread(() -> { output.setText("Diagnostic controller failed:\n" + ex); runButton.setEnabled(true); });
            }
        }, "vx201-diagnostics").start();
    }

    private static void ensureDir(File dir) throws IOException {
        if (!dir.mkdirs() && !dir.isDirectory()) throw new IOException("Cannot create " + dir);
    }

    private void extractAsset(String asset, File out) throws IOException {
        try (InputStream in = getAssets().open(asset); FileOutputStream fos = new FileOutputStream(out)) {
            byte[] buffer = new byte[65536]; int n; while ((n = in.read(buffer)) > 0) fos.write(buffer, 0, n);
        }
        if (!out.setReadable(true, true) || !out.setExecutable(true, true)) throw new IOException("chmod failed: " + out);
    }

    private String collectOwnLogcat(long startedMs) {
        StringBuilder result = new StringBuilder();
        result.append("Best-effort app-visible logcat only. This does not imply access to tombstones, si_code, si_syscall, or complete system logs.\n");
        Process process = null;
        try {
            process = new ProcessBuilder("logcat", "-d", "--pid=" + android.os.Process.myPid(), "-v", "threadtime", "-t", "800").redirectErrorStream(true).start();
            try (BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream(), StandardCharsets.UTF_8))) {
                String line; while ((line = reader.readLine()) != null) result.append(line).append('\n');
            }
            process.waitFor();
        } catch (Exception ex) {
            result.append("LOGCAT_UNAVAILABLE: ").append(ex).append('\n');
            if (process != null) process.destroy();
        }
        result.append("collection_started_epoch_ms=").append(startedMs).append('\n');
        return result.toString();
    }

    private static String buildTextSummary(String json) {
        return "VX 201 Runtime Diagnostic v2\n"
            + "The JSON below is authoritative. Android log collection is best-effort only.\n\n"
            + json;
    }

    private static void write(File file, String text) throws IOException {
        try (FileOutputStream out = new FileOutputStream(file)) { out.write(text.getBytes(StandardCharsets.UTF_8)); }
    }

    private static void zip(File zip, File... files) throws IOException {
        try (ZipOutputStream out = new ZipOutputStream(new FileOutputStream(zip))) {
            byte[] buffer = new byte[65536];
            for (File file : files) {
                out.putNextEntry(new ZipEntry(file.getName()));
                try (InputStream in = new FileInputStream(file)) { int n; while ((n = in.read(buffer)) > 0) out.write(buffer, 0, n); }
                out.closeEntry();
            }
        }
    }

    private void shareReport() {
        if (bundleFile == null || !bundleFile.isFile()) return;
        Uri uri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", bundleFile);
        Intent intent = new Intent(Intent.ACTION_SEND);
        intent.setType("application/zip");
        intent.putExtra(Intent.EXTRA_STREAM, uri);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        startActivity(Intent.createChooser(intent, "Share VX 201 diagnostic bundle"));
    }
}
