plugins { id("com.android.application") }

android {
    namespace = "com.vx.runtime"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.vx.runtime"
        minSdk = 29
        targetSdk = 35
        versionCode = 201
        versionName = "201.1-diagnostic-v2"
        ndk { abiFilters += "arm64-v8a" }
        externalNativeBuild { cmake { cppFlags += listOf("-std=c++20", "-Wall", "-Wextra", "-Werror=return-type") } }
    }

    externalNativeBuild { cmake { path = file("src/main/cpp/CMakeLists.txt"); version = "3.22.1" } }
    buildTypes {
        debug { isMinifyEnabled = false }
        release { isMinifyEnabled = false }
    }
    packaging { jniLibs { useLegacyPackaging = true } }
}

dependencies {
    implementation("androidx.core:core:1.13.1")
}
