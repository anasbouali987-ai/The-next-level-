#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
ASSET_ROOT="$ROOT/app/src/main/assets/execution"
USR_ASSETS="$ASSET_ROOT/usr"
HELLO_SOURCE="$ROOT/execution-components/src/hello_x86_64.c"
HELLO_ASSET="$ASSET_ROOT/hello-x86_64"
PACKAGE_NAME="com.gtav.runtimemanager"
DATA_DIR="/data/data/$PACKAGE_NAME"
PREFIX="$DATA_DIR/files/usr"
TERMUX_DIR="${TERMUX_PACKAGES_DIR:-$ROOT/.termux-packages}"
TERMUX_REF="${TERMUX_PACKAGES_REF:-}"
EXPECTED_PROOT_VERSION="${EXPECTED_PROOT_VERSION:-5.1.107.84}"
BUNDLE_URL="${PROOT_COMPONENT_BUNDLE_URL:-}"
BUNDLE_SHA256="${PROOT_COMPONENT_BUNDLE_SHA256:-}"
PROVISION_SOURCE="unknown"
PROVISION_EVIDENCE=""

log() { printf '[execution-components] %s\n' "$*"; }
fail() { printf 'BUILD FAILED: %s\n' "$*" >&2; exit 1; }

elf_machine() {
  local file="$1"
  readelf -h "$file" 2>/dev/null | awk -F: '/Machine:/{gsub(/^[ \t]+/,"",$2); print $2; exit}'
}

build_hello() {
  mkdir -p "$ASSET_ROOT"
  if [[ ! -f "$HELLO_SOURCE" ]]; then fail X86_64_TEST_SOURCE_MISSING; fi
  if command -v x86_64-linux-gnu-gcc >/dev/null 2>&1; then
    x86_64-linux-gnu-gcc -Os -static -s "$HELLO_SOURCE" -o "$HELLO_ASSET"
  elif command -v gcc >/dev/null 2>&1 && [[ "$(uname -m)" == "x86_64" ]]; then
    gcc -Os -static -s "$HELLO_SOURCE" -o "$HELLO_ASSET"
  elif [[ -f "$HELLO_ASSET" ]]; then
    log "Using repository hello-x86_64 asset"
  else
    fail X86_64_COMPILER_UNAVAILABLE
  fi
  chmod 0755 "$HELLO_ASSET"
  (cd "$ROOT" && sha256sum "app/src/main/assets/execution/hello-x86_64" > execution-components/HELLO_X86_64_SHA256.txt)
  [[ "$(elf_machine "$HELLO_ASSET")" == *"Advanced Micro Devices X86-64"* ]] ||
    fail X86_64_TEST_WRONG_ABI
}

install_bundle() {
  local archive="$ROOT/.execution-components-bundle"
  [[ "$BUNDLE_SHA256" =~ ^[0-9a-fA-F]{64}$ ]] || fail PROOT_BUNDLE_SHA256_REQUIRED
  log "Downloading prebuilt custom-prefix PRoot bundle"
  curl --fail --location --retry 4 --retry-delay 3 "$BUNDLE_URL" -o "$archive"
  echo "$BUNDLE_SHA256  $archive" | sha256sum -c -
  PROVISION_SOURCE="verified-bundle"
  PROVISION_EVIDENCE="sha256=${BUNDLE_SHA256,,}"
  rm -rf "$USR_ASSETS" "$ROOT/.execution-bundle-unpacked"
  mkdir -p "$USR_ASSETS" "$ROOT/.execution-bundle-unpacked"
  case "$BUNDLE_URL" in
    *.zip) unzip -q "$archive" -d "$ROOT/.execution-bundle-unpacked" ;;
    *) tar -xf "$archive" -C "$ROOT/.execution-bundle-unpacked" ;;
  esac
  local usr
  usr="$(find "$ROOT/.execution-bundle-unpacked" -type d -name usr | head -n 1 || true)"
  [[ -n "$usr" ]] || fail PROOT_BUNDLE_INVALID
  cp -a "$usr"/. "$USR_ASSETS"/
}

patch_termux_prefix() {
  local properties="$TERMUX_DIR/scripts/properties.sh"
  [[ -f "$properties" ]] || fail TERMUX_PROPERTIES_NOT_FOUND

  python3 - "$properties" "$PACKAGE_NAME" "$DATA_DIR" "$PREFIX" <<'PY'
from pathlib import Path
import re
import sys

p = Path(sys.argv[1])
package = sys.argv[2]
data = sys.argv[3]
prefix = sys.argv[4]
s = p.read_text()

# Support older revisions with direct final path assignments and newer
# revisions where HOME/PREFIX are derived from ROOTFS plus *_SUBDIR values.
replacements = {
    'TERMUX_APP__PACKAGE_NAME': f'"{package}"',
    'TERMUX_APP__DATA_DIR': f'"{data}"',
    'TERMUX__ROOTFS': f'"{data}/files"',
    'TERMUX__ROOTFS_SUBDIR': '"files"',
    'TERMUX__HOME': f'"{data}/files/home"',
    'TERMUX__HOME_SUBDIR': '"home"',
    'TERMUX__PREFIX': f'"{prefix}"',
    'TERMUX__PREFIX_SUBDIR': '"usr"',
    'TERMUX_APP_PACKAGE': f'"{package}"',
    'TERMUX_PREFIX': f'"{prefix}"',
}

changed = []
for key, value in replacements.items():
    pattern = rf'(?m)^({re.escape(key)}=).*$'
    updated, count = re.subn(pattern, rf'\g<1>{value}', s)
    if count:
        s = updated
        changed.append(key)

required = {'TERMUX_APP__PACKAGE_NAME', 'TERMUX_APP__DATA_DIR'}
missing = sorted(required - set(changed))
if missing:
    raise SystemExit('Required Termux properties not patched: ' + ', '.join(missing))

p.write_text(s)
print('Patched Termux assignments:', ', '.join(changed))
PY

  # Quality gate: evaluate the patched file and verify all effective values.
  local evaluated
  if ! evaluated="$(
    bash -e -o pipefail -c '
      source "$1"
      printf "%s\n" \
        "$TERMUX_APP__PACKAGE_NAME" \
        "$TERMUX_APP__DATA_DIR" \
        "$TERMUX__ROOTFS" \
        "$TERMUX__HOME" \
        "$TERMUX__PREFIX"
    ' _ "$properties"
  )"; then
    fail TERMUX_PROPERTIES_EVALUATION_FAILED
  fi

  local -a actual expected labels
  mapfile -t actual <<<"$evaluated"
  expected=("$PACKAGE_NAME" "$DATA_DIR" "$DATA_DIR/files" "$DATA_DIR/files/home" "$PREFIX")
  labels=(TERMUX_APP__PACKAGE_NAME TERMUX_APP__DATA_DIR TERMUX__ROOTFS TERMUX__HOME TERMUX__PREFIX)

  [[ "${#actual[@]}" -eq "${#expected[@]}" ]] || fail TERMUX_PROPERTIES_EVALUATION_INCOMPLETE
  local i
  for i in "${!expected[@]}"; do
    [[ "${actual[$i]}" == "${expected[$i]}" ]] ||
      fail "TERMUX_PROPERTY_VALUE_MISMATCH:${labels[$i]}:expected=${expected[$i]}:actual=${actual[$i]}"
  done

  log "Verified effective Termux package name, data dir, rootfs, home and prefix"
}

build_with_termux() {
  [[ "$TERMUX_REF" =~ ^[0-9a-fA-F]{40}$ ]] || fail TERMUX_PACKAGES_COMMIT_NOT_PINNED
  if [[ ! -d "$TERMUX_DIR/.git" ]]; then
    rm -rf "$TERMUX_DIR"
    git clone --filter=blob:none https://github.com/termux/termux-packages.git "$TERMUX_DIR"
  else
    log "Using cached termux-packages checkout"
  fi
  git -C "$TERMUX_DIR" fetch --depth 1 origin "$TERMUX_REF"
  git -C "$TERMUX_DIR" checkout --detach "$TERMUX_REF"
  [[ "$(git -C "$TERMUX_DIR" rev-parse HEAD)" == "$TERMUX_REF" ]] || fail TERMUX_PACKAGES_COMMIT_MISMATCH
  PROVISION_SOURCE="termux-source-build"
  PROVISION_EVIDENCE="commit=$TERMUX_REF"
  local declared_version
  declared_version="$(sed -n 's/^TERMUX_PKG_VERSION="\?\([^" ]*\)"\?$/\1/p' "$TERMUX_DIR/packages/proot/build.sh" | head -n 1)"
  [[ "$declared_version" == "$EXPECTED_PROOT_VERSION" ]] ||
    fail "PROOT_PACKAGE_VERSION_CHANGED:expected=$EXPECTED_PROOT_VERSION:actual=$declared_version"
  patch_termux_prefix
  pushd "$TERMUX_DIR" >/dev/null
  # Official Termux Docker build. It builds proot plus its package dependencies for aarch64.
  ./scripts/run-docker.sh ./build-package.sh -a aarch64 libandroid-shmem
  ./scripts/run-docker.sh ./build-package.sh -a aarch64 libtalloc
  ./scripts/run-docker.sh ./build-package.sh -a aarch64 proot
  popd >/dev/null

  local staging="$ROOT/.execution-component-staging"
  rm -rf "$staging" "$USR_ASSETS"
  mkdir -p "$staging" "$USR_ASSETS"
  local deb_count=0
  while IFS= read -r -d '' deb; do
    dpkg-deb -x "$deb" "$staging"
    deb_count=$((deb_count+1))
  done < <(find "$TERMUX_DIR/output" -maxdepth 1 -type f -name '*_aarch64.deb' -print0)
  (( deb_count > 0 )) || fail TERMUX_OUTPUT_EMPTY

  local compiled_prefix="$staging${PREFIX}"
  if [[ ! -d "$compiled_prefix" ]]; then
    compiled_prefix="$(find "$staging" -type f -path '*/bin/proot' -printf '%h\n' | sed 's#/bin$##' | head -n 1 || true)"
  fi
  [[ -n "$compiled_prefix" && -d "$compiled_prefix" ]] || fail PROOT_PREFIX_NOT_FOUND
  cp -a "$compiled_prefix"/. "$USR_ASSETS"/
}

materialize_asset_symlinks() {
  # Android assets do not preserve Unix symlink metadata. Materialize every
  # symlink inside the custom prefix. Absolute Termux-prefix links are mapped
  # back into the asset tree instead of being resolved against the build host.
  python3 - "$USR_ASSETS" "$PREFIX" <<'PYLINKS'
from pathlib import Path
import os, shutil, sys
root = Path(sys.argv[1]).resolve()
prefix = sys.argv[2].rstrip('/')

def lexical(path: Path) -> Path:
    return Path(os.path.normpath(str(path)))

def mapped_target(link: Path) -> Path:
    raw = os.readlink(link)
    if raw == prefix:
        target = root
    elif raw.startswith(prefix + '/'):
        target = root / raw[len(prefix) + 1:]
    elif raw.startswith('/'):
        raise RuntimeError(f'unsupported absolute asset symlink: {link} -> {raw}')
    else:
        target = lexical(link.parent / raw)
    try:
        target.relative_to(root)
    except ValueError:
        raise RuntimeError(f'asset symlink escapes prefix: {link} -> {raw}')
    return target

def resolve(link: Path) -> Path:
    current = link
    seen = set()
    while current.is_symlink():
        marker = str(current)
        if marker in seen:
            raise RuntimeError(f'asset symlink cycle: {link}')
        seen.add(marker)
        current = mapped_target(current)
    if not current.exists():
        raise RuntimeError(f'asset symlink target missing: {link} -> {current}')
    return current

for _ in range(32):
    links = []
    for base, dirs, files in os.walk(root, followlinks=False):
        for name in dirs + files:
            candidate = Path(base) / name
            if candidate.is_symlink():
                links.append(candidate)
    if not links:
        break
    for link in sorted(links, key=lambda x: len(x.parts), reverse=True):
        if not link.is_symlink():
            continue
        target = resolve(link)
        temp = Path(str(link) + '.materialized')
        if temp.exists() or temp.is_symlink():
            if temp.is_dir() and not temp.is_symlink(): shutil.rmtree(temp)
            else: temp.unlink()
        if target.is_dir():
            shutil.copytree(target, temp, symlinks=True)
        else:
            shutil.copy2(target, temp, follow_symlinks=True)
        link.unlink()
        temp.rename(link)
else:
    raise RuntimeError('too many asset symlink materialization passes')
PYLINKS
}
verify_components() {
  materialize_asset_symlinks
  local proot="$USR_ASSETS/bin/proot"
  local loader="$USR_ASSETS/libexec/proot/loader"
  [[ -f "$proot" ]] || fail PROOT_NOT_PACKAGED
  [[ -f "$loader" ]] || fail PROOT_LOADER_NOT_PACKAGED
  chmod 0755 "$proot" "$loader"
  [[ "$(elf_machine "$proot")" == *"AArch64"* ]] || fail PROOT_WRONG_ABI
  [[ "$(elf_machine "$loader")" == *"AArch64"* ]] || fail PROOT_LOADER_WRONG_ABI
  if grep -a -q '/data/data/com.termux' "$proot" "$loader"; then
    fail PROOT_WRONG_PREFIX
  fi
  if ! grep -a -q "$PACKAGE_NAME" "$proot" "$loader"; then
    log "Warning: package name not visible in ELF strings; runtime self-test remains authoritative"
  fi
  for executable in "$proot" "$loader"; do
    while IFS= read -r needed; do
      case "$needed" in
        libc.so|libdl.so|libm.so|liblog.so) continue ;;
      esac
      if ! find "$USR_ASSETS/lib" -type f -name "$needed" -print -quit 2>/dev/null | grep -q .; then
        fail "PROOT_RUNTIME_DEPENDENCY_MISSING:$(basename "$executable"):$needed"
      fi
    done < <(readelf -d "$executable" 2>/dev/null | sed -n 's/.*Shared library: \[\(.*\)\]/\1/p')
  done
  find "$USR_ASSETS" -type f -exec chmod 0644 {} +
  chmod 0755 "$proot" "$loader"
  find "$USR_ASSETS/bin" "$USR_ASSETS/libexec" -type f -exec chmod 0755 {} + 2>/dev/null || true

  local component_manifest="$ASSET_ROOT/EXECUTION_COMPONENTS_SHA256.txt"
  local component_manifest_tmp="${component_manifest}.tmp"
  (
    cd "$ASSET_ROOT"
    while IFS= read -r -d '' component; do sha256sum "$component"; done < <(find usr -type f -print0 | sort -z)
    sha256sum hello-x86_64
  ) > "$component_manifest_tmp"
  mv "$component_manifest_tmp" "$component_manifest"
  (cd "$ASSET_ROOT" && sha256sum --check --strict "$(basename "$component_manifest")")

  mkdir -p "$ROOT/execution-components/reports"
  {
    echo "Package name: $PACKAGE_NAME"
    echo "Provision source: $PROVISION_SOURCE"
    echo "Provision evidence: $PROVISION_EVIDENCE"
    echo "Expected PRoot version: $EXPECTED_PROOT_VERSION"
    if [[ -d "$TERMUX_DIR/.git" ]]; then echo "termux-packages commit: $(git -C "$TERMUX_DIR" rev-parse HEAD)"; fi
    echo "Data dir: $DATA_DIR"
    echo "Prefix: $PREFIX"
    echo "PRoot: $proot"
    echo "PRoot machine: $(elf_machine "$proot")"
    echo "Loader: $loader"
    echo "Loader machine: $(elf_machine "$loader")"
    echo "hello-x86_64: $HELLO_ASSET"
    echo "hello machine: $(elf_machine "$HELLO_ASSET")"
    echo
    find "$USR_ASSETS" -type f -printf '%P\n' | sort
  } > "$ROOT/execution-components/reports/EXECUTION_COMPONENTS.txt"
  sha256sum "$proot" "$loader" "$HELLO_ASSET" > "$ROOT/execution-components/reports/SHA256SUMS.txt"
}

build_hello
if [[ -n "$BUNDLE_URL" ]]; then
  install_bundle
elif [[ -f "$USR_ASSETS/bin/proot" && -f "$USR_ASSETS/libexec/proot/loader" ]] &&
     [[ "${FORCE_REBUILD_EXECUTION_COMPONENTS:-0}" != "1" ]]; then
  PROVISION_SOURCE="source-snapshot-assets"
  PROVISION_EVIDENCE="sha256=$(sha256sum "$USR_ASSETS/bin/proot" | awk '{print $1}')"
  log "Using already provisioned PRoot assets"
else
  command -v docker >/dev/null 2>&1 || fail DOCKER_REQUIRED_FOR_PROOT_BUILD
  build_with_termux
fi
verify_components
log "Execution components are ready"
