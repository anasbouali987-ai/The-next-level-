package com.gtav.runtimemanager.execution;

import org.junit.Test;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

public final class RuntimeProcessSupervisorTest {
    @Test public void processIdentityRejectsRecycledOrWrongStartTick() {
        long pid = ProcessHandle.current().pid();
        long start = RuntimeProcessSupervisor.readStartTicks(pid);
        assertTrue(start > 0);
        assertTrue(RuntimeProcessSupervisor.isSameProcess(pid, start));
        assertFalse(RuntimeProcessSupervisor.isSameProcess(pid, start + 1));
    }
}
