#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
[[ -f SOURCE_MANIFEST_SHA256.txt ]] || { echo 'SOURCE_MANIFEST_MISSING' >&2; exit 31; }
sha256sum --check --strict SOURCE_MANIFEST_SHA256.txt

expected="$(mktemp)"
actual="$(mktemp)"
trap 'rm -f "$expected" "$actual"' EXIT
awk '{sub(/^[^ ]+  /, ""); print}' SOURCE_MANIFEST_SHA256.txt | sort > "$expected"
find . -type f \
  ! -path './.git/*' \
  ! -path './.gradle/*' \
  ! -path './.termux-packages/*' \
  ! -path './app/build/*' \
  ! -path './build/*' \
  ! -name 'SOURCE_MANIFEST_SHA256.txt' \
  -printf '%P\n' | sort > "$actual"
if ! cmp -s "$expected" "$actual"; then
  echo 'SOURCE_MANIFEST_FILE_SET_MISMATCH' >&2
  diff -u "$expected" "$actual" || true
  exit 32
fi
echo 'SOURCE_MANIFEST_OK'
