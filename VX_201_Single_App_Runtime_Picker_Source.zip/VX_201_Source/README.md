# VX 201

نسخة واحدة من تطبيق VX 201 تحتوي على:

- زر **اختيار ملف Runtime** من مدير ملفات Android.
- تثبيت `GTAV_Runtime_Package.zip` أو Artifact ZIP يحتوي عليها.
- التحقق من `runtime_manifest.json` و`payload/rootfs.tar.zst`.
- تثبيت RootFS بأمان ثم تشغيل التشخيص المتدرج.

الـWorkflow يبني ملف APK واحدًا فقط:

`VX_201.apk`
