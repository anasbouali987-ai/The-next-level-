package com.vx.runtime

import android.content.Context
import org.json.JSONObject
import java.io.OutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

object DiagnosticBundle {
    fun create(context: Context, latestReport: JSONObject, output: OutputStream): JSONObject {
        val base = RuntimeStore.base(context)
        var count = 0
        ZipOutputStream(output.buffered()).use { zip ->
            fun add(name: String, bytes: ByteArray) {
                zip.putNextEntry(ZipEntry(name))
                zip.write(bytes)
                zip.closeEntry()
                count++
            }
            add("vx_report.json", latestReport.toString(2).toByteArray())
            add("bridge.json", BridgeMetadata.inspect(context).toString(2).toByteArray())
            listOf(
                RuntimeStore.stateFile(context),
                RuntimeStore.manifestFile(context),
                java.io.File(base, "import_state.json")
            ).filter { it.isFile }.forEach { add("runtime/${it.name}", it.readBytes()) }
            java.io.File(RuntimeStore.active(context), "logs").walkTopDown().filter { it.isFile }.forEach {
                add("logs/${it.relativeTo(java.io.File(RuntimeStore.active(context), "logs")).path}", it.readBytes())
            }
        }
        return JSONObject().put("files", count)
    }
}
