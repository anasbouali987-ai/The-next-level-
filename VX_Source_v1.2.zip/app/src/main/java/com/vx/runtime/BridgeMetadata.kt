package com.vx.runtime

import android.content.Context
import org.json.JSONObject
import java.io.File
import java.security.MessageDigest

object BridgeMetadata {
    private const val ASSET = "vx_bridge_manifest.json"

    fun read(context: Context): JSONObject = context.assets.open(ASSET).bufferedReader().use {
        JSONObject(it.readText())
    }

    fun loader(context: Context): File = File(context.applicationInfo.nativeLibraryDir, "libvxld.so")

    fun inspect(context: Context): JSONObject {
        val metadata = runCatching { read(context) }.getOrElse { JSONObject() }
        val loader = loader(context)
        val expected = metadata.optString("glibc_loader_sha256").lowercase()
        val actual = if (loader.isFile) sha256(loader) else ""
        val ready = metadata.optString("status") == "READY" &&
            expected.matches(Regex("[0-9a-f]{64}")) &&
            actual == expected
        return JSONObject()
            .put("ready", ready)
            .put("loader_path", loader.absolutePath)
            .put("loader_exists", loader.isFile)
            .put("expected_sha256", expected)
            .put("actual_sha256", actual)
            .put("metadata", metadata)
    }

    private fun sha256(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        file.inputStream().buffered().use { input ->
            val buffer = ByteArray(1024 * 1024)
            while (true) {
                val n = input.read(buffer)
                if (n <= 0) break
                digest.update(buffer, 0, n)
            }
        }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }
}
