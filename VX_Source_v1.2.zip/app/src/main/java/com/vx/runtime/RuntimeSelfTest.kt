package com.vx.runtime

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.concurrent.TimeUnit

object RuntimeSelfTest {
    private const val MAX_OUTPUT = 48_000

    fun run(context: Context): JSONObject {
        val active = RuntimeStore.active(context)
        val rootfs = RuntimeStore.rootfs(context)
        val loader = BridgeMetadata.loader(context)
        val logs = File(active, "logs/self_test").apply { mkdirs() }
        val prefix = File(active, "prefix").apply { mkdirs() }
        val home = File(active, "home").apply { mkdirs() }
        val tmp = File(active, "tmp").apply { mkdirs() }
        val box64 = File(rootfs, "usr/local/bin/box64")
        val bridge = BridgeMetadata.inspect(context)
        val tests = JSONArray()

        val prerequisiteErrors = JSONArray()
        if (!active.isDirectory) prerequisiteErrors.put("runtime_not_installed")
        if (!rootfs.isDirectory) prerequisiteErrors.put("rootfs_missing")
        if (!bridge.optBoolean("ready")) prerequisiteErrors.put("apk_glibc_bridge_not_ready")
        if (!box64.isFile) prerequisiteErrors.put("rootfs_box64_missing")

        if (prerequisiteErrors.length() > 0) {
            listOf("box64", "wine64", "wineserver", "wineboot").forEach {
                tests.put(JSONObject().put("id", it).put("status", "BLOCKED").put("errors", prerequisiteErrors))
            }
        } else {
            val armLibs = arm64LibraryPath(rootfs)
            val environment = environment(rootfs, active, prefix, home, tmp, armLibs)
            val bridgePrefix = listOf(
                loader.absolutePath,
                "--inhibit-cache",
                "--library-path",
                armLibs,
                box64.absolutePath
            )
            tests.put(execute("box64", bridgePrefix + "--version", rootfs, logs, environment, 30))

            val wine = configured(rootfs, "opt/gtav-runtime/config/wine-loader-path")
            val server = configured(rootfs, "opt/gtav-runtime/config/wineserver-path")
            val bootRel = File(rootfs, "opt/gtav-runtime/config/wineboot-relative-path")
                .takeIf { it.isFile }?.readText()?.trim().orEmpty().removePrefix("/")
            val boot = File(rootfs, "opt/gtav-wine/$bootRel")

            tests.put(execute("wine64", bridgePrefix + listOf(wine.absolutePath, "--version"), rootfs, logs, environment, 45, wine.isFile))
            tests.put(execute("wineserver", bridgePrefix + listOf(server.absolutePath, "--version"), rootfs, logs, environment, 45, server.isFile))
            tests.put(execute("wineboot", bridgePrefix + listOf(wine.absolutePath, boot.absolutePath, "--help"), rootfs, logs, environment, 90, wine.isFile && boot.isFile))
        }

        var pass = 0; var fail = 0; var blocked = 0
        for (i in 0 until tests.length()) when (tests.getJSONObject(i).optString("status")) {
            "PASS" -> pass++
            "FAIL" -> fail++
            else -> blocked++
        }
        val all = pass == 4
        val stateFile = RuntimeStore.stateFile(context)
        val state = stateFile.takeIf { it.isFile }?.let { runCatching { JSONObject(it.readText()) }.getOrNull() } ?: JSONObject()
        state.put("self_test_completed", true)
            .put("self_test_passed", all)
            .put("pass_count", pass)
            .put("fail_count", fail)
            .put("blocked_count", blocked)
            .put("tested_at_epoch_ms", System.currentTimeMillis())
            .put("ready_for_gtav", false)
        stateFile.writeText(state.toString(2))

        return JSONObject()
            .put("engine", "VX Standalone Runtime Self-Test 1.1")
            .put("strategy", "APK glibc loader -> imported Linux Box64 -> imported Wine")
            .put("bridge", bridge)
            .put("rootfs", rootfs.absolutePath)
            .put("tests", tests)
            .put("summary", JSONObject()
                .put("test_count", 4)
                .put("pass_count", pass)
                .put("fail_count", fail)
                .put("blocked_count", blocked)
                .put("all_passed", all)
                .put("display", "$pass من 4"))
            .put("runtime_state", state)
    }

    private fun configured(rootfs: File, relative: String): File {
        val config = File(rootfs, relative)
        if (!config.isFile) return File(rootfs, "__missing__")
        return File(rootfs, config.readText().trim().removePrefix("/"))
    }

    private fun arm64LibraryPath(rootfs: File): String = listOf(
        "lib/aarch64-linux-gnu", "usr/lib/aarch64-linux-gnu", "lib", "usr/lib", "usr/local/lib"
    ).map { File(rootfs, it) }.filter { it.isDirectory }.joinToString(":") { it.absolutePath }

    private fun environment(rootfs: File, active: File, prefix: File, home: File, tmp: File, armLibs: String): Map<String, String> {
        val wineRoot = File(rootfs, "opt/gtav-wine")
        val wineLibs = listOf(
            File(wineRoot, "lib/wine/x86_64-unix"),
            File(wineRoot, "lib64/wine/x86_64-unix"),
            File(wineRoot, "lib")
        ).filter { it.isDirectory }.joinToString(":") { it.absolutePath }
        val paths = listOf(File(wineRoot, "bin"), File(rootfs, "usr/local/bin"), File(rootfs, "usr/bin"), File(rootfs, "bin"))
            .filter { it.isDirectory }.joinToString(":") { it.absolutePath }
        val xdg = File(tmp, "xdg").apply { mkdirs() }
        return mapOf(
            "HOME" to home.absolutePath,
            "TMPDIR" to tmp.absolutePath,
            "XDG_RUNTIME_DIR" to xdg.absolutePath,
            "WINEPREFIX" to prefix.absolutePath,
            "WINEARCH" to "win64",
            "WINEDEBUG" to "-all",
            "WINEESYNC" to "0",
            "WINEFSYNC" to "0",
            "DISPLAY" to ":0",
            "LD_LIBRARY_PATH" to armLibs,
            "BOX64_PATH" to paths,
            "BOX64_LD_LIBRARY_PATH" to wineLibs,
            "BOX64_BASH" to File(rootfs, "bin/bash").absolutePath,
            "BOX64_DYNAREC" to "1",
            "BOX64_DYNAREC_BIGBLOCK" to "2",
            "BOX64_MMAP32" to "1",
            "BOX64_LOG" to "1",
            "BOX64_NOBANNER" to "0",
            "VX_ACTIVE_RUNTIME" to active.absolutePath,
            "VX_ROOTFS" to rootfs.absolutePath
        )
    }

    private fun execute(
        id: String,
        command: List<String>,
        workingDir: File,
        logs: File,
        env: Map<String, String>,
        timeout: Long,
        prerequisite: Boolean = true
    ): JSONObject {
        if (!prerequisite) return JSONObject().put("id", id).put("status", "BLOCKED").put("reason", "binary_missing")
        val start = System.nanoTime()
        return try {
            val builder = ProcessBuilder(command).directory(workingDir).redirectErrorStream(false)
            builder.environment().putAll(env)
            val process = builder.start()
            val stdout = Collector(process.inputStream, MAX_OUTPUT)
            val stderr = Collector(process.errorStream, MAX_OUTPUT)
            stdout.start(); stderr.start()
            val finished = process.waitFor(timeout, TimeUnit.SECONDS)
            if (!finished) {
                process.destroy()
                if (!process.waitFor(2, TimeUnit.SECONDS)) process.destroyForcibly()
            }
            stdout.join(2000); stderr.join(2000)
            val exit = if (finished) process.exitValue() else -1
            val elapsed = (System.nanoTime() - start) / 1_000_000.0
            val log = File(logs, "$id.log")
            log.writeText(buildString {
                appendLine("COMMAND: ${command.joinToString(" ")}")
                appendLine("FINISHED: $finished")
                appendLine("EXIT_CODE: $exit")
                appendLine("ELAPSED_MS: $elapsed")
                appendLine("--- ENV ---")
                env.toSortedMap().forEach { (k, v) -> appendLine("$k=$v") }
                appendLine("--- STDOUT ---"); appendLine(stdout.text())
                appendLine("--- STDERR ---"); appendLine(stderr.text())
            })
            JSONObject()
                .put("id", id)
                .put("status", if (finished && exit == 0) "PASS" else "FAIL")
                .put("command", JSONArray(command))
                .put("finished", finished)
                .put("exit_code", exit)
                .put("elapsed_ms", elapsed)
                .put("stdout", stdout.text())
                .put("stderr", stderr.text())
                .put("log", log.absolutePath)
        } catch (t: Throwable) {
            JSONObject().put("id", id).put("status", "FAIL").put("exception", t.javaClass.name).put("message", t.message)
        }
    }

    private class Collector(private val input: java.io.InputStream, private val max: Int) : Thread() {
        private val text = StringBuilder()
        override fun run() {
            input.bufferedReader().useLines { lines ->
                for (line in lines) {
                    if (text.length >= max) break
                    text.appendLine(line.take(max - text.length))
                }
            }
        }
        fun text() = text.toString()
    }
}
