package com.vx.runtime

import android.content.Context
import android.net.Uri
import android.os.StatFs
import android.system.Os
import android.system.OsConstants
import com.github.luben.zstd.ZstdInputStream
import org.apache.commons.compress.archivers.tar.TarArchiveEntry
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.RandomAccessFile
import java.nio.file.Files
import java.security.MessageDigest
import java.util.UUID
import java.util.zip.ZipFile

object RuntimeInstaller {
    private const val BUFFER = 1024 * 1024
    private const val MAX_PACKAGE = 4L * 1024 * 1024 * 1024
    private const val MAX_ROOTFS = 5L * 1024 * 1024 * 1024
    private const val MAX_NODES = 100_000
    private const val MAX_MANIFEST = 32L * 1024 * 1024

    data class Progress(val phase: String, val nodes: Int, val bytes: Long, val path: String)

    fun install(context: Context, uri: Uri, progress: (Progress) -> Unit = {}): JSONObject {
        val base = RuntimeStore.base(context).apply { mkdirs() }
        val staging = File(base, "staging-${UUID.randomUUID()}")
        val rootfs = File(staging, "rootfs")
        val selected = File(context.cacheDir, "vx-selected-${UUID.randomUUID()}.zip")
        val nested = File(context.cacheDir, "vx-runtime-${UUID.randomUUID()}.zip")
        val importState = File(base, "import_state.json")
        staging.deleteRecursively()
        check(rootfs.mkdirs()) { "تعذر إنشاء مجلد تثبيت Runtime" }

        var packageBytes = 0L
        var payloadBytes = 0L
        var extractedBytes = 0L
        var nodes = 0
        var rewrittenSymlinks = 0

        try {
            writeState(importState, "COPYING", 0, 0, "")
            context.contentResolver.openInputStream(uri)?.use { input ->
                BufferedInputStream(input, BUFFER).use { source ->
                    BufferedOutputStream(FileOutputStream(selected), BUFFER).use { output ->
                        val buffer = ByteArray(BUFFER)
                        while (true) {
                            val n = source.read(buffer)
                            if (n <= 0) break
                            packageBytes += n
                            require(packageBytes <= MAX_PACKAGE) { "حزمة Runtime أكبر من حد الأمان 4GiB" }
                            output.write(buffer, 0, n)
                            if (packageBytes % (16L * BUFFER) < n) {
                                progress(Progress("COPYING", 0, packageBytes, selected.name))
                            }
                        }
                    }
                }
            } ?: error("تعذر فتح الملف المختار")

            val packageFile = resolvePackage(selected, nested, progress)
            if (packageFile == nested) selected.delete()
            ensureSpace(context, packageFile.length())

            val bridge = BridgeMetadata.read(context)
            val manifest: JSONObject
            ZipFile(packageFile).use { zip ->
                val manifestEntry = zip.getEntry("runtime_manifest.json")
                    ?: error("runtime_manifest.json غير موجود داخل GTAV_Runtime_Package.zip")
                require(!manifestEntry.isDirectory && manifestEntry.size in 1..MAX_MANIFEST) {
                    "حجم runtime_manifest.json غير صالح"
                }
                manifest = zip.getInputStream(manifestEntry).bufferedReader().use { JSONObject(it.readText()) }
                validateManifest(manifest, bridge)
                File(staging, "runtime_manifest.json").writeText(manifest.toString(2))

                val payload = manifest.getJSONObject("rootfs_payload")
                val payloadPath = safeArchivePath(payload.getString("path"))
                val payloadEntry = zip.getEntry(payloadPath) ?: error("ملف RootFS مفقود: $payloadPath")
                val expectedSize = payload.getLong("size_bytes")
                val expectedSha = payload.getString("sha256").lowercase()
                require(expectedSize > 0 && expectedSize <= MAX_PACKAGE) { "حجم RootFS غير صالح" }
                require(expectedSha.matches(Regex("[0-9a-f]{64}"))) { "بصمة RootFS غير صالحة" }

                val payloadTemp = File(staging, "rootfs.tar.zst")
                val digest = MessageDigest.getInstance("SHA-256")
                zip.getInputStream(payloadEntry).use { raw ->
                    BufferedInputStream(raw, BUFFER).use { input ->
                        BufferedOutputStream(FileOutputStream(payloadTemp), BUFFER).use { output ->
                            val buffer = ByteArray(BUFFER)
                            while (true) {
                                val n = input.read(buffer)
                                if (n <= 0) break
                                payloadBytes += n
                                require(payloadBytes <= MAX_PACKAGE) { "RootFS payload أكبر من حد الأمان" }
                                digest.update(buffer, 0, n)
                                output.write(buffer, 0, n)
                                if (payloadBytes % (16L * BUFFER) < n) {
                                    progress(Progress("VERIFYING_PAYLOAD", 0, payloadBytes, payloadPath))
                                }
                            }
                        }
                    }
                }
                val actualSha = digest.digest().toHex()
                require(payloadBytes == expectedSize) {
                    "حجم payload لا يطابق Manifest: expected=$expectedSize actual=$payloadBytes"
                }
                require(actualSha == expectedSha) { "بصمة SHA-256 لملف RootFS لا تطابق Manifest" }

                val symlinks = mutableListOf<PendingLink>()
                val hardLinks = mutableListOf<PendingLink>()
                ZstdInputStream(BufferedInputStream(payloadTemp.inputStream(), BUFFER)).use { zstd ->
                    TarArchiveInputStream(BufferedInputStream(zstd, BUFFER)).use { tar ->
                        while (true) {
                            val entry = tar.nextTarEntry ?: break
                            val relative = safeTarPath(entry.name)
                            if (relative.isEmpty()) continue
                            nodes++
                            require(nodes <= MAX_NODES) { "RootFS يحتوي عناصر أكثر من حد الأمان" }
                            val target = safeTarget(rootfs, relative)
                            when {
                                entry.isDirectory -> {
                                    if (!target.isDirectory) require(target.mkdirs()) { "تعذر إنشاء $relative" }
                                    chmod(target, entry.mode, true)
                                }
                                entry.isSymbolicLink -> {
                                    target.parentFile?.mkdirs()
                                    symlinks += PendingLink(target, entry.linkName)
                                }
                                entry.isLink -> {
                                    target.parentFile?.mkdirs()
                                    hardLinks += PendingLink(target, entry.linkName)
                                }
                                entry.isFile -> {
                                    target.parentFile?.mkdirs()
                                    BufferedOutputStream(FileOutputStream(target), BUFFER).use { output ->
                                        copyEntry(tar, output, entry, relative) { count ->
                                            extractedBytes += count
                                            require(extractedBytes <= MAX_ROOTFS) { "RootFS بعد الفك أكبر من حد الأمان" }
                                        }
                                    }
                                    chmod(target, entry.mode, false)
                                }
                            }
                            if (nodes % 100 == 0) {
                                progress(Progress("EXTRACTING", nodes, extractedBytes, relative))
                                writeState(importState, "EXTRACTING", nodes, extractedBytes, relative)
                            }
                        }
                    }
                }

                for (link in hardLinks) {
                    val source = safeTarget(rootfs, safeTarPath(link.rawTarget))
                    require(source.exists()) { "مصدر hard link مفقود: ${link.rawTarget}" }
                    runCatching { Files.createLink(link.file.toPath(), source.toPath()) }
                        .getOrElse { source.copyTo(link.file, overwrite = true) }
                }
                for (link in symlinks) {
                    if (link.file.exists() || Files.isSymbolicLink(link.file.toPath())) link.file.delete()
                    val translated = translateSymlink(rootfs, link.file, link.rawTarget)
                    if (translated != link.rawTarget) rewrittenSymlinks++
                    Os.symlink(translated, link.file.absolutePath)
                }
                payloadTemp.delete()
            }

            progress(Progress("VALIDATING", nodes, extractedBytes, "Runtime core"))
            val validation = validateRootfs(rootfs, manifest, bridge)
            require(validation.getBoolean("valid")) { validation.getJSONArray("errors").toString() }

            val state = JSONObject()
                .put("status", "INSTALLED")
                .put("runtime_id", manifest.optString("runtime_id"))
                .put("runtime_version", manifest.optString("version"))
                .put("libc_model", manifest.optString("libc_model"))
                .put("source_package_bytes", packageBytes)
                .put("payload_bytes", payloadBytes)
                .put("rootfs_nodes", nodes)
                .put("rootfs_uncompressed_bytes", extractedBytes)
                .put("absolute_symlinks_rewritten", rewrittenSymlinks)
                .put("bridge_loader_sha256", bridge.optString("glibc_loader_sha256"))
                .put("installed_at_epoch_ms", System.currentTimeMillis())
                .put("ready_for_self_test", true)
                .put("ready_for_gtav", false)
            File(staging, "runtime_state.json").writeText(state.toString(2))

            val active = RuntimeStore.active(context)
            val backup = File(base, "runtime-backup")
            backup.deleteRecursively()
            if (active.exists()) require(active.renameTo(backup)) { "تعذر حفظ نسخة Runtime السابقة" }
            if (!staging.renameTo(active)) {
                if (backup.exists()) backup.renameTo(active)
                error("تعذر تفعيل Runtime الجديد")
            }
            backup.deleteRecursively()
            writeState(importState, "INSTALLED", nodes, extractedBytes, active.absolutePath)

            return JSONObject()
                .put("status", "INSTALLED")
                .put("runtime_id", manifest.optString("runtime_id"))
                .put("runtime_version", manifest.optString("version"))
                .put("source_kind", if (packageFile == nested) "github_artifact" else "runtime_package")
                .put("rootfs_path", File(active, "rootfs").absolutePath)
                .put("package_bytes", packageBytes)
                .put("payload_bytes", payloadBytes)
                .put("rootfs_nodes", nodes)
                .put("rootfs_bytes", extractedBytes)
                .put("absolute_symlinks_rewritten", rewrittenSymlinks)
                .put("validation", validation)
                .put("state", state)
        } catch (t: Throwable) {
            staging.deleteRecursively()
            writeState(importState, "FAILED", nodes, extractedBytes, t.message.orEmpty())
            throw t
        } finally {
            selected.delete()
            nested.delete()
        }
    }

    private fun resolvePackage(selected: File, nested: File, progress: (Progress) -> Unit): File {
        ZipFile(selected).use { zip ->
            if (zip.getEntry("runtime_manifest.json") != null && zip.getEntry("payload/rootfs.tar.zst") != null) {
                return selected
            }
            val candidates = zip.entries().asSequence().filter {
                !it.isDirectory && (it.name == "out/GTAV_Runtime_Package.zip" || it.name.endsWith("/GTAV_Runtime_Package.zip"))
            }.toList()
            require(candidates.size == 1) {
                "الملف المختار ليس GTAV_Runtime_Package.zip ولا Artifact يحتوي حزمة واحدة"
            }
            val entry = candidates.single()
            progress(Progress("EXTRACTING_INNER_PACKAGE", 0, 0, entry.name))
            zip.getInputStream(entry).use { input ->
                BufferedInputStream(input, BUFFER).use { source ->
                    BufferedOutputStream(FileOutputStream(nested), BUFFER).use { output ->
                        val buffer = ByteArray(BUFFER)
                        var bytes = 0L
                        while (true) {
                            val n = source.read(buffer)
                            if (n <= 0) break
                            bytes += n
                            require(bytes <= MAX_PACKAGE) { "الحزمة الداخلية أكبر من حد الأمان" }
                            output.write(buffer, 0, n)
                        }
                    }
                }
            }
        }
        return nested
    }

    private fun validateManifest(manifest: JSONObject, bridge: JSONObject) {
        require(manifest.optInt("schema_version") >= 3) { "VX يحتاج Runtime schema 3 أو أحدث" }
        require(manifest.optString("libc_model") == "glibc-rootfs") { "VX يحتاج glibc-rootfs" }
        require(manifest.optString("host_architecture") == "arm64") { "Runtime host يجب أن يكون ARM64" }
        require(manifest.optString("guest_architecture") == "x86_64") { "Runtime guest يجب أن يكون x86_64" }
        require(manifest.has("rootfs_payload")) { "rootfs_payload مفقود" }
        require(manifest.has("rootfs_files")) { "rootfs_files مفقود" }
        require(bridge.optString("status") == "READY") { "جسر VX لم يُحقن أثناء بناء APK" }
        val suite = manifest.optJSONObject("components")?.optString("debian").orEmpty()
        require(suite == bridge.optString("debian_suite")) {
            "نسخة Debian في Runtime لا تطابق جسر VX: runtime=$suite bridge=${bridge.optString("debian_suite")}" 
        }
    }

    private fun validateRootfs(rootfs: File, manifest: JSONObject, bridge: JSONObject): JSONObject {
        val errors = JSONArray()
        fun requireFile(path: String): File {
            val file = safeTarget(rootfs, path)
            if (!file.isFile) errors.put("missing:$path")
            return file
        }
        val rootfsLoader = requireFile("lib/ld-linux-aarch64.so.1")
        val box64 = requireFile("usr/local/bin/box64")
        val wineConfig = requireFile("opt/gtav-runtime/config/wine-loader-path")
        val serverConfig = requireFile("opt/gtav-runtime/config/wineserver-path")
        val bootConfig = requireFile("opt/gtav-runtime/config/wineboot-relative-path")

        if (rootfsLoader.isFile) {
            val actual = sha256(rootfsLoader)
            if (actual != bridge.optString("glibc_loader_sha256").lowercase()) {
                errors.put("glibc_loader_mismatch:runtime=$actual apk=${bridge.optString("glibc_loader_sha256")}")
            }
            if (elfMachine(rootfsLoader) != 183) errors.put("wrong_arch:glibc_loader")
        }
        if (box64.isFile && elfMachine(box64) != 183) errors.put("wrong_arch:box64")

        val wine = configuredPath(rootfs, wineConfig)
        val server = configuredPath(rootfs, serverConfig)
        val bootRel = bootConfig.takeIf { it.isFile }?.readText()?.trim().orEmpty().removePrefix("/")
        val boot = safeTarget(rootfs, "opt/gtav-wine/$bootRel")
        if (!wine.isFile) errors.put("missing:wine_loader:${wine.absolutePath}")
        if (!server.isFile) errors.put("missing:wineserver:${server.absolutePath}")
        if (!boot.isFile) errors.put("missing:wineboot:${boot.absolutePath}")
        if (wine.isFile && elfMachine(wine) != 62) errors.put("wrong_arch:wine_loader")
        if (server.isFile && elfMachine(server) != 62) errors.put("wrong_arch:wineserver")

        val requiredEntries = manifest.optJSONArray("rootfs_files") ?: JSONArray()
        var requiredVerified = 0
        for (i in 0 until requiredEntries.length()) {
            val item = requiredEntries.optJSONObject(i) ?: continue
            if (!item.optBoolean("required")) continue
            val path = item.optString("path")
            val node = runCatching { safeTarget(rootfs, path) }.getOrNull()
            if (node == null || !node.exists()) {
                errors.put("required_missing:$path")
                continue
            }
            if (item.optString("type") == "file" && node.isFile) {
                val expected = item.optString("sha256").lowercase()
                if (expected.length == 64 && sha256(node) != expected) errors.put("required_sha_mismatch:$path")
                else requiredVerified++
            } else requiredVerified++
        }

        return JSONObject()
            .put("valid", errors.length() == 0)
            .put("errors", errors)
            .put("required_verified", requiredVerified)
            .put("wine_loader", wine.absolutePath)
            .put("wineserver", server.absolutePath)
            .put("wineboot", boot.absolutePath)
    }

    private fun configuredPath(rootfs: File, config: File): File {
        if (!config.isFile) return File(rootfs, "__missing__")
        val path = config.readText().trim().removePrefix("/")
        return safeTarget(rootfs, path)
    }

    private fun ensureSpace(context: Context, packageSize: Long) {
        val stat = StatFs(context.filesDir.absolutePath)
        val available = stat.availableBytes
        val recommended = maxOf(1_500_000_000L, packageSize * 4)
        require(available >= recommended) {
            "المساحة غير كافية. المتاح=${available / 1024 / 1024}MiB والمطلوب تقريبًا=${recommended / 1024 / 1024}MiB"
        }
    }

    private fun copyEntry(
        tar: TarArchiveInputStream,
        output: BufferedOutputStream,
        entry: TarArchiveEntry,
        relative: String,
        onBytes: (Long) -> Unit
    ) {
        val buffer = ByteArray(BUFFER)
        var remaining = entry.size
        while (remaining > 0) {
            val requested = minOf(buffer.size.toLong(), remaining).toInt()
            val n = tar.read(buffer, 0, requested)
            require(n > 0) { "نهاية غير متوقعة أثناء استخراج $relative" }
            output.write(buffer, 0, n)
            remaining -= n
            onBytes(n.toLong())
        }
    }

    private fun translateSymlink(rootfs: File, link: File, target: String): String {
        if (!target.startsWith("/")) return target
        val destination = rootfs.toPath().resolve(target.removePrefix("/")).normalize()
        val parent = link.parentFile?.toPath() ?: rootfs.toPath()
        return parent.relativize(destination).toString()
    }

    private fun safeArchivePath(path: String): String {
        val p = path.replace('\\', '/').removePrefix("/")
        require(p.isNotBlank() && p.split('/').none { it == ".." }) { "مسار ZIP غير آمن: $path" }
        return p
    }

    private fun safeTarPath(path: String): String {
        var p = path.replace('\\', '/')
        while (p.startsWith("./")) p = p.removePrefix("./")
        p = p.removePrefix("/")
        if (p == ".") return ""
        require(p.split('/').none { it == ".." }) { "مسار TAR غير آمن: $path" }
        return p
    }

    private fun safeTarget(root: File, relative: String): File {
        val rootPath = root.toPath().toAbsolutePath().normalize()
        val target = rootPath.resolve(relative.removePrefix("/")).normalize()
        require(target.startsWith(rootPath)) { "مسار خارج RootFS: $relative" }
        return target.toFile()
    }

    private fun chmod(file: File, requested: Int, directory: Boolean) {
        val bits = requested and 0x1FF
        val safe = if (directory) bits or OsConstants.S_IXUSR else bits
        runCatching { Os.chmod(file.absolutePath, safe) }
    }

    private fun elfMachine(file: File): Int = runCatching {
        RandomAccessFile(file, "r").use { raf ->
            val header = ByteArray(20)
            raf.readFully(header)
            if (!(header[0] == 0x7f.toByte() && header[1] == 'E'.code.toByte() && header[2] == 'L'.code.toByte() && header[3] == 'F'.code.toByte())) return@use -1
            (header[18].toInt() and 0xff) or ((header[19].toInt() and 0xff) shl 8)
        }
    }.getOrDefault(-1)

    private fun sha256(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        file.inputStream().buffered().use { input ->
            val buffer = ByteArray(BUFFER)
            while (true) {
                val n = input.read(buffer)
                if (n <= 0) break
                digest.update(buffer, 0, n)
            }
        }
        return digest.digest().toHex()
    }

    private fun ByteArray.toHex() = joinToString("") { "%02x".format(it) }

    private fun writeState(file: File, status: String, nodes: Int, bytes: Long, detail: String) {
        runCatching {
            file.parentFile?.mkdirs()
            file.writeText(JSONObject()
                .put("status", status)
                .put("nodes", nodes)
                .put("bytes", bytes)
                .put("detail", detail)
                .put("updated_at_epoch_ms", System.currentTimeMillis())
                .toString(2))
        }
    }

    private data class PendingLink(val file: File, val rawTarget: String)
}
