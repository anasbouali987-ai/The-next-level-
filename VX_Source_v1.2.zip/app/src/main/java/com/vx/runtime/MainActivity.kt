package com.vx.runtime

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.vx.runtime.databinding.ActivityMainBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private var job: Job? = null
    private var latest = JSONObject()

    private val runtimePicker =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) install(uri)
        }

    private val diagnosticsPicker =
        registerForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri ->
            if (uri != null) saveDiagnostics(uri)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnImportRuntime.setOnClickListener {
            runtimePicker.launch(arrayOf("application/zip", "application/octet-stream"))
        }
        binding.btnRunTests.setOnClickListener { runTests() }
        binding.btnRefreshRuntime.setOnClickListener {
            setStatus("تمت إعادة فحص Runtime المثبت.")
            refresh()
        }
        binding.btnDiagnostics.setOnClickListener {
            diagnosticsPicker.launch("vx_runtime_diagnostic.zip")
        }
        binding.btnRemoveRuntime.setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("حذف Runtime")
                .setMessage("سيُحذف Runtime المثبت فقط، ولن يُحذف تطبيق VX.")
                .setNegativeButton("إلغاء", null)
                .setPositiveButton("حذف") { _, _ ->
                    val ok = RuntimeStore.remove(this)
                    setStatus(if (ok) "تم حذف Runtime." else "تعذر حذف Runtime بالكامل.")
                    refresh()
                }
                .show()
        }

        refresh()
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun install(uri: Uri) {
        if (job?.isActive == true) return

        runCatching {
            contentResolver.takePersistableUriPermission(
                uri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION
            )
        }

        setBusy(true, "بدء استيراد Runtime…")
        job = lifecycleScope.launch {
            try {
                val result = withContext(Dispatchers.IO) {
                    RuntimeInstaller.install(this@MainActivity, uri) { progress ->
                        runOnUiThread {
                            val mib = progress.bytes / 1024 / 1024
                            setStatus(
                                "${phaseName(progress.phase)} — " +
                                    "${progress.nodes} عنصر — ${mib}MiB\n" +
                                    progress.path.takeLast(100)
                            )
                        }
                    }
                }

                latest.put("install", result)
                binding.txtResult.text = result.toString(2)
                setStatus("تم تثبيت Runtime بنجاح. أصبح اختبار 4/4 جاهزًا.")
            } catch (t: Throwable) {
                latest.put(
                    "install_error",
                    JSONObject()
                        .put("type", t.javaClass.name)
                        .put("message", t.message)
                )
                setStatus("فشل التثبيت: ${t.message ?: t.javaClass.simpleName}")
            } finally {
                job = null
                setBusy(false, null)
                refresh()
            }
        }
    }

    private fun runTests() {
        if (job?.isActive == true) return

        val runtime = RuntimeStore.inspect(this)
        val bridge = BridgeMetadata.inspect(this)
        if (!runtime.optBoolean("installed")) {
            setStatus("لا يوجد Runtime مثبت.")
            refresh()
            return
        }
        if (!bridge.optBoolean("ready")) {
            setStatus("جسر VX غير جاهز. ثبّت APK المبني من Workflow الرسمي.")
            refresh()
            return
        }

        setBusy(true, "تشغيل glibc → Box64 → Wine…")
        job = lifecycleScope.launch {
            try {
                val result = withContext(Dispatchers.IO) {
                    RuntimeSelfTest.run(this@MainActivity)
                }

                latest.put("self_test", result)
                binding.txtResult.text = result.toString(2)

                val summary = result.getJSONObject("summary")
                val pass = summary.getInt("pass_count")
                setStatus(
                    if (summary.optBoolean("all_passed")) {
                        "نجحت اختبارات Runtime الأربعة ✅"
                    } else {
                        "اكتمل الاختبار: $pass من 4 نجح. احفظ حزمة التشخيص."
                    }
                )
            } catch (t: Throwable) {
                latest.put(
                    "self_test_error",
                    JSONObject()
                        .put("type", t.javaClass.name)
                        .put("message", t.message)
                )
                setStatus("فشل الاختبار: ${t.message ?: t.javaClass.simpleName}")
            } finally {
                job = null
                setBusy(false, null)
                refresh()
            }
        }
    }

    private fun saveDiagnostics(uri: Uri) {
        if (job?.isActive == true) return

        setBusy(true, "إنشاء حزمة التشخيص…")
        job = lifecycleScope.launch {
            try {
                val result = withContext(Dispatchers.IO) {
                    contentResolver.openOutputStream(uri)?.use { output ->
                        DiagnosticBundle.create(this@MainActivity, latest, output)
                    } ?: error("تعذر فتح ملف الحفظ")
                }
                setStatus("تم حفظ التشخيص: ${result.getInt("files")} ملف.")
            } catch (t: Throwable) {
                setStatus("فشل حفظ التشخيص: ${t.message ?: t.javaClass.simpleName}")
            } finally {
                job = null
                setBusy(false, null)
                refresh()
            }
        }
    }

    private fun refresh() {
        if (!::binding.isInitialized) return

        val runtime = RuntimeStore.inspect(this)
        val bridge = BridgeMetadata.inspect(this)
        val installed = runtime.optBoolean("installed")
        val readyForSelfTest = runtime.optBoolean("ready_for_self_test", installed)
        val idle = job?.isActive != true

        binding.btnImportRuntime.isEnabled = idle
        binding.btnRunTests.isEnabled =
            idle && installed && readyForSelfTest && bridge.optBoolean("ready")
        binding.btnRefreshRuntime.isEnabled = idle
        binding.btnDiagnostics.isEnabled = idle
        binding.btnRemoveRuntime.isEnabled = idle && installed

        binding.txtRuntimeStatus.text = buildString {
            appendLine("جسر VX: ${if (bridge.optBoolean("ready")) "جاهز ✅" else "غير جاهز ❌"}")
            appendLine("Runtime: ${if (installed) "مثبت ✅" else "غير مثبت"}")

            if (installed) {
                appendLine("ID: ${runtime.optString("runtime_id")}")
                appendLine("Version: ${runtime.optString("runtime_version")}")
                appendLine("Model: ${runtime.optString("libc_model")}")
                append(
                    "Self-test: " +
                        if (readyForSelfTest) "جاهز ✅" else "غير جاهز ❌"
                )
            } else {
                append("اختر GTAV_Runtime_Package.zip الكامل أو Artifact الذي نزل من GitHub.")
            }
        }
    }

    private fun setBusy(value: Boolean, message: String?) {
        binding.progressImport.visibility =
            if (value) android.view.View.VISIBLE else android.view.View.GONE
        if (message != null) setStatus(message)
        refresh()
    }

    private fun setStatus(message: String) {
        binding.txtOperationStatus.text = message
    }

    private fun phaseName(phase: String): String = when (phase) {
        "COPYING" -> "نسخ الحزمة"
        "EXTRACTING_INNER_PACKAGE" -> "استخراج الحزمة الداخلية"
        "EXTRACTING" -> "استخراج RootFS"
        "VALIDATING" -> "التحقق"
        else -> phase
    }
}
