package com.vx.runtime

import android.content.Context
import org.json.JSONObject
import java.io.File

object RuntimeStore {
    fun base(context: Context) = File(context.filesDir, "vx")
    fun active(context: Context) = File(base(context), "runtime")
    fun rootfs(context: Context) = File(active(context), "rootfs")
    fun stateFile(context: Context) = File(active(context), "runtime_state.json")
    fun manifestFile(context: Context) = File(active(context), "runtime_manifest.json")

    fun inspect(context: Context): JSONObject {
        val active = active(context)
        val rootfs = rootfs(context)
        val state = stateFile(context).takeIf { it.isFile }?.let {
            runCatching { JSONObject(it.readText()) }.getOrNull()
        } ?: JSONObject()
        val manifest = manifestFile(context).takeIf { it.isFile }?.let {
            runCatching { JSONObject(it.readText()) }.getOrNull()
        } ?: JSONObject()
        val required = listOf(
            File(rootfs, "lib/ld-linux-aarch64.so.1"),
            File(rootfs, "usr/local/bin/box64"),
            File(rootfs, "opt/gtav-runtime/config/wine-loader-path"),
            File(rootfs, "opt/gtav-runtime/config/wineserver-path"),
            File(rootfs, "opt/gtav-runtime/config/wineboot-relative-path")
        )
        val installed = active.isDirectory && required.all { it.exists() }
        return JSONObject()
            .put("installed", installed)
            .put("active_path", active.absolutePath)
            .put("rootfs_path", rootfs.absolutePath)
            .put("runtime_id", manifest.optString("runtime_id"))
            .put("runtime_version", manifest.optString("version"))
            .put("libc_model", manifest.optString("libc_model"))
            .put("state", state)
    }

    fun remove(context: Context): Boolean {
        val active = active(context)
        return !active.exists() || active.deleteRecursively()
    }
}
