The GitHub workflow replaces this placeholder with libvxld.so.
The full Runtime is never embedded in VX.apk.
