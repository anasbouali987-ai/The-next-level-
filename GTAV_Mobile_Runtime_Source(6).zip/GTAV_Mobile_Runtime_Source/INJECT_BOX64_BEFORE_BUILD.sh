#!/usr/bin/env bash
set -Eeuo pipefail

PROJECT_DIR="${1:?Usage: $0 PROJECT_DIR BOX64_BUNDLE_ZIP BOX64_BUNDLE_JSON}"
BUNDLE_ZIP="${2:?Usage: $0 PROJECT_DIR BOX64_BUNDLE_ZIP BOX64_BUNDLE_JSON}"
BUNDLE_JSON="${3:?Usage: $0 PROJECT_DIR BOX64_BUNDLE_ZIP BOX64_BUNDLE_JSON}"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

exec python3 "$SCRIPT_DIR/tools/inject_box64.py"           --project-dir "$PROJECT_DIR"           --bundle-zip "$BUNDLE_ZIP"           --bundle-json "$BUNDLE_JSON"
