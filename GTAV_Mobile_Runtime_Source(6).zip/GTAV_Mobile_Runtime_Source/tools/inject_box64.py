#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import stat
import sys
import tempfile
import zipfile
from pathlib import Path


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def require_file(path: Path, label: str) -> None:
    if not path.is_file():
        raise RuntimeError(f"{label} was not found: {path}")


def read_manifest(path: Path) -> dict:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise RuntimeError(f"Cannot read bundle manifest {path}: {exc}") from exc

    if not isinstance(value, dict):
        raise RuntimeError("Bundle manifest root must be a JSON object.")
    return value


def manifest_value(manifest: dict, *names: str):
    for name in names:
        if name in manifest:
            return manifest[name]
    return None


def locate_payload_name(archive: zipfile.ZipFile) -> str:
    candidates = (
        "libbox64.so",
        "box64",
        "bin/box64",
        "payload/libbox64.so",
    )
    names = archive.namelist()

    for candidate in candidates:
        if candidate in names:
            return candidate

    matches = [
        name
        for name in names
        if not name.endswith("/")
        and Path(name).name in {"libbox64.so", "box64"}
    ]
    if len(matches) == 1:
        return matches[0]

    raise RuntimeError(
        "Box64 payload is missing from box64_bundle.zip. "
        f"Archive entries: {names[:50]}"
    )


def validate_elf_aarch64(path: Path) -> None:
    with path.open("rb") as handle:
        header = handle.read(64)

    if len(header) < 20 or header[:4] != b"\x7fELF":
        raise RuntimeError("Box64 payload is not an ELF executable.")
    if header[4] != 2:
        raise RuntimeError(f"Box64 is not ELF64; ELF class={header[4]}.")
    if header[5] != 1:
        raise RuntimeError(
            f"Box64 is not little-endian ELF; encoding={header[5]}."
        )

    machine = int.from_bytes(header[18:20], "little")
    if machine != 183:
        raise RuntimeError(
            f"Box64 is not AArch64; e_machine={machine}, expected 183."
        )


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Verify an App 121 Box64 bundle and inject it into an Android project."
    )
    parser.add_argument("--project-dir", required=True, type=Path)
    parser.add_argument("--bundle-zip", required=True, type=Path)
    parser.add_argument("--bundle-json", required=True, type=Path)
    args = parser.parse_args()

    project_dir = args.project_dir.resolve()
    bundle_zip = args.bundle_zip.resolve()
    bundle_json = args.bundle_json.resolve()

    require_file(bundle_zip, "Box64 bundle ZIP")
    require_file(bundle_json, "Box64 bundle manifest")

    app_dir = project_dir / "app"
    if not app_dir.is_dir():
        raise RuntimeError(f"Android app module was not found: {app_dir}")

    manifest = read_manifest(bundle_json)

    expected_archive_hash = manifest_value(
        manifest,
        "archive_sha256",
        "bundle_sha256",
        "zip_sha256",
    )
    actual_archive_hash = sha256_file(bundle_zip)

    if expected_archive_hash:
        if actual_archive_hash.lower() != str(expected_archive_hash).lower():
            raise RuntimeError(
                "Bundle ZIP SHA-256 mismatch: "
                f"{actual_archive_hash} != {expected_archive_hash}"
            )

    with tempfile.TemporaryDirectory(prefix="box64-inject-") as temp:
        temp_dir = Path(temp)

        try:
            with zipfile.ZipFile(bundle_zip, "r") as archive:
                corrupt_entry = archive.testzip()
                if corrupt_entry:
                    raise RuntimeError(
                        f"Corrupt entry in Box64 bundle: {corrupt_entry}"
                    )

                payload_name = locate_payload_name(archive)
                payload_path = temp_dir / "libbox64.so"

                with archive.open(payload_name, "r") as source:
                    with payload_path.open("wb") as destination:
                        shutil.copyfileobj(
                            source,
                            destination,
                            length=1024 * 1024,
                        )
        except zipfile.BadZipFile as exc:
            raise RuntimeError(f"Invalid Box64 bundle ZIP: {exc}") from exc

        actual_size = payload_path.stat().st_size
        actual_payload_hash = sha256_file(payload_path)

        expected_size = manifest_value(
            manifest,
            "payload_size_bytes",
            "original_size_bytes",
            "box64_size_bytes",
        )
        expected_payload_hash = manifest_value(
            manifest,
            "payload_sha256",
            "original_sha256",
            "box64_sha256",
        )

        if expected_size is not None and actual_size != int(expected_size):
            raise RuntimeError(
                f"Box64 size mismatch: {actual_size} != {expected_size}"
            )

        if expected_payload_hash:
            if actual_payload_hash.lower() != str(expected_payload_hash).lower():
                raise RuntimeError(
                    "Box64 SHA-256 mismatch: "
                    f"{actual_payload_hash} != {expected_payload_hash}"
                )

        validate_elf_aarch64(payload_path)

        destination_dir = (
            project_dir / "app/src/main/jniLibs/arm64-v8a"
        )
        destination_dir.mkdir(parents=True, exist_ok=True)
        destination = destination_dir / "libbox64.so"

        shutil.copyfile(payload_path, destination)
        destination.chmod(
            stat.S_IRUSR
            | stat.S_IWUSR
            | stat.S_IXUSR
            | stat.S_IRGRP
            | stat.S_IXGRP
            | stat.S_IROTH
            | stat.S_IXOTH
        )

        readme = destination_dir / "README.txt"
        if readme.exists():
            readme.unlink()

    installed_hash = sha256_file(destination)
    if installed_hash != actual_payload_hash:
        raise RuntimeError(
            "Injected Box64 differs from the verified payload."
        )

    print(f"Bundle ZIP SHA-256: {actual_archive_hash}")
    print(f"Box64 payload size: {actual_size} bytes")
    print(f"Box64 payload SHA-256: {actual_payload_hash}")
    print(f"Injected path: {destination}")
    print("Box64 verification and injection: PASS")

    github_output = os.environ.get("GITHUB_OUTPUT")
    if github_output:
        with open(github_output, "a", encoding="utf-8") as handle:
            handle.write(f"sha256={actual_payload_hash}\n")
            handle.write(f"size={actual_size}\n")
            handle.write(f"archive_sha256={actual_archive_hash}\n")

    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        raise SystemExit(1)
