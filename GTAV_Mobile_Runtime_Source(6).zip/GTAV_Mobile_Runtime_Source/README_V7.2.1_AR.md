# GTA V Runtime Inspector v7.2.1

إصلاح فشل v7.2 السابق:

- لا يوجد Python داخل Bash أو here-document.
- التحقق والحقن في ملف مستقل: `tools/inject_box64.py`.
- يتحقق من ZIP وSHA-256 والحجم وELF64 وAArch64.
- يحقن Box64 في:
  `app/src/main/jniLibs/arm64-v8a/libbox64.so`
- يتحقق Workflow من وجود Box64 داخل APK وبالبصمة نفسها.
