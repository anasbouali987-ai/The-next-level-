package com.vx.runtime

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.vx.runtime.databinding.ActivityMainBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private var job: Job? = null
    private var latest = JSONObject()

    private val runtimePicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) install(uri)
    }
    private val diagnosticsPicker = registerForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri ->
        if (uri != null) saveDiagnostics(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnImportRuntime.setOnClickListener {
            runtimePicker.launch(arrayOf("application/zip", "application/octet-stream"))
        }
        binding.btnRunTests.setOnClickListener { runTests() }
        binding.btnDiagnostics.setOnClickListener { diagnosticsPicker.launch("vx_runtime_diagnostic.zip") }
        binding.btnRemoveRuntime.setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("حذف Runtime")
                .setMessage("سيُحذف Runtime المثبت فقط، ولن يُحذف تطبيق VX.")
                .setNegativeButton("إلغاء", null)
                .setPositiveButton("حذف") { _, _ ->
                    val ok = RuntimeStore.remove(this)
                    setStatus(if (ok) "تم حذف Runtime." else "تعذر حذف Runtime بالكامل.")
                    refresh()
                }.show()
        }
        refresh()
    }

    private fun install(uri: Uri) {
        if (job?.isActive == true) return
        runCatching { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
        busy(true, "بدء استيراد Runtime…")
        job = lifecycleScope.launch {
            try {
                val result = withContext(Dispatchers.IO) {
                    RuntimeInstaller.install(this@MainActivity, uri) { p ->
                        runOnUiThread {
                            val mib = p.bytes / 1024 / 1024
                            setStatus("${phaseName(p.phase)} — ${p.nodes} عنصر — ${mib}MiB\n${p.path.takeLast(100)}")
                        }
                    }
                }
                latest.put("install", result)
                binding.txtResult.text = result.toString(2)
                busy(false, "تم تثبيت Runtime بنجاح. شغّل الاختبارات الأربعة.")
                refresh()
            } catch (t: Throwable) {
                latest.put("install_error", JSONObject().put("type", t.javaClass.name).put("message", t.message))
                busy(false, "فشل التثبيت: ${t.message ?: t.javaClass.simpleName}")
            } finally { job = null }
        }
    }

    private fun runTests() {
        if (job?.isActive == true) return
        busy(true, "تشغيل glibc → Box64 → Wine…")
        job = lifecycleScope.launch {
            try {
                val result = withContext(Dispatchers.IO) { RuntimeSelfTest.run(this@MainActivity) }
                latest.put("self_test", result)
                binding.txtResult.text = result.toString(2)
                val s = result.getJSONObject("summary")
                busy(false, "اكتمل الاختبار: ${s.getInt("pass_count")} من 4 نجح.")
                refresh()
            } catch (t: Throwable) {
                busy(false, "فشل الاختبار: ${t.message}")
            } finally { job = null }
        }
    }

    private fun saveDiagnostics(uri: Uri) {
        if (job?.isActive == true) return
        busy(true, "إنشاء حزمة التشخيص…")
        job = lifecycleScope.launch {
            try {
                val result = withContext(Dispatchers.IO) {
                    contentResolver.openOutputStream(uri)?.use { DiagnosticBundle.create(this@MainActivity, latest, it) }
                        ?: error("تعذر فتح ملف الحفظ")
                }
                busy(false, "تم حفظ التشخيص: ${result.getInt("files")} ملف.")
            } catch (t: Throwable) {
                busy(false, "فشل حفظ التشخيص: ${t.message}")
            } finally { job = null }
        }
    }

    private fun refresh() {
        val runtime = RuntimeStore.inspect(this)
        val bridge = BridgeMetadata.inspect(this)
        val installed = runtime.optBoolean("installed")
        binding.btnRunTests.isEnabled = installed && bridge.optBoolean("ready") && job?.isActive != true
        binding.btnRemoveRuntime.isEnabled = installed && job?.isActive != true
        binding.txtRuntimeStatus.text = buildString {
            appendLine("جسر VX: ${if (bridge.optBoolean("ready")) "جاهز ✅" else "غير جاهز ❌"}")
            appendLine("Runtime: ${if (installed) "مثبت ✅" else "غير مثبت"}")
            if (installed) {
                appendLine("ID: ${runtime.optString("runtime_id")}")
                appendLine("Version: ${runtime.optString("runtime_version")}")
                append("Model: ${runtime.optString("libc_model")}")
            } else {
                append("اختر GTAV_Runtime_Package.zip الكامل أو Artifact الذي نزل من GitHub.")
            }
        }
    }

    private fun busy(value: Boolean, message: String) {
        binding.progressImport.visibility = if (value) android.view.View.VISIBLE else android.view.View.GONE
        binding.btnImportRuntime.isEnabled = !value
        binding.btnDiagnostics.isEnabled = !value
        setStatus(message)
        refresh()
    }

    private fun setStatus(message: String) { binding.txtOperationStatus.text = message }
    private fun phaseName(phase: String) = when (phase) {
        "COPYING" -> "نسخ الحزمة"
        "EXTRACTING_INNER_PACKAGE" -> "استخراج الحزمة الداخلية"
        "EXTRACTING" -> "استخراج RootFS"
        "VALIDATING" -> "التحقق"
        else -> phase
    }
}
