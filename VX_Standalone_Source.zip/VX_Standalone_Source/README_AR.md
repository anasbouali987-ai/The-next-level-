# VX Standalone

تطبيق VX خفيف ومستقل عن حزمة Runtime الثقيلة.

## التصميم

```text
VX.apk
└── واجهة + مستورد + مفك Zstandard/TAR + جسر glibc صغير فقط

GTAV_Runtime_Package.zip
└── يُختار من الهاتف بعد تثبيت VX، ولا يُدمج في APK
```

يمكن اختيار أحد الملفين مباشرة:

1. `GTAV_Runtime_Package.zip` بحجمه الكامل.
2. ملف Artifact الذي نزل من GitHub مثل `GTAV-Runtime-v2.3-11.zip`؛ سيعثر VX تلقائيًا على `out/GTAV_Runtime_Package.zip` داخله.

## ماذا يفعل VX عند الاستيراد؟

- يقرأ `runtime_manifest.json`.
- يتحقق من نموذج `glibc-rootfs` ومعمارية ARM64/x86_64.
- يتحقق من SHA-256 لـ`payload/rootfs.tar.zst`.
- يفك RootFS مع الصلاحيات والروابط.
- يحوّل الروابط الرمزية المطلقة إلى روابط داخل RootFS، كي لا تشير إلى نظام Android.
- يتحقق من glibc loader وLinux Box64 وWine64 وWineserver وWineboot.
- يثبت Runtime بصورة ذرية مع الاحتفاظ بالنسخة القديمة حتى نجاح الجديدة.

## الاختبارات الأربعة

```text
1. glibc loader → Linux Box64 --version
2. glibc loader → Linux Box64 → Wine64 --version
3. glibc loader → Linux Box64 → Wineserver --version
4. glibc loader → Linux Box64 → Wineboot --help
```

## الفصل بين التطبيق والـRuntime

- تعديل واجهة VX أو التشخيص: أعد بناء APK فقط.
- تحديث Wine/Box64/DXVK/RootFS: استورد حزمة Runtime جديدة من داخل التطبيق.
- الـWorkflow لا يحتاج ملف Runtime ولا `box64_bundle.zip`.

## ملاحظة الجسر الصغير

Android يمنع تشغيل ملفات تنفيذية مباشرة من مجلد التطبيق القابل للكتابة. لذلك يضع Workflow محمّل glibc صغيرًا باسم `libvxld.so` داخل APK. أما Linux Box64 وWine وبقية RootFS فتظل خارج APK وتأتي من Runtime المستورد.
