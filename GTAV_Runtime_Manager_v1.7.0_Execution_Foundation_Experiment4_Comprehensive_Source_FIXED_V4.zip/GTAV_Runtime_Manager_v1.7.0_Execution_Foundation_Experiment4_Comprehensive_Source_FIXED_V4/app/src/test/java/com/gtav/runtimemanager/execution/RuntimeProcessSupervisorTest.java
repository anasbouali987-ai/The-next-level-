package com.gtav.runtimemanager.execution;

import org.junit.Test;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

public final class RuntimeProcessSupervisorTest {
    @Test public void processIdentityRejectsRecycledOrWrongStartTick() {
        long pid = getCurrentPid();
        
        long start = RuntimeProcessSupervisor.readStartTicks(pid);
        assertTrue(start > 0);
        assertTrue(RuntimeProcessSupervisor.isSameProcess(pid, start));
        assertFalse(RuntimeProcessSupervisor.isSameProcess(pid, start + 1));
    
    private static long getCurrentPid() {
        String runtimeName = java.lang.management.ManagementFactory
                .getRuntimeMXBean()
                .getName();
        int separator = runtimeName.indexOf('@');
        String pidText = separator >= 0 ? runtimeName.substring(0, separator) : runtimeName;
        return Long.parseLong(pidText);
    }

}

    private static long getCurrentPid() {
        String runtimeName = java.lang.management.ManagementFactory
                .getRuntimeMXBean()
                .getName();
        int separator = runtimeName.indexOf('@');
        String pidText = separator >= 0 ? runtimeName.substring(0, separator) : runtimeName;
        return Long.parseLong(pidText);
    }

}
