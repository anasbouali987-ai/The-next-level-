# معمارية GTAV Runtime Manager v1.6.0

## المبادئ

1. لا تنفذ الواجهة عمليات ZIP أو Zstd أو TAR.
2. لا تستخدم أي طبقة `zstd-jni` مباشرة إلا `AndroidZstdJniEngine`.
3. لا يبدأ التثبيت إلا بعد نجاح التشخيص والحزمة ونظام الملفات والمحرك.
4. كل I/O كبير يعمل Streaming وبـBuffers ثابتة.
5. كل فشل يملك Stage وError code وتقريرًا، ولا يؤدي إلى إغلاق صامت.
6. التثبيت لا يصبح مرئيًا كنسخة نهائية إلا بعد التحقق والنقل الذري.

## الطبقات

```text
UI
MainActivity
  ├─ اختيار الحزمة وعرض الحالة فقط
  └─ لا يحتفظ بمنطق استخراج

Orchestration
RuntimeInstallCoordinator
  ├─ Executor واحد
  ├─ CancellationToken
  ├─ State publication
  └─ RuntimeInstallService + WakeLock + Notification

Installation pipeline
RuntimeInstaller
  ├─ RuntimePreflightChecker
  ├─ RuntimeExtractor
  ├─ RuntimePostVerifier
  └─ AtomicRuntimeSwap

Compression boundary
CompressionManager
  └─ ZstdEngine
       ├─ AndroidZstdJniEngine [الإنتاج]
       └─ NdkZstdEngine [معطّل/مستقبلي]

Reliability and diagnostics
RuntimeInstallJournal
RuntimeInstallWatchdog
RuntimeRecoveryManager
RuntimeLogWriter
RuntimeCrashReporter
DiagnosticsExporter
```

## مسار البيانات

```text
ContentResolver / SeekableZipReader
  → ZIP entry stream
  → BufferedInputStream
  → CompressionManager
  → ZstdInputStream
  → BufferedInputStream
  → TarArchiveInputStream
  → ملف مؤقت داخل <runtime-id>.installing
```

لا يوجد `readAllBytes()` للـPayload، ولا تُحمّل قائمة RootFS كاملة في الذاكرة. الروابط والصلاحيات المؤجلة تُسجل على القرص عند الحاجة.

## التشخيص على مستويين

### Startup Diagnostic

يعمل خارج Main Thread ويختبر:

- Android API وABI.
- JNI Runtime والمكتبات الأصلية المعبأة.
- ContentResolver وDocumentFile وSAF.
- SELinux وحالة التخزين.
- write + `fsync` + `chmod` + Symlink + rename في cache.
- تهيئة TAR.
- Zstd Round-trip وStreaming.

### Package Preflight

يعيد الاختبارات الحساسة داخل مسار Runtime الفعلي، ثم يفتح Payload ويقرأ أول TAR entry. هذا يمنع الاعتماد على نجاح اختبار cache وحده.

## التثبيت الذري والاستعادة

```text
<runtime>.installing
  ↓ extraction + post verification + state
<runtime> → <runtime>.backup
<runtime>.installing → <runtime>
  ↓ success
حذف <runtime>.backup
```

عند فشل ترقية النسخة الجديدة تُعاد `.backup`. وعند تشغيل التطبيق يفحص `RuntimeRecoveryManager` البقايا القابلة للاستعادة.

## حدود الأمان

- رفض المسارات المطلقة وWindows paths و`..`.
- منع الكتابة إذا كان أحد الآباء Symlink.
- إنشاء Symlinks وHard Links بعد استخراج الملفات العادية.
- حذف شجري لا يتبع Symlinks ولا يتجاوز Runtime root.
- SHA-256 متدفق للـPayload والملفات المطلوبة.
- مقارنة النوع والحجم والصلاحية والهدف والإحصائيات بعد التثبيت.
