# قائمة اعتماد الإصدار v1.6.0

- [ ] نجاح `tools/verify-source-boundaries.sh`.
- [ ] نجاح `testDebugUnitTest` و`lintDebug`.
- [ ] نجاح `verifyZstdAarContents`.
- [ ] نجاح `verifyDebugNativePackaging`.
- [ ] نجاح `verifyReleaseNativePackaging`.
- [ ] وجود Zstandard داخل `lib/arm64-v8a/` في APK النهائي.
- [ ] مراجعة `APK_NATIVE_LIBS.txt` و`BUILD_INFO.txt` و`SHA256SUMS.txt`.
- [ ] نجاح `connectedDebugAndroidTest` على جهاز ARM64.
- [ ] نجاح Startup Diagnostic على الجهاز المستهدف.
- [ ] تجربة حزمة Runtime حقيقية: verify → diagnose → install → recheck.
- [ ] اختبار الإلغاء أثناء الاستخراج.
- [ ] اختبار إعادة التثبيت وRollback واستعادة `.backup`.
- [ ] تصدير Diagnostics ZIP ومراجعة التقارير.
- [ ] توقيع Release APK واختباره بعد التوقيع.

لا يُعتبر المصدر وحده إصدارًا إنتاجيًا مكتمل الاعتماد قبل نجاح البنود الخاصة بالجهاز وAPK الموقّع.
