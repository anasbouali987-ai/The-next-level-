# بناء المشروع والتحقق منه

## فحص محلي كامل

```bash
gradle clean testDebugUnitTest lintDebug validateAllNativePackaging
```

تقوم `validateAllNativePackaging` ببناء Debug وRelease ثم تتحقق من:

- وجود مكتبات `.so` داخل APK.
- وجود مكتبة Zstandard تحت `lib/arm64-v8a/`.
- تطابق ABI المطلوب.
- إنشاء قائمة المكتبات ومعلومات البناء وSHA-256.
- فحص Android AAR المحلول قبل اعتماد APK.
- عدم وجود استخدام مباشر لـZstd خارج المحرك.

## اختبار جهاز ARM64

```bash
gradle connectedDebugAndroidTest
```

هذا الاختبار ضروري لأنه وحده يثبت نجاح `dlopen` وJNI وRound-trip وStreaming وفتح TAR.ZST على Android Runtime الفعلي.

## CI

الملف `.github/workflows/build-and-validate.yml` يثبت Gradle 8.11.1، يشغّل Unit tests وLint، ويبني Debug وRelease ويفحص Native Packaging، ثم يرفع APKs والتقارير كـArtifacts.

اختبارات الجهاز ليست جزءًا من Runner عادي، ويجب تشغيلها على جهاز/محاكي ARM64 أو مزرعة أجهزة.
