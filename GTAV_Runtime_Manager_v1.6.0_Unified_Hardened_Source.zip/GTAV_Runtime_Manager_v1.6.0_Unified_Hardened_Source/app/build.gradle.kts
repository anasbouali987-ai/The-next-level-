import java.security.MessageDigest
import java.util.zip.ZipFile

plugins {
    id("com.android.application")
}

val zstdVersion = "1.5.7-3"
val commonsCompressVersion = "1.27.1"
val requestedAbi = "arm64-v8a"

android {
    namespace = "com.gtav.runtimemanager"
    compileSdk = 36
    buildToolsVersion = "35.0.0"

    defaultConfig {
        applicationId = "com.gtav.runtimemanager"
        minSdk = 26
        targetSdk = 36
        versionCode = 8
        versionName = "1.6.0"
        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"

        ndk { abiFilters += listOf(requestedAbi) }
        buildConfigField("String", "ZSTD_DEPENDENCY_VERSION", "\"$zstdVersion\"")
        buildConfigField("String", "REQUESTED_ABI", "\"$requestedAbi\"")
    }

    buildTypes {
        debug {
            isMinifyEnabled = false
        }
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    buildFeatures { buildConfig = true }

    packaging {
        resources.excludes += setOf(
            "META-INF/DEPENDENCIES",
            "META-INF/LICENSE*",
            "META-INF/NOTICE*"
        )
        jniLibs.useLegacyPackaging = true
    }

    testOptions { unitTests.isReturnDefaultValues = true }
}

dependencies {
    implementation("org.apache.commons:commons-compress:$commonsCompressVersion")
    implementation("androidx.documentfile:documentfile:1.0.1")
    implementation("com.github.luben:zstd-jni:$zstdVersion@aar")

    // JVM unit tests need the regular JAR; the APK still consumes the Android AAR above.
    testImplementation("com.github.luben:zstd-jni:$zstdVersion")
    testImplementation("junit:junit:4.13.2")

    androidTestImplementation("androidx.test.ext:junit:1.2.1")
    androidTestImplementation("androidx.test:core:1.6.1")
    androidTestImplementation("androidx.test:runner:1.6.2")
}

fun sha256(file: File): String {
    val digest = MessageDigest.getInstance("SHA-256")
    file.inputStream().use { input ->
        val buffer = ByteArray(256 * 1024)
        while (true) {
            val read = input.read(buffer)
            if (read < 0) break
            digest.update(buffer, 0, read)
        }
    }
    return digest.digest().joinToString("") { "%02x".format(it) }
}

fun findVariantApks(variant: String): List<File> {
    val outputDir = layout.buildDirectory.dir("outputs/apk/$variant").get().asFile
    return outputDir.walkTopDown().filter { it.isFile && it.extension == "apk" }.toList()
}

fun validateApk(apk: File, variant: String) {
    val entries = ZipFile(apk).use { zip ->
        zip.entries().asSequence().map { it.name }.toList()
    }
    val nativeEntries = entries.filter { it.startsWith("lib/") && it.endsWith(".so") }.sorted()
    val abiEntries = nativeEntries.filter { it.startsWith("lib/$requestedAbi/") }
    val zstdEntries = abiEntries.filter { it.substringAfterLast('/').contains("zstd", ignoreCase = true) }
    val packagedAbis = nativeEntries.mapNotNull { it.split('/').getOrNull(1) }.distinct()

    val reportDir = layout.buildDirectory.dir("reports/native-packaging/$variant").get().asFile
        .apply { mkdirs() }
    File(reportDir, "APK_NATIVE_LIBS.txt").writeText(nativeEntries.joinToString("\n", postfix = "\n"))
    File(reportDir, "BUILD_INFO.txt").writeText(buildString {
        appendLine("Application version: ${android.defaultConfig.versionName}")
        appendLine("Requested ABI: $requestedAbi")
        appendLine("Packaged ABIs: ${packagedAbis.joinToString()}")
        appendLine("Zstd dependency: $zstdVersion")
        appendLine("Variant: $variant")
        appendLine("APK: ${apk.name}")
        appendLine("Zstd entries:")
        zstdEntries.forEach { appendLine(" - $it") }
    })
    File(reportDir, "SHA256SUMS.txt").writeText("${sha256(apk)}  ${apk.name}\n")

    if (abiEntries.isEmpty()) {
        throw GradleException("BUILD FAILED: ABI_NOT_PACKAGED_$requestedAbi")
    }
    if (zstdEntries.isEmpty()) {
        logger.error("Files inside lib/$requestedAbi/:\n${abiEntries.joinToString("\n")}")
        throw GradleException("BUILD FAILED: ZSTD_NOT_PACKAGED")
    }
    logger.lifecycle("Native packaging passed for $variant: ${zstdEntries.joinToString()}")
}

tasks.register("verifyZstdAarContents") {
    group = "verification"
    description = "Checks the resolved Android AAR for the requested arm64 Zstandard library."
    doLast {
        val artifacts = configurations.getByName("releaseRuntimeClasspath")
            .resolvedConfiguration.resolvedArtifacts
            .filter { it.moduleVersion.id.group == "com.github.luben" && it.name == "zstd-jni" }
        val aar = artifacts.map { it.file }.firstOrNull { it.extension == "aar" }
            ?: throw GradleException("BUILD FAILED: ZSTD_AAR_NOT_RESOLVED")
        val entries = ZipFile(aar).use { zip -> zip.entries().asSequence().map { it.name }.toList() }
        val expected = entries.filter {
            it.startsWith("jni/$requestedAbi/") && it.endsWith(".so") &&
                    it.substringAfterLast('/').contains("zstd", ignoreCase = true)
        }
        if (expected.isEmpty()) throw GradleException("BUILD FAILED: ZSTD_AAR_MISSING_$requestedAbi")
        logger.lifecycle("Resolved Zstandard AAR ${aar.name}: ${expected.joinToString()}")
    }
}

tasks.register("verifyNoDirectZstdUsage") {
    group = "verification"
    description = "Keeps all direct zstd-jni calls behind AndroidZstdJniEngine."
    doLast {
        val allowed = file(
            "src/main/java/com/gtav/runtimemanager/compression/zstd/AndroidZstdJniEngine.java"
        ).canonicalFile
        val violations = file("src").walkTopDown()
            .filter { it.isFile && it.extension in setOf("java", "kt") }
            .filter { it.canonicalFile != allowed }
            .filter { source ->
                val text = source.readText()
                Regex("import\\s+com\\.github\\.luben\\.zstd").containsMatchIn(text) ||
                        Regex("\\bnew\\s+ZstdInputStream\\b").containsMatchIn(text) ||
                        Regex("\\bZstd\\.").containsMatchIn(text)
            }.toList()
        if (violations.isNotEmpty()) {
            throw GradleException(
                "Direct Zstandard usage outside the engine:\n" +
                        violations.joinToString("\n") { it.relativeTo(projectDir).path }
            )
        }
    }
}

listOf("debug", "release").forEach { variant ->
    val cap = variant.replaceFirstChar { it.uppercase() }
    tasks.register("verify${cap}NativePackaging") {
        group = "verification"
        dependsOn("assemble$cap", "verifyZstdAarContents", "verifyNoDirectZstdUsage")
        doLast {
            val apks = findVariantApks(variant)
            if (apks.isEmpty()) throw GradleException("BUILD FAILED: APK_NOT_FOUND_$variant")
            apks.forEach { validateApk(it, variant) }
        }
    }
}

tasks.register("validateAllNativePackaging") {
    group = "verification"
    dependsOn("verifyDebugNativePackaging", "verifyReleaseNativePackaging")
}

tasks.named("check") {
    dependsOn("verifyNoDirectZstdUsage")
}
