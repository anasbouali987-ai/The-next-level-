package com.gtav.runtimemanager;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;


/**
 * يبقي عملية الاستخراج الطويلة في Foreground ويحتفظ بـWakeLock جزئي.
 * منطق التثبيت نفسه يبقى داخل RuntimeInstallCoordinator ولا يحتفظ بالخدمة.
 */
public final class RuntimeInstallService extends Service {
    private static final String CHANNEL_ID = "gtav_runtime_install";
    private static final int NOTIFICATION_ID = 1400;
    private static final String ACTION_START = "com.gtav.runtimemanager.START_INSTALL_FGS";
    private static final String ACTION_CANCEL = "com.gtav.runtimemanager.CANCEL_INSTALL";

    private PowerManager.WakeLock wakeLock;

    static void begin(Context context) {
        ensureChannel(context);
        Intent intent = new Intent(context, RuntimeInstallService.class)
                .setAction(ACTION_START);
        context.startForegroundService(intent);
    }

    static void finish(Context context) {
        try {
            context.stopService(new Intent(context, RuntimeInstallService.class));
        } catch (Throwable ignored) {
        }
    }

    @SuppressLint("MissingPermission")
    static void update(Context context, InstallSnapshot snapshot) {
        try {
            ensureChannel(context);

            NotificationManager manager = (NotificationManager)
                    context.getSystemService(Context.NOTIFICATION_SERVICE);
            if (manager == null) return;

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU
                    && context.checkSelfPermission(
                    Manifest.permission.POST_NOTIFICATIONS
            ) != PackageManager.PERMISSION_GRANTED) {
                return;
            }

            manager.notify(
                    NOTIFICATION_ID,
                    buildNotification(context, snapshot)
            );
        } catch (Throwable ignored) {
        }
    }

    @Override
    public void onCreate() {
        super.onCreate();
        ensureChannel(this);
        try {
            PowerManager power = (PowerManager) getSystemService(Context.POWER_SERVICE);
            if (power != null) {
                wakeLock = power.newWakeLock(
                        PowerManager.PARTIAL_WAKE_LOCK,
                        "GTAVRuntimeManager:RuntimeInstall"
                );
                wakeLock.setReferenceCounted(false);
                wakeLock.acquire(6L * 60L * 60L * 1000L);
            }
        } catch (Throwable ignored) {
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        InstallSnapshot snapshot = RuntimeInstallCoordinator.get(this).current();
        startForeground(NOTIFICATION_ID, buildNotification(this, snapshot));
        if (intent != null && ACTION_CANCEL.equals(intent.getAction())) {
            RuntimeInstallCoordinator.get(this).cancel();
        }
        return START_NOT_STICKY;
    }

    @Override
    public void onDestroy() {
        try {
            if (wakeLock != null && wakeLock.isHeld()) wakeLock.release();
        } catch (Throwable ignored) {
        }
        stopForeground(STOP_FOREGROUND_REMOVE);
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    private static Notification buildNotification(Context context, InstallSnapshot snapshot) {
        long total = snapshot == null ? 0 : snapshot.total;
        long done = snapshot == null ? 0 : snapshot.done;
        int percent = total > 0 ? (int) Math.min(100, done * 100L / total) : 0;
        String stage = snapshot == null ? "تجهيز التثبيت" : snapshot.stage.label;
        String text = total > 0
                ? stage + " — " + percent + "%"
                : stage;

        Intent cancel = new Intent(context, RuntimeInstallService.class)
                .setAction(ACTION_CANCEL);
        PendingIntent cancelAction = PendingIntent.getService(
                context,
                1401,
                cancel,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        Notification.Builder builder = new Notification.Builder(context, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.stat_sys_download)
                .setContentTitle("GTAV Runtime Manager")
                .setContentText(text)
                .setOnlyAlertOnce(true)
                .setOngoing(snapshot == null || snapshot.running)
                .setCategory(Notification.CATEGORY_PROGRESS)
                .addAction(android.R.drawable.ic_menu_close_clear_cancel,
                        "إلغاء", cancelAction);

        if (total > 0) {
            builder.setProgress(100, percent, false);
        } else {
            builder.setProgress(0, 0, true);
        }
        return builder.build();
    }

    private static void ensureChannel(Context context) {
        NotificationManager manager = (NotificationManager)
                context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (manager == null) return;
        NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID,
                "تثبيت GTAV Runtime",
                NotificationManager.IMPORTANCE_LOW
        );
        channel.setDescription("تقدم التحقق والاستخراج والتثبيت الذري");
        manager.createNotificationChannel(channel);
    }
}
