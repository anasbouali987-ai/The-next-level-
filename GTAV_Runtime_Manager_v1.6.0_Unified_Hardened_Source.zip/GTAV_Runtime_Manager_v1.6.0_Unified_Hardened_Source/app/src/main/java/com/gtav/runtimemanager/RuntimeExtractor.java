package com.gtav.runtimemanager;

import android.system.Os;


import org.apache.commons.compress.archivers.tar.TarArchiveEntry;
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.RandomAccessFile;
import java.nio.charset.StandardCharsets;
import java.util.Base64;

final class RuntimeExtractor {
    private static final int BUFFER_SIZE = 256 * 1024;
    private final CompressionManager compressionManager;

    RuntimeExtractor(CompressionManager compressionManager) {
        this.compressionManager = compressionManager;
    }

    InstallStats extract(PackageReader reader, PackageInfo pkg, File tempRoot,
                         CancellationToken token, InstallProgressSink progress,
                         RuntimeLogWriter log) throws RuntimeInstallException {
        InstallStats stats = new InstallStats();
        File metadataDir = new File(tempRoot, ".installer");
        if (!metadataDir.mkdirs()) {
            throw new RuntimeInstallException(InstallErrorCode.TEMP_DIRECTORY_FAILED,
                    InstallStage.PREPARING, "تعذر إنشاء مجلد بيانات التثبيت");
        }
        File symlinkFile = new File(metadataDir, "symlinks.tsv");
        File hardlinkFile = new File(metadataDir, "hardlinks.tsv");
        File directoryModeFile = new File(metadataDir, "directory_modes.tsv");
        PermissionApplier permissions = new PermissionApplier(new PermissionApplier.AndroidOps());

        String zstdStatus = "جارٍ التهيئة";
        String tarStatus = "جارٍ التهيئة";

        try (BufferedWriter symlinks = new BufferedWriter(new FileWriter(symlinkFile));
             BufferedWriter hardlinks = new BufferedWriter(new FileWriter(hardlinkFile));
             BufferedWriter directoryModes = new BufferedWriter(new FileWriter(directoryModeFile));
             SeekableZipReader zip = reader.open(pkg.uri)) {

            if (!zip.contains(pkg.manifest.payload.path)) {
                throw new RuntimeInstallException(
                        InstallErrorCode.PAYLOAD_NOT_FOUND,
                        InstallStage.OPENING_PACKAGE,
                        "Payload غير موجود: " + pkg.manifest.payload.path
                );
            }
            progress.update(InstallStage.OPENING_PACKAGE, 0,
                    pkg.manifest.expectedStats.fileBytes, 0, stats,
                    pkg.manifest.payload.path, zstdStatus, tarStatus,
                    "تم فتح الحزمة", true);
            log.log("PACKAGE_OPENED payload=" + pkg.manifest.payload.path);

            try (InputStream payload = zip.openEntry(pkg.manifest.payload.path);
                 CountingInputStream compressed = new CountingInputStream(
                         new BufferedInputStream(payload, BUFFER_SIZE));
                 InputStream zstd = compressionManager.openZstdStream(compressed, InstallStage.STARTING_ZSTD);
                 TarArchiveInputStream tar = new TarArchiveInputStream(
                         new BufferedInputStream(zstd, BUFFER_SIZE))) {

                zstdStatus = "جاهز";
                progress.update(InstallStage.STARTING_ZSTD, 0,
                        pkg.manifest.expectedStats.fileBytes, compressed.count, stats,
                        pkg.manifest.payload.path, zstdStatus, tarStatus,
                        "محرك Zstandard جاهز", true);
                log.log("ZSTD_STREAM_OPENED");

                tarStatus = "جاهز";
                progress.update(InstallStage.READING_TAR, 0,
                        pkg.manifest.expectedStats.fileBytes, compressed.count, stats,
                        pkg.manifest.payload.path, zstdStatus, tarStatus,
                        "قارئ TAR جاهز", true);
                log.log("TAR_STREAM_OPENED");

                byte[] buffer = new byte[BUFFER_SIZE];
                TarArchiveEntry entry;
                long lastLoggedNodes = 0;
                while ((entry = tar.getNextTarEntry()) != null) {
                    token.throwIfCancelled(InstallStage.EXTRACTING);
                    String rawName = entry.getName();
                    if (".".equals(rawName) || "./".equals(rawName)) {
                        continue;
                    }
                    String relative;
                    try {
                        RuntimeManifest.validateRelative(rawName);
                        relative = RuntimeManifest.normalize(rawName);
                    } catch (IllegalArgumentException unsafe) {
                        throw new RuntimeInstallException(
                                InstallErrorCode.TAR_UNSAFE_PATH,
                                InstallStage.EXTRACTING,
                                unsafe.getMessage(), rawName, unsafe);
                    }
                    File output = RuntimePaths.safeChild(tempRoot, relative);
                    RuntimePaths.ensureParentsAreNotSymlinks(tempRoot, output);

                    if (entry.isDirectory()) {
                        ensureDirectory(output, relative);
                        writeMode(directoryModes, relative, entry.getMode());
                        stats.directories++;
                    } else if (entry.isSymbolicLink()) {
                        ensureParent(output, relative);
                        writeLink(symlinks, relative, entry.getLinkName());
                        stats.symlinks++;
                    } else if (entry.isLink()) {
                        ensureParent(output, relative);
                        String rawTarget = entry.getLinkName();
                        String target;
                        try {
                            RuntimeManifest.validateRelative(rawTarget);
                            target = RuntimeManifest.normalize(rawTarget);
                        } catch (IllegalArgumentException unsafe) {
                            throw new RuntimeInstallException(
                                    InstallErrorCode.TAR_UNSAFE_PATH,
                                    InstallStage.EXTRACTING,
                                    "هدف Hard Link غير آمن: " + rawTarget,
                                    relative, unsafe);
                        }
                        writeLink(hardlinks, relative, target);
                        stats.hardLinks++;
                    } else if (entry.isFile()) {
                        ensureParent(output, relative);
                        deleteExistingNoFollow(tempRoot, output);
                        long fileBytes = 0;
                        try (OutputStream fileOutput = new BufferedOutputStream(
                                new FileOutputStream(output, false), BUFFER_SIZE)) {
                            int read;
                            while ((read = tar.read(buffer)) != -1) {
                                token.throwIfCancelled(InstallStage.EXTRACTING);
                                fileOutput.write(buffer, 0, read);
                                fileBytes += read;
                                stats.writtenBytes += read;
                                progress.update(InstallStage.EXTRACTING,
                                        stats.writtenBytes,
                                        Math.max(1, pkg.manifest.expectedStats.fileBytes),
                                        compressed.count,
                                        stats,
                                        relative,
                                        zstdStatus,
                                        tarStatus,
                                        "استخراج الملفات",
                                        false);
                            }
                        } catch (RuntimeInstallException error) {
                            throw error;
                        } catch (Throwable error) {
                            throw new RuntimeInstallException(
                                    InstallErrorCode.FILE_WRITE_FAILED,
                                    InstallStage.EXTRACTING,
                                    "تعذر كتابة الملف: " + relative,
                                    relative,
                                    error
                            );
                        }
                        if (entry.getSize() >= 0 && fileBytes != entry.getSize()) {
                            throw new RuntimeInstallException(
                                    InstallErrorCode.FILE_WRITE_FAILED,
                                    InstallStage.EXTRACTING,
                                    "حجم الملف المستخرج لا يطابق TAR: " + relative,
                                    relative,
                                    null
                            );
                        }
                        permissions.apply(output, entry.getMode(), InstallStage.EXTRACTING);
                        stats.files++;
                    } else {
                        throw new RuntimeInstallException(
                                InstallErrorCode.UNSUPPORTED_TAR_ENTRY,
                                InstallStage.EXTRACTING,
                                "نوع TAR غير مدعوم: " + relative,
                                relative,
                                null
                        );
                    }

                    if (stats.totalNodes() - lastLoggedNodes >= 50) {
                        lastLoggedNodes = stats.totalNodes();
                        log.log("EXTRACT_PROGRESS nodes=" + stats.totalNodes() +
                                " bytes=" + stats.writtenBytes + " current=" + relative);
                    }
                    progress.update(InstallStage.EXTRACTING,
                            stats.writtenBytes,
                            Math.max(1, pkg.manifest.expectedStats.fileBytes),
                            compressed.count,
                            stats,
                            relative,
                            zstdStatus,
                            tarStatus,
                            "استخراج RootFS",
                            false);
                }
            } catch (RuntimeInstallException error) {
                throw error;
            } catch (UnsatisfiedLinkError error) {
                throw new RuntimeInstallException(
                        InstallErrorCode.ZSTD_NATIVE_LIBRARY_FAILED,
                        InstallStage.STARTING_ZSTD,
                        "تعذر تحميل مكتبة Zstandard الأصلية",
                        error
                );
            } catch (OutOfMemoryError error) {
                throw new RuntimeInstallException(
                        InstallErrorCode.OUT_OF_MEMORY,
                        InstallStage.EXTRACTING,
                        "نفدت ذاكرة التطبيق أثناء الاستخراج",
                        error
                );
            } catch (Throwable error) {
                throw new RuntimeInstallException(
                        InstallErrorCode.TAR_INVALID,
                        InstallStage.EXTRACTING,
                        "تعذر فك Zstandard أو قراءة TAR: " + message(error),
                        error
                );
            }
        } catch (RuntimeInstallException error) {
            throw error;
        } catch (Throwable error) {
            throw new RuntimeInstallException(
                    InstallErrorCode.ZIP_OPEN_FAILED,
                    InstallStage.OPENING_PACKAGE,
                    "تعذر فتح حزمة Runtime: " + message(error),
                    error
            );
        }

        createHardLinks(tempRoot, hardlinkFile, stats, token, progress, log);
        createSymlinks(tempRoot, symlinkFile, stats, token, progress, log);
        applyDirectoryModesReverse(tempRoot, directoryModeFile, permissions, token, progress, stats, log);
        FileTools.deleteTreeQuietly(tempRoot, metadataDir, log);

        progress.update(InstallStage.APPLYING_PERMISSIONS,
                stats.writtenBytes,
                Math.max(1, pkg.manifest.expectedStats.fileBytes),
                pkg.manifest.payload.sizeBytes,
                stats,
                "",
                "جاهز",
                "جاهز",
                "اكتمل الاستخراج وتطبيق بيانات Unix",
                true);
        log.log("EXTRACTION_COMPLETE files=" + stats.files +
                " dirs=" + stats.directories +
                " symlinks=" + stats.symlinks +
                " hardlinks=" + stats.hardLinks +
                " bytes=" + stats.writtenBytes);
        return stats;
    }

    private static void createHardLinks(File root, File metadata, InstallStats stats,
                                        CancellationToken token, InstallProgressSink progress,
                                        RuntimeLogWriter log) throws RuntimeInstallException {
        progress.update(InstallStage.CREATING_HARDLINKS, stats.writtenBytes,
                Math.max(1, stats.writtenBytes), 0, stats, "", "جاهز", "جاهز",
                "إنشاء Hard Links", true);
        if (!metadata.isFile()) return;
        try (BufferedReader reader = new BufferedReader(new FileReader(metadata))) {
            String line;
            while ((line = reader.readLine()) != null) {
                token.throwIfCancelled(InstallStage.CREATING_HARDLINKS);
                String[] parts = line.split("\\t", 2);
                if (parts.length != 2) continue;
                String relative = decode(parts[0]);
                String targetRelative = decode(parts[1]);
                File output = RuntimePaths.safeChild(root, relative);
                File target = RuntimePaths.safeChild(root, targetRelative);
                RuntimePaths.ensureParentsAreNotSymlinks(root, output);
                if (!FileTools.existsNoFollow(target)) {
                    throw new RuntimeInstallException(
                            InstallErrorCode.HARDLINK_FAILED,
                            InstallStage.CREATING_HARDLINKS,
                            "هدف Hard Link مفقود: " + targetRelative,
                            relative,
                            null
                    );
                }
                deleteExistingNoFollow(root, output);
                try {
                    Os.link(target.getAbsolutePath(), output.getAbsolutePath());
                    stats.hardLinkLogicalBytes += Math.max(0,
                            Os.lstat(target.getAbsolutePath()).st_size);
                } catch (Throwable error) {
                    throw new RuntimeInstallException(
                            InstallErrorCode.HARDLINK_FAILED,
                            InstallStage.CREATING_HARDLINKS,
                            "تعذر إنشاء Hard Link: " + relative,
                            relative,
                            error
                    );
                }
                progress.update(InstallStage.CREATING_HARDLINKS, stats.writtenBytes,
                        Math.max(1, stats.writtenBytes), 0, stats, relative,
                        "جاهز", "جاهز", "إنشاء Hard Links", false);
            }
        } catch (RuntimeInstallException error) {
            throw error;
        } catch (Throwable error) {
            throw new RuntimeInstallException(InstallErrorCode.HARDLINK_FAILED,
                    InstallStage.CREATING_HARDLINKS, "فشل معالجة Hard Links", error);
        }
        log.log("HARDLINKS_CREATED count=" + stats.hardLinks);
    }

    private static void createSymlinks(File root, File metadata, InstallStats stats,
                                       CancellationToken token, InstallProgressSink progress,
                                       RuntimeLogWriter log) throws RuntimeInstallException {
        progress.update(InstallStage.CREATING_SYMLINKS, stats.writtenBytes,
                Math.max(1, stats.writtenBytes), 0, stats, "", "جاهز", "جاهز",
                "إنشاء Symlinks", true);
        if (!metadata.isFile()) return;
        try (BufferedReader reader = new BufferedReader(new FileReader(metadata))) {
            String line;
            while ((line = reader.readLine()) != null) {
                token.throwIfCancelled(InstallStage.CREATING_SYMLINKS);
                String[] parts = line.split("\\t", 2);
                if (parts.length != 2) continue;
                String relative = decode(parts[0]);
                String target = decode(parts[1]);
                File output = RuntimePaths.safeChild(root, relative);
                RuntimePaths.ensureParentsAreNotSymlinks(root, output);
                deleteExistingNoFollow(root, output);
                try {
                    Os.symlink(target, output.getAbsolutePath());
                    String actual = Os.readlink(output.getAbsolutePath());
                    if (!target.equals(actual)) {
                        throw new IOException("هدف الرابط بعد الإنشاء لا يطابق TAR");
                    }
                } catch (Throwable error) {
                    throw new RuntimeInstallException(
                            InstallErrorCode.SYMLINK_FAILED,
                            InstallStage.CREATING_SYMLINKS,
                            "تعذر إنشاء Symlink: " + relative + " → " + target,
                            relative,
                            error
                    );
                }
                progress.update(InstallStage.CREATING_SYMLINKS, stats.writtenBytes,
                        Math.max(1, stats.writtenBytes), 0, stats, relative,
                        "جاهز", "جاهز", "إنشاء Symlinks", false);
            }
        } catch (RuntimeInstallException error) {
            throw error;
        } catch (Throwable error) {
            throw new RuntimeInstallException(InstallErrorCode.SYMLINK_FAILED,
                    InstallStage.CREATING_SYMLINKS, "فشل معالجة Symlinks", error);
        }
        log.log("SYMLINKS_CREATED count=" + stats.symlinks);
    }

    private static void applyDirectoryModesReverse(File root, File metadata,
                                                   PermissionApplier permissions,
                                                   CancellationToken token,
                                                   InstallProgressSink progress,
                                                   InstallStats stats,
                                                   RuntimeLogWriter log)
            throws RuntimeInstallException {
        progress.update(InstallStage.APPLYING_PERMISSIONS, stats.writtenBytes,
                Math.max(1, stats.writtenBytes), 0, stats, "", "جاهز", "جاهز",
                "تطبيق صلاحيات المجلدات", true);
        if (!metadata.isFile()) return;
        try (RandomAccessFile random = new RandomAccessFile(metadata, "r")) {
            long pointer = random.length() - 1;
            StringBuilder line = new StringBuilder(256);
            while (pointer >= 0) {
                token.throwIfCancelled(InstallStage.APPLYING_PERMISSIONS);
                random.seek(pointer--);
                int value = random.read();
                if (value == '\n' || pointer < 0) {
                    if (pointer < 0 && value != '\n' && value != '\r') line.append((char) value);
                    if (line.length() > 0) {
                        String reversed = line.reverse().toString();
                        applyDirectoryModeLine(root, reversed, permissions);
                        line.setLength(0);
                    }
                } else if (value != '\r') {
                    line.append((char) value);
                }
            }
        } catch (RuntimeInstallException error) {
            throw error;
        } catch (Throwable error) {
            throw new RuntimeInstallException(InstallErrorCode.CHMOD_FAILED,
                    InstallStage.APPLYING_PERMISSIONS,
                    "فشل تطبيق صلاحيات المجلدات", error);
        }
        log.log("DIRECTORY_MODES_APPLIED count=" + stats.directories);
    }

    private static void applyDirectoryModeLine(File root, String line,
                                               PermissionApplier permissions)
            throws RuntimeInstallException, IOException {
        String[] parts = line.split("\\t", 2);
        if (parts.length != 2) return;
        int mode = Integer.parseInt(parts[0]);
        String relative = decode(parts[1]);
        File directory = RuntimePaths.safeChild(root, relative);
        permissions.apply(directory, mode, InstallStage.APPLYING_PERMISSIONS);
    }

    private static void ensureDirectory(File directory, String relative)
            throws RuntimeInstallException {
        try {
            if (FileTools.existsNoFollow(directory)) {
                if (!FileTools.isDirectoryNoFollow(directory)) {
                    throw new IOException("المسار موجود وليس مجلدًا");
                }
                return;
            }
            if (!directory.mkdirs()) throw new IOException("mkdirs returned false");
        } catch (Throwable error) {
            throw new RuntimeInstallException(InstallErrorCode.FILE_WRITE_FAILED,
                    InstallStage.EXTRACTING, "تعذر إنشاء المجلد: " + relative,
                    relative, error);
        }
    }

    private static void ensureParent(File output, String relative)
            throws RuntimeInstallException {
        File parent = output.getParentFile();
        if (parent == null) return;
        try {
            if (!parent.exists() && !parent.mkdirs()) {
                throw new IOException("mkdirs returned false");
            }
        } catch (Throwable error) {
            throw new RuntimeInstallException(InstallErrorCode.FILE_WRITE_FAILED,
                    InstallStage.EXTRACTING, "تعذر إنشاء المجلد الأب: " + relative,
                    relative, error);
        }
    }

    private static void deleteExistingNoFollow(File root, File output)
            throws RuntimeInstallException {
        try {
            if (FileTools.existsNoFollow(output)) {
                FileTools.deleteTree(root, output);
            }
        } catch (Throwable error) {
            throw new RuntimeInstallException(InstallErrorCode.FILE_WRITE_FAILED,
                    InstallStage.EXTRACTING, "تعذر استبدال المسار: " + output.getAbsolutePath(),
                    output.getAbsolutePath(), error);
        }
    }

    private static void writeMode(BufferedWriter writer, String relative, int mode)
            throws IOException {
        writer.write(Integer.toString(mode));
        writer.write('\t');
        writer.write(encode(relative));
        writer.newLine();
    }

    private static void writeLink(BufferedWriter writer, String relative, String target)
            throws IOException {
        writer.write(encode(relative));
        writer.write('\t');
        writer.write(encode(target == null ? "" : target));
        writer.newLine();
    }

    private static String encode(String value) {
        return Base64.getUrlEncoder().withoutPadding()
                .encodeToString(value.getBytes(StandardCharsets.UTF_8));
    }

    private static String decode(String value) {
        return new String(Base64.getUrlDecoder().decode(value), StandardCharsets.UTF_8);
    }

    private static String message(Throwable error) {
        return error.getMessage() == null ? error.getClass().getSimpleName() : error.getMessage();
    }
}
