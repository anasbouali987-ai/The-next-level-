package com.gtav.runtimemanager.compression.zstd;

import java.io.InputStream;

/** Reserved adapter for a future app-owned NDK bridge. It is never selected in v1.6.0. */
public final class NdkZstdEngine implements ZstdEngine {
    private UnsupportedOperationException unavailable() {
        return new UnsupportedOperationException("The app-owned NDK Zstandard engine is not enabled");
    }

    @Override public String engineName() { return "libgtav_zstd.so (future adapter)"; }
    @Override public String dependencyVersion() { return "not-enabled"; }
    @Override public String nativeVersion() { throw unavailable(); }
    @Override public InputStream openDecompressionStream(InputStream source) { throw unavailable(); }
    @Override public ZstdHealthResult runRoundTripTest() {
        return ZstdHealthResult.failure("ZSTD_ENGINE_DISABLED", unavailable().getMessage(), null);
    }
    @Override public ZstdHealthResult runStreamingTest() {
        return ZstdHealthResult.failure("ZSTD_ENGINE_DISABLED", unavailable().getMessage(), null);
    }
}
