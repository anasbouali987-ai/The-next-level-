package com.gtav.runtimemanager;

import android.content.Context;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

final class DiagnosticsExporter {
    private DiagnosticsExporter() {}

    static File create(Context context, PackageInfo pkg) throws Exception {
        File output = new File(context.getCacheDir(), "GTAV_Runtime_Diagnostics.zip");
        if (output.exists()) output.delete();

        Map<String, File> files = new LinkedHashMap<>();
        files.put("reports/verification_report.txt", RuntimeLogWriter.verificationReport(context));
        files.put("reports/installation_report.txt", RuntimeLogWriter.installationReport(context));
        files.put("logs/install.log", RuntimeLogWriter.lastInstallLog(context));
        files.put("reports/crash_report.txt", RuntimeCrashReporter.file(context));
        files.put("reports/diagnostic_report.txt", RuntimeLogWriter.diagnosticReport(context));
        files.put("reports/install_state.json", RuntimeLogWriter.lastInstallState(context));
        files.put("reports/install_journal.jsonl", new File(RuntimeLogWriter.reportsDir(context), "install_journal.jsonl"));
        files.put("reports/watchdog_report.txt", new File(RuntimeLogWriter.reportsDir(context), "watchdog_report.txt"));
        files.put("reports/startup_diagnostic.txt", StartupDiagnostic.reportFile(context));

        if (pkg != null) {
            InstalledRuntime installed = InstalledRuntime.find(
                    StorageLocations.runtimesRoot(context), pkg.manifest.runtimeId);
            if (installed != null) {
                files.put("runtime/installed_runtime.json",
                        new File(installed.path, "installed_runtime.json"));
                files.put("runtime/install_state.json",
                        new File(installed.path, "install_state.json"));
            }
        }

        try (ZipOutputStream zip = new ZipOutputStream(
                new BufferedOutputStream(new FileOutputStream(output), 128 * 1024))) {
            byte[] buffer = new byte[128 * 1024];
            for (Map.Entry<String, File> item : files.entrySet()) {
                File file = item.getValue();
                if (file == null || !file.isFile()) continue;
                zip.putNextEntry(new ZipEntry(item.getKey()));
                try (BufferedInputStream input = new BufferedInputStream(
                        new FileInputStream(file), 128 * 1024)) {
                    int read;
                    while ((read = input.read(buffer)) != -1) zip.write(buffer, 0, read);
                }
                zip.closeEntry();
            }

            if (pkg != null) {
                zip.putNextEntry(new ZipEntry("runtime/runtime_manifest.json"));
                java.io.OutputStreamWriter manifestWriter =
                        new java.io.OutputStreamWriter(zip, StandardCharsets.UTF_8);
                manifestWriter.write(pkg.manifest.rawJson);
                manifestWriter.flush();
                zip.closeEntry();
            }

            zip.putNextEntry(new ZipEntry("diagnostics/device_summary.txt"));
            MemorySnapshot memory = MemorySnapshot.capture();
            NativeLibraryManager.Report nativeReport = new NativeLibraryManager().inspect(context, "diagnostics export");
            String summary = "App version: " + BuildConfig.VERSION_NAME + "\n" +
                    "Android API: " + android.os.Build.VERSION.SDK_INT + "\n" +
                    "Device: " + android.os.Build.MANUFACTURER + " " + android.os.Build.MODEL + "\n" +
                    "ABIs: " + java.util.Arrays.toString(android.os.Build.SUPPORTED_ABIS) + "\n" +
                    "Memory free: " + memory.freeBytes + "\n" +
                    "Memory used: " + memory.usedBytes + "\n" +
                    "Memory max: " + memory.maxBytes + "\n" +
                    "Requested ABI: " + BuildConfig.REQUESTED_ABI + "\n" +
                    "Zstd dependency: " + BuildConfig.ZSTD_DEPENDENCY_VERSION + "\n\n" +
                    nativeReport.format();
            zip.write(summary.getBytes(StandardCharsets.UTF_8));
            zip.closeEntry();
        }
        return output;
    }
}
