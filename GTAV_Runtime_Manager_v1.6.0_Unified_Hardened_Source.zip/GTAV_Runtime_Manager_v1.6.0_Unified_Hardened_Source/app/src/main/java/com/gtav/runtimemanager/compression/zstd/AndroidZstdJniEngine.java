package com.gtav.runtimemanager.compression.zstd;

import com.github.luben.zstd.Zstd;
import com.github.luben.zstd.ZstdInputStream;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;

/** Production Android AAR implementation. No other application class may call zstd-jni directly. */
public final class AndroidZstdJniEngine implements ZstdEngine {
    public static final String DEPENDENCY_VERSION = "1.5.7-3";
    private static final int TEST_LEVEL = 3;
    private static final int MAX_PROBE_OUTPUT = 64 * 1024;
    private static final byte[] PROBE = (
            "GTAV_RUNTIME_MANAGER_ZSTD_HEALTH_CHECK_V1_6_0|" +
                    "round-trip|streaming|arm64-v8a"
    ).getBytes(StandardCharsets.UTF_8);

    @Override public String engineName() { return "zstd-jni Android AAR"; }
    @Override public String dependencyVersion() { return DEPENDENCY_VERSION; }
    @Override public String nativeVersion() { return String.valueOf(Zstd.versionNumber()); }

    @Override
    public InputStream openDecompressionStream(InputStream source) throws Exception {
        if (source == null) throw new IllegalArgumentException("source == null");
        return new ZstdInputStream(source);
    }

    @Override
    public ZstdHealthResult runRoundTripTest() {
        try {
            byte[] compressed = Zstd.compress(PROBE, TEST_LEVEL);
            byte[] restored = new byte[PROBE.length];
            long written = Zstd.decompress(restored, compressed);
            if (Zstd.isError(written)) {
                return ZstdHealthResult.failure(
                        "ZSTD_ROUND_TRIP_FAILED",
                        "native error: " + Zstd.getErrorName(written),
                        null
                );
            }
            if (written != PROBE.length || !Arrays.equals(PROBE, restored)) {
                return ZstdHealthResult.failure(
                        "ZSTD_ROUND_TRIP_FAILED",
                        "data mismatch; expected=" + PROBE.length + ", written=" + written,
                        null
                );
            }
            return ZstdHealthResult.success(
                    "round-trip ok; dependency=" + dependencyVersion() +
                            "; native=" + nativeVersion() +
                            "; compressed=" + compressed.length + " bytes"
            );
        } catch (Throwable error) {
            return ZstdHealthResult.failure(
                    ZstdErrorClassifier.classify(error),
                    ZstdErrorClassifier.describe(error),
                    error
            );
        }
    }

    @Override
    public ZstdHealthResult runStreamingTest() {
        try {
            byte[] compressed = Zstd.compress(PROBE, TEST_LEVEL);
            ByteArrayOutputStream output = new ByteArrayOutputStream(PROBE.length);
            try (InputStream input = openDecompressionStream(new ByteArrayInputStream(compressed))) {
                byte[] buffer = new byte[256];
                int read;
                while ((read = input.read(buffer)) != -1) {
                    if (read == 0) continue;
                    if (output.size() + read > MAX_PROBE_OUTPUT) {
                        return ZstdHealthResult.failure(
                                "ZSTD_STREAM_TEST_FAILED",
                                "health-check output exceeded limit",
                                null
                        );
                    }
                    output.write(buffer, 0, read);
                }
            }
            if (!Arrays.equals(PROBE, output.toByteArray())) {
                return ZstdHealthResult.failure(
                        "ZSTD_STREAM_TEST_FAILED",
                        "stream data mismatch",
                        null
                );
            }
            return ZstdHealthResult.success("streaming ok; output=" + output.size() + " bytes");
        } catch (Throwable error) {
            return ZstdHealthResult.failure(
                    ZstdErrorClassifier.classify(error),
                    ZstdErrorClassifier.describe(error),
                    error
            );
        }
    }
}
