#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT"

"$ROOT/tools/verify-source-boundaries.sh"

if [[ -x "$ROOT/gradlew" ]]; then
  GRADLE=("$ROOT/gradlew")
elif command -v gradle >/dev/null 2>&1; then
  GRADLE=(gradle)
else
  echo "Gradle غير موجود. افتح المشروع في Android Studio أو ثبّت Gradle 8.11.1." >&2
  exit 2
fi

"${GRADLE[@]}" --no-daemon clean testDebugUnitTest lintDebug validateAllNativePackaging
cat <<'MSG'
نجحت بوابات المصدر والبناء وNative Packaging.
الخطوة الإلزامية المتبقية لاعتماد الجهاز:
  gradle connectedDebugAndroidTest
MSG
