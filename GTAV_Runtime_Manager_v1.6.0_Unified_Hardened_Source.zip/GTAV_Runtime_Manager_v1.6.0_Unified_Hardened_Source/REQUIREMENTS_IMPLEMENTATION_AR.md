# مطابقة متطلبات v1.6.0

## الاعتمادية

- Foreground Service من نوع `dataSync` مع WakeLock محدود وتحرير حتمي.
- Executor منفصل عن UI وإلغاء منظم عبر `CancellationToken`.
- Journal متتابع، Watchdog تشخيصي، وRecovery عند بدء التطبيق.
- Global crash handler وتقارير Stack trace والمرحلة والذاكرة.

## الضغط والمكتبات الأصلية

- Android AAR هو محرك الإنتاج الوحيد.
- كل استدعاءات Zstandard خلف `ZstdEngine`.
- Error codes منفصلة لـABI وPackaging و`dlopen` وJNI init وRound-trip وStreaming.
- فحص AAR قبل البناء وفحص APK بعد البناء.

## المنصة والتخزين

- API 26 كحد أدنى وABI المطلوب `arm64-v8a`.
- ContentResolver وDocumentFile/SAF.
- write + `fsync` + chmod + Symlink + Atomic rename.
- فحص المساحة وحالة التخزين وSELinux وTAR engine.
- إعادة الاختبار على Runtime root الفعلي قبل التثبيت.

## الأمان والتكامل

- SHA-256 متدفق للـPayload.
- رفض Path Traversal والمسارات المطلقة ومسارات Windows.
- منع الكتابة عبر Symlink parent.
- استخراج إلى `.installing` ثم Post verification ثم Atomic promotion.
- Rollback من `.backup` عند فشل الترقية.
- حذف آمن لا يتبع الروابط.

## الذاكرة والأداء

- Payload → Zstd → TAR → output بأسلوب Streaming.
- Buffer استخراج ثابت 256 KiB.
- عدم الاحتفاظ بقائمة RootFS كاملة.
- تحديث تقدم مخنوق بدل تحديث الواجهة لكل Byte.
- التقارير والـmetadata الكبيرة تُكتب مباشرة إلى القرص.
