# مصفوفة تنفيذ المشروع الخامس

| المجال | التنفيذ | مصدر الفكرة الأساسي |
|---|---|---|
| واجهة الضغط | `CompressionManager.java` | 2 + 4 |
| عقد المحرك | `compression/zstd/ZstdEngine.java` | 2 |
| محرك الإنتاج | `AndroidZstdJniEngine.java` | 2 + 4 |
| محول NDK المستقبلي | `NdkZstdEngine.java` معطّل بوضوح | 1 + 2 |
| تصنيف أخطاء JNI | `ZstdErrorClassifier.java` + `InstallErrorCode.java` | 4 |
| Round-trip وStreaming | داخل المحرك، Startup، وPreflight | 1 + 4 |
| فحص المكتبات الأصلية | `NativeLibraryManager.java` | 3 + 4 |
| فحص المنصة وSAF | `RuntimePlatformValidator.java` | 3 |
| تشخيص بدء التشغيل | `StartupDiagnostic.java` | 3 |
| فحص مسار التثبيت والحزمة | `RuntimePreflightChecker.java` | 1 + 3 + 4 |
| استخراج Streaming | `RuntimeExtractor.java` | جميع التجارب |
| التثبيت الذري وRollback | `AtomicRuntimeSwap.java` | الأساس المشترك |
| Journal وWatchdog وRecovery | ملفات Runtime reliability | 1/3 |
| التقارير والانهيار | `RuntimeLogWriter`, `RuntimeCrashReporter`, `DiagnosticsExporter` | 1 + 3 |
| منع Zstd المباشر | Gradle task + `tools/verify-source-boundaries.sh` | 2 + 4 |
| فحص AAR | `verifyZstdAarContents` | 2 + 4 |
| فحص APK Debug/Release | `validateAllNativePackaging` | 1 + 4 |
| SHA-256 وتقارير البناء | `APK_NATIVE_LIBS`, `BUILD_INFO`, `SHA256SUMS` | 1 + 4 |
| Unit tests | 11 ملفات اختبار | جميع التجارب + إضافات المشروع الخامس |
| Instrumented tests | Platform + ARM64 Zstd + TAR.ZST | 3 + 4 |
