#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
OUT="$ROOT/app/src/main/assets/execution/hello-x86_64"
mkdir -p "$(dirname "$OUT")"
CC="${X86_64_CC:-gcc}"
"$CC" -O2 -static -s "$ROOT/tools/hello-x86_64.c" -o "$OUT"
python3 - "$OUT" <<'PY'
import pathlib, struct, sys
b=pathlib.Path(sys.argv[1]).read_bytes()[:20]
if len(b)<20 or b[:4] != b'\x7fELF': raise SystemExit('X86_64_TEST_NOT_ELF')
m=struct.unpack('<H' if b[5] == 1 else '>H', b[18:20])[0]
if m != 62: raise SystemExit(f'X86_64_TEST_WRONG_ABI: {m}')
PY
chmod 0755 "$OUT"
sha256sum "$OUT"
