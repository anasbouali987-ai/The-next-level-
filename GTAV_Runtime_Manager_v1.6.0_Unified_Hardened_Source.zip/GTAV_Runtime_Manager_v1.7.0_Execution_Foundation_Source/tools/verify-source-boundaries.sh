#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
SRC="$ROOT/app/src"
ALLOWED_ZSTD='app/src/main/java/com/gtav/runtimemanager/compression/zstd/AndroidZstdJniEngine.java'

violations="$({
  grep -RIlE 'import[[:space:]]+com\.github\.luben\.zstd|\bnew[[:space:]]+ZstdInputStream\b|\bZstd\.' \
    "$SRC" --include='*.java' --include='*.kt' || true
} | sed "s#^$ROOT/##" | grep -vFx "$ALLOWED_ZSTD" || true)"

if [[ -n "$violations" ]]; then
  echo "Direct Zstandard usage outside AndroidZstdJniEngine:" >&2
  echo "$violations" >&2
  exit 1
fi

main_activity="$ROOT/app/src/main/java/com/gtav/runtimemanager/MainActivity.java"
count="$(grep -c 'protected void onDestroy()' "$main_activity" || true)"
if [[ "$count" != "1" ]]; then
  echo "Expected exactly one MainActivity.onDestroy(), found $count" >&2
  exit 1
fi

if grep -RInE 'GTAV Runtime Manager v1\.(4|5|6)|versionName[[:space:]]*=[[:space:]]*"1\.(4|5|6)' \
  "$ROOT/app/src" "$ROOT/app/build.gradle.kts"; then
  echo "Stale application version found in runtime source/build files" >&2
  exit 1
fi

# Installation Domain may cross into Execution Domain only through the UI and provider bridge.
execution_imports="$({
  grep -RIl 'com.gtav.runtimemanager.execution' \
    "$ROOT/app/src/main/java/com/gtav/runtimemanager" --include='*.java' --include='*.kt' || true
} | grep -v '/execution/' | sed "s#^$ROOT/##" | \
  grep -vFx 'app/src/main/java/com/gtav/runtimemanager/MainActivity.java' | \
  grep -vFx 'app/src/main/java/com/gtav/runtimemanager/InstalledRuntimeProvider.java' || true)"
if [[ -n "$execution_imports" ]]; then
  echo "Installation Domain imports Execution internals:" >&2
  echo "$execution_imports" >&2
  exit 1
fi

if grep -RInE '\b(RuntimeInstaller|RuntimeExtractor|AtomicRuntimeSwap|RuntimeInstallCoordinator|RuntimePreflightChecker)\b' \
  "$ROOT/app/src/main/java/com/gtav/runtimemanager/execution" --include='*.java' --include='*.kt'; then
  echo "Execution Domain depends on Installation internals" >&2
  exit 1
fi

HELLO="$ROOT/app/src/main/assets/execution/hello-x86_64"
python3 - "$HELLO" <<'PY'
import pathlib, struct, sys
p=pathlib.Path(sys.argv[1])
if not p.is_file(): raise SystemExit('BUILD FAILED: X86_64_TEST_NOT_PACKAGED')
b=p.read_bytes()[:20]
if len(b)<20 or b[:4]!=b'\x7fELF': raise SystemExit('BUILD FAILED: X86_64_TEST_WRONG_ABI')
m=struct.unpack('<H' if b[5]==1 else '>H', b[18:20])[0]
if m != 62: raise SystemExit(f'BUILD FAILED: X86_64_TEST_WRONG_ABI ({m})')
PY

PROOT=''
for candidate in \
  "$ROOT/app/src/main/jniLibs/arm64-v8a/libproot_exec.so" \
  "$ROOT/app/src/main/jniLibs/arm64-v8a/libproot.so" \
  "$ROOT/app/src/main/jniLibs/arm64-v8a/libexec_proot.so"; do
  [[ -f "$candidate" ]] && PROOT="$candidate" && break
done
if [[ -z "$PROOT" ]]; then
  if [[ "${ALLOW_MISSING_PROOT:-0}" == "1" ]]; then
    echo "WARNING: BUILD FAILED: PROOT_NOT_PACKAGED (allowed for source-only validation)" >&2
  else
    echo "BUILD FAILED: PROOT_NOT_PACKAGED" >&2
    echo "Run tools/fetch-proot-android.sh with a pinned SHA-256." >&2
    exit 1
  fi
else
  python3 - "$PROOT" <<'PY'
import pathlib, struct, sys
b=pathlib.Path(sys.argv[1]).read_bytes()[:20]
if len(b)<20 or b[:4]!=b'\x7fELF': raise SystemExit('BUILD FAILED: PROOT_WRONG_ABI')
m=struct.unpack('<H' if b[5]==1 else '>H', b[18:20])[0]
if m != 183: raise SystemExit(f'BUILD FAILED: PROOT_WRONG_ABI ({m})')
PY
fi

echo "Source boundaries passed."
