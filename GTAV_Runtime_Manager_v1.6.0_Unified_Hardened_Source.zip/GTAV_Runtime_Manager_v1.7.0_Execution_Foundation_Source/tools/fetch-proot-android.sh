#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
URL="${PROOT_URL:-https://skirsten.github.io/proot-portable-android-binaries/aarch64/proot}"
EXPECTED_SHA="${PROOT_SHA256:-}"
DEST_DIR="$ROOT/app/src/main/jniLibs/arm64-v8a"
DEST="$DEST_DIR/libproot_exec.so"
TMP="${TMPDIR:-/tmp}/gtav-proot-aarch64.$$"
trap 'rm -f "$TMP"' EXIT

mkdir -p "$DEST_DIR"

echo "Downloading Android AArch64 PRoot from: $URL"
if command -v curl >/dev/null 2>&1; then
  curl --fail --location --retry 3 --output "$TMP" "$URL"
elif command -v wget >/dev/null 2>&1; then
  wget -O "$TMP" "$URL"
else
  echo "curl أو wget مطلوب لتنزيل PRoot" >&2
  exit 2
fi

python3 - "$TMP" <<'PY'
import pathlib, struct, sys
p = pathlib.Path(sys.argv[1])
b = p.read_bytes()[:20]
if len(b) < 20 or b[:4] != b'\x7fELF':
    raise SystemExit('PROOT_NOT_ELF')
machine = struct.unpack('<H' if b[5] == 1 else '>H', b[18:20])[0]
if machine != 183:
    raise SystemExit(f'PROOT_WRONG_ABI: ELF machine={machine}, expected 183/AArch64')
print('PRoot ELF ABI: AArch64')
PY

ACTUAL_SHA="$(sha256sum "$TMP" | awk '{print $1}')"
if [[ -n "$EXPECTED_SHA" && "${ACTUAL_SHA,,}" != "${EXPECTED_SHA,,}" ]]; then
  echo "PRoot SHA-256 mismatch" >&2
  echo "Expected: $EXPECTED_SHA" >&2
  echo "Actual:   $ACTUAL_SHA" >&2
  exit 3
fi

install -m 0755 "$TMP" "$DEST"
cat > "$ROOT/app/src/main/jniLibs/PROOT_PROVENANCE.txt" <<META
Component: PRoot Android executable
Packaged name: arm64-v8a/libproot_exec.so
Source URL: $URL
Fetched UTC: $(date -u +'%Y-%m-%dT%H:%M:%SZ')
SHA-256: $ACTUAL_SHA
ELF machine: 183 (AArch64)
Expected SHA supplied: ${EXPECTED_SHA:-NO — pin PROOT_SHA256 before a public release}

Release requirement:
Record the exact upstream source revision, preserve all applicable PRoot/dependency
license notices, and publish corresponding source/build inputs before redistribution.
META

echo "Installed: $DEST"
echo "SHA-256: $ACTUAL_SHA"
if [[ -z "$EXPECTED_SHA" ]]; then
  echo "WARNING: run again with PROOT_SHA256=<pinned hash> before a public release." >&2
fi
