# مصفوفة تنفيذ v1.7.0

| المتطلب | التنفيذ | الحالة |
|---|---|---|
| فصل التثبيت عن التنفيذ | `InstalledRuntimeProvider` + فحص معماري | منفذ |
| Runtime متحقق وجاهز | `VerifiedInstalledRuntime.readyForExecution()` | منفذ |
| State Machine | `ExecutionStage` + انتقالات صريحة | منفذ |
| Runtime Console حي | `RuntimeConsoleActivity` + `RuntimeConsoleStore` | منفذ |
| سجل كامل/ذاكرة محدودة | ملف دائم + آخر 600 سطر | منفذ |
| Process timeout/cancel | `RuntimeProcessRunner` | منفذ |
| شجرة العمليات | `RuntimeProcessSupervisor` | منفذ |
| حماية PID reuse | هوية `/proc/PID/stat` | منفذ |
| Bind model | `RuntimeBindMount` | منفذ |
| فصل Bionic/glibc | `RuntimeEnvironmentBuilder` | منفذ |
| PRoot interface | `IsolationEngine → ProotIsolationEngine` | منفذ برمجيًا |
| PRoot Android AArch64 | Build gate + fetch/provenance script | يجب تزويد binary موثق |
| RootFS smoke tests | true/echo/sh | منفذ |
| ELF x86_64 فعلي | `assets/execution/hello-x86_64` | منفذ |
| Box64 smoke | `BOX64_SMOKE_TEST_OK` | منفذ |
| Wine Prefix خارجي | `WinePrefixManager` | منفذ |
| Wine Console | `WINE_RUNTIME_OK` | منفذ |
| Feature capability states | Requested/Available/Validated/Enabled | منفذ |
| Backend registry | Display/Audio/Graphics/Input | منفذ كقدرات فقط |
| Foreground service | Notification + WakeLock + stop | منفذ |
| تقارير التنفيذ | ملفات الطبقات + ZIP export | منفذ |
| Debug/Release component gates | Gradle source/APK checks | منفذ |
| Display/Audio/Vulkan/DXVK/Input/Game Library | خارج v1.7.0 | مؤجل |
