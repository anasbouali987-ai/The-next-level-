# Third-party execution components

## PRoot

The source tree intentionally does not invent or silently substitute a PRoot binary.
`tools/fetch-proot-android.sh` can install an Android AArch64 development binary into
`app/src/main/jniLibs/arm64-v8a/libproot_exec.so`. Before redistribution, pin its
SHA-256 and document the exact source revision, build inputs, licenses, and corresponding
source obligations.

## hello-x86_64

`app/src/main/assets/execution/hello-x86_64` is a tiny statically linked x86_64 Linux
smoke-test program built from `tools/hello-x86_64.c`. It prints exactly
`BOX64_SMOKE_TEST_OK` and exits with code 0.
