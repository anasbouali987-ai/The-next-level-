# ملاحظات الترقية إلى v1.7.0 — Execution Foundation

## من v1.4.1 وv1.5.0

- رفع `versionCode` إلى 8 و`versionName` إلى `1.6.0`.
- تثبيت AGP على `8.10.1` مع Gradle `8.11.1` وBuild Tools `35.0.0` لتوافق API 36.
- إزالة أرقام الإصدارات hardcoded من واجهة التطبيق والتقارير واستخدام `BuildConfig.VERSION_NAME`.
- توحيد إنشاء محرك الضغط عبر `CompressionManager.createDefault()`.
- فصل عقد Zstandard ونتائج Health check وتصنيف الأخطاء في package واحد.
- استعادة Startup Diagnostic وDocumentFile/SAF من فرع v1.5.0.
- دمج تقرير المكتبات الأصلية الغني مع Error codes الخاصة بفرع Compression Hardening.
- تقسيم Preflight إلى Platform وNative Zstd وStreaming وTAR.
- إضافة اختبارات لتصنيف الأخطاء وحدود المعمارية وجاهزية المنصة.
- توحيد بوابات Debug وRelease تحت `validateAllNativePackaging`.
- إضافة Workflow وScripts قابلة للتشغيل دون افتراض وجود Gradle Wrapper.

## توافق الحزم

لم يتغير هدف المشروع أو صيغة مسار Payload الأساسية. يجب مع ذلك إعادة اختبار أي حزمة Runtime حقيقية لأن المشروع الخامس أصبح أكثر تشددًا في التحقق من المسارات وTAR وJNI ونظام الملفات.

## v1.7.0 — Execution Foundation

- أضيف Execution Domain مستقل بالكامل عن المثبّت المستقر.
- أضيف PRoot/RootFS/Box64/Wine Console diagnostic pipeline.
- أضيف Wine Prefix تشخيصي خارج RootFS، State Machine، Foreground Service، Runtime Console،
  تقارير طبقية، Feature Capability states، وإدارة شجرة العمليات.
- Display وAudio وGraphics وInput وGame Library مسجلة كقدرات تجريبية غير منفذة.
- لا تتضمن شجرة المصدر Binary PRoot غير موثق؛ يجب تثبيته مع SHA-256 ومصدر/ترخيص مثبتين
  قبل البناء العام.
