#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT"

"$ROOT/tools/verify-source-boundaries.sh"

if [[ -x "$ROOT/gradlew" ]]; then
  GRADLE=("$ROOT/gradlew")
elif command -v gradle >/dev/null 2>&1; then
  GRADLE=(gradle)
else
  echo "Gradle غير موجود. افتح المشروع في Android Studio أو ثبّت Gradle 8.11.1." >&2
  exit 2
fi

"${GRADLE[@]}" --no-daemon clean \
  verifyExecutionSourceComponents \
  verifyExecutionDomainBoundaries \
  testDebugUnitTest lintDebug validateAllNativePackaging
cat <<'MSG'
نجحت بوابات Installation/Execution والفحوص والوحدات وDebug/Release packaging.
بوابات الجهاز الإلزامية قبل اعتماد v1.7.0:
  gradle connectedDebugAndroidTest
  Runtime Console → WINE_RUNTIME_OK → COMPLETED → no orphan processes
MSG
