import java.security.MessageDigest
import java.util.zip.ZipFile
import java.io.RandomAccessFile

plugins {
    id("com.android.application")
}

val zstdVersion = "1.5.7-3"
val commonsCompressVersion = "1.27.1"
val requestedAbi = "arm64-v8a"
val executionProotNames = listOf("libproot_exec.so", "libproot.so", "libexec_proot.so")
val helloAssetPath = "assets/execution/hello-x86_64"

android {
    namespace = "com.gtav.runtimemanager"
    compileSdk = 36
    buildToolsVersion = "35.0.0"

    defaultConfig {
        applicationId = "com.gtav.runtimemanager"
        minSdk = 26
        targetSdk = 36
        versionCode = 9
        versionName = "1.7.0"
        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"

        ndk { abiFilters += listOf(requestedAbi) }
        buildConfigField("String", "ZSTD_DEPENDENCY_VERSION", "\"$zstdVersion\"")
        buildConfigField("String", "REQUESTED_ABI", "\"$requestedAbi\"")
        buildConfigField("String", "EXECUTION_FOUNDATION_VERSION", "\"1.7.0\"")
        buildConfigField("boolean", "FEATURE_PROOT_REQUESTED", "true")
        buildConfigField("boolean", "FEATURE_BOX64_REQUESTED", "true")
        buildConfigField("boolean", "FEATURE_WINE_REQUESTED", "true")
        buildConfigField("boolean", "FEATURE_DISPLAY_REQUESTED", "false")
        buildConfigField("boolean", "FEATURE_AUDIO_REQUESTED", "false")
        buildConfigField("boolean", "FEATURE_GRAPHICS_REQUESTED", "false")
        buildConfigField("boolean", "FEATURE_INPUT_REQUESTED", "false")
        buildConfigField("boolean", "FEATURE_GAME_LIBRARY_REQUESTED", "false")
    }

    buildTypes {
        debug {
            isMinifyEnabled = false
        }
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    buildFeatures { buildConfig = true }

    packaging {
        resources.excludes += setOf(
            "META-INF/DEPENDENCIES",
            "META-INF/LICENSE*",
            "META-INF/NOTICE*"
        )
        jniLibs.useLegacyPackaging = true
    }

    testOptions { unitTests.isReturnDefaultValues = true }
}

dependencies {
    implementation("org.apache.commons:commons-compress:$commonsCompressVersion")
    implementation("androidx.documentfile:documentfile:1.0.1")
    implementation("com.github.luben:zstd-jni:$zstdVersion@aar")

    // JVM unit tests need the regular JAR; the APK still consumes the Android AAR above.
    testImplementation("com.github.luben:zstd-jni:$zstdVersion")
    testImplementation("junit:junit:4.13.2")

    androidTestImplementation("androidx.test.ext:junit:1.2.1")
    androidTestImplementation("androidx.test:core:1.6.1")
    androidTestImplementation("androidx.test:runner:1.6.2")
}


fun elfMachine(header: ByteArray): Int {
    if (header.size < 20) return -1
    if ((header[0].toInt() and 0xff) != 0x7f || header[1].toInt() != 'E'.code ||
        header[2].toInt() != 'L'.code || header[3].toInt() != 'F'.code) return -1
    val little = header[5].toInt() == 1
    return if (little) (header[18].toInt() and 0xff) or ((header[19].toInt() and 0xff) shl 8)
    else ((header[18].toInt() and 0xff) shl 8) or (header[19].toInt() and 0xff)
}

fun elfMachine(file: File): Int {
    if (!file.isFile || file.length() < 20) return -1
    RandomAccessFile(file, "r").use { input ->
        val header = ByteArray(20)
        input.readFully(header)
        return elfMachine(header)
    }
}

fun elfMachine(apk: File, entryName: String): Int = ZipFile(apk).use { zip ->
    val entry = zip.getEntry(entryName) ?: return@use -1
    zip.getInputStream(entry).use { input ->
        val header = ByteArray(20)
        var offset = 0
        while (offset < header.size) {
            val read = input.read(header, offset, header.size - offset)
            if (read < 0) break
            offset += read
        }
        if (offset < header.size) -1 else elfMachine(header)
    }
}

fun executionFeatureFlagsText(variant: String): String = buildString {
    appendLine("Variant: $variant")
    appendLine("Release line: v1.7.0 Execution Foundation")
    appendLine("Internal gates: alpha1 Process/Session/Console; alpha2 PRoot/RootFS; alpha3 Box64 ELF; alpha4 Wine/Prefix; RC Cleanup/Reports/Recovery")
    appendLine("FEATURE_PROOT: requested")
    appendLine("FEATURE_BOX64: requested; gated by PRoot + RootFS")
    appendLine("FEATURE_WINE: requested; gated by Box64 smoke test")
    appendLine("FEATURE_DISPLAY: experimental; not implemented")
    appendLine("FEATURE_AUDIO: experimental; not implemented")
    appendLine("FEATURE_GRAPHICS: experimental; not implemented")
    appendLine("FEATURE_INPUT: experimental; not implemented")
    appendLine("FEATURE_GAME_LIBRARY: experimental; not implemented")
}

fun sha256(file: File): String {
    val digest = MessageDigest.getInstance("SHA-256")
    file.inputStream().use { input ->
        val buffer = ByteArray(256 * 1024)
        while (true) {
            val read = input.read(buffer)
            if (read < 0) break
            digest.update(buffer, 0, read)
        }
    }
    return digest.digest().joinToString("") { "%02x".format(it) }
}

fun findVariantApks(variant: String): List<File> {
    val outputDir = layout.buildDirectory.dir("outputs/apk/$variant").get().asFile
    return outputDir.walkTopDown().filter { it.isFile && it.extension == "apk" }.toList()
}

fun validateApk(apk: File, variant: String) {
    val entries = ZipFile(apk).use { zip ->
        zip.entries().asSequence().map { it.name }.toList()
    }
    val nativeEntries = entries.filter { it.startsWith("lib/") && it.endsWith(".so") }.sorted()
    val abiEntries = nativeEntries.filter { it.startsWith("lib/$requestedAbi/") }
    val zstdEntries = abiEntries.filter { it.substringAfterLast('/').contains("zstd", ignoreCase = true) }
    val prootEntries = abiEntries.filter { it.substringAfterLast('/') in executionProotNames }
    val helloEntries = entries.filter { it == helloAssetPath }
    val packagedAbis = nativeEntries.mapNotNull { it.split('/').getOrNull(1) }.distinct()
    val prootMachine = prootEntries.firstOrNull()?.let { elfMachine(apk, it) } ?: -1
    val helloMachine = helloEntries.firstOrNull()?.let { elfMachine(apk, it) } ?: -1

    val reportDir = layout.buildDirectory.dir("reports/native-packaging/$variant").get().asFile
        .apply { mkdirs() }
    File(reportDir, "APK_NATIVE_LIBS.txt").writeText(nativeEntries.joinToString("\n", postfix = "\n"))
    File(reportDir, "BUILD_INFO.txt").writeText(buildString {
        appendLine("Application version: ${android.defaultConfig.versionName}")
        appendLine("Requested ABI: $requestedAbi")
        appendLine("Packaged ABIs: ${packagedAbis.joinToString()}")
        appendLine("Zstd dependency: $zstdVersion")
        appendLine("Variant: $variant")
        appendLine("APK: ${apk.name}")
        appendLine("Zstd entries:")
        zstdEntries.forEach { appendLine(" - $it") }
        appendLine("PRoot entries:")
        prootEntries.forEach { appendLine(" - $it") }
        appendLine("x86_64 smoke test entries:")
        helloEntries.forEach { appendLine(" - $it") }
    })
    File(reportDir, "EXECUTION_COMPONENTS.txt").writeText(buildString {
        appendLine("APK: ${apk.name}")
        appendLine("Requested ABI: $requestedAbi")
        appendLine("PRoot: ${if (prootEntries.isEmpty()) "MISSING" else prootEntries.joinToString()}")
        appendLine("PRoot ELF machine: $prootMachine (expected 183/AArch64)")
        appendLine("hello-x86_64: ${if (helloEntries.isEmpty()) "MISSING" else helloEntries.joinToString()}")
        appendLine("hello-x86_64 ELF machine: $helloMachine (expected 62/x86_64)")
        appendLine("Box64: provided by verified installed RootFS at runtime")
        appendLine("Wine: provided by verified installed RootFS at runtime")
    })
    File(reportDir, "FEATURE_FLAGS.txt").writeText(executionFeatureFlagsText(variant))
    File(reportDir, "SHA256SUMS.txt").writeText("${sha256(apk)}  ${apk.name}\n")

    if (abiEntries.isEmpty()) {
        throw GradleException("BUILD FAILED: ABI_NOT_PACKAGED_$requestedAbi")
    }
    if (zstdEntries.isEmpty()) {
        logger.error("Files inside lib/$requestedAbi/:\n${abiEntries.joinToString("\n")}")
        throw GradleException("BUILD FAILED: ZSTD_NOT_PACKAGED")
    }
    if (prootEntries.isEmpty()) {
        logger.error("Files inside lib/$requestedAbi/:\n${abiEntries.joinToString("\n")}")
        throw GradleException("BUILD FAILED: PROOT_NOT_PACKAGED")
    }
    if (prootMachine != 183) {
        throw GradleException("BUILD FAILED: PROOT_WRONG_ABI")
    }
    if (helloEntries.isEmpty()) {
        throw GradleException("BUILD FAILED: X86_64_TEST_NOT_PACKAGED")
    }
    if (helloMachine != 62) {
        throw GradleException("BUILD FAILED: X86_64_TEST_WRONG_ABI")
    }
    logger.lifecycle("Native/execution packaging passed for $variant")
}


tasks.register("verifyExecutionSourceComponents") {
    group = "verification"
    description = "Checks the Android AArch64 PRoot executable and x86_64 ELF smoke-test asset before build."
    doLast {
        val jniDir = file("src/main/jniLibs/$requestedAbi")
        val proot = executionProotNames.map { File(jniDir, it) }.firstOrNull { it.isFile }
            ?: throw GradleException("BUILD FAILED: PROOT_NOT_PACKAGED")
        if (elfMachine(proot) != 183) {
            throw GradleException("BUILD FAILED: PROOT_WRONG_ABI")
        }
        val hello = file("src/main/assets/execution/hello-x86_64")
        if (!hello.isFile) throw GradleException("BUILD FAILED: X86_64_TEST_NOT_PACKAGED")
        if (elfMachine(hello) != 62) {
            throw GradleException("BUILD FAILED: X86_64_TEST_WRONG_ABI")
        }
        val reportDir = layout.buildDirectory.dir("reports/execution-components/source").get().asFile
            .apply { mkdirs() }
        File(reportDir, "EXECUTION_COMPONENTS.txt").writeText(buildString {
            appendLine("PRoot file: ${proot.relativeTo(projectDir)}")
            appendLine("PRoot ELF machine: 183 (AArch64)")
            appendLine("PRoot SHA-256: ${sha256(proot)}")
            appendLine("hello-x86_64 file: ${hello.relativeTo(projectDir)}")
            appendLine("hello-x86_64 ELF machine: 62 (x86_64)")
            appendLine("hello-x86_64 SHA-256: ${sha256(hello)}")
        })
        File(reportDir, "FEATURE_FLAGS.txt").writeText(executionFeatureFlagsText("source"))
        logger.lifecycle("Execution source components passed: ${proot.name}, ${hello.name}")
    }
}

tasks.register("verifyExecutionDomainBoundaries") {
    group = "verification"
    description = "Prevents the stable installation domain from depending on execution internals."
    doLast {
        val root = file("src/main/java/com/gtav/runtimemanager")
        val allowedBridgeFiles = setOf(
            file("src/main/java/com/gtav/runtimemanager/MainActivity.java").canonicalFile,
            file("src/main/java/com/gtav/runtimemanager/InstalledRuntimeProvider.java").canonicalFile
        )
        val installationViolations = root.walkTopDown()
            .filter { it.isFile && it.extension in setOf("java", "kt") }
            .filter { !it.toPath().startsWith(file("src/main/java/com/gtav/runtimemanager/execution").toPath()) }
            .filter { it.canonicalFile !in allowedBridgeFiles }
            .filter { it.readText().contains("com.gtav.runtimemanager.execution") }
            .toList()
        if (installationViolations.isNotEmpty()) {
            throw GradleException("Installation domain imports execution internals:\n" +
                installationViolations.joinToString("\n") { it.relativeTo(projectDir).path })
        }

        val executionRoot = file("src/main/java/com/gtav/runtimemanager/execution")
        val forbidden = Regex("\\b(RuntimeInstaller|RuntimeExtractor|AtomicRuntimeSwap|RuntimeInstallCoordinator|RuntimePreflightChecker)\\b")
        val executionViolations = executionRoot.walkTopDown()
            .filter { it.isFile && it.extension in setOf("java", "kt") }
            .filter { forbidden.containsMatchIn(it.readText()) }
            .toList()
        if (executionViolations.isNotEmpty()) {
            throw GradleException("Execution domain depends on installation internals:\n" +
                executionViolations.joinToString("\n") { it.relativeTo(projectDir).path })
        }
    }
}

tasks.register("verifyZstdAarContents") {
    group = "verification"
    description = "Checks the resolved Android AAR for the requested arm64 Zstandard library."
    doLast {
        val artifacts = configurations.getByName("releaseRuntimeClasspath")
            .resolvedConfiguration.resolvedArtifacts
            .filter { it.moduleVersion.id.group == "com.github.luben" && it.name == "zstd-jni" }
        val aar = artifacts.map { it.file }.firstOrNull { it.extension == "aar" }
            ?: throw GradleException("BUILD FAILED: ZSTD_AAR_NOT_RESOLVED")
        val entries = ZipFile(aar).use { zip -> zip.entries().asSequence().map { it.name }.toList() }
        val expected = entries.filter {
            it.startsWith("jni/$requestedAbi/") && it.endsWith(".so") &&
                    it.substringAfterLast('/').contains("zstd", ignoreCase = true)
        }
        if (expected.isEmpty()) throw GradleException("BUILD FAILED: ZSTD_AAR_MISSING_$requestedAbi")
        logger.lifecycle("Resolved Zstandard AAR ${aar.name}: ${expected.joinToString()}")
    }
}

tasks.register("verifyNoDirectZstdUsage") {
    group = "verification"
    description = "Keeps all direct zstd-jni calls behind AndroidZstdJniEngine."
    doLast {
        val allowed = file(
            "src/main/java/com/gtav/runtimemanager/compression/zstd/AndroidZstdJniEngine.java"
        ).canonicalFile
        val violations = file("src").walkTopDown()
            .filter { it.isFile && it.extension in setOf("java", "kt") }
            .filter { it.canonicalFile != allowed }
            .filter { source ->
                val text = source.readText()
                Regex("import\\s+com\\.github\\.luben\\.zstd").containsMatchIn(text) ||
                        Regex("\\bnew\\s+ZstdInputStream\\b").containsMatchIn(text) ||
                        Regex("\\bZstd\\.").containsMatchIn(text)
            }.toList()
        if (violations.isNotEmpty()) {
            throw GradleException(
                "Direct Zstandard usage outside the engine:\n" +
                        violations.joinToString("\n") { it.relativeTo(projectDir).path }
            )
        }
    }
}

listOf("debug", "release").forEach { variant ->
    val cap = variant.replaceFirstChar { it.uppercase() }
    tasks.register("verify${cap}NativePackaging") {
        group = "verification"
        dependsOn("assemble$cap", "verifyZstdAarContents", "verifyNoDirectZstdUsage", "verifyExecutionSourceComponents", "verifyExecutionDomainBoundaries")
        doLast {
            val apks = findVariantApks(variant)
            if (apks.isEmpty()) throw GradleException("BUILD FAILED: APK_NOT_FOUND_$variant")
            apks.forEach { validateApk(it, variant) }
        }
    }
}

tasks.register("validateAllNativePackaging") {
    group = "verification"
    dependsOn("verifyDebugNativePackaging", "verifyReleaseNativePackaging")
}

tasks.named("preBuild") {
    dependsOn("verifyExecutionSourceComponents", "verifyExecutionDomainBoundaries")
}

tasks.named("check") {
    dependsOn("verifyNoDirectZstdUsage", "verifyExecutionSourceComponents", "verifyExecutionDomainBoundaries")
}
