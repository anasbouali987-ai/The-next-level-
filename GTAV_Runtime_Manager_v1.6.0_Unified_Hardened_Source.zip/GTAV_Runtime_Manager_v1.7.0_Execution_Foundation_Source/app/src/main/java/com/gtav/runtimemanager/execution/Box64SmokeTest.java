package com.gtav.runtimemanager.execution;

import java.util.Arrays;
import java.util.List;

public final class Box64SmokeTest {
    public List<String> command(Box64Manager manager, VerifiedInstalledRuntime runtime) {
        return Arrays.asList(manager.guestPath(runtime), "/opt/gtav-tests/hello-x86_64");
    }

    public void assertSuccess(RuntimeProcessResult result) throws ExecutionException {
        if (!result.success() || !result.stdout.contains("BOX64_SMOKE_TEST_OK")) {
            throw new ExecutionException(ExecutionErrorCode.BOX64_SMOKE_TEST_FAILED,
                    ExecutionStage.RUNNING_BOX64,
                    "Box64 ELF smoke test failed; exit=" + result.exitCode + " stderr=" + result.stderr);
        }
    }
}
