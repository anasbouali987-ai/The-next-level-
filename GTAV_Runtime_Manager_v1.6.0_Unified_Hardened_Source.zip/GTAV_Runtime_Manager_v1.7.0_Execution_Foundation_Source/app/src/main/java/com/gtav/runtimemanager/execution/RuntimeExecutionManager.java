package com.gtav.runtimemanager.execution;

import android.content.Context;

import com.gtav.runtimemanager.InstalledRuntimeProvider;

import java.io.File;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;

public final class RuntimeExecutionManager {
    public interface Listener {
        void onExecutionChanged(RuntimeSessionSnapshot snapshot, String recentConsole);
    }

    private static volatile RuntimeExecutionManager instance;

    public static RuntimeExecutionManager get(Context context) {
        if (instance == null) {
            synchronized (RuntimeExecutionManager.class) {
                if (instance == null) instance = new RuntimeExecutionManager(context.getApplicationContext());
            }
        }
        return instance;
    }

    private final Context context;
    private final ExecutorService executor = Executors.newSingleThreadExecutor(r -> {
        Thread thread = new Thread(r, "gtav-runtime-execution");
        thread.setPriority(Thread.NORM_PRIORITY - 1);
        return thread;
    });
    private final AtomicBoolean running = new AtomicBoolean(false);
    private final CopyOnWriteArrayList<Listener> listeners = new CopyOnWriteArrayList<>();
    private final RuntimeSessionManager sessions;
    private final RuntimeProcessSupervisor supervisor = new RuntimeProcessSupervisor();
    private final RuntimeFeatureFlags featureFlags = new RuntimeFeatureFlags();
    private final BackendCapabilityRegistry backends = new BackendCapabilityRegistry();
    private volatile RuntimeConsoleStore console;
    private volatile ExecutionCancellationToken cancellation;
    private volatile File currentSessionRoot;
    private final AtomicLong lastConsoleDispatch = new AtomicLong(0);

    private RuntimeExecutionManager(Context context) {
        this.context = context;
        this.sessions = new RuntimeSessionManager(context);
        RuntimeSessionSnapshot restored = this.sessions.current();
        if (restored != null && restored.sessionId != null && !restored.sessionId.isEmpty()) {
            try { this.currentSessionRoot = ExecutionPaths.sessionRoot(context, restored.sessionId); }
            catch (Throwable ignored) {}
        }
        this.sessions.addListener(snapshot -> notifyListeners());
    }

    public void addListener(Listener listener) {
        if (listener != null) listeners.addIfAbsent(listener);
        if (listener != null) listener.onExecutionChanged(sessions.current(), recentConsole());
    }

    public void removeListener(Listener listener) { listeners.remove(listener); }
    public RuntimeSessionSnapshot current() { return sessions.current(); }
    public boolean isRunning() { return running.get(); }
    public File currentSessionRoot() { return currentSessionRoot; }
    public List<Long> currentProcessTreePids() { return supervisor.observedPids(); }

    public boolean startFullDiagnostic() {
        if (!running.compareAndSet(false, true)) return false;
        cancellation = new ExecutionCancellationToken();
        executor.execute(this::executeFullDiagnostic);
        return true;
    }

    public void stopCurrentProcess() {
        supervisor.stopActiveGracefully();
    }

    public void cancel() {
        ExecutionCancellationToken token = cancellation;
        if (token != null) token.cancel();
        supervisor.cancelActive();
    }

    private void executeFullDiagnostic() {
        WinePrefixManager.PrefixLease prefixLease = null;
        RuntimeExecutionReporter reporter = null;
        RuntimeProcessSupervisor.CleanupResult cleanup = null;
        try {
            supervisor.beginSession();
            featureFlags.reset();
            RuntimeSessionSnapshot created = sessions.create("auto-detect");
            currentSessionRoot = ExecutionPaths.sessionRoot(context, created.sessionId);
            console = new RuntimeConsoleStore(new File(currentSessionRoot, "execution_log.txt"), 600, () -> {
                long now = android.os.SystemClock.elapsedRealtime();
                long previous = lastConsoleDispatch.get();
                if (now - previous >= 120 && lastConsoleDispatch.compareAndSet(previous, now)) {
                    notifyListeners();
                }
            });
            console.append(RuntimeConsoleStore.Stream.SYSTEM,
                    "GTAV Runtime Manager v1.7.0 — Execution Foundation");
            reporter = new RuntimeExecutionReporter(currentSessionRoot);

            VerifiedInstalledRuntime runtime;
            try {
                runtime = new InstalledRuntimeProvider(context).latestReady();
            } catch (Throwable error) {
                throw new ExecutionException(ExecutionErrorCode.NO_VERIFIED_RUNTIME,
                        ExecutionStage.PREPARING, error.getMessage() == null ? "No verified runtime" : error.getMessage(), error);
            }
            sessions.updateRuntimeId(runtime.runtimeId);
            prefixLease = new WinePrefixManager(context).acquire(runtime.runtimeId, runtime.version);

            RuntimeImmutabilityGuard immutabilityGuard = new RuntimeImmutabilityGuard(runtime);
            reporter.writeText("runtime_immutability.txt", immutabilityGuard.policySummary());
            RuntimeLauncher launcher = new RuntimeLauncher(context);
            RuntimeLaunchPlan plan = launcher.build(runtime, created.sessionId, prefixLease);
            reporter.writeEnvironment(plan.hostEnvironment, plan.guestEnvironment);
            reporter.writeMounts(plan.mounts);
            reporter.writeFeatureFlags(featureFlags, backends);

            sessions.transition(ExecutionStage.VALIDATING, "execution-preflight", "", -1,
                    null, ExecutionErrorCode.NONE, "");
            RuntimeExecutionValidator.Result validation;
            try {
                validation = new RuntimeExecutionValidator(context)
                        .validate(runtime, plan.isolationEngine, plan.helloBinary);
                reporter.writePreflight(validation);
            } catch (ExecutionException validationError) {
                reporter.writeText("execution_preflight.txt",
                        "FAIL " + validationError.code + "\nStage: " + validationError.stage
                                + "\nMessage: " + validationError.getMessage() + "\n");
                throw validationError;
            }
            reporter.writeText("proot_diagnostic.txt", ProotCompatibilityDiagnostic.collect(plan.isolationEngine.executable()));
            featureFlags.set(featureFlags.get(FeatureCapability.Feature.PROOT).available("AArch64 binary packaged"));

            sessions.transition(ExecutionStage.STARTING_PROOT, "proot-smoke", "/bin/true", -1,
                    null, ExecutionErrorCode.NONE, "");
            RuntimeProcessResult trueResult = runGuest(plan, "proot-true",
                    Arrays.asList("/bin/true"), 15_000);
            requireSuccess(trueResult, ExecutionErrorCode.PROOT_EXEC_FAILED, ExecutionStage.STARTING_PROOT,
                    "/bin/true failed");
            reporter.appendText("proot_diagnostic.txt", "\n--- /bin/true execution ---\n");
            reporter.appendText("proot_diagnostic.txt", processResultText(lastSpec, trueResult));
            featureFlags.set(featureFlags.get(FeatureCapability.Feature.PROOT).validated("/bin/true exit 0"));

            sessions.transition(ExecutionStage.ENTERING_ROOTFS, "rootfs-smoke",
                    "/bin/echo then /bin/sh", -1, null,
                    ExecutionErrorCode.NONE, "");
            RuntimeProcessResult echoResult = runGuest(plan, "rootfs-echo",
                    Arrays.asList("/bin/echo", "LINUX_ECHO_OK"), 15_000);
            RuntimeProcessSpec echoSpec = lastSpec;
            if (!echoResult.success() || !echoResult.stdout.contains("LINUX_ECHO_OK")) {
                throw new ExecutionException(ExecutionErrorCode.ROOTFS_SMOKE_TEST_FAILED,
                        ExecutionStage.ENTERING_ROOTFS, "/bin/echo smoke test failed");
            }
            RuntimeProcessResult rootfsResult = runGuest(plan, "rootfs-smoke",
                    Arrays.asList("/bin/sh", "-c", "echo LINUX_RUNTIME_OK"), 20_000);
            RuntimeProcessSpec rootfsSpec = lastSpec;
            if (!rootfsResult.success() || !rootfsResult.stdout.contains("LINUX_RUNTIME_OK")) {
                throw new ExecutionException(ExecutionErrorCode.ROOTFS_SMOKE_TEST_FAILED,
                        ExecutionStage.ENTERING_ROOTFS, "RootFS smoke test failed");
            }
            reporter.writeText("rootfs_smoke_test.txt", processResultText(echoSpec, echoResult) + "\n" + processResultText(rootfsSpec, rootfsResult));
            featureFlags.set(featureFlags.get(FeatureCapability.Feature.PROOT).enabled("RootFS shell validated"));

            sessions.transition(ExecutionStage.RUNNING_BOX64, "box64-version", "box64 --version",
                    -1, null, ExecutionErrorCode.NONE, "");
            RuntimeProcessResult boxVersion = runGuest(plan, "box64-version",
                    plan.box64Manager.versionCommand(runtime), 20_000);
            requireSuccess(boxVersion, ExecutionErrorCode.BOX64_VERSION_FAILED,
                    ExecutionStage.RUNNING_BOX64, "box64 --version failed");
            reporter.writeProcessResult("box64_diagnostic.txt", lastSpec, boxVersion);
            featureFlags.set(featureFlags.get(FeatureCapability.Feature.BOX64).available("Box64 executable found"));

            RuntimeProcessResult boxSmoke = runGuest(plan, "box64-smoke",
                    new Box64SmokeTest().command(plan.box64Manager, runtime), 30_000);
            new Box64SmokeTest().assertSuccess(boxSmoke);
            reporter.writeProcessResult("box64_smoke_test.txt", lastSpec, boxSmoke);
            featureFlags.set(featureFlags.get(FeatureCapability.Feature.BOX64).enabled("x86_64 ELF smoke test passed"));

            sessions.transition(ExecutionStage.STARTING_WINE, "wine-version", "wine64 --version",
                    -1, null, ExecutionErrorCode.NONE, "");
            RuntimeProcessResult wineVersion = runGuest(plan, "wine-version",
                    plan.wineManager.versionCommand(), 45_000);
            requireSuccess(wineVersion, ExecutionErrorCode.WINE_NOT_FOUND,
                    ExecutionStage.STARTING_WINE, "wine64 --version failed");
            featureFlags.set(featureFlags.get(FeatureCapability.Feature.WINE).available("Wine entrypoint executed"));

            RuntimeProcessResult wineboot = runGuest(plan, "wineboot",
                    plan.wineManager.winebootCommand(), 180_000);
            requireSuccess(wineboot, ExecutionErrorCode.WINE_BOOT_FAILED,
                    ExecutionStage.STARTING_WINE, "wineboot failed");
            reporter.writeProcessResult("wine_prefix_diagnostic.txt", lastSpec, wineboot);
            featureFlags.set(featureFlags.get(FeatureCapability.Feature.WINE).validated("Diagnostic prefix initialized"));

            sessions.transition(ExecutionStage.RUNNING, "wine-console",
                    "wine64 cmd.exe /c echo WINE_RUNTIME_OK", -1, null,
                    ExecutionErrorCode.NONE, "");
            RuntimeProcessResult wineConsole = runGuest(plan, "wine-console",
                    plan.wineManager.consoleSmokeCommand(), 90_000);
            if (!wineConsole.success() || !wineConsole.stdout.contains("WINE_RUNTIME_OK")) {
                throw new ExecutionException(ExecutionErrorCode.WINE_CONSOLE_FAILED,
                        ExecutionStage.RUNNING,
                        "Wine console smoke test failed; exit=" + wineConsole.exitCode);
            }
            reporter.writeProcessResult("wine_console_smoke_test.txt", lastSpec, wineConsole);
            featureFlags.set(featureFlags.get(FeatureCapability.Feature.WINE).enabled("WINE_RUNTIME_OK"));

            sessions.transition(ExecutionStage.STOPPING, "wine-shutdown", "wineserver -k", -1,
                    null, ExecutionErrorCode.NONE, "");
            try { runGuest(plan, "wine-shutdown", plan.wineManager.shutdownCommand(), 20_000); }
            catch (Throwable ignored) {}
            immutabilityGuard.verifyUnchanged();
            reporter.appendText("runtime_immutability.txt", "Result: PASS — runtime tree unchanged\n");
            cleanup = supervisor.cleanup(plan.prefixRoot, console);
            reporter.writeProcessTree(cleanup.processTree);
            if (!cleanup.clean) {
                throw new ExecutionException(ExecutionErrorCode.ORPHAN_PROCESS_REMAINS,
                        ExecutionStage.STOPPING, "Orphan processes remain: " + cleanup.survivors);
            }
            sessions.transition(ExecutionStage.COMPLETED, "completed", "", -1, 0,
                    ExecutionErrorCode.NONE, "WINE_RUNTIME_OK; no orphan processes");
        } catch (ExecutionException error) {
            if (reporter != null && !reporter.file("execution_preflight.txt").isFile()) {
                reporter.writeText("execution_preflight.txt",
                        "FAIL " + error.code + "\nStage: " + error.stage
                                + "\nMessage: " + error.getMessage() + "\n");
            }
            failSession(error);
        } catch (Throwable error) {
            ExecutionException wrapped = new ExecutionException(ExecutionErrorCode.INTERNAL_ERROR,
                    sessions.current().stage, error.getMessage() == null ? error.toString() : error.getMessage(), error);
            if (reporter != null && !reporter.file("execution_preflight.txt").isFile()) {
                reporter.writeText("execution_preflight.txt",
                        "FAIL " + wrapped.code + "\nStage: " + wrapped.stage
                                + "\nMessage: " + wrapped.getMessage() + "\n");
            }
            failSession(wrapped);
        } finally {
            try {
                if (cleanup == null) cleanup = supervisor.cleanup(prefixLease == null ? null : prefixLease.root, console);
                if (prefixLease != null) prefixLease.close();
                if (reporter != null) {
                    reporter.writeFeatureFlags(featureFlags, backends);
                    reporter.writeState(sessions.current());
                    reporter.writeProcessTree(cleanup.processTree);
                    reporter.writeSessionReport(sessions.current(), cleanup);
                }
                if (console != null) console.close();
            } catch (Throwable ignored) {}
            running.set(false);
            notifyListeners();
        }
    }

    private volatile RuntimeProcessSpec lastSpec;

    private RuntimeProcessResult runGuest(RuntimeLaunchPlan plan, String operation,
                                          List<String> guestCommand, long timeout)
            throws ExecutionException {
        cancellation.throwIfCancelled(sessions.current().stage);
        RuntimeProcessSpec spec = plan.isolationEngine.buildGuestCommand(operation,
                plan.runtime, plan.mounts, plan.hostEnvironment, plan.guestEnvironment,
                guestCommand, timeout);
        lastSpec = spec;
        sessions.updateCurrent(operation, spec.printableCommand(), -1, null);
        RuntimeProcessRunner.ProcessObserver observer = new RuntimeProcessRunner.ProcessObserver() {
            @Override public void onStarted(Process process, long pid) {
                supervisor.onStarted(process, pid);
                sessions.updateCurrent(operation, spec.printableCommand(), pid, null);
                notifyListeners();
            }
            @Override public void onFinished(Process process, RuntimeProcessResult result) {
                supervisor.onFinished(process, result);
                sessions.updateCurrent(operation, spec.printableCommand(), result.pid, result.exitCode);
                notifyListeners();
            }
        };
        RuntimeProcessResult result = new RuntimeProcessRunner().run(spec, cancellation, console, observer);
        if (result.cancelled) {
            throw new ExecutionException(ExecutionErrorCode.PROCESS_CANCELLED,
                    sessions.current().stage, "Execution cancelled");
        }
        if (result.timedOut) {
            throw new ExecutionException(ExecutionErrorCode.PROCESS_TIMEOUT,
                    sessions.current().stage, "Process timed out: " + operation);
        }
        return result;
    }

    private static String processResultText(RuntimeProcessSpec spec, RuntimeProcessResult result) {
        return "Operation: " + spec.name + "\nCommand: " + spec.printableCommand()
                + "\nPID: " + result.pid + "\nExit Code: " + result.exitCode
                + "\nDuration ms: " + result.durationMillis()
                + "\n[stdout]\n" + result.stdout + "\n[stderr]\n" + result.stderr + "\n";
    }

    private static void requireSuccess(RuntimeProcessResult result, ExecutionErrorCode code,
                                       ExecutionStage stage, String message) throws ExecutionException {
        if (!result.success()) throw new ExecutionException(code, stage,
                message + "; exit=" + result.exitCode + "; stderr=" + result.stderr);
    }

    private void failSession(ExecutionException error) {
        try {
            if (error.code == ExecutionErrorCode.PROOT_NOT_PACKAGED || error.code == ExecutionErrorCode.PROOT_WRONG_ABI
                    || error.code == ExecutionErrorCode.PROOT_NOT_EXECUTABLE || error.code == ExecutionErrorCode.PROOT_EXEC_FAILED) {
                featureFlags.set(featureFlags.get(FeatureCapability.Feature.PROOT).unavailable(error.getMessage()));
            } else if (error.code.name().startsWith("BOX64") || error.code.name().startsWith("X86_64")) {
                featureFlags.set(featureFlags.get(FeatureCapability.Feature.BOX64).unavailable(error.getMessage()));
            } else if (error.code.name().startsWith("WINE")) {
                featureFlags.set(featureFlags.get(FeatureCapability.Feature.WINE).unavailable(error.getMessage()));
            }
            if (console != null) console.append(RuntimeConsoleStore.Stream.SYSTEM,
                    "FAILED " + error.code + ": " + error.getMessage());
            ExecutionStage next = error.code == ExecutionErrorCode.PROCESS_CANCELLED
                    ? ExecutionStage.CANCELLED : ExecutionStage.FAILED;
            sessions.transition(next, "failure", "", -1, null, error.code, error.getMessage());
        } catch (Throwable ignored) {}
    }

    private String recentConsole() {
        RuntimeConsoleStore store = console;
        if (store != null) return store.recentText();
        File root = currentSessionRoot;
        if (root == null) return "";
        return RuntimeConsoleStore.readRecentText(new File(root, "execution_log.txt"), 600);
    }

    private void notifyListeners() {
        RuntimeSessionSnapshot snapshot = sessions.current();
        String recent = recentConsole();
        for (Listener listener : listeners) {
            try { listener.onExecutionChanged(snapshot, recent); } catch (Throwable ignored) {}
        }
    }
}
