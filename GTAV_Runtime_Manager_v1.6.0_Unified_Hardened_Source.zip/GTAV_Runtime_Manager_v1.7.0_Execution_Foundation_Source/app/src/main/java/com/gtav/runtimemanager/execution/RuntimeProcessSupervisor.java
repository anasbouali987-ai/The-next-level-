package com.gtav.runtimemanager.execution;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.AtomicReference;
import java.nio.file.Files;

/** يدير العملية الحالية وشجرة العمليات والتنظيف؛ لا يبني الأوامر. */
public final class RuntimeProcessSupervisor implements RuntimeProcessRunner.ProcessObserver {
    private final AtomicReference<Process> activeProcess = new AtomicReference<>();
    /** PID -> Linux /proc start-time token لمنع قتل PID أعيد استخدامه لعملية أخرى. */
    private final Map<Long, String> observedIdentities =
            Collections.synchronizedMap(new LinkedHashMap<>());
    private final AtomicLong watchGeneration = new AtomicLong();
    private volatile long rootPid = -1;

    public synchronized void beginSession() throws ExecutionException {
        Process active = activeProcess.get();
        if (active != null && active.isAlive()) {
            throw new ExecutionException(ExecutionErrorCode.INVALID_STATE_TRANSITION,
                    ExecutionStage.PREPARING, "A supervised process is still active");
        }
        activeProcess.set(null);
        observedIdentities.clear();
        rootPid = -1;
        watchGeneration.incrementAndGet();
    }

    @Override public void onStarted(Process process, long pid) {
        activeProcess.set(process);
        rootPid = pid;
        remember(pid);
        long generation = watchGeneration.incrementAndGet();
        Thread watcher = new Thread(() -> watchTree(process, pid, generation), "runtime-process-tree");
        watcher.setDaemon(true);
        watcher.start();
    }

    @Override public void onFinished(Process process, RuntimeProcessResult result) {
        collectTree(result.pid);
        remember(result.pid);
        activeProcess.compareAndSet(process, null);
        watchGeneration.incrementAndGet();
    }

    /** يوقف العملية الحالية تدريجيًا من دون وضع الجلسة في حالة الإلغاء. */
    public void stopActiveGracefully() {
        Process process = activeProcess.get();
        if (process == null) return;
        collectTree(rootPid);
        signalObserved(15);
        try { process.destroy(); } catch (Throwable ignored) {}
    }

    /** يلغي الجلسة ويصعّد إلى SIGKILL بعد مهلة قصيرة. */
    public void cancelActive() {
        Process process = activeProcess.getAndSet(null);
        collectTree(rootPid);
        signalObserved(15);
        if (process != null) {
            try { process.destroy(); } catch (Throwable ignored) {}
            try { Thread.sleep(700); } catch (InterruptedException error) { Thread.currentThread().interrupt(); }
            try { if (process.isAlive()) process.destroyForcibly(); } catch (Throwable ignored) {}
        }
        signalObserved(9);
        watchGeneration.incrementAndGet();
    }

    public CleanupResult cleanup(File prefixRoot, RuntimeConsoleStore console) {
        collectTree(rootPid);
        signalObserved(15);
        waitForExit(1_000);
        List<Long> survivors = liveObservedPids();
        if (!survivors.isEmpty()) {
            signal(survivors, 9);
            waitForExit(800);
            survivors = liveObservedPids();
        }
        cleanupPrefixLocks(prefixRoot);
        if (console != null) {
            console.append(RuntimeConsoleStore.Stream.SYSTEM,
                    survivors.isEmpty() ? "PROCESS_CLEANUP_OK" : "ORPHAN_PIDS=" + survivors);
        }
        return new CleanupResult(survivors.isEmpty(), survivors, snapshotProcessTree());
    }

    public List<Long> observedPids() {
        synchronized (observedIdentities) {
            return new ArrayList<>(observedIdentities.keySet());
        }
    }

    private void watchTree(Process process, long pid, long generation) {
        while (watchGeneration.get() == generation && activeProcess.get() == process) {
            collectTree(pid);
            try {
                if (!process.isAlive()) break;
                Thread.sleep(100);
            } catch (InterruptedException error) {
                Thread.currentThread().interrupt();
                break;
            } catch (Throwable ignored) {
            }
        }
        collectTree(pid);
    }

    private void collectTree(long parent) {
        if (parent <= 0) return;
        remember(parent);
        for (Long child : snapshotDescendants(parent)) remember(child);
    }

    private void remember(long pid) {
        if (pid <= 1 || pid == android.os.Process.myPid()) return;
        String identity = processIdentity(pid);
        if (!identity.isEmpty()) observedIdentities.putIfAbsent(pid, identity);
    }

    private void signalObserved(int value) {
        List<Long> pids;
        synchronized (observedIdentities) { pids = new ArrayList<>(observedIdentities.keySet()); }
        Collections.reverse(pids);
        signal(pids, value);
    }

    private void signal(List<Long> pids, int value) {
        for (Long pid : pids) {
            String expected = observedIdentities.get(pid);
            if (expected != null && expected.equals(processIdentity(pid))) signalPid(pid, value);
        }
    }

    private void waitForExit(long timeoutMillis) {
        long deadline = android.os.SystemClock.elapsedRealtime() + timeoutMillis;
        while (android.os.SystemClock.elapsedRealtime() < deadline) {
            if (liveObservedPids().isEmpty()) return;
            try { Thread.sleep(50); } catch (InterruptedException error) {
                Thread.currentThread().interrupt();
                return;
            }
        }
    }

    private List<Long> liveObservedPids() {
        List<Long> live = new ArrayList<>();
        synchronized (observedIdentities) {
            for (Map.Entry<Long, String> entry : observedIdentities.entrySet()) {
                long pid = entry.getKey();
                if (pid > 1 && entry.getValue().equals(processIdentity(pid))) live.add(pid);
            }
        }
        return live;
    }

    private static void signalPid(long pid, int signal) {
        if (pid <= 1 || pid == android.os.Process.myPid()) return;
        try { android.system.Os.kill((int) pid, signal); } catch (Throwable ignored) {}
    }

    private static List<Long> snapshotDescendants(long parent) {
        List<Long> result = new ArrayList<>();
        if (parent <= 0) return result;
        boolean changed;
        Set<Long> parents = new HashSet<>();
        parents.add(parent);
        do {
            changed = false;
            File proc = new File("/proc");
            File[] entries = proc.listFiles(File::isDirectory);
            if (entries == null) break;
            for (File entry : entries) {
                long pid;
                try { pid = Long.parseLong(entry.getName()); } catch (NumberFormatException ignored) { continue; }
                if (result.contains(pid) || pid == android.os.Process.myPid()) continue;
                long ppid = readParentPid(pid);
                if (parents.contains(ppid)) {
                    result.add(pid);
                    parents.add(pid);
                    changed = true;
                }
            }
        } while (changed);
        return result;
    }

    private static long readParentPid(long pid) {
        File status = new File("/proc/" + pid + "/status");
        try (BufferedReader reader = new BufferedReader(new FileReader(status))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.startsWith("PPid:")) return Long.parseLong(line.substring(5).trim());
            }
        } catch (Throwable ignored) {}
        return -1;
    }

    /** الحقل 22 من /proc/PID/stat ثابت طوال حياة العملية. */
    private static String processIdentity(long pid) {
        if (pid <= 1) return "";
        String stat = readSmall(new File("/proc/" + pid + "/stat"));
        if (stat.isEmpty()) return "";
        int close = stat.lastIndexOf(')');
        if (close < 0 || close + 2 >= stat.length()) return "";
        String[] fields = stat.substring(close + 2).trim().split("\\s+");
        return fields.length > 19 ? fields[19] : "";
    }

    private static void cleanupPrefixLocks(File root) {
        if (root == null || !root.isDirectory()) return;
        File[] files = root.listFiles();
        if (files == null) return;
        for (File file : files) {
            String name = file.getName();
            if (name.startsWith(".wine-") || name.endsWith(".lock") || name.equals("wineserver.pid")) {
                try { file.delete(); } catch (Throwable ignored) {}
            }
            try {
                if (file.isDirectory() && !Files.isSymbolicLink(file.toPath())) cleanupPrefixLocks(file);
            } catch (Throwable ignored) {}
        }
    }

    public JSONArray snapshotProcessTree() {
        JSONArray array = new JSONArray();
        Set<Long> pids = new LinkedHashSet<>();
        synchronized (observedIdentities) { pids.addAll(observedIdentities.keySet()); }
        if (rootPid > 0) {
            pids.add(rootPid);
            pids.addAll(snapshotDescendants(rootPid));
        }
        for (Long pid : pids) {
            JSONObject item = new JSONObject();
            try {
                String expected = observedIdentities.get(pid);
                String actual = processIdentity(pid);
                item.put("pid", pid);
                item.put("ppid", readParentPid(pid));
                item.put("identity", expected == null ? "" : expected);
                item.put("alive", expected != null && expected.equals(actual));
                item.put("cmdline", readSmall(new File("/proc/" + pid + "/cmdline")).replace('\0', ' '));
            } catch (Exception ignored) {}
            array.put(item);
        }
        return array;
    }

    private static String readSmall(File file) {
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line = reader.readLine();
            return line == null ? "" : line;
        } catch (IOException ignored) { return ""; }
    }

    public static final class CleanupResult {
        public final boolean clean;
        public final List<Long> survivors;
        public final JSONArray processTree;

        CleanupResult(boolean clean, List<Long> survivors, JSONArray processTree) {
            this.clean = clean;
            this.survivors = Collections.unmodifiableList(new ArrayList<>(survivors));
            this.processTree = processTree;
        }
    }
}
