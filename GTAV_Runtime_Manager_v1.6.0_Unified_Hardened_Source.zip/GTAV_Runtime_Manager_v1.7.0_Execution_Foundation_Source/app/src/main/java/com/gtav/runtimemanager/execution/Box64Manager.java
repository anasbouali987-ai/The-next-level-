package com.gtav.runtimemanager.execution;

import java.io.File;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

public final class Box64Manager {
    private final File box64;

    public Box64Manager(VerifiedInstalledRuntime runtime) throws ExecutionException {
        box64 = RuntimeExecutionValidator.locate(runtime.root,
                "usr/local/bin/box64", "usr/bin/box64", "opt/gtav-runtime/bin/box64", "bin/box64");
        if (box64 == null) throw new ExecutionException(ExecutionErrorCode.BOX64_NOT_FOUND,
                ExecutionStage.RUNNING_BOX64, "Box64 executable not found");
    }

    public String guestPath(VerifiedInstalledRuntime runtime) {
        String root = runtime.root.getAbsolutePath();
        String path = box64.getAbsolutePath();
        return path.startsWith(root) ? path.substring(root.length()) : "/usr/bin/box64";
    }

    public List<String> versionCommand(VerifiedInstalledRuntime runtime) {
        return Arrays.asList(guestPath(runtime), "--version");
    }
}
