package com.gtav.runtimemanager.execution;

import java.io.File;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public final class RuntimeLaunchPlan {
    public final VerifiedInstalledRuntime runtime;
    public final File sessionRoot;
    public final File prefixRoot;
    public final File helloBinary;
    public final List<RuntimeBindMount> mounts;
    public final Map<String, String> hostEnvironment;
    public final Map<String, String> guestEnvironment;
    public final IsolationEngine isolationEngine;
    public final Box64Manager box64Manager;
    public final WineManager wineManager;

    public RuntimeLaunchPlan(VerifiedInstalledRuntime runtime, File sessionRoot, File prefixRoot,
                             File helloBinary, List<RuntimeBindMount> mounts,
                             Map<String, String> hostEnvironment, Map<String, String> guestEnvironment,
                             IsolationEngine isolationEngine, Box64Manager box64Manager,
                             WineManager wineManager) {
        this.runtime = runtime;
        this.sessionRoot = sessionRoot;
        this.prefixRoot = prefixRoot;
        this.helloBinary = helloBinary;
        this.mounts = Collections.unmodifiableList(mounts);
        this.hostEnvironment = Collections.unmodifiableMap(new LinkedHashMap<>(hostEnvironment));
        this.guestEnvironment = Collections.unmodifiableMap(new LinkedHashMap<>(guestEnvironment));
        this.isolationEngine = isolationEngine;
        this.box64Manager = box64Manager;
        this.wineManager = wineManager;
    }
}
