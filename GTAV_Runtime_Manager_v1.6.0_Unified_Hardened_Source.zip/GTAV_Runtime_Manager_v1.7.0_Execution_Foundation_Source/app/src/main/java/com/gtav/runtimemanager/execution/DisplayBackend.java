package com.gtav.runtimemanager.execution;

/** عقد مستقبلي فقط؛ لا يوجد Display backend مفعّل في v1.7.0. */
public interface DisplayBackend {
    String id();
    FeatureCapability capability();
}
