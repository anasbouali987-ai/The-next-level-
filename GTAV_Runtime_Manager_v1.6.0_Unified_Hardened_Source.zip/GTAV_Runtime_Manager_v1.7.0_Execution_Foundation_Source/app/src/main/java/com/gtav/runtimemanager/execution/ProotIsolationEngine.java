package com.gtav.runtimemanager.execution;

import android.content.Context;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/** الواجهة الوحيدة لـ PRoot في Execution Domain. */
public final class ProotIsolationEngine implements IsolationEngine {
    private final File proot;

    public ProotIsolationEngine(Context context) {
        this.proot = RuntimeFeatureFlags.locatePackagedProot(context);
    }

    @Override public String name() { return "Android PRoot"; }
    @Override public File executable() { return proot; }

    @Override public void validate() throws ExecutionException {
        if (!proot.isFile()) {
            throw new ExecutionException(ExecutionErrorCode.PROOT_NOT_PACKAGED,
                    ExecutionStage.VALIDATING,
                    "PRoot is not packaged in nativeLibraryDir: " + proot.getAbsolutePath());
        }
        try {
            if (ElfInspector.architecture(proot) != ElfInspector.Architecture.AARCH64) {
                throw new ExecutionException(ExecutionErrorCode.PROOT_WRONG_ABI,
                        ExecutionStage.VALIDATING, "PRoot is not AArch64: " + proot);
            }
        } catch (ExecutionException error) {
            throw error;
        } catch (Exception error) {
            throw new ExecutionException(ExecutionErrorCode.PROOT_WRONG_ABI,
                    ExecutionStage.VALIDATING, "Cannot inspect PRoot ELF", error);
        }
        if (!proot.canExecute()) {
            throw new ExecutionException(ExecutionErrorCode.PROOT_NOT_EXECUTABLE,
                    ExecutionStage.VALIDATING, "PRoot is not executable: " + proot);
        }
    }

    @Override public RuntimeProcessSpec buildGuestCommand(String operation,
                                                           VerifiedInstalledRuntime runtime,
                                                           List<RuntimeBindMount> mounts,
                                                           Map<String, String> hostEnvironment,
                                                           Map<String, String> guestEnvironment,
                                                           List<String> guestCommand,
                                                           long timeoutMillis)
            throws ExecutionException {
        validate();
        List<String> command = new ArrayList<>();
        command.add(proot.getAbsolutePath());
        command.add("--kill-on-exit");
        command.add("--link2symlink");
        command.add("-0");
        command.add("-r");
        command.add(runtime.root.getAbsolutePath());
        command.add("-w");
        command.add("/home/gtav");
        for (RuntimeBindMount mount : mounts) {
            if (!mount.hostPath.exists() && !mount.required) continue;
            command.add("-b");
            command.add(mount.prootArgument());
        }
        command.add("/usr/bin/env");
        command.add("-i");
        for (Map.Entry<String, String> item : guestEnvironment.entrySet()) {
            command.add(item.getKey() + "=" + item.getValue());
        }
        command.addAll(guestCommand);
        return new RuntimeProcessSpec(operation, command, runtime.root, hostEnvironment, timeoutMillis);
    }
}
