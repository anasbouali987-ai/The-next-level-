package com.gtav.runtimemanager.execution;

import org.json.JSONObject;

public final class RuntimeSessionSnapshot {
    public final String sessionId;
    public final String runtimeId;
    public final ExecutionStage stage;
    public final String operation;
    public final String command;
    public final long pid;
    public final Integer exitCode;
    public final long startedAt;
    public final long updatedAt;
    public final ExecutionErrorCode errorCode;
    public final String errorMessage;

    public RuntimeSessionSnapshot(String sessionId, String runtimeId, ExecutionStage stage,
                                  String operation, String command, long pid, Integer exitCode,
                                  long startedAt, long updatedAt, ExecutionErrorCode errorCode,
                                  String errorMessage) {
        this.sessionId = sessionId;
        this.runtimeId = runtimeId;
        this.stage = stage;
        this.operation = operation == null ? "" : operation;
        this.command = command == null ? "" : command;
        this.pid = pid;
        this.exitCode = exitCode;
        this.startedAt = startedAt;
        this.updatedAt = updatedAt;
        this.errorCode = errorCode == null ? ExecutionErrorCode.NONE : errorCode;
        this.errorMessage = errorMessage == null ? "" : errorMessage;
    }

    public long elapsedMillis() {
        long end = stage.terminal() ? updatedAt : System.currentTimeMillis();
        return Math.max(0, end - startedAt);
    }

    public JSONObject toJson() {
        JSONObject json = new JSONObject();
        try {
            json.put("session_id", sessionId);
            json.put("runtime_id", runtimeId);
            json.put("stage", stage.name());
            json.put("operation", operation);
            json.put("command", command);
            json.put("pid", pid);
            json.put("exit_code", exitCode == null ? JSONObject.NULL : exitCode);
            json.put("started_at", startedAt);
            json.put("updated_at", updatedAt);
            json.put("elapsed_ms", elapsedMillis());
            json.put("error_code", errorCode.name());
            json.put("error_message", errorMessage);
        } catch (Exception ignored) {}
        return json;
    }

    public static RuntimeSessionSnapshot idle() {
        long now = System.currentTimeMillis();
        return new RuntimeSessionSnapshot("", "", ExecutionStage.IDLE, "", "", -1,
                null, now, now, ExecutionErrorCode.NONE, "");
    }
}
