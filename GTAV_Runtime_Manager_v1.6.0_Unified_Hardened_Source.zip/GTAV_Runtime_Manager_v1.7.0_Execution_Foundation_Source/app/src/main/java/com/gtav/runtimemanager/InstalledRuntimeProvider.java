package com.gtav.runtimemanager;

import android.content.Context;

import com.gtav.runtimemanager.execution.VerifiedInstalledRuntime;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * نقطة العبور الوحيدة من مجال التثبيت المستقر إلى مجال التنفيذ.
 * لا تعيد إلا Runtime مكتمل التثبيت، متطابق الهوية، وله Manifest محفوظ.
 */
public final class InstalledRuntimeProvider {
    private final Context context;

    public InstalledRuntimeProvider(Context context) {
        this.context = context.getApplicationContext();
    }

    public VerifiedInstalledRuntime require(String runtimeId) throws Exception {
        File runtimesRoot = StorageLocations.runtimesRoot(context).getCanonicalFile();
        File root = new File(runtimesRoot, RuntimePaths.safeId(runtimeId)).getCanonicalFile();
        requireInside(root, runtimesRoot);
        VerifiedInstalledRuntime runtime = read(root, runtimesRoot);
        if (runtime == null || !runtime.readyForExecution()) {
            throw new IllegalStateException("Runtime غير مثبت أو غير متحقق أو غير جاهز للتنفيذ: " + runtimeId);
        }
        return runtime;
    }

    public VerifiedInstalledRuntime latestReady() throws Exception {
        List<VerifiedInstalledRuntime> runtimes = listReady();
        if (runtimes.isEmpty()) throw new IllegalStateException("لا يوجد Runtime مثبت ومتحقق وجاهز للتنفيذ");
        return runtimes.get(0);
    }

    public List<VerifiedInstalledRuntime> listReady() {
        List<VerifiedInstalledRuntime> result = new ArrayList<>();
        File runtimesRoot;
        try { runtimesRoot = StorageLocations.runtimesRoot(context).getCanonicalFile(); }
        catch (Exception error) { return result; }
        File[] children = runtimesRoot.listFiles(File::isDirectory);
        if (children == null) return result;
        for (File child : children) {
            try {
                VerifiedInstalledRuntime runtime = read(child.getCanonicalFile(), runtimesRoot);
                if (runtime != null && runtime.readyForExecution()) result.add(runtime);
            } catch (Throwable ignored) {
            }
        }
        result.sort(Comparator.comparingLong((VerifiedInstalledRuntime value) ->
                value.root.lastModified()).reversed());
        return result;
    }

    private static VerifiedInstalledRuntime read(File root, File runtimesRoot) throws Exception {
        requireInside(root, runtimesRoot);
        File stateFile = new File(root, "installed_runtime.json");
        File manifestFile = new File(root, "runtime_manifest.json");
        if (!root.isDirectory() || !stateFile.isFile() || !manifestFile.isFile()) return null;

        JSONObject state = new JSONObject(readSmallText(stateFile, 2 * 1024 * 1024));
        if (!"complete".equals(state.optString("install_state"))) return null;
        if (!"COMPLETED".equalsIgnoreCase(state.optString("stage", "COMPLETED"))) return null;
        String recordedRoot = state.optString("rootfs_path", "");
        if (recordedRoot.isEmpty() || !root.getCanonicalPath().equals(new File(recordedRoot).getCanonicalPath())) return null;

        JSONObject manifest = new JSONObject(readSmallText(manifestFile, 16 * 1024 * 1024));
        String runtimeId = manifest.optString("runtime_id", "");
        String version = manifest.optString("version", "");
        String stateId = state.optString("runtime_id", "");
        String stateVersion = state.optString("version", "");
        if (!runtimeId.equals(stateId) || !version.equals(stateVersion)) return null;
        if (!RuntimePaths.safeId(runtimeId).equals(root.getName())) return null;

        JSONObject payload = manifest.optJSONObject("rootfs_payload");
        String manifestSha = payload == null ? "" : payload.optString("sha256", "");
        String stateSha = state.optString("payload_sha256", "");
        if (!manifestSha.equalsIgnoreCase(stateSha)) return null;

        JSONObject components = manifest.optJSONObject("components");
        JSONObject entrypoints = manifest.optJSONObject("entrypoints");
        Map<String, String> metadata = new LinkedHashMap<>();
        metadata.put("installed_at", state.optString("installed_at", ""));
        metadata.put("install_state", state.optString("install_state", ""));
        metadata.put("rootfs_path", root.getAbsolutePath());
        metadata.put("schema", Integer.toString(state.optInt("schema", -1)));

        return new VerifiedInstalledRuntime(
                root,
                manifestFile,
                runtimeId,
                version,
                stateSha,
                manifest.optString("host_architecture", ""),
                manifest.optString("guest_architecture", ""),
                manifest.optString("libc_model", ""),
                manifest.optString("android_integration_model", ""),
                value(components, "box64"),
                value(components, "wine"),
                value(entrypoints, "wine64"),
                value(entrypoints, "wineboot"),
                value(entrypoints, "wineserver"),
                metadata
        );
    }


    private static void requireInside(File child, File root) throws Exception {
        String childPath = child.getCanonicalPath();
        String rootPath = root.getCanonicalPath();
        if (!childPath.startsWith(rootPath + File.separator)) {
            throw new SecurityException("Runtime path escapes runtimes root: " + childPath);
        }
    }

    private static String value(JSONObject object, String key) {
        return object == null ? "" : object.optString(key, "");
    }

    private static String readSmallText(File file, int maxBytes) throws Exception {
        try (InputStream input = new FileInputStream(file);
             ByteArrayOutputStream output = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[32 * 1024];
            int total = 0;
            int read;
            while ((read = input.read(buffer)) != -1) {
                total += read;
                if (total > maxBytes) throw new IllegalStateException("ملف أكبر من حد القراءة: " + file);
                output.write(buffer, 0, read);
            }
            return output.toString(StandardCharsets.UTF_8.name());
        }
    }
}
