package com.gtav.runtimemanager.execution;

import android.content.Context;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;

public final class ExecutionComponentInstaller {
    private final Context context;

    public ExecutionComponentInstaller(Context context) { this.context = context.getApplicationContext(); }

    public File installHelloX8664(File sessionRoot) throws ExecutionException {
        File output = new File(sessionRoot, "components/hello-x86_64");
        File parent = output.getParentFile();
        if (parent != null && !parent.exists() && !parent.mkdirs()) {
            throw new ExecutionException(ExecutionErrorCode.X86_64_TEST_NOT_PACKAGED,
                    ExecutionStage.PREPARING, "Cannot create component directory");
        }
        try (InputStream input = context.getAssets().open("execution/hello-x86_64");
             FileOutputStream stream = new FileOutputStream(output, false)) {
            byte[] buffer = new byte[64 * 1024];
            int read;
            while ((read = input.read(buffer)) != -1) stream.write(buffer, 0, read);
            stream.getFD().sync();
        } catch (Throwable error) {
            throw new ExecutionException(ExecutionErrorCode.X86_64_TEST_NOT_PACKAGED,
                    ExecutionStage.PREPARING, "hello-x86_64 asset is missing", error);
        }
        if (!output.setExecutable(true, true)) {
            throw new ExecutionException(ExecutionErrorCode.X86_64_TEST_NOT_PACKAGED,
                    ExecutionStage.PREPARING, "Cannot make hello-x86_64 executable");
        }
        try {
            if (ElfInspector.architecture(output) != ElfInspector.Architecture.X86_64) {
                throw new ExecutionException(ExecutionErrorCode.X86_64_TEST_WRONG_ABI,
                        ExecutionStage.PREPARING, "hello-x86_64 has wrong ABI");
            }
        } catch (ExecutionException error) {
            throw error;
        } catch (Throwable error) {
            throw new ExecutionException(ExecutionErrorCode.X86_64_TEST_WRONG_ABI,
                    ExecutionStage.PREPARING, "Cannot inspect hello-x86_64", error);
        }
        return output;
    }
}
