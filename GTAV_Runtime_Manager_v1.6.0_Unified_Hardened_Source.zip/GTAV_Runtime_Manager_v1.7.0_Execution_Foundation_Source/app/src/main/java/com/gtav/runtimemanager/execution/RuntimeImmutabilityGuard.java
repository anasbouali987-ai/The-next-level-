package com.gtav.runtimemanager.execution;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.attribute.BasicFileAttributes;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.stream.Stream;

/**
 * يفرض سياسة Runtime read-mostly: كل مسارات الكتابة تُربط خارج RootFS، ثم تُقارن
 * البنية والقياسات/الأزمنة لكل عقدة قبل الجلسة وبعدها، مع SHA-256 للملفات الحرجة.
 * هذا كشفٌ دفاعي لأن PRoot ليس mount namespace يقدم read-only mount حقيقيًا.
 */
public final class RuntimeImmutabilityGuard {
    private final File root;
    private final Map<String, NodeFingerprint> treeBaseline;
    private final Map<String, CriticalFingerprint> criticalBaseline = new LinkedHashMap<>();

    public RuntimeImmutabilityGuard(VerifiedInstalledRuntime runtime) throws ExecutionException {
        this.root = runtime.root;
        this.treeBaseline = snapshotTree(root);
        captureCritical(runtime.manifestFile);
        captureCritical(new File(runtime.root, "installed_runtime.json"));
        captureCritical(runtime.resolveGuestPath(runtime.wine64Entrypoint));
        if (!runtime.winebootEntrypoint.isEmpty()) captureCritical(runtime.resolveGuestPath(runtime.winebootEntrypoint));
        if (!runtime.wineserverEntrypoint.isEmpty()) captureCritical(runtime.resolveGuestPath(runtime.wineserverEntrypoint));
        File box64 = RuntimeExecutionValidator.locate(runtime.root,
                "usr/local/bin/box64", "usr/bin/box64", "opt/gtav-runtime/bin/box64", "bin/box64");
        if (box64 != null) captureCritical(box64);
    }

    public int baselineNodeCount() { return treeBaseline.size(); }

    public String policySummary() {
        return "Runtime root: " + root + "\n"
                + "Policy: read-mostly / no planned writes inside RootFS\n"
                + "Writable roots: prefixes/, sessions/, cache/, logs/, profiles/\n"
                + "Baseline nodes: " + treeBaseline.size() + "\n"
                + "Critical SHA-256 files: " + criticalBaseline.size() + "\n"
                + "Enforcement: external writable binds + full metadata comparison + critical hashes\n"
                + "Limitation: PRoot itself does not provide a kernel-enforced read-only root mount.\n";
    }

    public void verifyUnchanged() throws ExecutionException {
        Map<String, NodeFingerprint> currentTree = snapshotTree(root);
        List<String> changes = compare(treeBaseline, currentTree, 20);
        for (Map.Entry<String, CriticalFingerprint> item : criticalBaseline.entrySet()) {
            File file = new File(item.getKey());
            CriticalFingerprint current = criticalFingerprint(file);
            if (!item.getValue().equals(current)) changes.add("critical-content-changed: " + file);
        }
        if (!changes.isEmpty()) {
            throw new ExecutionException(ExecutionErrorCode.RUNTIME_MUTABLE_PATH,
                    ExecutionStage.STOPPING,
                    "Immutable runtime changed (" + changes.size() + "): " + String.join("; ", changes));
        }
    }

    private void captureCritical(File file) throws ExecutionException {
        if (file != null && file.isFile()) {
            criticalBaseline.put(file.getAbsolutePath(), criticalFingerprint(file));
        }
    }

    private static Map<String, NodeFingerprint> snapshotTree(File root) throws ExecutionException {
        try {
            Path rootPath = root.toPath();
            Map<String, NodeFingerprint> snapshot = new TreeMap<>();
            try (Stream<Path> paths = Files.walk(rootPath)) {
                paths.forEach(path -> {
                    try {
                        BasicFileAttributes attrs = Files.readAttributes(path,
                                BasicFileAttributes.class, LinkOption.NOFOLLOW_LINKS);
                        String relative = rootPath.relativize(path).toString().replace(File.separatorChar, '/');
                        String type = attrs.isSymbolicLink() ? "symlink"
                                : attrs.isDirectory() ? "directory"
                                : attrs.isRegularFile() ? "file" : "other";
                        snapshot.put(relative, new NodeFingerprint(type, attrs.size(),
                                attrs.lastModifiedTime().toMillis()));
                    } catch (Throwable error) {
                        throw new SnapshotFailure(error);
                    }
                });
            }
            return snapshot;
        } catch (SnapshotFailure error) {
            throw new ExecutionException(ExecutionErrorCode.RUNTIME_NOT_READY,
                    ExecutionStage.VALIDATING, "Cannot snapshot immutable runtime tree", error.getCause());
        } catch (Throwable error) {
            throw new ExecutionException(ExecutionErrorCode.RUNTIME_NOT_READY,
                    ExecutionStage.VALIDATING, "Cannot snapshot immutable runtime tree", error);
        }
    }

    private static List<String> compare(Map<String, NodeFingerprint> baseline,
                                        Map<String, NodeFingerprint> current,
                                        int limit) {
        List<String> changes = new ArrayList<>();
        for (Map.Entry<String, NodeFingerprint> item : baseline.entrySet()) {
            NodeFingerprint now = current.get(item.getKey());
            if (now == null) changes.add("removed: " + item.getKey());
            else if (!item.getValue().equals(now)) changes.add("metadata-changed: " + item.getKey());
            if (changes.size() >= limit) return changes;
        }
        for (String path : current.keySet()) {
            if (!baseline.containsKey(path)) changes.add("added: " + path);
            if (changes.size() >= limit) return changes;
        }
        return changes;
    }

    private static CriticalFingerprint criticalFingerprint(File file) throws ExecutionException {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            try (BufferedInputStream input = new BufferedInputStream(new FileInputStream(file))) {
                byte[] buffer = new byte[64 * 1024];
                int read;
                while ((read = input.read(buffer)) != -1) digest.update(buffer, 0, read);
            }
            StringBuilder hex = new StringBuilder();
            for (byte value : digest.digest()) hex.append(String.format("%02x", value));
            return new CriticalFingerprint(file.length(), file.lastModified(), hex.toString());
        } catch (Throwable error) {
            throw new ExecutionException(ExecutionErrorCode.RUNTIME_NOT_READY,
                    ExecutionStage.VALIDATING, "Cannot fingerprint runtime file: " + file, error);
        }
    }

    private static final class SnapshotFailure extends RuntimeException {
        SnapshotFailure(Throwable cause) { super(cause); }
    }

    private static final class NodeFingerprint {
        final String type;
        final long size;
        final long modified;
        NodeFingerprint(String type, long size, long modified) {
            this.type = type; this.size = size; this.modified = modified;
        }
        @Override public boolean equals(Object object) {
            if (!(object instanceof NodeFingerprint)) return false;
            NodeFingerprint other = (NodeFingerprint) object;
            return size == other.size && modified == other.modified && type.equals(other.type);
        }
        @Override public int hashCode() { return type.hashCode() * 31 + Long.hashCode(size); }
    }

    private static final class CriticalFingerprint {
        final long size;
        final long modified;
        final String sha;
        CriticalFingerprint(long size, long modified, String sha) {
            this.size = size; this.modified = modified; this.sha = sha;
        }
        @Override public boolean equals(Object object) {
            if (!(object instanceof CriticalFingerprint)) return false;
            CriticalFingerprint other = (CriticalFingerprint) object;
            return size == other.size && modified == other.modified && sha.equals(other.sha);
        }
        @Override public int hashCode() { return sha.hashCode(); }
    }
}
