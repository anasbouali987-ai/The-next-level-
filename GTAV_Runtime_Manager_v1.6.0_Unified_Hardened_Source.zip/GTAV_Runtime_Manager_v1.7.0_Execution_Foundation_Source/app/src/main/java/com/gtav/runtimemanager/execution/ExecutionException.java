package com.gtav.runtimemanager.execution;

public final class ExecutionException extends Exception {
    public final ExecutionErrorCode code;
    public final ExecutionStage stage;

    public ExecutionException(ExecutionErrorCode code, ExecutionStage stage, String message) {
        super(message);
        this.code = code;
        this.stage = stage;
    }

    public ExecutionException(ExecutionErrorCode code, ExecutionStage stage, String message, Throwable cause) {
        super(message, cause);
        this.code = code;
        this.stage = stage;
    }
}
