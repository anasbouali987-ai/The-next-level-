package com.gtav.runtimemanager.execution;

public final class RuntimeProcessResult {
    public final String name;
    public final long pid;
    public final int exitCode;
    public final long startedAt;
    public final long finishedAt;
    public final boolean timedOut;
    public final boolean cancelled;
    public final String stdout;
    public final String stderr;

    public RuntimeProcessResult(String name, long pid, int exitCode, long startedAt, long finishedAt,
                                boolean timedOut, boolean cancelled, String stdout, String stderr) {
        this.name = name;
        this.pid = pid;
        this.exitCode = exitCode;
        this.startedAt = startedAt;
        this.finishedAt = finishedAt;
        this.timedOut = timedOut;
        this.cancelled = cancelled;
        this.stdout = stdout == null ? "" : stdout;
        this.stderr = stderr == null ? "" : stderr;
    }

    public long durationMillis() { return Math.max(0, finishedAt - startedAt); }
    public boolean success() { return !timedOut && !cancelled && exitCode == 0; }
}
