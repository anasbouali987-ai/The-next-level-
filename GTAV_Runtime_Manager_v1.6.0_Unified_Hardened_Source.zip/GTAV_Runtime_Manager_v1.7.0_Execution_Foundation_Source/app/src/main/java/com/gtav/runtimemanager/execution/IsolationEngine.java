package com.gtav.runtimemanager.execution;

import java.io.File;
import java.util.List;
import java.util.Map;

public interface IsolationEngine {
    String name();
    File executable();
    void validate() throws ExecutionException;
    RuntimeProcessSpec buildGuestCommand(String operation,
                                         VerifiedInstalledRuntime runtime,
                                         List<RuntimeBindMount> mounts,
                                         Map<String, String> hostEnvironment,
                                         Map<String, String> guestEnvironment,
                                         List<String> guestCommand,
                                         long timeoutMillis) throws ExecutionException;
}
