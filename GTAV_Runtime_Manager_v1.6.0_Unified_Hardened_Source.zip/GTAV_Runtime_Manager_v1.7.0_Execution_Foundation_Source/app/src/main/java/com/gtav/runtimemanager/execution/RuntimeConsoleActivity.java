package com.gtav.runtimemanager.execution;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Build;
import android.Manifest;
import android.content.pm.PackageManager;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.gtav.runtimemanager.R;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.OutputStream;

public final class RuntimeConsoleActivity extends Activity implements RuntimeExecutionManager.Listener {
    private static final int EXPORT_REPORT = 2201;
    private RuntimeExecutionManager manager;
    private TextView stateText;
    private TextView detailsText;
    private TextView consoleText;
    private Button startButton;
    private Button stopButton;
    private Button cancelButton;
    private Button copyButton;
    private Button exportButton;
    private File pendingExport;
    private String latestConsole = "";

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_runtime_console);
        manager = RuntimeExecutionManager.get(this);
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1707);
        }
        stateText = findViewById(R.id.executionStateText);
        detailsText = findViewById(R.id.executionDetailsText);
        consoleText = findViewById(R.id.runtimeConsoleText);
        startButton = findViewById(R.id.startExecutionButton);
        stopButton = findViewById(R.id.stopExecutionButton);
        cancelButton = findViewById(R.id.cancelExecutionButton);
        copyButton = findViewById(R.id.copyExecutionLogButton);
        exportButton = findViewById(R.id.exportExecutionReportButton);
        startButton.setOnClickListener(v -> confirmStart());
        stopButton.setOnClickListener(v -> manager.stopCurrentProcess());
        cancelButton.setOnClickListener(v -> RuntimeExecutionService.stop(this));
        copyButton.setOnClickListener(v -> copyLog());
        exportButton.setOnClickListener(v -> exportReport());
        findViewById(R.id.executionBackButton).setOnClickListener(v -> finish());
        render(manager.current(), "");
    }

    @Override protected void onStart() {
        super.onStart();
        manager.addListener(this);
    }

    @Override protected void onStop() {
        manager.removeListener(this);
        super.onStop();
    }

    private void confirmStart() {
        new AlertDialog.Builder(this)
                .setTitle("تشغيل البوابات التنفيذية")
                .setMessage("سيتم اختبار PRoot ثم RootFS ثم Box64 ثم Wine Console داخل Prefix تشخيصي منفصل.")
                .setNegativeButton("إلغاء", null)
                .setPositiveButton("بدء", (dialog, which) -> RuntimeExecutionService.start(this))
                .show();
    }

    @Override public void onExecutionChanged(RuntimeSessionSnapshot snapshot, String recentConsole) {
        runOnUiThread(() -> render(snapshot, recentConsole));
    }

    private void render(RuntimeSessionSnapshot snapshot, String recentConsole) {
        if (!recentConsole.isEmpty()) latestConsole = recentConsole;
        stateText.setText("الحالة: " + snapshot.stage);
        detailsText.setText(
                "Session: " + empty(snapshot.sessionId) +
                "\nRuntime: " + empty(snapshot.runtimeId) +
                "\nOperation: " + empty(snapshot.operation) +
                "\nPID: " + snapshot.pid +
                "\nChild/observed PIDs: " + manager.currentProcessTreePids() +
                "\nStarted: " + new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.US)
                        .format(new java.util.Date(snapshot.startedAt)) +
                "\nExit Code: " + (snapshot.exitCode == null ? "—" : snapshot.exitCode) +
                "\nElapsed: " + snapshot.elapsedMillis() + " ms" +
                "\nError: " + snapshot.errorCode +
                (snapshot.errorMessage.isEmpty() ? "" : "\n" + snapshot.errorMessage) +
                (snapshot.command.isEmpty() ? "" : "\n\nCommand:\n" + snapshot.command)
        );
        consoleText.setText(latestConsole.isEmpty() ? "لا يوجد سجل بعد." : latestConsole);
        startButton.setEnabled(!manager.isRunning());
        stopButton.setEnabled(manager.isRunning() && snapshot.pid > 0);
        cancelButton.setEnabled(manager.isRunning());
        copyButton.setEnabled(!latestConsole.isEmpty());
        exportButton.setEnabled(manager.currentSessionRoot() != null);
    }

    private void copyLog() {
        android.content.ClipboardManager clipboard =
                (android.content.ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
        if (clipboard != null) {
            clipboard.setPrimaryClip(android.content.ClipData.newPlainText("GTAV execution log", latestConsole));
            Toast.makeText(this, "تم نسخ السجل", Toast.LENGTH_SHORT).show();
        }
    }

    private void exportReport() {
        File root = manager.currentSessionRoot();
        if (root == null) return;
        try {
            pendingExport = RuntimeReportBundle.create(root);
        } catch (Throwable error) {
            Toast.makeText(this, "تعذر إنشاء حزمة التقارير: " + error.getMessage(), Toast.LENGTH_LONG).show();
            return;
        }
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("application/zip");
        intent.putExtra(Intent.EXTRA_TITLE, pendingExport.getName());
        startActivityForResult(intent, EXPORT_REPORT);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != EXPORT_REPORT || resultCode != RESULT_OK || data == null || pendingExport == null) return;
        Uri uri = data.getData();
        if (uri == null) return;
        try (BufferedInputStream input = new BufferedInputStream(new FileInputStream(pendingExport));
             OutputStream raw = getContentResolver().openOutputStream(uri, "w");
             BufferedOutputStream output = raw == null ? null : new BufferedOutputStream(raw)) {
            if (output == null) throw new IllegalStateException("تعذر فتح ملف التصدير");
            byte[] buffer = new byte[64 * 1024];
            int read;
            while ((read = input.read(buffer)) != -1) output.write(buffer, 0, read);
            output.flush();
            Toast.makeText(this, "تم تصدير التقرير", Toast.LENGTH_SHORT).show();
        } catch (Throwable error) {
            Toast.makeText(this, error.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private static String empty(String value) { return value == null || value.isEmpty() ? "—" : value; }
}
