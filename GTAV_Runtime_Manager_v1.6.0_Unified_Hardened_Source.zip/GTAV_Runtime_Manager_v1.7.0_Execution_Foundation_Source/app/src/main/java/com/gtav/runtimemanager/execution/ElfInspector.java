package com.gtav.runtimemanager.execution;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;

public final class ElfInspector {
    public enum Architecture { AARCH64, X86_64, ARM, X86, UNKNOWN }

    private ElfInspector() {}

    public static Architecture architecture(File file) throws IOException {
        byte[] header = new byte[20];
        try (InputStream input = new FileInputStream(file)) {
            int offset = 0;
            while (offset < header.length) {
                int read = input.read(header, offset, header.length - offset);
                if (read < 0) break;
                offset += read;
            }
            if (offset < header.length) return Architecture.UNKNOWN;
        }
        if ((header[0] & 0xff) != 0x7f || header[1] != 'E' || header[2] != 'L' || header[3] != 'F') {
            return Architecture.UNKNOWN;
        }
        boolean little = header[5] == 1;
        int machine = little
                ? (header[18] & 0xff) | ((header[19] & 0xff) << 8)
                : ((header[18] & 0xff) << 8) | (header[19] & 0xff);
        switch (machine) {
            case 183: return Architecture.AARCH64;
            case 62: return Architecture.X86_64;
            case 40: return Architecture.ARM;
            case 3: return Architecture.X86;
            default: return Architecture.UNKNOWN;
        }
    }
}
