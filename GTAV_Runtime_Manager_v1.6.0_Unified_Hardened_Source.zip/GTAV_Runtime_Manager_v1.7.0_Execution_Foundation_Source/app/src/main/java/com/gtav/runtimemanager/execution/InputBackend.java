package com.gtav.runtimemanager.execution;

/** عقد مستقبلي فقط؛ Touch/Gamepad mapping خارج معيار نجاح v1.7.0. */
public interface InputBackend {
    String id();
    FeatureCapability capability();
}
