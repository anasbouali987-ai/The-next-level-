package com.gtav.runtimemanager.execution;

import java.io.BufferedWriter;
import java.io.Closeable;
import java.io.File;
import java.io.FileOutputStream;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * يكتب السجل الكامل مباشرة إلى ملف، ولا يحتفظ في الذاكرة إلا بنافذة محدودة للواجهة.
 */
public final class RuntimeConsoleStore implements Closeable {
    public enum Stream { SYSTEM, STDOUT, STDERR }
    public interface Listener { void onConsoleAppended(); }

    private final File logFile;
    private final int maxMemoryLines;
    private final ArrayDeque<String> recent = new ArrayDeque<>();
    private final BufferedWriter writer;
    private final Listener listener;
    private boolean closed;

    public RuntimeConsoleStore(File logFile, int maxMemoryLines) throws IOException {
        this(logFile, maxMemoryLines, null);
    }

    public RuntimeConsoleStore(File logFile, int maxMemoryLines, Listener listener) throws IOException {
        this.logFile = logFile;
        this.maxMemoryLines = Math.max(50, maxMemoryLines);
        this.listener = listener;
        File parent = logFile.getParentFile();
        if (parent != null && !parent.exists() && !parent.mkdirs()) {
            throw new IOException("Cannot create console directory: " + parent);
        }
        writer = new BufferedWriter(new OutputStreamWriter(
                new FileOutputStream(logFile, true), StandardCharsets.UTF_8), 64 * 1024);
    }

    public void append(Stream stream, String text) {
        synchronized (this) {
            if (closed) return;
            String value = text == null ? "" : text;
            String[] lines = value.replace("\r", "").split("\n", -1);
            for (String line : lines) {
                if (line.isEmpty() && lines.length > 1) continue;
                String formatted = timestamp() + " [" + stream.name() + "] " + line;
                recent.addLast(formatted);
                while (recent.size() > maxMemoryLines) recent.removeFirst();
                try {
                    writer.write(formatted);
                    writer.newLine();
                    writer.flush();
                } catch (IOException ignored) {
                }
            }
        }
        if (listener != null) {
            try { listener.onConsoleAppended(); } catch (Throwable ignored) {}
        }
    }

    public synchronized List<String> recentLines() {
        return new ArrayList<>(recent);
    }

    public synchronized String recentText() {
        StringBuilder result = new StringBuilder();
        for (String line : recent) result.append(line).append('\n');
        return result.toString();
    }


    public static String readRecentText(File file, int maxLines) {
        if (file == null || !file.isFile()) return "";
        ArrayDeque<String> lines = new ArrayDeque<>();
        int limit = Math.max(1, maxLines);
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                lines.addLast(line);
                while (lines.size() > limit) lines.removeFirst();
            }
        } catch (IOException ignored) { return ""; }
        StringBuilder text = new StringBuilder();
        for (String line : lines) text.append(line).append('\n');
        return text.toString();
    }

    public File file() { return logFile; }

    @Override public synchronized void close() throws IOException {
        if (closed) return;
        closed = true;
        writer.close();
    }

    private static String timestamp() {
        return new SimpleDateFormat("HH:mm:ss.SSS", Locale.US).format(new Date());
    }
}
