package com.gtav.runtimemanager.execution;

public enum ExecutionStage {
    IDLE,
    PREPARING,
    VALIDATING,
    STARTING_PROOT,
    ENTERING_ROOTFS,
    RUNNING_BOX64,
    STARTING_WINE,
    RUNNING,
    STOPPING,
    COMPLETED,
    FAILED,
    CANCELLED;

    public boolean terminal() {
        return this == COMPLETED || this == FAILED || this == CANCELLED;
    }
}
