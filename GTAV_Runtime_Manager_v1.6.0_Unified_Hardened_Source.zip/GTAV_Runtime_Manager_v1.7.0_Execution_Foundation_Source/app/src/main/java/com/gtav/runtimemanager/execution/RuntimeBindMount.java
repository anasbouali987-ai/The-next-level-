package com.gtav.runtimemanager.execution;

import java.io.File;
import java.util.Objects;

public final class RuntimeBindMount {
    public final File hostPath;
    public final String guestPath;
    public final boolean readOnly;
    public final boolean required;

    public RuntimeBindMount(File hostPath, String guestPath, boolean readOnly, boolean required) {
        this.hostPath = Objects.requireNonNull(hostPath, "hostPath").getAbsoluteFile();
        this.guestPath = normalizeGuestPath(guestPath);
        this.readOnly = readOnly;
        this.required = required;
    }

    public void validate() throws ExecutionException {
        if (required && !hostPath.exists()) {
            throw new ExecutionException(
                    ExecutionErrorCode.RUNTIME_NOT_READY,
                    ExecutionStage.VALIDATING,
                    "Required bind source is missing: " + hostPath
            );
        }
    }

    public String prootArgument() {
        return hostPath.getAbsolutePath() + ":" + guestPath;
    }

    private static String normalizeGuestPath(String value) {
        if (value == null || value.isEmpty() || !value.startsWith("/")) {
            throw new IllegalArgumentException("Guest path must be absolute: " + value);
        }
        String path = value.replace('\\', '/');
        if (path.contains("/../") || path.endsWith("/..")) {
            throw new IllegalArgumentException("Unsafe guest path: " + value);
        }
        return path;
    }

    @Override public String toString() {
        return hostPath + " -> " + guestPath + " [" +
                (readOnly ? "read-only-policy" : "read-write") +
                ", required=" + required + "]";
    }
}
