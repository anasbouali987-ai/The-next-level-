package com.gtav.runtimemanager.execution;

import java.io.File;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;

public final class VerifiedInstalledRuntime {
    public final File root;
    public final File manifestFile;
    public final String runtimeId;
    public final String version;
    public final String payloadSha256;
    public final String hostArchitecture;
    public final String guestArchitecture;
    public final String libcModel;
    public final String integrationModel;
    public final String box64Version;
    public final String wineVersion;
    public final String wine64Entrypoint;
    public final String winebootEntrypoint;
    public final String wineserverEntrypoint;
    public final Map<String, String> metadata;

    public VerifiedInstalledRuntime(
            File root,
            File manifestFile,
            String runtimeId,
            String version,
            String payloadSha256,
            String hostArchitecture,
            String guestArchitecture,
            String libcModel,
            String integrationModel,
            String box64Version,
            String wineVersion,
            String wine64Entrypoint,
            String winebootEntrypoint,
            String wineserverEntrypoint,
            Map<String, String> metadata
    ) {
        this.root = root;
        this.manifestFile = manifestFile;
        this.runtimeId = runtimeId;
        this.version = version;
        this.payloadSha256 = payloadSha256;
        this.hostArchitecture = hostArchitecture;
        this.guestArchitecture = guestArchitecture;
        this.libcModel = libcModel;
        this.integrationModel = integrationModel;
        this.box64Version = box64Version;
        this.wineVersion = wineVersion;
        this.wine64Entrypoint = normalizeGuestPath(wine64Entrypoint);
        this.winebootEntrypoint = normalizeGuestPath(winebootEntrypoint);
        this.wineserverEntrypoint = normalizeGuestPath(wineserverEntrypoint);
        this.metadata = Collections.unmodifiableMap(new LinkedHashMap<>(metadata));
    }

    public File resolveGuestPath(String guestPath) {
        String normalized = normalizeGuestPath(guestPath);
        return new File(root, normalized);
    }

    public boolean readyForExecution() {
        return root.isDirectory()
                && manifestFile.isFile()
                && !runtimeId.isEmpty()
                && !version.isEmpty()
                && payloadSha256.matches("[0-9a-fA-F]{64}")
                && "arm64".equalsIgnoreCase(hostArchitecture)
                && "x86_64".equalsIgnoreCase(guestArchitecture)
                && libcModel.toLowerCase().contains("glibc")
                && RuntimeExecutionValidator.locate(root,
                    "usr/local/bin/box64", "usr/bin/box64", "opt/gtav-runtime/bin/box64", "bin/box64") != null
                && resolveGuestPath(wine64Entrypoint).isFile()
                && resolveGuestPath(winebootEntrypoint).isFile()
                && (wineserverEntrypoint.isEmpty() || resolveGuestPath(wineserverEntrypoint).isFile());
    }

    private static String normalizeGuestPath(String value) {
        String path = value == null ? "" : value.replace('\\', '/');
        while (path.startsWith("/")) path = path.substring(1);
        while (path.startsWith("./")) path = path.substring(2);
        if (path.contains("../") || path.equals("..")) {
            throw new IllegalArgumentException("Unsafe guest path: " + value);
        }
        return path;
    }
}
