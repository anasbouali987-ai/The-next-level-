package com.gtav.runtimemanager.execution;

import android.os.Build;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;

public final class ProotCompatibilityDiagnostic {
    private ProotCompatibilityDiagnostic() {}

    public static String collect(File proot) {
        StringBuilder text = new StringBuilder();
        text.append("PRoot path: ").append(proot).append('\n');
        text.append("PRoot exists: ").append(proot.isFile()).append('\n');
        text.append("PRoot executable: ").append(proot.canExecute()).append('\n');
        try { text.append("PRoot ELF: ").append(ElfInspector.architecture(proot)).append('\n'); }
        catch (Throwable error) { text.append("PRoot ELF error: ").append(error).append('\n'); }
        text.append("Android SDK: ").append(Build.VERSION.SDK_INT).append('\n');
        text.append("ABIs: ").append(String.join(",", Build.SUPPORTED_ABIS)).append('\n');
        text.append("SELinux enforcing: ").append(readFirst("/sys/fs/selinux/enforce")).append('\n');
        text.append("Process security status:\n");
        text.append(selectStatusLines("/proc/self/status", "Seccomp:", "NoNewPrivs:", "TracerPid:"));
        text.append("execve diagnosis: validated by launching PRoot through RuntimeProcessRunner\n");
        return text.toString();
    }

    private static String readFirst(String path) {
        try (BufferedReader reader = new BufferedReader(new FileReader(path))) {
            String line = reader.readLine();
            return line == null ? "unknown" : line.trim();
        } catch (Throwable ignored) { return "unavailable"; }
    }

    private static String selectStatusLines(String path, String... prefixes) {
        StringBuilder text = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new FileReader(path))) {
            String line;
            while ((line = reader.readLine()) != null) {
                for (String prefix : prefixes) {
                    if (line.startsWith(prefix)) text.append(line).append('\n');
                }
            }
        } catch (Throwable error) {
            text.append("status unavailable: ").append(error).append('\n');
        }
        return text.toString();
    }
}
