package com.gtav.runtimemanager.execution;

import android.content.Context;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.nio.charset.StandardCharsets;

/** يدير Prefix تشخيصيًا خارج RootFS ويمنع استخدامه من جلستين متعارضتين. */
public final class WinePrefixManager {
    private final Context context;

    public WinePrefixManager(Context context) { this.context = context.getApplicationContext(); }

    public PrefixLease acquire(String runtimeId, String runtimeVersion) throws ExecutionException {
        try {
            File root = ExecutionPaths.prefixRoot(context,
                    runtimeId + "-" + runtimeVersion + "-diagnostic");
            File lock = new File(root, ".execution-prefix.lock");
            removeStaleLock(lock);
            if (!lock.createNewFile()) {
                throw new ExecutionException(ExecutionErrorCode.WINE_PREFIX_LOCKED,
                        ExecutionStage.STARTING_WINE, "Wine prefix is already locked: " + root);
            }
            try (FileOutputStream output = new FileOutputStream(lock, false)) {
                output.write(("pid=" + android.os.Process.myPid() + "\n" +
                        "created=" + System.currentTimeMillis() + "\n").getBytes(StandardCharsets.UTF_8));
                output.getFD().sync();
            }
            return new PrefixLease(root, lock);
        } catch (ExecutionException error) {
            throw error;
        } catch (Throwable error) {
            throw new ExecutionException(ExecutionErrorCode.WINE_PREFIX_LOCKED,
                    ExecutionStage.STARTING_WINE, "Cannot acquire Wine prefix", error);
        }
    }

    private static void removeStaleLock(File lock) {
        if (!lock.isFile()) return;
        long pid = -1;
        try (BufferedReader reader = new BufferedReader(new FileReader(lock))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.startsWith("pid=")) pid = Long.parseLong(line.substring(4).trim());
            }
        } catch (Throwable ignored) {
        }
        if (pid <= 0 || !new File("/proc/" + pid).isDirectory()) {
            try { lock.delete(); } catch (Throwable ignored) {}
        }
    }

    public static final class PrefixLease implements AutoCloseable {
        public final File root;
        private final File lock;

        PrefixLease(File root, File lock) { this.root = root; this.lock = lock; }

        @Override public void close() {
            try { lock.delete(); } catch (Throwable ignored) {}
        }
    }
}
