package com.gtav.runtimemanager.execution;

import org.json.JSONArray;

import java.util.Collections;
import java.util.EnumMap;
import java.util.Map;

public final class BackendCapabilityRegistry {
    public enum Backend { DISPLAY, AUDIO, GRAPHICS, INPUT }

    private final EnumMap<Backend, FeatureCapability> capabilities = new EnumMap<>(Backend.class);

    public BackendCapabilityRegistry() {
        capabilities.put(Backend.DISPLAY, experimental(FeatureCapability.Feature.DISPLAY));
        capabilities.put(Backend.AUDIO, experimental(FeatureCapability.Feature.AUDIO));
        capabilities.put(Backend.GRAPHICS, experimental(FeatureCapability.Feature.GRAPHICS));
        capabilities.put(Backend.INPUT, experimental(FeatureCapability.Feature.INPUT));
    }

    private static FeatureCapability experimental(FeatureCapability.Feature feature) {
        return new FeatureCapability(feature, false, false, false, false,
                FeatureCapability.State.EXPERIMENTAL,
                "واجهة القدرة موجودة؛ التنفيذ مؤجل إلى إصدار لاحق");
    }

    public FeatureCapability get(Backend backend) {
        return capabilities.get(backend);
    }

    public Map<Backend, FeatureCapability> snapshot() {
        return Collections.unmodifiableMap(new EnumMap<>(capabilities));
    }

    public JSONArray toJson() {
        JSONArray array = new JSONArray();
        for (FeatureCapability capability : capabilities.values()) array.put(capability.toJson());
        return array;
    }
}
