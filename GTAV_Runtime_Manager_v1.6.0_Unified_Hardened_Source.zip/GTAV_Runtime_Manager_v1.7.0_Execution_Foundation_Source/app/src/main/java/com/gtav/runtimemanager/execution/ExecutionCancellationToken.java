package com.gtav.runtimemanager.execution;

import java.util.concurrent.atomic.AtomicBoolean;

public final class ExecutionCancellationToken {
    private final AtomicBoolean cancelled = new AtomicBoolean(false);
    public void cancel() { cancelled.set(true); }
    public boolean isCancelled() { return cancelled.get(); }
    public void throwIfCancelled(ExecutionStage stage) throws ExecutionException {
        if (isCancelled()) {
            throw new ExecutionException(ExecutionErrorCode.PROCESS_CANCELLED, stage, "تم إلغاء جلسة التنفيذ");
        }
    }
}
