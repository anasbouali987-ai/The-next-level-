package com.gtav.runtimemanager.execution;

/** عقد مستقبلي فقط؛ Vulkan/DXVK خارج معيار نجاح v1.7.0. */
public interface GraphicsBackend {
    String id();
    FeatureCapability capability();
}
