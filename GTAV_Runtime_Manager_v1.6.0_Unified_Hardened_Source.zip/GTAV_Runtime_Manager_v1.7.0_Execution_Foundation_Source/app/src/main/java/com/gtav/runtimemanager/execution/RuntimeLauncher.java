package com.gtav.runtimemanager.execution;

import android.content.Context;

import java.io.File;
import java.util.List;
import java.util.Map;

/** يبني خطة التنفيذ فقط ولا يشغّل العمليات. */
public final class RuntimeLauncher {
    private final Context context;

    public RuntimeLauncher(Context context) { this.context = context.getApplicationContext(); }

    public RuntimeLaunchPlan build(VerifiedInstalledRuntime runtime,
                                   String sessionId,
                                   WinePrefixManager.PrefixLease prefixLease)
            throws Exception {
        File sessionRoot = ExecutionPaths.sessionRoot(context, sessionId);
        File hello = new ExecutionComponentInstaller(context).installHelloX8664(sessionRoot);
        RuntimeEnvironmentBuilder environmentBuilder = new RuntimeEnvironmentBuilder(context);
        Map<String, String> host = environmentBuilder.buildHostEnvironment(sessionRoot);
        Map<String, String> guest = new Box64EnvironmentBuilder().apply(
                environmentBuilder.buildGuestEnvironment(prefixLease.root), true);
        RuntimeMountManager mountManager = new RuntimeMountManager(context);
        List<RuntimeBindMount> mounts = mountManager.buildDefaultMounts(
                runtime, sessionRoot, prefixLease.root, hello);
        IsolationEngine isolation = new ProotIsolationEngine(context);
        Box64Manager box64 = new Box64Manager(runtime);
        WineManager wine = new WineManager(runtime);
        return new RuntimeLaunchPlan(runtime, sessionRoot, prefixLease.root, hello,
                mounts, host, guest, isolation, box64, wine);
    }
}
