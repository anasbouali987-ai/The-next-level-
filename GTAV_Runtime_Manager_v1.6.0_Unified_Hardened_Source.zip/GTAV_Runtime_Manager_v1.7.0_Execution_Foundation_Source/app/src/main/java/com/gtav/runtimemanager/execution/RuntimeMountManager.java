package com.gtav.runtimemanager.execution;

import android.content.Context;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public final class RuntimeMountManager {
    private final Context context;

    public RuntimeMountManager(Context context) { this.context = context.getApplicationContext(); }

    public List<RuntimeBindMount> buildDefaultMounts(VerifiedInstalledRuntime runtime,
                                                      File sessionRoot,
                                                      File prefixRoot,
                                                      File helloBinary) throws Exception {
        List<RuntimeBindMount> mounts = new ArrayList<>();
        mounts.add(new RuntimeBindMount(new File("/proc"), "/proc", true, true));
        mounts.add(new RuntimeBindMount(new File("/dev"), "/dev", false, true));
        mounts.add(new RuntimeBindMount(ExecutionPaths.ensure(new File(sessionRoot, "guest-tmp")), "/tmp", false, true));
        mounts.add(new RuntimeBindMount(ExecutionPaths.ensure(new File(sessionRoot, "home")), "/home/gtav", false, true));
        mounts.add(new RuntimeBindMount(prefixRoot, "/home/gtav/.wine", false, true));
        mounts.add(new RuntimeBindMount(ExecutionPaths.ensure(new File(sessionRoot, "cache")), "/home/gtav/.cache", false, true));
        mounts.add(new RuntimeBindMount(helloBinary, "/opt/gtav-tests/hello-x86_64", true, true));
        File external = context.getExternalFilesDir(null);
        if (external != null) mounts.add(new RuntimeBindMount(external, "/mnt/android-external", false, false));
        validate(mounts, runtime.root);
        return Collections.unmodifiableList(mounts);
    }

    public void validate(List<RuntimeBindMount> mounts, File runtimeRoot) throws ExecutionException {
        Set<String> guests = new HashSet<>();
        for (RuntimeBindMount mount : mounts) {
            mount.validate();
            if (!guests.add(mount.guestPath)) {
                throw new ExecutionException(ExecutionErrorCode.RUNTIME_NOT_READY,
                        ExecutionStage.VALIDATING, "Duplicate guest bind path: " + mount.guestPath);
            }
            if (isChild(mount.hostPath, runtimeRoot) && !mount.readOnly) {
                throw new ExecutionException(ExecutionErrorCode.RUNTIME_MUTABLE_PATH,
                        ExecutionStage.VALIDATING,
                        "Execution cannot create a writable bind from inside the immutable runtime: " + mount.hostPath);
            }
        }
    }

    private static boolean isChild(File candidate, File root) {
        try {
            String c = candidate.getCanonicalPath();
            String r = root.getCanonicalPath();
            return c.equals(r) || c.startsWith(r + File.separator);
        } catch (Exception ignored) { return false; }
    }

    public static String format(List<RuntimeBindMount> mounts) {
        StringBuilder text = new StringBuilder();
        for (RuntimeBindMount mount : mounts) text.append(mount).append('\n');
        return text.toString();
    }
}
