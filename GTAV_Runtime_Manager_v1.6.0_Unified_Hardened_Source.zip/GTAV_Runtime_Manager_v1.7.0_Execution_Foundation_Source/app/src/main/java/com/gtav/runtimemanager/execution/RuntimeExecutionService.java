package com.gtav.runtimemanager.execution;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;

import com.gtav.runtimemanager.R;

public final class RuntimeExecutionService extends Service implements RuntimeExecutionManager.Listener {
    public static final String ACTION_START = "com.gtav.runtimemanager.execution.START";
    public static final String ACTION_STOP = "com.gtav.runtimemanager.execution.STOP";
    private static final String CHANNEL_ID = "gtav_runtime_execution";
    private static final int NOTIFICATION_ID = 1700;

    private RuntimeExecutionManager manager;
    private PowerManager.WakeLock wakeLock;

    public static void start(Context context) {
        ensureChannel(context);
        Intent intent = new Intent(context, RuntimeExecutionService.class).setAction(ACTION_START);
        context.startForegroundService(intent);
    }

    public static void stop(Context context) {
        Intent intent = new Intent(context, RuntimeExecutionService.class).setAction(ACTION_STOP);
        context.startService(intent);
    }

    @Override public void onCreate() {
        super.onCreate();
        ensureChannel(this);
        manager = RuntimeExecutionManager.get(this);
        manager.addListener(this);
        try {
            PowerManager power = (PowerManager) getSystemService(Context.POWER_SERVICE);
            if (power != null) {
                wakeLock = power.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,
                        "GTAVRuntimeManager:ExecutionSession");
                wakeLock.setReferenceCounted(false);
            }
        } catch (Throwable ignored) {}
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? ACTION_START : intent.getAction();
        startForeground(NOTIFICATION_ID, buildNotification(this, manager.current()));
        if (ACTION_STOP.equals(action)) {
            manager.cancel();
            if (!manager.isRunning()) stopSelf(startId);
            return START_NOT_STICKY;
        }
        if (wakeLock != null && !wakeLock.isHeld()) {
            try { wakeLock.acquire(6L * 60L * 60L * 1000L); } catch (Throwable ignored) {}
        }
        boolean started = manager.startFullDiagnostic();
        if (!started && !manager.isRunning()) stopSelf(startId);
        return START_STICKY;
    }

    @Override public void onExecutionChanged(RuntimeSessionSnapshot snapshot, String recentConsole) {
        notifyNow(snapshot);
        if (snapshot.stage.terminal() && !manager.isRunning()) stopSelf();
    }

    @SuppressLint("NotificationPermission")
    private void notifyNow(RuntimeSessionSnapshot snapshot) {
        try {
            if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                    != PackageManager.PERMISSION_GRANTED) return;
            NotificationManager notifications =
                    (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            if (notifications != null) notifications.notify(NOTIFICATION_ID, buildNotification(this, snapshot));
        } catch (Throwable ignored) {}
    }

    @Override public void onDestroy() {
        manager.removeListener(this);
        try { if (wakeLock != null && wakeLock.isHeld()) wakeLock.release(); } catch (Throwable ignored) {}
        stopForeground(STOP_FOREGROUND_REMOVE);
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }

    private static Notification buildNotification(Context context, RuntimeSessionSnapshot snapshot) {
        Intent open = new Intent(context, RuntimeConsoleActivity.class);
        PendingIntent content = PendingIntent.getActivity(context, 1700, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Intent stop = new Intent(context, RuntimeExecutionService.class).setAction(ACTION_STOP);
        PendingIntent stopAction = PendingIntent.getService(context, 1701, stop,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        String text = snapshot.stage + (snapshot.operation.isEmpty() ? "" : " — " + snapshot.operation)
                + " — " + formatElapsed(snapshot.elapsedMillis());
        Notification.Builder builder = new Notification.Builder(context, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.stat_sys_download_done)
                .setContentTitle("GTAV Execution Foundation")
                .setContentText(text)
                .setStyle(new Notification.BigTextStyle().bigText(
                        text + (snapshot.command.isEmpty() ? "" : "\n" + snapshot.command)))
                .setContentIntent(content)
                .setOnlyAlertOnce(true)
                .setOngoing(!snapshot.stage.terminal())
                .setCategory(Notification.CATEGORY_SERVICE);
        if (!snapshot.stage.terminal()) {
            builder.addAction(android.R.drawable.ic_menu_close_clear_cancel, "إيقاف", stopAction);
        }
        return builder.build();
    }

    private static String formatElapsed(long ms) {
        long seconds = ms / 1000L;
        return String.format(java.util.Locale.US, "%02d:%02d:%02d",
                seconds / 3600, (seconds / 60) % 60, seconds % 60);
    }

    private static void ensureChannel(Context context) {
        NotificationManager manager =
                (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (manager == null) return;
        NotificationChannel channel = new NotificationChannel(CHANNEL_ID,
                "جلسات تنفيذ GTAV Runtime", NotificationManager.IMPORTANCE_LOW);
        channel.setDescription("حالة PRoot وRootFS وBox64 وWine Console");
        manager.createNotificationChannel(channel);
    }
}
