package com.gtav.runtimemanager.execution;

import android.content.Context;

import java.io.File;
import java.io.IOException;

public final class ExecutionPaths {
    private ExecutionPaths() {}

    public static File executionRoot(Context context) throws IOException {
        return ensure(new File(context.getFilesDir(), "execution"));
    }

    public static File prefixesRoot(Context context) throws IOException {
        return ensure(new File(context.getFilesDir(), "prefixes"));
    }

    public static File sessionsRoot(Context context) throws IOException {
        return ensure(new File(context.getFilesDir(), "sessions"));
    }

    public static File cacheRoot(Context context) throws IOException {
        return ensure(new File(context.getCacheDir(), "runtime-execution"));
    }

    public static File logsRoot(Context context) throws IOException {
        return ensure(new File(context.getFilesDir(), "logs/execution"));
    }

    public static File profilesRoot(Context context) throws IOException {
        return ensure(new File(context.getFilesDir(), "profiles"));
    }

    public static File sessionRoot(Context context, String sessionId) throws IOException {
        return ensure(new File(sessionsRoot(context), safeId(sessionId)));
    }

    public static File prefixRoot(Context context, String prefixId) throws IOException {
        return ensure(new File(prefixesRoot(context), safeId(prefixId)));
    }

    public static File ensure(File file) throws IOException {
        if (!file.exists() && !file.mkdirs()) {
            throw new IOException("Cannot create directory: " + file.getAbsolutePath());
        }
        if (!file.isDirectory()) throw new IOException("Not a directory: " + file);
        return file;
    }

    public static String safeId(String value) {
        if (value == null || value.isEmpty()) return "default";
        return value.replaceAll("[^A-Za-z0-9._-]", "_");
    }
}
