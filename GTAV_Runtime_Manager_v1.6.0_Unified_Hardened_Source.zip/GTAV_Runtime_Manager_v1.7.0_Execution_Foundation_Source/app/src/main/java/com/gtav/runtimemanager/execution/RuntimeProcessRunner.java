package com.gtav.runtimemanager.execution;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.Map;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;

/** يشغّل عملية واحدة فقط؛ إدارة الجلسة والشجرة مسؤولية RuntimeProcessSupervisor. */
public final class RuntimeProcessRunner {
    private static final int MAX_RESULT_CHARS_PER_STREAM = 2 * 1024 * 1024;

    public interface ProcessObserver {
        void onStarted(Process process, long pid);
        void onFinished(Process process, RuntimeProcessResult result);
    }

    public RuntimeProcessResult run(RuntimeProcessSpec spec,
                                    ExecutionCancellationToken token,
                                    RuntimeConsoleStore console,
                                    ProcessObserver observer) throws ExecutionException {
        long started = System.currentTimeMillis();
        Process process;
        try {
            ProcessBuilder builder = new ProcessBuilder(spec.command);
            if (spec.workingDirectory != null) builder.directory(spec.workingDirectory);
            Map<String, String> environment = builder.environment();
            environment.clear();
            environment.putAll(spec.environment);
            process = builder.start();
        } catch (Throwable error) {
            throw new ExecutionException(ExecutionErrorCode.PROCESS_START_FAILED,
                    ExecutionStage.RUNNING, "تعذر تشغيل: " + spec.printableCommand(), error);
        }

        long pid = processPid(process);
        if (console != null) {
            console.append(RuntimeConsoleStore.Stream.SYSTEM, "COMMAND: " + spec.printableCommand());
            console.append(RuntimeConsoleStore.Stream.SYSTEM, "PID: " + pid);
        }
        if (observer != null) observer.onStarted(process, pid);

        BoundedTextBuffer stdout = new BoundedTextBuffer(MAX_RESULT_CHARS_PER_STREAM);
        BoundedTextBuffer stderr = new BoundedTextBuffer(MAX_RESULT_CHARS_PER_STREAM);
        CountDownLatch streamsDone = new CountDownLatch(2);
        Thread outThread = streamThread("runtime-stdout", process.getInputStream(), stdout,
                line -> { if (console != null) console.append(RuntimeConsoleStore.Stream.STDOUT, line); }, streamsDone);
        Thread errThread = streamThread("runtime-stderr", process.getErrorStream(), stderr,
                line -> { if (console != null) console.append(RuntimeConsoleStore.Stream.STDERR, line); }, streamsDone);
        outThread.setDaemon(true);
        errThread.setDaemon(true);
        outThread.start();
        errThread.start();

        boolean timeout = false;
        boolean cancelled = false;
        int exitCode = -1;
        long deadline = android.os.SystemClock.elapsedRealtime() + spec.timeoutMillis;
        try {
            while (true) {
                if (token != null && token.isCancelled()) {
                    cancelled = true;
                    terminate(process);
                    break;
                }
                if (process.waitFor(100, TimeUnit.MILLISECONDS)) {
                    exitCode = process.exitValue();
                    break;
                }
                if (android.os.SystemClock.elapsedRealtime() >= deadline) {
                    timeout = true;
                    terminate(process);
                    break;
                }
            }
            if (exitCode == -1) {
                try { exitCode = process.waitFor(); }
                catch (InterruptedException ignored) { Thread.currentThread().interrupt(); }
            }
            streamsDone.await(3, TimeUnit.SECONDS);
        } catch (InterruptedException error) {
            Thread.currentThread().interrupt();
            cancelled = true;
            terminate(process);
        }

        RuntimeProcessResult result = new RuntimeProcessResult(
                spec.name, pid, exitCode, started, System.currentTimeMillis(),
                timeout, cancelled, stdout.value(), stderr.value());
        if (console != null) {
            console.append(RuntimeConsoleStore.Stream.SYSTEM,
                    "EXIT: " + result.exitCode + " duration=" + result.durationMillis() +
                            "ms timeout=" + timeout + " cancelled=" + cancelled);
            if (stdout.truncated() || stderr.truncated()) {
                console.append(RuntimeConsoleStore.Stream.SYSTEM,
                        "REPORT_CAPTURE_TRUNCATED full output remains in execution_log.txt");
            }
        }
        if (observer != null) observer.onFinished(process, result);
        return result;
    }

    private static Thread streamThread(String name, InputStream input, BoundedTextBuffer target,
                                       Consumer<String> consumer, CountDownLatch done) {
        return new Thread(() -> {
            try (BufferedReader reader = new BufferedReader(
                    new InputStreamReader(input, StandardCharsets.UTF_8), 16 * 1024)) {
                String line;
                while ((line = reader.readLine()) != null) {
                    target.appendLine(line);
                    consumer.accept(line);
                }
            } catch (IOException ignored) {
            } finally {
                done.countDown();
            }
        }, name);
    }

    private static void terminate(Process process) {
        try { process.destroy(); } catch (Throwable ignored) {}
        try {
            if (!process.waitFor(1500, TimeUnit.MILLISECONDS)) process.destroyForcibly();
        } catch (Throwable ignored) {
            try { process.destroyForcibly(); } catch (Throwable ignoredAgain) {}
        }
    }

    private static long processPid(Process process) {
        try { return process.pid(); } catch (Throwable ignored) { return -1; }
    }

    private static final class BoundedTextBuffer {
        private final int maxChars;
        private final StringBuilder value = new StringBuilder();
        private boolean truncated;

        BoundedTextBuffer(int maxChars) { this.maxChars = Math.max(1024, maxChars); }

        synchronized void appendLine(String line) {
            if (truncated) return;
            int required = line.length() + 1;
            if (value.length() + required > maxChars) {
                int remaining = maxChars - value.length();
                if (remaining > 0) value.append(line, 0, Math.min(line.length(), remaining));
                value.append("\n...[truncated; see execution_log.txt]...\n");
                truncated = true;
                return;
            }
            value.append(line).append('\n');
        }

        synchronized String value() { return value.toString(); }
        synchronized boolean truncated() { return truncated; }
    }
}
