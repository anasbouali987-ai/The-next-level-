package com.gtav.runtimemanager.execution;

import android.content.Context;
import android.os.Build;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class RuntimeExecutionValidator {
    public static final class Result {
        public final boolean ready;
        public final List<String> checks;
        public final File proot;
        public final File box64;
        public final File wine64;

        Result(boolean ready, List<String> checks, File proot, File box64, File wine64) {
            this.ready = ready;
            this.checks = Collections.unmodifiableList(new ArrayList<>(checks));
            this.proot = proot;
            this.box64 = box64;
            this.wine64 = wine64;
        }

        public String format() {
            StringBuilder text = new StringBuilder();
            for (String check : checks) text.append(check).append('\n');
            return text.toString();
        }
    }

    private final Context context;
    public RuntimeExecutionValidator(Context context) { this.context = context.getApplicationContext(); }

    public Result validate(VerifiedInstalledRuntime runtime, IsolationEngine isolation,
                           File helloBinary) throws ExecutionException {
        List<String> checks = new ArrayList<>();
        if (!RuntimeFeatureFlags.buildVariantAllowsExecution()) {
            throw new ExecutionException(ExecutionErrorCode.RUNTIME_NOT_READY,
                    ExecutionStage.VALIDATING, "Execution Foundation disabled by build feature flags");
        }
        checks.add("PASS Build flags: PRoot + Box64 + Wine requested");
        if (!RuntimeFeatureFlags.deviceIsArm64()) {
            throw new ExecutionException(ExecutionErrorCode.RUNTIME_NOT_READY,
                    ExecutionStage.VALIDATING, "Device ABI is not arm64-v8a: " + String.join(",", Build.SUPPORTED_ABIS));
        }
        checks.add("PASS Device ABI: arm64-v8a");
        if (!runtime.readyForExecution()) {
            throw new ExecutionException(ExecutionErrorCode.RUNTIME_NOT_READY,
                    ExecutionStage.VALIDATING, "Installed runtime is not verified and ready");
        }
        checks.add("PASS Installed + Verified + Ready: " + runtime.runtimeId + " " + runtime.version);
        checks.add("PASS Runtime policy: read-mostly; writable data is external to RootFS");
        isolation.validate();
        checks.add("PASS PRoot: " + isolation.executable());
        try {
            if (ElfInspector.architecture(helloBinary) != ElfInspector.Architecture.X86_64) {
                throw new ExecutionException(ExecutionErrorCode.X86_64_TEST_WRONG_ABI,
                        ExecutionStage.VALIDATING, "hello-x86_64 is not x86_64");
            }
        } catch (ExecutionException error) { throw error; }
        catch (Exception error) {
            throw new ExecutionException(ExecutionErrorCode.X86_64_TEST_WRONG_ABI,
                    ExecutionStage.VALIDATING, "Cannot inspect hello-x86_64", error);
        }
        checks.add("PASS hello-x86_64: " + helloBinary);

        File box64 = locate(runtime.root,
                "usr/local/bin/box64", "usr/bin/box64", "opt/gtav-runtime/bin/box64", "bin/box64");
        if (box64 == null) {
            throw new ExecutionException(ExecutionErrorCode.BOX64_NOT_FOUND,
                    ExecutionStage.VALIDATING, "Box64 executable not found in RootFS");
        }
        checks.add("PASS Box64: " + box64);
        File wine64 = runtime.resolveGuestPath(runtime.wine64Entrypoint);
        if (!wine64.isFile()) {
            throw new ExecutionException(ExecutionErrorCode.WINE_NOT_FOUND,
                    ExecutionStage.VALIDATING, "Wine64 entrypoint not found: " + wine64);
        }
        checks.add("PASS Wine64: " + wine64);
        return new Result(true, checks, isolation.executable(), box64, wine64);
    }

    public static File locate(File root, String... relativePaths) {
        for (String path : relativePaths) {
            File candidate = new File(root, path);
            if (candidate.isFile()) return candidate;
        }
        return null;
    }
}
