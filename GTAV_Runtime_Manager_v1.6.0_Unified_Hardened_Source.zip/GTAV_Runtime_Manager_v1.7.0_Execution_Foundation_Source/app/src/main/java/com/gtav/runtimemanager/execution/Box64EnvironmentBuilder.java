package com.gtav.runtimemanager.execution;

import java.util.LinkedHashMap;
import java.util.Map;

public final class Box64EnvironmentBuilder {
    public Map<String, String> apply(Map<String, String> base, boolean diagnostic) {
        Map<String, String> env = new LinkedHashMap<>(base);
        env.put("BOX64_NOBANNER", "1");
        env.put("BOX64_DYNAREC", "1");
        env.put("BOX64_LOG", diagnostic ? "2" : "1");
        env.put("BOX64_SHOWSEGV", "1");
        env.put("BOX64_DYNAREC_BIGBLOCK", diagnostic ? "0" : "1");
        env.put("BOX64_DYNAREC_SAFEFLAGS", diagnostic ? "2" : "1");
        env.put("BOX64_DYNAREC_STRONGMEM", diagnostic ? "1" : "0");
        return env;
    }
}
