package com.gtav.runtimemanager.execution;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public final class RuntimeProcessSpec {
    public final String name;
    public final List<String> command;
    public final File workingDirectory;
    public final Map<String, String> environment;
    public final long timeoutMillis;

    public RuntimeProcessSpec(String name, List<String> command, File workingDirectory,
                              Map<String, String> environment, long timeoutMillis) {
        if (command == null || command.isEmpty()) throw new IllegalArgumentException("Empty command");
        this.name = name == null ? "process" : name;
        this.command = Collections.unmodifiableList(new ArrayList<>(command));
        this.workingDirectory = workingDirectory;
        this.environment = Collections.unmodifiableMap(new LinkedHashMap<>(environment));
        this.timeoutMillis = Math.max(1_000L, timeoutMillis);
    }

    public String printableCommand() {
        StringBuilder output = new StringBuilder();
        for (String item : command) {
            if (output.length() > 0) output.append(' ');
            if (item.matches("[A-Za-z0-9_./:=+,-]+")) output.append(item);
            else output.append('\'').append(item.replace("'", "'\\''")).append('\'');
        }
        return output.toString();
    }
}
