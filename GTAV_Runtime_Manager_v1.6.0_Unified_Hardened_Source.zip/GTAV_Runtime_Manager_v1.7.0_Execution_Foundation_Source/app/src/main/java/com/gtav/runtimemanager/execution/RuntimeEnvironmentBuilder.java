package com.gtav.runtimemanager.execution;

import android.content.Context;

import java.io.File;
import java.util.LinkedHashMap;
import java.util.Map;

/** يبني بيئة Android/Bionic منفصلة عن بيئة الضيف glibc. */
public final class RuntimeEnvironmentBuilder {
    public static final String ANDROID_LD_LIBRARY_PATH = "ANDROID_LD_LIBRARY_PATH";
    public static final String GUEST_LD_LIBRARY_PATH = "GUEST_LD_LIBRARY_PATH";
    public static final String BOX64_LD_LIBRARY_PATH = "BOX64_LD_LIBRARY_PATH";

    private final Context context;

    public RuntimeEnvironmentBuilder(Context context) {
        this.context = context.getApplicationContext();
    }

    public Map<String, String> buildHostEnvironment(File sessionRoot) throws Exception {
        Map<String, String> env = new LinkedHashMap<>();
        String nativeDir = context.getApplicationInfo().nativeLibraryDir;
        env.put("HOME", context.getFilesDir().getAbsolutePath());
        env.put("TMPDIR", ExecutionPaths.ensure(new File(sessionRoot, "host-tmp")).getAbsolutePath());
        env.put("PROOT_TMP_DIR", ExecutionPaths.ensure(new File(sessionRoot, "proot-tmp")).getAbsolutePath());
        env.put("PATH", "/system/bin:/system/xbin");
        env.put("LANG", "C.UTF-8");
        env.put("LC_ALL", "C.UTF-8");
        env.put(ANDROID_LD_LIBRARY_PATH, nativeDir);
        env.put("LD_LIBRARY_PATH", nativeDir);
        env.put(GUEST_LD_LIBRARY_PATH, "/lib:/usr/lib:/usr/local/lib:/opt/gtav-runtime/lib");
        env.put(BOX64_LD_LIBRARY_PATH,
                "/lib/x86_64-linux-gnu:/usr/lib/x86_64-linux-gnu:/usr/local/lib/x86_64-linux-gnu:/opt/gtav-runtime/lib64");
        return env;
    }

    public Map<String, String> buildGuestEnvironment(File prefixHostPath) {
        Map<String, String> env = new LinkedHashMap<>();
        env.put("HOME", "/home/gtav");
        env.put("USER", "gtav");
        env.put("LOGNAME", "gtav");
        env.put("TMPDIR", "/tmp");
        env.put("PATH", "/opt/gtav-runtime/bin:/usr/local/bin:/usr/bin:/bin");
        env.put("LANG", "C.UTF-8");
        env.put("LC_ALL", "C.UTF-8");
        env.put("WINEPREFIX", "/home/gtav/.wine");
        env.put("WINEDEBUG", "-all");
        env.put("BOX64_NOBANNER", "1");
        env.put("BOX64_LOG", "1");
        env.put("BOX64_DYNAREC", "1");
        env.put("BOX64_SHOWSEGV", "1");
        env.put(GUEST_LD_LIBRARY_PATH, "/lib:/usr/lib:/usr/local/lib:/opt/gtav-runtime/lib");
        env.put(BOX64_LD_LIBRARY_PATH,
                "/lib/x86_64-linux-gnu:/usr/lib/x86_64-linux-gnu:/usr/local/lib/x86_64-linux-gnu:/opt/gtav-runtime/lib64");
        // Deliberately do not pass Android nativeLibraryDir as guest LD_LIBRARY_PATH.
        env.put("LD_LIBRARY_PATH", env.get(GUEST_LD_LIBRARY_PATH));
        return env;
    }

    public static String format(Map<String, String> host, Map<String, String> guest) {
        StringBuilder text = new StringBuilder();
        text.append("[Android/Bionic]\n");
        for (Map.Entry<String, String> item : host.entrySet()) text.append(item.getKey()).append('=').append(item.getValue()).append('\n');
        text.append("\n[Guest/glibc]\n");
        for (Map.Entry<String, String> item : guest.entrySet()) text.append(item.getKey()).append('=').append(item.getValue()).append('\n');
        return text.toString();
    }
}
