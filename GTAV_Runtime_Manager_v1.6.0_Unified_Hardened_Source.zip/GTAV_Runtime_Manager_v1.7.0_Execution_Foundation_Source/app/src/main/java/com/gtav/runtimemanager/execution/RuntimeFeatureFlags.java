package com.gtav.runtimemanager.execution;

import android.content.Context;

import com.gtav.runtimemanager.BuildConfig;

import org.json.JSONArray;

import java.io.File;
import java.util.Collections;
import java.util.EnumMap;
import java.util.Map;

/**
 * Feature Flags متعددة المراحل: Requested → Available → Validated → Enabled.
 * الحالة النهائية تعتمد على Build Variant وملفات APK وقدرات الجهاز والـManifest والبوابات السابقة.
 */
public final class RuntimeFeatureFlags {
    private final EnumMap<FeatureCapability.Feature, FeatureCapability> flags =
            new EnumMap<>(FeatureCapability.Feature.class);

    public RuntimeFeatureFlags() { reset(); }

    public synchronized void reset() {
        flags.clear();
        flags.put(FeatureCapability.Feature.PROOT, initial(
                FeatureCapability.Feature.PROOT, BuildConfig.FEATURE_PROOT_REQUESTED));
        flags.put(FeatureCapability.Feature.BOX64, initial(
                FeatureCapability.Feature.BOX64, BuildConfig.FEATURE_BOX64_REQUESTED));
        flags.put(FeatureCapability.Feature.WINE, initial(
                FeatureCapability.Feature.WINE, BuildConfig.FEATURE_WINE_REQUESTED));
        flags.put(FeatureCapability.Feature.DISPLAY, deferred(
                FeatureCapability.Feature.DISPLAY, BuildConfig.FEATURE_DISPLAY_REQUESTED));
        flags.put(FeatureCapability.Feature.AUDIO, deferred(
                FeatureCapability.Feature.AUDIO, BuildConfig.FEATURE_AUDIO_REQUESTED));
        flags.put(FeatureCapability.Feature.GRAPHICS, deferred(
                FeatureCapability.Feature.GRAPHICS, BuildConfig.FEATURE_GRAPHICS_REQUESTED));
        flags.put(FeatureCapability.Feature.INPUT, deferred(
                FeatureCapability.Feature.INPUT, BuildConfig.FEATURE_INPUT_REQUESTED));
        flags.put(FeatureCapability.Feature.GAME_LIBRARY, deferred(
                FeatureCapability.Feature.GAME_LIBRARY, BuildConfig.FEATURE_GAME_LIBRARY_REQUESTED));
    }

    private static FeatureCapability initial(FeatureCapability.Feature feature, boolean requested) {
        return requested ? FeatureCapability.requested(feature)
                : new FeatureCapability(feature, false, false, false, false,
                FeatureCapability.State.NOT_REQUESTED, "Disabled by build variant");
    }

    private static FeatureCapability deferred(FeatureCapability.Feature feature, boolean requested) {
        return new FeatureCapability(feature, requested, false, false, false,
                FeatureCapability.State.EXPERIMENTAL,
                requested ? "Requested experimentally; implementation unavailable"
                        : "خارج نطاق v1.7.0؛ الواجهة مسجلة فقط");
    }

    public synchronized void set(FeatureCapability capability) {
        flags.put(capability.feature, capability);
    }

    public synchronized FeatureCapability get(FeatureCapability.Feature feature) {
        return flags.get(feature);
    }

    public synchronized Map<FeatureCapability.Feature, FeatureCapability> snapshot() {
        return Collections.unmodifiableMap(new EnumMap<>(flags));
    }

    public synchronized JSONArray toJson() {
        JSONArray array = new JSONArray();
        for (FeatureCapability capability : flags.values()) array.put(capability.toJson());
        return array;
    }

    public static boolean buildVariantAllowsExecution() {
        return BuildConfig.FEATURE_PROOT_REQUESTED
                && BuildConfig.FEATURE_BOX64_REQUESTED
                && BuildConfig.FEATURE_WINE_REQUESTED;
    }

    public static boolean deviceIsArm64() {
        for (String abi : android.os.Build.SUPPORTED_ABIS) {
            if ("arm64-v8a".equals(abi)) return true;
        }
        return false;
    }

    public static File locatePackagedProot(Context context) {
        String nativeDir = context.getApplicationInfo().nativeLibraryDir;
        String[] names = {"libproot_exec.so", "libproot.so", "libexec_proot.so"};
        for (String name : names) {
            File candidate = new File(nativeDir, name);
            if (candidate.isFile()) return candidate;
        }
        return new File(nativeDir, "libproot_exec.so");
    }
}
