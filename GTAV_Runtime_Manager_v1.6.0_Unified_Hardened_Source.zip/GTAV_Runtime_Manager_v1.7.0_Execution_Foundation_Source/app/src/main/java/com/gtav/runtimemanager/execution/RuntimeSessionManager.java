package com.gtav.runtimemanager.execution;

import android.content.Context;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.EnumMap;
import java.util.EnumSet;
import java.util.UUID;
import org.json.JSONObject;
import java.util.concurrent.CopyOnWriteArrayList;

public final class RuntimeSessionManager {
    public interface Listener { void onSessionChanged(RuntimeSessionSnapshot snapshot); }

    private static final EnumMap<ExecutionStage, EnumSet<ExecutionStage>> ALLOWED = buildTransitions();
    private final Context context;
    private final CopyOnWriteArrayList<Listener> listeners = new CopyOnWriteArrayList<>();
    private volatile RuntimeSessionSnapshot current = RuntimeSessionSnapshot.idle();

    public RuntimeSessionManager(Context context) {
        this.context = context.getApplicationContext();
        this.current = restoreLastState();
    }

    public synchronized RuntimeSessionSnapshot create(String runtimeId) throws Exception {
        if (!current.stage.terminal() && current.stage != ExecutionStage.IDLE) {
            throw new ExecutionException(ExecutionErrorCode.INVALID_STATE_TRANSITION,
                    current.stage, "توجد جلسة تنفيذ نشطة بالفعل");
        }
        String id = "exec-" + UUID.randomUUID();
        long now = System.currentTimeMillis();
        current = new RuntimeSessionSnapshot(id, runtimeId, ExecutionStage.PREPARING,
                "create-session", "", -1, null, now, now,
                ExecutionErrorCode.NONE, "");
        persist();
        notifyListeners();
        return current;
    }

    public synchronized RuntimeSessionSnapshot transition(ExecutionStage next, String operation,
                                                           String command, long pid, Integer exitCode,
                                                           ExecutionErrorCode code, String message)
            throws ExecutionException {
        EnumSet<ExecutionStage> allowed = ALLOWED.get(current.stage);
        if (allowed == null || !allowed.contains(next)) {
            throw new ExecutionException(ExecutionErrorCode.INVALID_STATE_TRANSITION,
                    current.stage, "انتقال غير صالح: " + current.stage + " -> " + next);
        }
        current = new RuntimeSessionSnapshot(current.sessionId, current.runtimeId, next,
                operation, command, pid, exitCode, current.startedAt, System.currentTimeMillis(),
                code, message);
        persist();
        notifyListeners();
        return current;
    }


    public synchronized RuntimeSessionSnapshot updateRuntimeId(String runtimeId) {
        current = new RuntimeSessionSnapshot(current.sessionId, runtimeId, current.stage,
                current.operation, current.command, current.pid, current.exitCode,
                current.startedAt, System.currentTimeMillis(), current.errorCode, current.errorMessage);
        persist();
        notifyListeners();
        return current;
    }

    public synchronized RuntimeSessionSnapshot updateCurrent(String operation, String command, long pid, Integer exitCode) {
        current = new RuntimeSessionSnapshot(current.sessionId, current.runtimeId, current.stage,
                operation, command, pid, exitCode, current.startedAt, System.currentTimeMillis(),
                current.errorCode, current.errorMessage);
        persist();
        notifyListeners();
        return current;
    }

    public RuntimeSessionSnapshot current() { return current; }
    public void addListener(Listener listener) { if (listener != null) listeners.addIfAbsent(listener); }
    public void removeListener(Listener listener) { listeners.remove(listener); }

    private void notifyListeners() {
        for (Listener listener : listeners) {
            try { listener.onSessionChanged(current); } catch (Throwable ignored) {}
        }
    }

    private void persist() {
        try {
            File root = ExecutionPaths.sessionRoot(context, current.sessionId.isEmpty() ? "last" : current.sessionId);
            File file = new File(root, "execution_state.json");
            File temp = new File(root, "execution_state.json.tmp");
            try (FileOutputStream output = new FileOutputStream(temp, false)) {
                output.write(current.toJson().toString(2).getBytes(StandardCharsets.UTF_8));
                output.getFD().sync();
            }
            if (file.exists()) file.delete();
            temp.renameTo(file);

            File global = new File(ExecutionPaths.executionRoot(context), "last_execution_state.json");
            File globalTemp = new File(global.getParentFile(), global.getName() + ".tmp");
            try (FileOutputStream output = new FileOutputStream(globalTemp, false)) {
                output.write(current.toJson().toString(2).getBytes(StandardCharsets.UTF_8));
                output.getFD().sync();
            }
            if (global.exists()) global.delete();
            globalTemp.renameTo(global);
        } catch (Throwable ignored) {}
    }

    private RuntimeSessionSnapshot restoreLastState() {
        try {
            File file = new File(ExecutionPaths.executionRoot(context), "last_execution_state.json");
            if (!file.isFile()) return RuntimeSessionSnapshot.idle();
            ByteArrayOutputStream output = new ByteArrayOutputStream();
            try (FileInputStream input = new FileInputStream(file)) {
                byte[] buffer = new byte[8192];
                int read;
                while ((read = input.read(buffer)) != -1) {
                    if (output.size() + read > 1024 * 1024) return RuntimeSessionSnapshot.idle();
                    output.write(buffer, 0, read);
                }
            }
            JSONObject json = new JSONObject(output.toString(StandardCharsets.UTF_8.name()));
            ExecutionStage restoredStage = ExecutionStage.valueOf(json.optString("stage", "IDLE"));
            ExecutionStage stage = restoredStage.terminal() ? restoredStage : ExecutionStage.FAILED;
            ExecutionErrorCode code = restoredStage.terminal()
                    ? ExecutionErrorCode.valueOf(json.optString("error_code", "NONE"))
                    : ExecutionErrorCode.INTERRUPTED_SESSION_RECOVERED;
            String message = restoredStage.terminal()
                    ? json.optString("error_message", "")
                    : "Recovered an interrupted execution session after process restart";
            Integer exit = json.isNull("exit_code") ? null : json.optInt("exit_code");
            return new RuntimeSessionSnapshot(
                    json.optString("session_id", ""),
                    json.optString("runtime_id", ""),
                    stage,
                    json.optString("operation", ""),
                    json.optString("command", ""),
                    json.optLong("pid", -1),
                    exit,
                    json.optLong("started_at", System.currentTimeMillis()),
                    System.currentTimeMillis(),
                    code, message);
        } catch (Throwable ignored) {
            return RuntimeSessionSnapshot.idle();
        }
    }

    private static EnumMap<ExecutionStage, EnumSet<ExecutionStage>> buildTransitions() {
        EnumMap<ExecutionStage, EnumSet<ExecutionStage>> map = new EnumMap<>(ExecutionStage.class);
        map.put(ExecutionStage.IDLE, EnumSet.of(ExecutionStage.PREPARING));
        map.put(ExecutionStage.PREPARING, EnumSet.of(ExecutionStage.VALIDATING, ExecutionStage.FAILED, ExecutionStage.CANCELLED));
        map.put(ExecutionStage.VALIDATING, EnumSet.of(ExecutionStage.STARTING_PROOT, ExecutionStage.FAILED, ExecutionStage.CANCELLED));
        map.put(ExecutionStage.STARTING_PROOT, EnumSet.of(ExecutionStage.ENTERING_ROOTFS, ExecutionStage.FAILED, ExecutionStage.CANCELLED));
        map.put(ExecutionStage.ENTERING_ROOTFS, EnumSet.of(ExecutionStage.RUNNING_BOX64, ExecutionStage.FAILED, ExecutionStage.CANCELLED));
        map.put(ExecutionStage.RUNNING_BOX64, EnumSet.of(ExecutionStage.STARTING_WINE, ExecutionStage.FAILED, ExecutionStage.CANCELLED));
        map.put(ExecutionStage.STARTING_WINE, EnumSet.of(ExecutionStage.RUNNING, ExecutionStage.FAILED, ExecutionStage.CANCELLED));
        map.put(ExecutionStage.RUNNING, EnumSet.of(ExecutionStage.STOPPING, ExecutionStage.COMPLETED, ExecutionStage.FAILED, ExecutionStage.CANCELLED));
        map.put(ExecutionStage.STOPPING, EnumSet.of(ExecutionStage.COMPLETED, ExecutionStage.FAILED, ExecutionStage.CANCELLED));
        map.put(ExecutionStage.COMPLETED, EnumSet.of(ExecutionStage.PREPARING));
        map.put(ExecutionStage.FAILED, EnumSet.of(ExecutionStage.PREPARING));
        map.put(ExecutionStage.CANCELLED, EnumSet.of(ExecutionStage.PREPARING));
        return map;
    }
}
