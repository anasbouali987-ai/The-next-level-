package com.gtav.runtimemanager.execution;

/** عقد مستقبلي فقط؛ لا يوجد Audio backend مفعّل في v1.7.0. */
public interface AudioBackend {
    String id();
    FeatureCapability capability();
}
