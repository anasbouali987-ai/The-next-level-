package com.gtav.runtimemanager.execution;

import org.json.JSONObject;

public final class FeatureCapability {
    public enum Feature { PROOT, BOX64, WINE, DISPLAY, AUDIO, GRAPHICS, INPUT, GAME_LIBRARY }
    public enum State { NOT_REQUESTED, REQUESTED, AVAILABLE, VALIDATED, ENABLED, UNAVAILABLE, EXPERIMENTAL }

    public final Feature feature;
    public final boolean requested;
    public final boolean available;
    public final boolean validated;
    public final boolean enabled;
    public final State state;
    public final String reason;

    public FeatureCapability(Feature feature, boolean requested, boolean available,
                             boolean validated, boolean enabled, State state, String reason) {
        this.feature = feature;
        this.requested = requested;
        this.available = available;
        this.validated = validated;
        this.enabled = enabled;
        this.state = state;
        this.reason = reason == null ? "" : reason;
    }

    public static FeatureCapability requested(Feature feature) {
        return new FeatureCapability(feature, true, false, false, false, State.REQUESTED, "");
    }

    public FeatureCapability available(String reason) {
        return new FeatureCapability(feature, requested, true, false, false, State.AVAILABLE, reason);
    }

    public FeatureCapability validated(String reason) {
        return new FeatureCapability(feature, requested, true, true, false, State.VALIDATED, reason);
    }

    public FeatureCapability enabled(String reason) {
        return new FeatureCapability(feature, requested, true, true, true, State.ENABLED, reason);
    }

    public FeatureCapability unavailable(String reason) {
        return new FeatureCapability(feature, requested, false, false, false, State.UNAVAILABLE, reason);
    }

    public JSONObject toJson() {
        JSONObject json = new JSONObject();
        try {
            json.put("feature", feature.name());
            json.put("requested", requested);
            json.put("available", available);
            json.put("validated", validated);
            json.put("enabled", enabled);
            json.put("state", state.name());
            json.put("reason", reason);
        } catch (Exception ignored) {}
        return json;
    }

    @Override public String toString() {
        return feature + ": " + state + (reason.isEmpty() ? "" : " — " + reason);
    }
}
