package com.gtav.runtimemanager.execution;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Arrays;
import java.util.Comparator;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/** ينشئ حزمة تشخيص واحدة من ملفات الجلسة من دون إدخال ملفات Prefix أو Runtime. */
public final class RuntimeReportBundle {
    private RuntimeReportBundle() {}

    public static File create(File sessionRoot) throws IOException {
        if (sessionRoot == null || !sessionRoot.isDirectory()) {
            throw new IOException("Session report directory is missing");
        }
        File output = new File(sessionRoot, "runtime_execution_reports.zip");
        File temporary = new File(sessionRoot, output.getName() + ".tmp");
        File[] files = sessionRoot.listFiles(file -> file.isFile()
                && !file.getName().equals(output.getName())
                && !file.getName().equals(temporary.getName()));
        if (files == null) files = new File[0];
        Arrays.sort(files, Comparator.comparing(File::getName));
        try (ZipOutputStream zip = new ZipOutputStream(new BufferedOutputStream(
                new FileOutputStream(temporary, false), 64 * 1024))) {
            byte[] buffer = new byte[64 * 1024];
            for (File file : files) {
                ZipEntry entry = new ZipEntry(file.getName());
                entry.setTime(file.lastModified());
                zip.putNextEntry(entry);
                try (BufferedInputStream input = new BufferedInputStream(new FileInputStream(file))) {
                    int read;
                    while ((read = input.read(buffer)) != -1) zip.write(buffer, 0, read);
                }
                zip.closeEntry();
            }
        }
        if (output.exists() && !output.delete()) throw new IOException("Cannot replace report bundle");
        if (!temporary.renameTo(output)) throw new IOException("Cannot finalize report bundle");
        return output;
    }
}
