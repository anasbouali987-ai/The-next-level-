package com.gtav.runtimemanager.execution;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Map;

public final class RuntimeExecutionReporter {
    private final File sessionRoot;

    public RuntimeExecutionReporter(File sessionRoot) { this.sessionRoot = sessionRoot; }

    public void writePreflight(RuntimeExecutionValidator.Result result) {
        writeText("execution_preflight.txt", result.format());
    }

    public void writeEnvironment(Map<String, String> host, Map<String, String> guest) {
        writeText("runtime_environment.txt", RuntimeEnvironmentBuilder.format(host, guest));
    }

    public void writeMounts(List<RuntimeBindMount> mounts) {
        writeText("runtime_mounts.txt", RuntimeMountManager.format(mounts));
    }

    public void writeFeatureFlags(RuntimeFeatureFlags flags, BackendCapabilityRegistry registry) {
        JSONObject json = new JSONObject();
        try {
            json.put("features", flags.toJson());
            json.put("backends", registry.toJson());
        } catch (Exception ignored) {}
        writeText("feature_flags.txt", pretty(json));
    }

    public void writeProcessResult(String fileName, RuntimeProcessSpec spec, RuntimeProcessResult result) {
        StringBuilder text = new StringBuilder();
        text.append("Operation: ").append(spec.name).append('\n');
        text.append("Command: ").append(spec.printableCommand()).append('\n');
        text.append("Arguments:\n");
        for (int index = 0; index < spec.command.size(); index++) {
            text.append("  [").append(index).append("] ").append(spec.command.get(index)).append('\n');
        }
        text.append("Working directory: ").append(spec.workingDirectory).append('\n');
        text.append("Environment:\n");
        for (Map.Entry<String, String> item : spec.environment.entrySet()) {
            text.append("  ").append(item.getKey()).append('=').append(item.getValue()).append('\n');
        }
        text.append("PID: ").append(result.pid).append('\n');
        text.append("Exit Code: ").append(result.exitCode).append('\n');
        text.append("Duration ms: ").append(result.durationMillis()).append('\n');
        text.append("Timed out: ").append(result.timedOut).append('\n');
        text.append("Cancelled: ").append(result.cancelled).append('\n');
        text.append("\n[stdout]\n").append(result.stdout);
        text.append("\n[stderr]\n").append(result.stderr);
        writeText(fileName, text.toString());
    }

    public void writeState(RuntimeSessionSnapshot state) {
        writeText("execution_state.json", pretty(state.toJson()));
    }

    public void writeProcessTree(JSONArray tree) {
        writeText("process_tree.json", pretty(tree));
    }

    public void writeSessionReport(RuntimeSessionSnapshot state,
                                   RuntimeProcessSupervisor.CleanupResult cleanup) {
        StringBuilder text = new StringBuilder();
        text.append("GTAV Runtime Execution Session\n");
        text.append("==============================\n");
        text.append("Session ID: ").append(state.sessionId).append('\n');
        text.append("Runtime ID: ").append(state.runtimeId).append('\n');
        text.append("State: ").append(state.stage).append('\n');
        text.append("Exit Code: ").append(state.exitCode).append('\n');
        text.append("Elapsed ms: ").append(state.elapsedMillis()).append('\n');
        text.append("Error Code: ").append(state.errorCode).append('\n');
        text.append("Error: ").append(state.errorMessage).append('\n');
        text.append("Cleanup performed: ").append(cleanup != null).append('\n');
        text.append("No orphan processes: ").append(cleanup != null && cleanup.clean).append('\n');
        if (cleanup != null && !cleanup.survivors.isEmpty()) {
            text.append("Survivors: ").append(cleanup.survivors).append('\n');
        }
        writeText("runtime_session_report.txt", text.toString());
    }



    private static String pretty(JSONObject json) {
        try { return json.toString(2); } catch (Exception ignored) { return json.toString(); }
    }

    private static String pretty(JSONArray json) {
        try { return json.toString(2); } catch (Exception ignored) { return json.toString(); }
    }

    public void appendText(String name, String text) {
        try {
            File file = new File(sessionRoot, name);
            try (FileOutputStream output = new FileOutputStream(file, true)) {
                output.write((text == null ? "" : text).getBytes(StandardCharsets.UTF_8));
                output.getFD().sync();
            }
        } catch (Throwable ignored) {}
    }

    public File file(String name) { return new File(sessionRoot, name); }

    public void writeText(String name, String text) {
        try {
            File file = new File(sessionRoot, name);
            File parent = file.getParentFile();
            if (parent != null && !parent.exists()) parent.mkdirs();
            File temp = new File(parent, file.getName() + ".tmp");
            try (FileOutputStream output = new FileOutputStream(temp, false)) {
                output.write((text == null ? "" : text).getBytes(StandardCharsets.UTF_8));
                output.getFD().sync();
            }
            if (file.exists()) file.delete();
            temp.renameTo(file);
        } catch (Throwable ignored) {}
    }
}
