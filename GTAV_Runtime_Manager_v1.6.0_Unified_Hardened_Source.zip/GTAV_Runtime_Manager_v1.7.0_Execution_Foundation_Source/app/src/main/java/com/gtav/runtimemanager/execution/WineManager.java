package com.gtav.runtimemanager.execution;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public final class WineManager {
    private final VerifiedInstalledRuntime runtime;

    public WineManager(VerifiedInstalledRuntime runtime) { this.runtime = runtime; }

    public List<String> versionCommand() {
        return Arrays.asList(guestPath(runtime.wine64Entrypoint), "--version");
    }

    public List<String> winebootCommand() {
        return Arrays.asList(guestPath(runtime.winebootEntrypoint), "-u");
    }

    public List<String> consoleSmokeCommand() {
        List<String> command = new ArrayList<>();
        command.add(guestPath(runtime.wine64Entrypoint));
        command.add("cmd.exe");
        command.add("/c");
        command.add("echo");
        command.add("WINE_RUNTIME_OK");
        return command;
    }

    public List<String> shutdownCommand() {
        if (runtime.wineserverEntrypoint.isEmpty()) return Arrays.asList("/usr/bin/true");
        return Arrays.asList(guestPath(runtime.wineserverEntrypoint), "-k");
    }

    private static String guestPath(String relative) {
        return relative.startsWith("/") ? relative : "/" + relative;
    }
}
