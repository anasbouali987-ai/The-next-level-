# PRoot Android component

The v1.7.0 execution build gate requires one Android **AArch64** executable at:

```text
arm64-v8a/libproot_exec.so
```

The `.so` suffix is only the Android packaging name; the file is launched as a separate
native executable and is never loaded with `System.loadLibrary`.

Install a development binary with:

```bash
PROOT_SHA256=<pinned-sha256> ./tools/fetch-proot-android.sh
```

`verifyExecutionSourceComponents` rejects a missing file or a non-AArch64 ELF with:

- `BUILD FAILED: PROOT_NOT_PACKAGED`
- `BUILD FAILED: PROOT_WRONG_ABI`

Do not publish a PRoot binary without pinned provenance, applicable license notices,
and corresponding source/build inputs.
