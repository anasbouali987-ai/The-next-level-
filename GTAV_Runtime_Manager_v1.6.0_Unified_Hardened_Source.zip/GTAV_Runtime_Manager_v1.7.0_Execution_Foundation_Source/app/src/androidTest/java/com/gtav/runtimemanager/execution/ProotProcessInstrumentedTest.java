package com.gtav.runtimemanager.execution;

import android.content.Context;

import androidx.test.core.app.ApplicationProvider;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import org.junit.Test;
import org.junit.runner.RunWith;

import java.io.File;
import java.util.Arrays;
import java.util.HashMap;

import static org.junit.Assert.assertFalse;

@RunWith(AndroidJUnit4.class)
public class ProotProcessInstrumentedTest {
    @Test public void prootNativeExecutableCanStartHelp() throws Exception {
        Context context = ApplicationProvider.getApplicationContext();
        File proot = RuntimeFeatureFlags.locatePackagedProot(context);
        RuntimeProcessSpec spec = new RuntimeProcessSpec("proot-help",
                Arrays.asList(proot.getAbsolutePath(), "--help"), context.getFilesDir(),
                new HashMap<String, String>() {{
                    put("HOME", context.getFilesDir().getAbsolutePath());
                    put("TMPDIR", context.getCacheDir().getAbsolutePath());
                    put("PROOT_TMP_DIR", context.getCacheDir().getAbsolutePath());
                    put("PATH", "/system/bin");
                    put("LD_LIBRARY_PATH", context.getApplicationInfo().nativeLibraryDir);
                }}, 15_000);
        RuntimeProcessResult result = new RuntimeProcessRunner().run(spec,
                new ExecutionCancellationToken(), null, null);
        assertFalse("PRoot timed out: " + result.stderr, result.timedOut);
    }
}
