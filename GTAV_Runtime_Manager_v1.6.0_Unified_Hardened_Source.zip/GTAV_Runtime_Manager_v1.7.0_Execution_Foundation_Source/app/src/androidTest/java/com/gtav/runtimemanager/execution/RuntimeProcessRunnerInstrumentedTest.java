package com.gtav.runtimemanager.execution;

import android.content.Context;

import androidx.test.core.app.ApplicationProvider;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import org.junit.Test;
import org.junit.runner.RunWith;

import java.util.Arrays;
import java.util.Collections;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

@RunWith(AndroidJUnit4.class)
public class RuntimeProcessRunnerInstrumentedTest {
    @Test public void capturesStdoutStderrAndExitCode() throws Exception {
        Context context = ApplicationProvider.getApplicationContext();
        RuntimeProcessSpec spec = new RuntimeProcessSpec("streams",
                Arrays.asList("/system/bin/sh", "-c", "echo PROCESS_STDOUT; echo PROCESS_STDERR >&2; exit 7"),
                context.getFilesDir(), Collections.singletonMap("PATH", "/system/bin"), 10_000);
        RuntimeProcessResult result = new RuntimeProcessRunner().run(spec,
                new ExecutionCancellationToken(), null, null);
        assertEquals(7, result.exitCode);
        assertTrue(result.stdout, result.stdout.contains("PROCESS_STDOUT"));
        assertTrue(result.stderr, result.stderr.contains("PROCESS_STDERR"));
        assertFalse(result.timedOut);
        assertFalse(result.cancelled);
    }

    @Test public void timeoutTerminatesProcess() throws Exception {
        Context context = ApplicationProvider.getApplicationContext();
        RuntimeProcessSpec spec = new RuntimeProcessSpec("timeout",
                Arrays.asList("/system/bin/sh", "-c", "sleep 10"),
                context.getFilesDir(), Collections.singletonMap("PATH", "/system/bin"), 1_000);
        RuntimeProcessResult result = new RuntimeProcessRunner().run(spec,
                new ExecutionCancellationToken(), null, null);
        assertTrue("Expected timeout", result.timedOut);
    }

    @Test public void cancellationTerminatesProcess() throws Exception {
        Context context = ApplicationProvider.getApplicationContext();
        ExecutionCancellationToken token = new ExecutionCancellationToken();
        Thread canceller = new Thread(() -> {
            try { Thread.sleep(250); } catch (InterruptedException ignored) { Thread.currentThread().interrupt(); }
            token.cancel();
        });
        canceller.start();
        RuntimeProcessSpec spec = new RuntimeProcessSpec("cancel",
                Arrays.asList("/system/bin/sh", "-c", "sleep 10"),
                context.getFilesDir(), Collections.singletonMap("PATH", "/system/bin"), 15_000);
        RuntimeProcessResult result = new RuntimeProcessRunner().run(spec, token, null, null);
        canceller.join(2_000);
        assertTrue("Expected cancellation", result.cancelled);
    }
}
