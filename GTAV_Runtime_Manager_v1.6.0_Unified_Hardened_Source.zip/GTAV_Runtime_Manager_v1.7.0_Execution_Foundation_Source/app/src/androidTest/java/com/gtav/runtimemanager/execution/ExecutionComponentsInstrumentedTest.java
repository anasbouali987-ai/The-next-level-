package com.gtav.runtimemanager.execution;

import android.content.Context;

import androidx.test.core.app.ApplicationProvider;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import org.junit.Test;
import org.junit.runner.RunWith;

import java.io.File;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

@RunWith(AndroidJUnit4.class)
public class ExecutionComponentsInstrumentedTest {
    @Test public void packagedProotIsExecutableAarch64AndHelloIsX8664() throws Exception {
        Context context = ApplicationProvider.getApplicationContext();
        File proot = RuntimeFeatureFlags.locatePackagedProot(context);
        assertTrue("Missing PRoot in nativeLibraryDir: " + proot, proot.isFile());
        assertTrue("PRoot is not executable", proot.canExecute());
        assertEquals(ElfInspector.Architecture.AARCH64, ElfInspector.architecture(proot));

        File session = ExecutionPaths.sessionRoot(context, "instrumented-components");
        File hello = new ExecutionComponentInstaller(context).installHelloX8664(session);
        assertEquals(ElfInspector.Architecture.X86_64, ElfInspector.architecture(hello));
    }
}
