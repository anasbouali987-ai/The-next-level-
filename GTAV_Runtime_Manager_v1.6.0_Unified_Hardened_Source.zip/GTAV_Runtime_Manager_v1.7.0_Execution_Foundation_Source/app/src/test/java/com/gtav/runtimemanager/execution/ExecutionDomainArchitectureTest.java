package com.gtav.runtimemanager.execution;

import org.junit.Test;

import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

public class ExecutionDomainArchitectureTest {
    @Test public void requiredExecutionComponentsArePresent() {
        Set<String> names = new HashSet<>(Arrays.asList(
                "RuntimeExecutionManager.java", "RuntimeSessionManager.java", "RuntimeLauncher.java",
                "RuntimeEnvironmentBuilder.java", "RuntimeMountManager.java", "RuntimeProcessRunner.java",
                "RuntimeProcessSupervisor.java", "IsolationEngine.java", "ProotIsolationEngine.java",
                "RuntimeExecutionReporter.java", "RuntimeConsoleStore.java", "RuntimeExecutionService.java"
        ));
        File root = new File("src/main/java/com/gtav/runtimemanager/execution");
        File[] files = root.listFiles((dir, name) -> name.endsWith(".java"));
        assertTrue(root.getAbsolutePath(), files != null);
        for (File file : files) names.remove(file.getName());
        assertTrue("Missing: " + names, names.isEmpty());
    }

    @Test public void executionDomainDoesNotCallInstallerInternals() throws Exception {
        File root = new File("src/main/java/com/gtav/runtimemanager/execution");
        File[] files = root.listFiles((dir, name) -> name.endsWith(".java"));
        assertTrue(files != null);
        for (File file : files) {
            String source = new String(Files.readAllBytes(file.toPath()), StandardCharsets.UTF_8);
            assertFalse(file.getName(), source.contains("RuntimeInstaller"));
            assertFalse(file.getName(), source.contains("RuntimeExtractor"));
            assertFalse(file.getName(), source.contains("AtomicRuntimeSwap"));
        }
    }
}
