package com.gtav.runtimemanager.execution;

import org.junit.Test;

import java.util.Arrays;
import java.util.Collections;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

public class RuntimeProcessSpecTest {
    @Test public void quotesPrintableArgumentsWithoutUsingShell() {
        RuntimeProcessSpec spec = new RuntimeProcessSpec("test",
                Arrays.asList("/bin/echo", "hello world", "safe=value"), null,
                Collections.emptyMap(), 100);
        assertTrue(spec.printableCommand().contains("'hello world'"));
        assertEquals(1000L, spec.timeoutMillis);
    }
}
