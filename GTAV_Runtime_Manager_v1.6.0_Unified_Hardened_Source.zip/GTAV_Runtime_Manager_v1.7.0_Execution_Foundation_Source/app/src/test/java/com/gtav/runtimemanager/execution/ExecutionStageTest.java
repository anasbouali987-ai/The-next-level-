package com.gtav.runtimemanager.execution;

import org.junit.Test;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

public class ExecutionStageTest {
    @Test public void onlyFinalStatesAreTerminal() {
        for (ExecutionStage stage : ExecutionStage.values()) {
            boolean expected = stage == ExecutionStage.COMPLETED
                    || stage == ExecutionStage.FAILED
                    || stage == ExecutionStage.CANCELLED;
            if (expected) assertTrue(stage.name(), stage.terminal());
            else assertFalse(stage.name(), stage.terminal());
        }
    }
}
