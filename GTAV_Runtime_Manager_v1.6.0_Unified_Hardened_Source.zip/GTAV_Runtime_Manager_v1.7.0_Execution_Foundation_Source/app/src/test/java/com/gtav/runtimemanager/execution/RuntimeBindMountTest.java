package com.gtav.runtimemanager.execution;

import org.junit.Test;

import java.io.File;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

public class RuntimeBindMountTest {
    @Test public void createsStructuredProotArgument() {
        RuntimeBindMount mount = new RuntimeBindMount(new File("/tmp"), "/guest/tmp", false, true);
        assertTrue(mount.prootArgument().endsWith(":/guest/tmp"));
        assertEquals("/guest/tmp", mount.guestPath);
    }

    @Test(expected = IllegalArgumentException.class)
    public void rejectsRelativeGuestPath() {
        new RuntimeBindMount(new File("/tmp"), "guest/tmp", false, true);
    }

    @Test(expected = IllegalArgumentException.class)
    public void rejectsTraversalGuestPath() {
        new RuntimeBindMount(new File("/tmp"), "/guest/../root", false, true);
    }
}
