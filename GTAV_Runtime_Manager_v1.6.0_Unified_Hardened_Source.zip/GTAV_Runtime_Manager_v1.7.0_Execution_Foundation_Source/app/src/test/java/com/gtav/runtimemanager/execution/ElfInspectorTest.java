package com.gtav.runtimemanager.execution;

import org.junit.Test;

import java.io.File;
import java.io.FileOutputStream;

import static org.junit.Assert.assertEquals;

public class ElfInspectorTest {
    @Test public void detectsAarch64AndX8664() throws Exception {
        assertEquals(ElfInspector.Architecture.AARCH64, ElfInspector.architecture(fakeElf(183)));
        assertEquals(ElfInspector.Architecture.X86_64, ElfInspector.architecture(fakeElf(62)));
    }

    @Test public void rejectsNonElf() throws Exception {
        File file = File.createTempFile("not-elf", ".bin");
        try (FileOutputStream out = new FileOutputStream(file)) { out.write(new byte[20]); }
        assertEquals(ElfInspector.Architecture.UNKNOWN, ElfInspector.architecture(file));
    }

    private static File fakeElf(int machine) throws Exception {
        byte[] header = new byte[20];
        header[0] = 0x7f; header[1] = 'E'; header[2] = 'L'; header[3] = 'F';
        header[4] = 2; header[5] = 1;
        header[18] = (byte) (machine & 0xff);
        header[19] = (byte) ((machine >>> 8) & 0xff);
        File file = File.createTempFile("elf", ".bin");
        try (FileOutputStream out = new FileOutputStream(file)) { out.write(header); }
        return file;
    }
}
