package com.gtav.runtimemanager.execution;

import org.junit.Test;

import java.util.HashSet;
import java.util.Set;

import static org.junit.Assert.assertTrue;

public class ExecutionErrorCodeTest {
    @Test public void requiredBuildAndRuntimeCodesExistAndAreUnique() {
        Set<String> names = new HashSet<>();
        for (ExecutionErrorCode code : ExecutionErrorCode.values()) {
            assertTrue("duplicate enum name", names.add(code.name()));
        }
        assertTrue(names.contains("PROOT_NOT_PACKAGED"));
        assertTrue(names.contains("PROOT_WRONG_ABI"));
        assertTrue(names.contains("X86_64_TEST_NOT_PACKAGED"));
        assertTrue(names.contains("X86_64_TEST_WRONG_ABI"));
        assertTrue(names.contains("ORPHAN_PROCESS_REMAINS"));
    }
}
