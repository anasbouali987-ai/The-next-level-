package com.gtav.runtimemanager.execution;

import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

public class FeatureCapabilityTest {
    @Test public void followsRequestedAvailableValidatedEnabledChain() {
        FeatureCapability requested = FeatureCapability.requested(FeatureCapability.Feature.PROOT);
        FeatureCapability available = requested.available("packaged");
        FeatureCapability validated = available.validated("ABI ok");
        FeatureCapability enabled = validated.enabled("smoke test ok");
        assertFalse(requested.available);
        assertTrue(available.available);
        assertTrue(validated.validated);
        assertTrue(enabled.enabled);
        assertEquals(FeatureCapability.State.ENABLED, enabled.state);
    }
}
