package com.gtav.runtimemanager.execution;

import org.junit.Test;

import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.HashSet;
import java.util.Set;
import java.util.zip.ZipFile;

import static org.junit.Assert.assertTrue;

public class RuntimeReportBundleTest {
    @Test public void exportsOnlySessionFiles() throws Exception {
        File root = Files.createTempDirectory("execution-reports").toFile();
        Files.write(new File(root, "execution_log.txt").toPath(), "log".getBytes(StandardCharsets.UTF_8));
        Files.write(new File(root, "runtime_session_report.txt").toPath(), "report".getBytes(StandardCharsets.UTF_8));
        File bundle = RuntimeReportBundle.create(root);
        assertTrue(bundle.isFile());
        Set<String> names = new HashSet<>();
        try (ZipFile zip = new ZipFile(bundle)) {
            zip.entries().asIterator().forEachRemaining(entry -> names.add(entry.getName()));
        }
        assertTrue(names.contains("execution_log.txt"));
        assertTrue(names.contains("runtime_session_report.txt"));
    }
}
