# قائمة اعتماد GTAV Runtime Manager v1.7.0

## المصدر والبناء

- [ ] تثبيت PRoot Android AArch64 في `app/src/main/jniLibs/arm64-v8a/libproot_exec.so`.
- [ ] تثبيت SHA-256 للمصدر في `PROOT_PROVENANCE.txt` وحفظ الالتزامات الترخيصية.
- [ ] نجاح `tools/verify-source-boundaries.sh` دون `ALLOW_MISSING_PROOT`.
- [ ] نجاح `verifyExecutionSourceComponents`.
- [ ] نجاح `verifyExecutionDomainBoundaries`.
- [ ] نجاح اختبارات JVM.
- [ ] نجاح Debug وRelease packaging.
- [ ] وجود `EXECUTION_COMPONENTS.txt` و`FEATURE_FLAGS.txt` لكل Variant.

## بوابات جهاز ARM64

- [ ] PRoot ELF = AArch64 وقابل للتنفيذ.
- [ ] `/bin/true` يخرج 0.
- [ ] `/bin/echo LINUX_ECHO_OK` صحيح.
- [ ] `/bin/sh -c 'echo LINUX_RUNTIME_OK'` صحيح.
- [ ] `box64 --version` يخرج 0.
- [ ] `hello-x86_64` يطبع `BOX64_SMOKE_TEST_OK` ويخرج 0.
- [ ] `wine64 --version` يخرج 0.
- [ ] `wineboot -u` يهيئ Prefix التشخيصي خارج RootFS.
- [ ] Wine Console يطبع `WINE_RUNTIME_OK` ويخرج 0.
- [ ] الحالة النهائية `COMPLETED`.
- [ ] `process_tree.json` لا يسجل Orphans أحياء.
- [ ] `runtime_immutability.txt` يسجل PASS.
- [ ] إلغاء جلسة طويلة ينظف PRoot/Box64/Wine/wineserver.
- [ ] إعادة فتح الواجهة تعرض آخر حالة وآخر السجل.

لا يعتمد الإصدار العام بمجرد نجاح التجميع. سلسلة الجهاز كاملة إلزامية.
