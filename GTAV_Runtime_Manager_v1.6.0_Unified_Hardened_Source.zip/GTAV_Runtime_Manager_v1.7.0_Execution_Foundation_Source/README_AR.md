# GTAV Runtime Manager v1.7.0 — Execution Foundation

المشروع الخامس هو دمج هندسي منظم لأفضل أفكار التجارب الأربع، وليس تجميعًا آليًا للملفات. وظيفته قراءة حزمة Runtime موثوقة، التحقق منها، فك `rootfs.tar.zst` بصورة متدفقة، ثم تثبيتها ذريًا مع تقارير قابلة للتصدير.

> هذا المشروع **مدير تثبيت Runtime** فقط. لا يشغّل GTA V، ولا يتضمن PRoot أو Box64 أو Wine أو DXVK أو Vulkan أو تشغيل ملفات EXE.

## ما الذي يميّز المشروع الخامس؟

- واجهة ضغط واحدة: `CompressionManager` ← `ZstdEngine`.
- محرك إنتاج واحد فقط: `AndroidZstdJniEngine` المبني على Android AAR.
- محول `NdkZstdEngine` محفوظ كحد معماري مستقبلي لكنه غير مفعّل، لتجنب وجود محركين متنافسين.
- تصنيف واضح لأخطاء ABI و`dlopen` وتهيئة JNI والذاكرة وStreaming.
- تشخيص عند بدء التطبيق، وتشخيص أعمق قبل التثبيت على مسار التخزين الفعلي.
- فحص API وABI وJNI وSAF وContentResolver وSELinux والكتابة و`fsync` و`chmod` وSymlink وAtomic rename والمساحة ومحرك TAR.
- Round-trip وStreaming حقيقيان لـZstandard قبل السماح بالتثبيت.
- استخراج Streaming دون تحميل Payload أو TAR كاملًا في الذاكرة.
- حماية من Path Traversal والكتابة عبر Symlink أب.
- تثبيت ذري باستخدام `.installing` و`.backup` مع Rollback.
- Foreground Service وWakeLock وإلغاء آمن ومراقب توقف وJournal واستعادة بعد الانقطاع.
- بوابات بناء تفحص AAR وAPK الفعليين، وتمنع استخدام Zstd المباشر خارج المحرك.
- تقارير SHA-256 ومحتوى المكتبات الأصلية ومعلومات البناء لكل Variant.

## المعمارية المختصرة

```text
MainActivity
  ├─ StartupDiagnostic
  └─ RuntimeInstallCoordinator
       ├─ RuntimeInstallService
       └─ RuntimeInstaller
            ├─ RuntimePreflightChecker
            │    ├─ RuntimePlatformValidator
            │    ├─ NativeLibraryManager
            │    └─ CompressionManager → ZstdEngine
            ├─ RuntimeExtractor
            ├─ RuntimePostVerifier
            ├─ AtomicRuntimeSwap
            ├─ RuntimeInstallJournal / Watchdog / Recovery
            └─ RuntimeLogWriter / CrashReporter / DiagnosticsExporter
```

## متطلبات البناء

- JDK 17
- Gradle 8.11.1
- Android SDK Platform 36
- Android SDK Build Tools 35.0.0
- جهاز أو محاكي ARM64 لاختبارات Android Instrumented

لا يحتوي الأرشيف على Gradle Wrapper binary. يمكن فتح المشروع في Android Studio أو استخدام Gradle 8.11.1 المثبت محليًا.

## أوامر البناء والتحقق

```bash
gradle clean testDebugUnitTest lintDebug validateAllNativePackaging
```

لاختبارات الجهاز:

```bash
gradle connectedDebugAndroidTest
```

أو استخدم:

```bash
./validate-release.sh
```

ينشئ فحص APK تقارير تحت:

```text
app/build/reports/native-packaging/debug/
app/build/reports/native-packaging/release/
```

وتتضمن:

- `APK_NATIVE_LIBS.txt`
- `BUILD_INFO.txt`
- `SHA256SUMS.txt`

## شروط السماح بالتثبيت

لا يُفتح مسار التثبيت إلا بعد نجاح:

1. تشخيص بدء التشغيل.
2. التحقق من الحزمة والـManifest والـPayload.
3. فحص المساحة ونظام الملفات الفعلي.
4. توافق `arm64-v8a` ووجود مكتبة Zstandard داخل التطبيق.
5. Round-trip وStreaming لـJNI.
6. فتح أول TAR entry والتحقق من سلامة مساره.

## الاختبارات الموجودة

### Unit tests

- التثبيت الذري واستعادة النسخة الاحتياطية.
- الإلغاء المنظم.
- تحويل فشل `chmod` إلى خطأ Typed.
- التحقق من Payload وإحصائيات Hard Links.
- تفويض `CompressionManager` للمحرك.
- بنية محرك AAR وتعطيل محول NDK المستقبلي.
- تصنيف أخطاء Zstandard.
- منطق جاهزية المنصة وتقارير المكتبات الأصلية.

### Instrumented tests

- توافق ABI ووجود مكتبة Zstandard الأصلية.
- Round-trip وStreaming على Android Runtime.
- فتح عينة `sample.tar.zst` حقيقية وقراءة TAR.
- تقرير جاهزية المنصة على جهاز ARM64 مدعوم.

## وثائق إضافية

- `PROJECT_5_COMPARISON_AR.md`: ما أُخذ من كل تجربة ولماذا.
- `ARCHITECTURE_AR.md`: المعمارية ومسار البيانات والحماية.
- `IMPLEMENTATION_MATRIX_AR.md`: مصفوفة المتطلبات والتنفيذ.
- `VALIDATION_RESULT_AR.md`: ما تم فحصه في بيئة الإنشاء وما يحتاج جهاز Android.
- `RELEASE_CHECKLIST_AR.md`: شروط اعتماد APK نهائي.

## Execution Foundation v1.7.0

أضيف مجال تشغيل مستقل لا يغير المثبّت المستقر. افتح **Runtime Console** بعد تثبيت Runtime
متحقق منه لتشغيل البوابات بالترتيب: PRoot ثم RootFS ثم Box64 ELF smoke ثم Wine Console.
المعيار النهائي هو `WINE_RUNTIME_OK` مع Exit Code 0 وحالة `COMPLETED` وعدم وجود عمليات يتيمة.

راجع:

- `EXECUTION_ARCHITECTURE_AR.md`
- `EXECUTION_IMPLEMENTATION_MATRIX_AR.md`
- `EXECUTION_RELEASE_CHECKLIST_AR.md`
- `THIRD_PARTY_EXECUTION_COMPONENTS.md`

> ملاحظة بناء: يلزم PRoot Android AArch64 موثق ومثبت بواسطة
> `tools/fetch-proot-android.sh` مع `PROOT_SHA256` مثبت. بوابة البناء ترفض غيابه عمدًا.
