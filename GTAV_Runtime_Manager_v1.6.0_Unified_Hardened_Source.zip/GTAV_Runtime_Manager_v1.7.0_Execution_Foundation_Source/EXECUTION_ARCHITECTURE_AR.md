# معمارية Execution Foundation — الإصدار 1.7.0

## حدود المجالين

```text
Installation Domain (مستقر)
├── RuntimeInstaller
├── RuntimeExtractor
├── Verification
└── Atomic Swap
          │
          └── InstalledRuntimeProvider → VerifiedInstalledRuntime

Execution Domain
├── RuntimeExecutionService
├── RuntimeExecutionManager
├── RuntimeSessionManager
├── RuntimeLauncher
├── RuntimeProcessRunner
├── RuntimeProcessSupervisor
├── IsolationEngine → ProotIsolationEngine
├── Box64Manager / Box64SmokeTest
├── WineManager / WinePrefixManager
├── RuntimeConsoleStore
└── RuntimeExecutionReporter
```

لا يستورد Execution Domain أيًا من تفاصيل المثبّت. نقطة العبور الوحيدة هي
`InstalledRuntimeProvider`، ولا تعيد إلا Runtime حالته `complete/COMPLETED`، وهويته
وإصداره وSHA-256 متطابقة مع الـManifest، ومساره داخل مجلد runtimes المعتمد.

## سلسلة النجاح

```text
Android ARM64 / Bionic
  → PRoot Android AArch64
  → Debian glibc RootFS
  → Box64
  → hello-x86_64
  → Wine Console + Prefix خارجي
  → cmd.exe /c echo WINE_RUNTIME_OK
```

النجاح النهائي يتطلب:

- ظهور `WINE_RUNTIME_OK`.
- Exit Code يساوي صفرًا.
- حالة الجلسة `COMPLETED`.
- تنظيف شجرة العمليات وعدم بقاء Orphans.
- عدم تغير شجرة Runtime أو الملفات الحرجة أثناء الجلسة.

## آلة الحالات

`IDLE → PREPARING → VALIDATING → STARTING_PROOT → ENTERING_ROOTFS → RUNNING_BOX64 → STARTING_WINE → RUNNING → STOPPING → COMPLETED`

ويمكن لأي مرحلة نشطة أن تنتهي بـ`FAILED` أو `CANCELLED` وفق جدول الانتقالات الصريح في
`RuntimeSessionManager`.

## مسؤوليات الطبقات

- `RuntimeLauncher`: يبني خطة التنفيذ فقط.
- `RuntimeProcessRunner`: يشغل عملية واحدة، يلتقط stdout/stderr وExit Code وTimeout.
- `RuntimeProcessSupervisor`: يتتبع PID والأبناء، يحمي من PID reuse، وينفذ TERM ثم KILL.
- `RuntimeExecutionManager`: ينسق البوابات بالترتيب ولا يبني تفاصيل PRoot يدويًا.
- `RuntimeConsoleStore`: يكتب السجل الكامل إلى ملف ويحتفظ بآخر 600 سطر للواجهة.
- `RuntimeExecutionReporter`: ينشئ تقارير كل طبقة.

## Bionic مقابل glibc

- بيئة المضيف تستخدم Android/Bionic و`ANDROID_LD_LIBRARY_PATH`.
- بيئة الضيف تبدأ عبر `/usr/bin/env -i`، وتستخدم `GUEST_LD_LIBRARY_PATH` و
  `BOX64_LD_LIBRARY_PATH`.
- لا يمر `nativeLibraryDir` الخاص بأندرويد إلى `LD_LIBRARY_PATH` داخل الضيف.

## سياسة Runtime شبه الثابت

كل الكتابة المخططة تقع خارج RootFS داخل:

- `prefixes/`
- `sessions/`
- `cache/`
- `logs/`
- `profiles/`

Wine Prefix لا يُنشأ داخل RootFS. يتم أخذ Snapshot كامل لبيانات عقد RootFS قبل الجلسة
وبعدها، مع SHA-256 للـManifest وBox64 وWine entrypoints. هذه آلية كشف دفاعية؛ PRoot
لا يوفر وحده mount root حقيقيًا للقراءة فقط مثل mount namespace في نواة بصلاحيات root.

## المكونات المؤجلة

`BackendCapabilityRegistry` يسجل Display وAudio وGraphics وInput بحالة `EXPERIMENTAL`.
لا توجد مديرات فارغة أو ادعاء جاهزية. Game Library مسجلة Feature Flag فقط، وكل هذه
المكونات خارج معيار نجاح v1.7.0.
