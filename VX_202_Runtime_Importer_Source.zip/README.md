# VX 202 — Runtime Importer + Diagnostic

اسم التطبيق يبقى **VX** ومعرّف الحزمة يبقى:

```text
com.vx.runtime
```

## الوظائف

- اختيار `GTAV_Runtime_Package.zip` مباشرة من الهاتف.
- أو اختيار Artifact الكامل الذي يحتوي `out/GTAV_Runtime_Package.zip`.
- التحقق من `runtime_manifest.json`.
- التحقق من حجم وبصمة `payload/rootfs.tar.zst`.
- فك Zstandard وTAR داخل مساحة VX.
- الحفاظ على الروابط والصلاحيات الأساسية.
- التحقق من glibc loader وBox64 وملفات إعداد Wine.
- تفعيل التشخيص بعد نجاح الاستيراد.
- حذف Runtime المثبت من داخل التطبيق.
- حفظ تقرير التشخيص كملف ZIP قابل للمشاركة.

## تنبيه

تثبيت APK كتحديث فوق نسخة VX سابقة يتطلب توقيعه بالمفتاح نفسه.
