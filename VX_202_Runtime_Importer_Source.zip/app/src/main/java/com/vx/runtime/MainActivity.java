package com.vx.runtime;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.PowerManager;
import android.provider.OpenableColumns;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import androidx.core.content.FileProvider;
import org.json.JSONObject;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

public final class MainActivity extends Activity {
    static { System.loadLibrary("vxdiagnostic"); }

    private static final int REQUEST_RUNTIME = 202;
    private native String nativeRunDiagnostics(String filesDir, String nativeLibraryDir, String reportDir);

    private TextView runtimeStatus;
    private TextView output;
    private Button importButton;
    private Button runButton;
    private Button shareButton;
    private Button removeButton;
    private ProgressBar importProgress;
    private File bundleFile;
    private volatile boolean busy;

    @Override
    public void onCreate(Bundle state) {
        super.onCreate(state);
        setContentView(R.layout.activity_main);

        runtimeStatus = findViewById(R.id.runtimeStatus);
        output = findViewById(R.id.output);
        importButton = findViewById(R.id.importButton);
        runButton = findViewById(R.id.runButton);
        shareButton = findViewById(R.id.shareButton);
        removeButton = findViewById(R.id.removeButton);
        importProgress = findViewById(R.id.importProgress);

        importButton.setOnClickListener(v -> chooseRuntime());
        runButton.setOnClickListener(v -> runDiagnostics());
        shareButton.setOnClickListener(v -> shareReport());
        removeButton.setOnClickListener(v -> confirmRemoveRuntime());

        refreshRuntimeStatus();
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshRuntimeStatus();
    }

    private void chooseRuntime() {
        if (busy) return;
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("application/zip");
        intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[] {
            "application/zip",
            "application/octet-stream",
            "application/x-zip-compressed"
        });
        startActivityForResult(intent, REQUEST_RUNTIME);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQUEST_RUNTIME || resultCode != RESULT_OK || data == null) return;

        Uri uri = data.getData();
        if (uri == null) return;

        try {
            getContentResolver().takePersistableUriPermission(
                uri,
                data.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
            );
        } catch (Exception ignored) {}

        installRuntime(uri);
    }

    private void installRuntime(Uri uri) {
        setBusy(true);
        importProgress.setVisibility(View.VISIBLE);
        importProgress.setProgress(0);
        output.setText("تم اختيار الملف:\n" + displayName(uri) + "\n\nبدء استيراد Runtime…");

        new Thread(() -> {
            PowerManager.WakeLock wakeLock = null;
            try {
                PowerManager pm = (PowerManager)getSystemService(POWER_SERVICE);
                wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "VX:RuntimeImport");
                wakeLock.acquire(60L * 60L * 1000L);

                JSONObject result = RuntimeImporter.install(this, uri, (phase, percent, bytes, nodes, path) -> {
                    runOnUiThread(() -> {
                        importProgress.setProgress(percent);
                        output.setText(
                            phase + "\n" +
                            "التقدم: " + percent + "%\n" +
                            "البيانات: " + formatBytes(bytes) + "\n" +
                            "العناصر: " + nodes + "\n" +
                            "المسار: " + path
                        );
                    });
                });

                runOnUiThread(() -> {
                    importProgress.setProgress(100);
                    output.setText("✅ تم تثبيت Runtime بنجاح\n\n" + result.toString(2));
                    setBusy(false);
                    refreshRuntimeStatus();
                });
            } catch (Throwable error) {
                runOnUiThread(() -> {
                    output.setText("❌ فشل استيراد Runtime\n\n" + error.getClass().getName() + "\n" + error.getMessage());
                    setBusy(false);
                    refreshRuntimeStatus();
                });
            } finally {
                if (wakeLock != null && wakeLock.isHeld()) wakeLock.release();
            }
        }, "vx-runtime-import").start();
    }

    private void refreshRuntimeStatus() {
        File active = new File(getFilesDir(), "vx/runtime");
        File rootfs = new File(active, "rootfs");
        File stateFile = new File(active, "runtime_state.json");
        File manifestFile = new File(active, "runtime_manifest.json");

        boolean installed =
            rootfs.isDirectory() &&
            new File(rootfs, "lib/ld-linux-aarch64.so.1").exists() &&
            new File(rootfs, "usr/local/bin/box64").exists();

        String runtimeId = "";
        String runtimeVersion = "";
        try {
            if (manifestFile.isFile()) {
                JSONObject manifest = new JSONObject(readFile(manifestFile));
                runtimeId = manifest.optString("runtime_id");
                runtimeVersion = manifest.optString("version");
            }
        } catch (Exception ignored) {}

        StringBuilder status = new StringBuilder();
        status.append("Package: ").append(getPackageName()).append('\n');
        status.append("Runtime: ").append(installed ? "INSTALLED ✅" : "NOT INSTALLED").append('\n');
        status.append("Path: ").append(rootfs.getAbsolutePath());

        if (installed) {
            status.append("\nID: ").append(runtimeId);
            status.append("\nVersion: ").append(runtimeVersion);
        } else {
            status.append("\n\nاختر GTAV_Runtime_Package.zip أو Artifact الكامل من الهاتف.");
        }

        runtimeStatus.setText(status.toString());
        runButton.setEnabled(installed && !busy);
        removeButton.setEnabled(installed && !busy);
        importButton.setEnabled(!busy);
    }

    private void runDiagnostics() {
        if (busy) return;
        setBusy(true);
        shareButton.setEnabled(false);
        output.setText("Preparing VX diagnostics…\n");

        new Thread(() -> {
            try {
                File base = new File(getFilesDir(), "diagnostic-v2");
                File bin = new File(base, "bin");
                File reports = new File(base, "reports");
                File shared = new File(getCacheDir(), "vx-share");
                ensureDir(bin);
                ensureDir(reports);
                ensureDir(shared);

                extractAsset("diagnostic/hello_static", new File(bin, "hello_static"));
                extractAsset("diagnostic/hello_dynamic_glibc", new File(bin, "hello_dynamic_glibc"));
                extractAsset("diagnostic/hello_x86_64", new File(bin, "hello_x86_64"));

                long started = System.currentTimeMillis();
                String json = nativeRunDiagnostics(
                    getFilesDir().getAbsolutePath(),
                    getApplicationInfo().nativeLibraryDir,
                    reports.getAbsolutePath()
                );

                File jsonFile = new File(reports, "vx_diagnostic_report.json");
                File txtFile = new File(reports, "vx_diagnostic_report.txt");
                File logFile = new File(reports, "android_logcat_best_effort.txt");

                write(jsonFile, json);
                write(txtFile, buildTextSummary(json));
                write(logFile, collectOwnLogcat(started));

                String stamp = new SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(new Date());
                bundleFile = new File(shared, "vx_runtime_diagnostic_" + stamp + ".zip");
                zip(bundleFile, jsonFile, txtFile, logFile);

                runOnUiThread(() -> {
                    output.setText(prettyDiagnosticSummary(json));
                    shareButton.setEnabled(true);
                    setBusy(false);
                    refreshRuntimeStatus();
                });
            } catch (Exception ex) {
                runOnUiThread(() -> {
                    output.setText("Diagnostic controller failed:\n" + ex);
                    setBusy(false);
                    refreshRuntimeStatus();
                });
            }
        }, "vx-diagnostics").start();
    }

    private String prettyDiagnosticSummary(String json) {
        try {
            JSONObject root = new JSONObject(json);
            String firstFailure = root.optString("first_failure_stage", "");
            String status = root.optString("status", "");
            return "VX Diagnostic completed\n\n" +
                "Status: " + status + "\n" +
                "First failure: " + (firstFailure.isEmpty() ? "none" : firstFailure) + "\n\n" +
                "التقرير الكامل محفوظ ويمكن مشاركته من الزر.\n\n" +
                json;
        } catch (Exception ignored) {
            return json;
        }
    }

    private void confirmRemoveRuntime() {
        new AlertDialog.Builder(this)
            .setTitle("حذف Runtime")
            .setMessage("سيتم حذف Runtime المثبت فقط. هل أنت متأكد؟")
            .setNegativeButton("إلغاء", null)
            .setPositiveButton("حذف", (dialog, which) -> {
                setBusy(true);
                new Thread(() -> {
                    RuntimeImporter.deleteRecursively(new File(getFilesDir(), "vx/runtime"));
                    runOnUiThread(() -> {
                        bundleFile = null;
                        shareButton.setEnabled(false);
                        output.setText("تم حذف Runtime المثبت.");
                        setBusy(false);
                        refreshRuntimeStatus();
                    });
                }).start();
            })
            .show();
    }

    private void setBusy(boolean value) {
        busy = value;
        importButton.setEnabled(!value);
        runButton.setEnabled(!value && runtimeInstalled());
        removeButton.setEnabled(!value && runtimeInstalled());
    }

    private boolean runtimeInstalled() {
        File rootfs = new File(getFilesDir(), "vx/runtime/rootfs");
        return rootfs.isDirectory()
            && new File(rootfs, "lib/ld-linux-aarch64.so.1").exists()
            && new File(rootfs, "usr/local/bin/box64").exists();
    }

    private String displayName(Uri uri) {
        try (android.database.Cursor cursor = getContentResolver().query(uri, null, null, null, null)) {
            if (cursor != null && cursor.moveToFirst()) {
                int index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (index >= 0) return cursor.getString(index);
            }
        } catch (Exception ignored) {}
        return uri.toString();
    }

    private static String formatBytes(long bytes) {
        if (bytes < 1024) return bytes + " B";
        double value = bytes;
        String[] units = {"KiB", "MiB", "GiB"};
        int unit = -1;
        while (value >= 1024 && unit < units.length - 1) {
            value /= 1024;
            unit++;
        }
        return String.format(Locale.US, "%.2f %s", value, units[unit]);
    }

    private static String readFile(File file) throws IOException {
        try (InputStream in = new FileInputStream(file);
             ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[64 * 1024];
            int n;
            while ((n = in.read(buffer)) > 0) out.write(buffer, 0, n);
            return out.toString(StandardCharsets.UTF_8.name());
        }
    }

    private static void ensureDir(File dir) throws IOException {
        if (!dir.mkdirs() && !dir.isDirectory()) throw new IOException("Cannot create " + dir);
    }

    private void extractAsset(String asset, File out) throws IOException {
        try (InputStream in = getAssets().open(asset);
             FileOutputStream fos = new FileOutputStream(out)) {
            byte[] buffer = new byte[65536];
            int n;
            while ((n = in.read(buffer)) > 0) fos.write(buffer, 0, n);
        }
        if (!out.setReadable(true, true) || !out.setExecutable(true, true)) {
            throw new IOException("chmod failed: " + out);
        }
    }

    private String collectOwnLogcat(long startedMs) {
        StringBuilder result = new StringBuilder();
        result.append("Best-effort app-visible logcat only.\n");
        Process process = null;
        try {
            process = new ProcessBuilder(
                "logcat", "-d", "--pid=" + android.os.Process.myPid(),
                "-v", "threadtime", "-t", "800"
            ).redirectErrorStream(true).start();

            try (BufferedReader reader = new BufferedReader(
                new InputStreamReader(process.getInputStream(), StandardCharsets.UTF_8))) {
                String line;
                while ((line = reader.readLine()) != null) result.append(line).append('\n');
            }
            process.waitFor();
        } catch (Exception ex) {
            result.append("LOGCAT_UNAVAILABLE: ").append(ex).append('\n');
            if (process != null) process.destroy();
        }
        result.append("collection_started_epoch_ms=").append(startedMs).append('\n');
        return result.toString();
    }

    private static String buildTextSummary(String json) {
        return "VX Runtime Importer + Diagnostic\n"
            + "The JSON below is authoritative.\n\n"
            + json;
    }

    private static void write(File file, String text) throws IOException {
        try (FileOutputStream out = new FileOutputStream(file)) {
            out.write(text.getBytes(StandardCharsets.UTF_8));
        }
    }

    private static void zip(File zip, File... files) throws IOException {
        try (ZipOutputStream out = new ZipOutputStream(new FileOutputStream(zip))) {
            byte[] buffer = new byte[65536];
            for (File file : files) {
                out.putNextEntry(new ZipEntry(file.getName()));
                try (InputStream in = new FileInputStream(file)) {
                    int n;
                    while ((n = in.read(buffer)) > 0) out.write(buffer, 0, n);
                }
                out.closeEntry();
            }
        }
    }

    private void shareReport() {
        if (bundleFile == null || !bundleFile.isFile()) return;
        Uri uri = FileProvider.getUriForFile(
            this,
            getPackageName() + ".fileprovider",
            bundleFile
        );
        Intent intent = new Intent(Intent.ACTION_SEND);
        intent.setType("application/zip");
        intent.putExtra(Intent.EXTRA_STREAM, uri);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        startActivity(Intent.createChooser(intent, "مشاركة تقرير VX"));
    }
}
