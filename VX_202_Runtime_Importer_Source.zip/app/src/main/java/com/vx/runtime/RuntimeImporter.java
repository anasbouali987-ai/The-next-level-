package com.vx.runtime;

import android.content.Context;
import android.net.Uri;
import android.system.Os;
import com.github.luben.zstd.ZstdInputStream;
import org.apache.commons.compress.archivers.tar.TarArchiveEntry;
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream;
import org.json.JSONObject;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.security.MessageDigest;
import java.util.*;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

public final class RuntimeImporter {
    private static final int BUFFER = 1024 * 1024;
    private static final long MAX_PACKAGE = 4L * 1024 * 1024 * 1024;
    private static final long MAX_ROOTFS = 6L * 1024 * 1024 * 1024;
    private static final int MAX_NODES = 150_000;
    private static final long MAX_MANIFEST = 32L * 1024 * 1024;

    public interface Listener {
        void onProgress(String phase, int percent, long bytes, int nodes, String path);
    }

    private static final class PendingLink {
        final File file;
        final String rawTarget;
        final boolean hard;
        PendingLink(File file, String rawTarget, boolean hard) {
            this.file = file;
            this.rawTarget = rawTarget;
            this.hard = hard;
        }
    }

    private RuntimeImporter() {}

    public static JSONObject install(Context context, Uri uri, Listener listener) throws Exception {
        File vxBase = new File(context.getFilesDir(), "vx");
        File active = new File(vxBase, "runtime");
        File staging = new File(vxBase, "staging-" + UUID.randomUUID());
        File rootfs = new File(staging, "rootfs");
        File selected = new File(context.getCacheDir(), "vx-selected-" + UUID.randomUUID() + ".zip");
        File nested = new File(context.getCacheDir(), "vx-package-" + UUID.randomUUID() + ".zip");

        deleteRecursively(staging);
        if (!rootfs.mkdirs() && !rootfs.isDirectory()) {
            throw new IOException("تعذر إنشاء مجلد تثبيت Runtime");
        }

        long selectedBytes = 0;
        long payloadBytes = 0;
        long extractedBytes = 0;
        int nodes = 0;
        int rewrittenSymlinks = 0;

        try {
            listener.onProgress("COPYING", 0, 0, 0, "نسخ الملف المختار");
            try (InputStream raw = context.getContentResolver().openInputStream(uri)) {
                if (raw == null) throw new IOException("تعذر فتح الملف المختار");
                try (BufferedInputStream in = new BufferedInputStream(raw, BUFFER);
                     BufferedOutputStream out = new BufferedOutputStream(new FileOutputStream(selected), BUFFER)) {
                    byte[] buffer = new byte[BUFFER];
                    int n;
                    while ((n = in.read(buffer)) > 0) {
                        selectedBytes += n;
                        if (selectedBytes > MAX_PACKAGE) throw new IOException("الحزمة أكبر من حد الأمان 4GiB");
                        out.write(buffer, 0, n);
                        if ((selectedBytes & ((16L * BUFFER) - 1)) < n) {
                            listener.onProgress("COPYING", 0, selectedBytes, 0, selected.getName());
                        }
                    }
                }
            }

            File packageFile = resolvePackage(selected, nested, listener);
            listener.onProgress("VALIDATING_PACKAGE", 5, packageFile.length(), 0, packageFile.getName());

            JSONObject manifest;
            JSONObject payloadDescriptor;
            File payloadTemp = new File(staging, "rootfs.tar.zst");

            try (ZipFile zip = new ZipFile(packageFile)) {
                ZipEntry manifestEntry = zip.getEntry("runtime_manifest.json");
                if (manifestEntry == null || manifestEntry.isDirectory()) {
                    throw new IOException("runtime_manifest.json غير موجود داخل الحزمة");
                }
                if (manifestEntry.getSize() <= 0 || manifestEntry.getSize() > MAX_MANIFEST) {
                    throw new IOException("حجم runtime_manifest.json غير صالح");
                }

                try (InputStream in = zip.getInputStream(manifestEntry)) {
                    manifest = new JSONObject(readText(in, MAX_MANIFEST));
                }

                payloadDescriptor = manifest.getJSONObject("rootfs_payload");
                String payloadPath = safeArchivePath(payloadDescriptor.getString("path"));
                ZipEntry payloadEntry = zip.getEntry(payloadPath);
                if (payloadEntry == null || payloadEntry.isDirectory()) {
                    throw new IOException("ملف RootFS مفقود: " + payloadPath);
                }

                long expectedSize = payloadDescriptor.getLong("size_bytes");
                String expectedSha = payloadDescriptor.getString("sha256").toLowerCase(Locale.US);
                if (expectedSize <= 0 || expectedSize > MAX_PACKAGE) {
                    throw new IOException("حجم RootFS غير صالح");
                }
                if (!expectedSha.matches("[0-9a-f]{64}")) {
                    throw new IOException("بصمة RootFS غير صالحة");
                }

                MessageDigest digest = MessageDigest.getInstance("SHA-256");
                try (InputStream raw = zip.getInputStream(payloadEntry);
                     BufferedInputStream in = new BufferedInputStream(raw, BUFFER);
                     BufferedOutputStream out = new BufferedOutputStream(new FileOutputStream(payloadTemp), BUFFER)) {
                    byte[] buffer = new byte[BUFFER];
                    int n;
                    while ((n = in.read(buffer)) > 0) {
                        payloadBytes += n;
                        if (payloadBytes > MAX_PACKAGE) throw new IOException("RootFS payload أكبر من حد الأمان");
                        digest.update(buffer, 0, n);
                        out.write(buffer, 0, n);
                        int percent = (int)Math.min(35, 5 + (payloadBytes * 30 / Math.max(1, expectedSize)));
                        listener.onProgress("VERIFYING_PAYLOAD", percent, payloadBytes, 0, payloadPath);
                    }
                }

                String actualSha = hex(digest.digest());
                if (payloadBytes != expectedSize) {
                    throw new IOException("حجم RootFS لا يطابق Manifest: expected=" + expectedSize + " actual=" + payloadBytes);
                }
                if (!actualSha.equals(expectedSha)) {
                    throw new IOException("بصمة SHA-256 لملف RootFS لا تطابق Manifest");
                }
            }

            File manifestFile = new File(staging, "runtime_manifest.json");
            writeText(manifestFile, manifest.toString(2));

            List<PendingLink> links = new ArrayList<>();
            long estimatedUncompressed = Math.max(
                manifest.optLong("rootfs_uncompressed_bytes", 0),
                payloadDescriptor.optLong("uncompressed_size_bytes", 0)
            );

            try (InputStream payloadIn = new BufferedInputStream(new FileInputStream(payloadTemp), BUFFER);
                 ZstdInputStream zstd = new ZstdInputStream(payloadIn);
                 TarArchiveInputStream tar = new TarArchiveInputStream(new BufferedInputStream(zstd, BUFFER))) {

                TarArchiveEntry entry;
                byte[] buffer = new byte[BUFFER];
                while ((entry = tar.getNextTarEntry()) != null) {
                    String relative = safeTarPath(entry.getName());
                    if (relative.isEmpty()) continue;

                    nodes++;
                    if (nodes > MAX_NODES) throw new IOException("RootFS يحتوي عناصر أكثر من حد الأمان");

                    File target = safeTarget(rootfs, relative);
                    if (entry.isDirectory()) {
                        if (!target.mkdirs() && !target.isDirectory()) {
                            throw new IOException("تعذر إنشاء " + relative);
                        }
                        chmod(target, entry.getMode(), true);
                    } else if (entry.isSymbolicLink()) {
                        File parent = target.getParentFile();
                        if (parent != null) parent.mkdirs();
                        links.add(new PendingLink(target, entry.getLinkName(), false));
                    } else if (entry.isLink()) {
                        File parent = target.getParentFile();
                        if (parent != null) parent.mkdirs();
                        links.add(new PendingLink(target, entry.getLinkName(), true));
                    } else if (entry.isFile()) {
                        File parent = target.getParentFile();
                        if (parent != null && !parent.mkdirs() && !parent.isDirectory()) {
                            throw new IOException("تعذر إنشاء مجلد " + parent);
                        }
                        try (BufferedOutputStream out = new BufferedOutputStream(new FileOutputStream(target), BUFFER)) {
                            int n;
                            while ((n = tar.read(buffer)) > 0) {
                                extractedBytes += n;
                                if (extractedBytes > MAX_ROOTFS) throw new IOException("RootFS بعد الفك أكبر من حد الأمان");
                                out.write(buffer, 0, n);
                            }
                        }
                        chmod(target, entry.getMode(), false);
                    }

                    if (nodes % 50 == 0) {
                        int percent;
                        if (estimatedUncompressed > 0) {
                            percent = (int)Math.min(90, 35 + (extractedBytes * 55 / estimatedUncompressed));
                        } else {
                            percent = Math.min(90, 35 + nodes / 200);
                        }
                        listener.onProgress("EXTRACTING", percent, extractedBytes, nodes, relative);
                    }
                }
            }

            for (PendingLink link : links) {
                if (link.hard) {
                    File source = safeTarget(rootfs, safeTarPath(link.rawTarget));
                    if (!source.exists()) throw new IOException("مصدر hard link مفقود: " + link.rawTarget);
                    if (link.file.exists()) link.file.delete();
                    try {
                        Files.createLink(link.file.toPath(), source.toPath());
                    } catch (Exception ex) {
                        copyFile(source, link.file);
                    }
                }
            }

            for (PendingLink link : links) {
                if (link.hard) continue;
                if (link.file.exists() || Files.isSymbolicLink(link.file.toPath())) link.file.delete();
                String translated = translateSymlink(rootfs, link.file, link.rawTarget);
                if (!translated.equals(link.rawTarget)) rewrittenSymlinks++;
                Os.symlink(translated, link.file.getAbsolutePath());
            }

            payloadTemp.delete();
            listener.onProgress("VALIDATING_ROOTFS", 94, extractedBytes, nodes, "Runtime core");

            JSONObject validation = validateRootfs(rootfs);
            if (!validation.getBoolean("valid")) {
                throw new IOException(validation.getJSONArray("errors").toString());
            }

            JSONObject state = new JSONObject()
                .put("status", "INSTALLED")
                .put("runtime_id", manifest.optString("runtime_id"))
                .put("runtime_version", manifest.optString("version"))
                .put("libc_model", manifest.optString("libc_model"))
                .put("source_package_bytes", selectedBytes)
                .put("payload_bytes", payloadBytes)
                .put("rootfs_nodes", nodes)
                .put("rootfs_uncompressed_bytes", extractedBytes)
                .put("absolute_symlinks_rewritten", rewrittenSymlinks)
                .put("installed_at_epoch_ms", System.currentTimeMillis())
                .put("ready_for_diagnostics", true)
                .put("ready_for_gtav", false);

            writeText(new File(staging, "runtime_state.json"), state.toString(2));

            File backup = new File(vxBase, "runtime-backup");
            deleteRecursively(backup);
            if (active.exists() && !active.renameTo(backup)) {
                throw new IOException("تعذر حفظ نسخة Runtime السابقة");
            }
            if (!staging.renameTo(active)) {
                if (backup.exists()) backup.renameTo(active);
                throw new IOException("تعذر تفعيل Runtime الجديد");
            }
            deleteRecursively(backup);

            listener.onProgress("INSTALLED", 100, extractedBytes, nodes, active.getAbsolutePath());

            return new JSONObject()
                .put("status", "INSTALLED")
                .put("runtime_id", manifest.optString("runtime_id"))
                .put("runtime_version", manifest.optString("version"))
                .put("source_kind", packageFile.equals(nested) ? "github_artifact" : "runtime_package")
                .put("rootfs_path", new File(active, "rootfs").getAbsolutePath())
                .put("package_bytes", selectedBytes)
                .put("payload_bytes", payloadBytes)
                .put("rootfs_nodes", nodes)
                .put("rootfs_bytes", extractedBytes)
                .put("absolute_symlinks_rewritten", rewrittenSymlinks)
                .put("validation", validation)
                .put("state", state);

        } catch (Throwable t) {
            deleteRecursively(staging);
            throw t;
        } finally {
            selected.delete();
            nested.delete();
        }
    }

    private static File resolvePackage(File selected, File nested, Listener listener) throws Exception {
        try (ZipFile zip = new ZipFile(selected)) {
            if (zip.getEntry("runtime_manifest.json") != null &&
                zip.getEntry("payload/rootfs.tar.zst") != null) {
                return selected;
            }

            List<ZipEntry> candidates = new ArrayList<>();
            Enumeration<? extends ZipEntry> entries = zip.entries();
            while (entries.hasMoreElements()) {
                ZipEntry entry = entries.nextElement();
                if (!entry.isDirectory() &&
                    (entry.getName().equals("out/GTAV_Runtime_Package.zip") ||
                     entry.getName().endsWith("/GTAV_Runtime_Package.zip"))) {
                    candidates.add(entry);
                }
            }

            if (candidates.size() != 1) {
                throw new IOException("الملف المختار ليس GTAV_Runtime_Package.zip ولا Artifact يحتوي حزمة واحدة");
            }

            ZipEntry entry = candidates.get(0);
            listener.onProgress("EXTRACTING_INNER_PACKAGE", 3, 0, 0, entry.getName());
            try (InputStream raw = zip.getInputStream(entry);
                 BufferedInputStream in = new BufferedInputStream(raw, BUFFER);
                 BufferedOutputStream out = new BufferedOutputStream(new FileOutputStream(nested), BUFFER)) {
                byte[] buffer = new byte[BUFFER];
                long bytes = 0;
                int n;
                while ((n = in.read(buffer)) > 0) {
                    bytes += n;
                    if (bytes > MAX_PACKAGE) throw new IOException("الحزمة الداخلية أكبر من حد الأمان");
                    out.write(buffer, 0, n);
                }
            }
        }
        return nested;
    }

    private static JSONObject validateRootfs(File rootfs) throws Exception {
        JSONObject result = new JSONObject();
        org.json.JSONArray errors = new org.json.JSONArray();

        String[] required = {
            "lib/ld-linux-aarch64.so.1",
            "usr/local/bin/box64",
            "opt/gtav-runtime/config/wine-loader-path",
            "opt/gtav-runtime/config/wineserver-path",
            "opt/gtav-runtime/config/wineboot-relative-path"
        };

        for (String relative : required) {
            File file = new File(rootfs, relative);
            if (!file.exists()) errors.put("missing:" + relative);
        }

        File loader = new File(rootfs, "lib/ld-linux-aarch64.so.1");
        File box64 = new File(rootfs, "usr/local/bin/box64");
        if (loader.isFile && !isElfMachine(loader, 183)) errors.put("loader_not_aarch64");
        if (box64.isFile && !isElfMachine(box64, 183)) errors.put("box64_not_aarch64");

        result.put("valid", errors.length() == 0);
        result.put("errors", errors);
        result.put("rootfs_path", rootfs.getAbsolutePath());
        return result;
    }

    private static boolean isElfMachine(File file, int expected) {
        try (RandomAccessFile raf = new RandomAccessFile(file, "r")) {
            if (raf.length() < 20) return false;
            byte[] head = new byte[20];
            raf.readFully(head);
            if ((head[0] & 0xff) != 0x7f || head[1] != 'E' || head[2] != 'L' || head[3] != 'F') return false;
            int machine = (head[18] & 0xff) | ((head[19] & 0xff) << 8);
            return machine == expected;
        } catch (Exception e) {
            return false;
        }
    }

    private static String safeArchivePath(String input) throws IOException {
        String path = input.replace('\\', '/');
        if (path.startsWith("/") || path.contains("../") || path.equals("..")) {
            throw new IOException("مسار غير آمن داخل ZIP: " + input);
        }
        return path;
    }

    private static String safeTarPath(String input) throws IOException {
        String path = input.replace('\\', '/');
        while (path.startsWith("./")) path = path.substring(2);
        if (path.startsWith("/") || path.contains("../") || path.equals("..")) {
            throw new IOException("مسار غير آمن داخل TAR: " + input);
        }
        return path;
    }

    private static File safeTarget(File root, String relative) throws IOException {
        File target = new File(root, relative);
        String rootPath = root.getCanonicalPath() + File.separator;
        String targetPath = target.getCanonicalPath();
        if (!targetPath.startsWith(rootPath)) {
            throw new IOException("محاولة خروج من RootFS: " + relative);
        }
        return target;
    }

    private static String translateSymlink(File rootfs, File linkFile, String rawTarget) throws IOException {
        if (rawTarget == null || rawTarget.isEmpty()) throw new IOException("symlink target فارغ");
        if (!rawTarget.startsWith("/")) return rawTarget;

        String clean = safeTarPath(rawTarget.substring(1));
        File absoluteInsideRootfs = new File(rootfs, clean);
        File parent = linkFile.getParentFile();
        if (parent == null) return absoluteInsideRootfs.getAbsolutePath();

        try {
            return parent.toPath().relativize(absoluteInsideRootfs.toPath()).toString();
        } catch (Exception ex) {
            return absoluteInsideRootfs.getAbsolutePath();
        }
    }

    private static void chmod(File file, int mode, boolean directory) {
        boolean ownerRead = (mode & 0400) != 0;
        boolean ownerWrite = (mode & 0200) != 0;
        boolean ownerExec = (mode & 0100) != 0;
        file.setReadable(ownerRead, true);
        file.setWritable(ownerWrite, true);
        file.setExecutable(ownerExec || directory, true);
    }

    private static String readText(InputStream input, long maxBytes) throws IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buffer = new byte[64 * 1024];
        long total = 0;
        int n;
        while ((n = input.read(buffer)) > 0) {
            total += n;
            if (total > maxBytes) throw new IOException("النص أكبر من حد الأمان");
            out.write(buffer, 0, n);
        }
        return out.toString(StandardCharsets.UTF_8.name());
    }

    private static void writeText(File file, String text) throws IOException {
        File parent = file.getParentFile();
        if (parent != null) parent.mkdirs();
        try (FileOutputStream out = new FileOutputStream(file)) {
            out.write(text.getBytes(StandardCharsets.UTF_8));
        }
    }

    private static void copyFile(File source, File target) throws IOException {
        File parent = target.getParentFile();
        if (parent != null) parent.mkdirs();
        try (InputStream in = new FileInputStream(source);
             OutputStream out = new FileOutputStream(target)) {
            byte[] buffer = new byte[BUFFER];
            int n;
            while ((n = in.read(buffer)) > 0) out.write(buffer, 0, n);
        }
    }

    private static String hex(byte[] bytes) {
        StringBuilder out = new StringBuilder(bytes.length * 2);
        for (byte b : bytes) out.append(String.format(Locale.US, "%02x", b & 0xff));
        return out.toString();
    }

    public static void deleteRecursively(File file) {
        if (file == null || !file.exists()) return;
        if (file.isDirectory() && !Files.isSymbolicLink(file.toPath())) {
            File[] children = file.listFiles();
            if (children != null) {
                for (File child : children) deleteRecursively(child);
            }
        }
        file.delete();
    }
}
