plugins { id("com.android.application") }

android {
    namespace = "com.vx.runtime"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.vx.runtime"
        minSdk = 29
        targetSdk = 35
        versionCode = 202
        versionName = "202.0-runtime-importer-diagnostic"
        ndk { abiFilters += "arm64-v8a" }
        externalNativeBuild { cmake { cppFlags += listOf("-std=c++20", "-Wall", "-Wextra", "-Werror=return-type") } }
    }

    externalNativeBuild { cmake { path = file("src/main/cpp/CMakeLists.txt"); version = "3.22.1" } }
    buildTypes {
        debug { isMinifyEnabled = false }
        release { isMinifyEnabled = false }
    }
    packaging { jniLibs { useLegacyPackaging = true } }
}

dependencies {
    implementation("androidx.core:core:1.13.1")
    implementation("com.github.luben:zstd-jni:1.5.6-6@aar")
    implementation("org.apache.commons:commons-compress:1.26.2")
}
