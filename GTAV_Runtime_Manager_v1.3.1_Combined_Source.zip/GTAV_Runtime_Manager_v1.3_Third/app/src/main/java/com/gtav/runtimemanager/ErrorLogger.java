package com.gtav.runtimemanager;

import android.content.Context;
import java.io.File;
import java.io.FileWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

final class ErrorLogger {
    private static File file(Context c){return new File(c.getFilesDir(),"gtav_runtime_errors.log");}
    static synchronized void log(Context c,String operation,Throwable error){try(FileWriter w=new FileWriter(file(c),true)){w.write("["+new SimpleDateFormat("yyyy-MM-dd HH:mm:ss",Locale.US).format(new Date())+"] "+operation+"\n");w.write((error.getMessage()==null?error.getClass().getName():error.getMessage())+"\n\n");}catch(Exception ignored){}}
    static String read(Context c){try{return Files.readString(file(c).toPath(),StandardCharsets.UTF_8);}catch(Exception e){return "لا توجد أخطاء مسجلة.";}}
    static void clear(Context c){file(c).delete();}
}
