package com.gtav.runtimemanager;

import android.content.Context;
import android.system.Os;
import com.github.luben.zstd.ZstdInputStream;
import org.apache.commons.compress.archivers.tar.TarArchiveEntry;
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream;
import org.json.JSONObject;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

final class RuntimeInstaller {
    static InstallResult install(Context context, PackageReader reader, PackageInfo pkg,
                                 OperationProgress progress, boolean replace) throws Exception {
        long started = System.currentTimeMillis();
        File root = StorageLocations.runtimesRoot(context);
        File target = new File(root, safeId(pkg.manifest.runtimeId));
        File temp = new File(root, safeId(pkg.manifest.runtimeId) + ".installing");
        File backup = new File(root, safeId(pkg.manifest.runtimeId) + ".backup");
        FileTools.deleteTree(temp); FileTools.deleteTree(backup);
        if (target.exists() && !replace) throw new IOException("Runtime مثبت مسبقًا");
        if (!temp.mkdirs()) throw new IOException("تعذر إنشاء مجلد التثبيت المؤقت");

        long extractedBytes = 0, extractedNodes = 0;
        List<PendingHardLink> pendingHardLinks = new ArrayList<>();
        try (SeekableZipReader zip = reader.open(pkg.uri);
             InputStream payload = zip.openEntry(pkg.manifest.payload.path);
             CountingInputStream compressed = new CountingInputStream(new BufferedInputStream(payload, 1024 * 1024));
             ZstdInputStream zstd = new ZstdInputStream(compressed);
             TarArchiveInputStream tar = new TarArchiveInputStream(new BufferedInputStream(zstd, 1024 * 1024))) {

            TarArchiveEntry entry;
            byte[] buffer = new byte[1024 * 1024];
            while ((entry = tar.getNextTarEntry()) != null) {
                if (progress.isCancelled()) throw new CancelledException();
                String relative = RuntimeManifest.normalize(entry.getName());
                RuntimeManifest.validateRelative(relative);
                File out = safeChild(temp, relative);
                ensureParentsAreNotSymlinks(temp, out);
                String current = relative;

                if (entry.isDirectory()) {
                    if (!out.exists() && !out.mkdirs()) throw new IOException("تعذر إنشاء المجلد: " + relative);
                    chmod(out, entry.getMode());
                } else if (entry.isSymbolicLink()) {
                    File parent = out.getParentFile(); if (parent != null && !parent.exists() && !parent.mkdirs()) throw new IOException("تعذر إنشاء المجلد الأب");
                    if (out.exists() || Files.isSymbolicLink(out.toPath())) out.delete();
                    try { Os.symlink(entry.getLinkName(), out.getAbsolutePath()); }
                    catch (Exception e) { throw new IOException("تعذر إنشاء Symlink: " + relative + " → " + entry.getLinkName(), e); }
                } else if (entry.isLink()) {
                    String linkName = RuntimeManifest.normalize(entry.getLinkName());
                    RuntimeManifest.validateRelative(linkName);
                    File source = safeChild(temp, linkName);
                    File parent = out.getParentFile();
                    if (parent != null && !parent.exists() && !parent.mkdirs()) throw new IOException("تعذر إنشاء المجلد الأب");
                    if (source.exists()) {
                        try { Os.link(source.getAbsolutePath(), out.getAbsolutePath()); }
                        catch (Exception e) { throw new IOException("تعذر إنشاء Hard link: " + relative, e); }
                    } else {
                        pendingHardLinks.add(new PendingHardLink(out, source, relative));
                    }
                } else if (entry.isFile()) {
                    File parent = out.getParentFile(); if (parent != null && !parent.exists() && !parent.mkdirs()) throw new IOException("تعذر إنشاء المجلد الأب");
                    try (OutputStream output = new BufferedOutputStream(new FileOutputStream(out), 1024 * 1024)) {
                        int n; while ((n = tar.read(buffer)) != -1) {
                            if (progress.isCancelled()) throw new CancelledException();
                            output.write(buffer, 0, n); extractedBytes += n;
                            progress.update("فك ضغط Zstandard واستخراج RootFS", extractedBytes,
                                    Math.max(pkg.manifest.expectedExtractedBytes, extractedBytes), current, started);
                        }
                    }
                    chmod(out, entry.getMode());
                }
                extractedNodes++;
                progress.update("استخراج RootFS", extractedBytes,
                        Math.max(pkg.manifest.expectedExtractedBytes, extractedBytes), current, started);
            }
            for (PendingHardLink link : pendingHardLinks) {
                if (progress.isCancelled()) throw new CancelledException();
                if (!link.source.exists()) throw new IOException("تعذر إنشاء Hard link؛ الهدف مفقود: " + link.relative);
                ensureParentsAreNotSymlinks(temp, link.output);
                try { Os.link(link.source.getAbsolutePath(), link.output.getAbsolutePath()); }
                catch (Exception e) { throw new IOException("تعذر إنشاء Hard link مؤجل: " + link.relative, e); }
            }
        } catch (Exception e) {
            FileTools.deleteTree(temp);
            throw e;
        }

        if (!pkg.manifest.rootfsFiles.isEmpty() && extractedNodes < pkg.manifest.rootfsFiles.size()) {
            FileTools.deleteTree(temp);
            throw new IOException("تعذر إكمال الاستخراج: عدد العناصر المستخرجة أقل من Manifest");
        }

        progress.update("التحقق من الملفات الأساسية", 0, 1, "", started);
        VerificationResult post = verifyInstalled(temp, pkg.manifest);
        if (!post.ok) { FileTools.deleteTree(temp); throw new IOException(post.message); }

        PackageInfo currentPackage = reader.read(pkg.uri);
        if (currentPackage.zipSize != pkg.zipSize ||
                (pkg.modifiedAt >= 0 && currentPackage.modifiedAt >= 0 && currentPackage.modifiedAt != pkg.modifiedAt)) {
            FileTools.deleteTree(temp);
            throw new IOException("تغيرت الحزمة أثناء التثبيت");
        }

        JSONObject state = new JSONObject();
        state.put("runtime_id", pkg.manifest.runtimeId); state.put("version", pkg.manifest.version);
        state.put("schema", pkg.manifest.schema); state.put("installed_at", isoNow());
        state.put("rootfs_path", target.getAbsolutePath()); state.put("payload_sha256", pkg.manifest.payload.sha256);
        state.put("install_state", "complete"); state.put("file_count", extractedNodes);
        state.put("installed_size_bytes", FileTools.size(temp)); state.put("source_uri", pkg.uri.toString());
        writeText(new File(temp, "installed_runtime.json"), state.toString(2));
        writeText(new File(temp, "runtime_manifest.json"), pkg.manifest.rawJson);

        if (target.exists()) {
            if (!target.renameTo(backup)) { FileTools.deleteTree(temp); throw new IOException("تعذر تجهيز إعادة التثبيت الذرية"); }
        }
        if (!temp.renameTo(target)) {
            if (backup.exists()) backup.renameTo(target);
            FileTools.deleteTree(temp); throw new IOException("تعذر إنهاء التثبيت الذري");
        }
        FileTools.deleteTree(backup);
        progress.update("إنهاء التثبيت", 1, 1, "", started);
        return new InstallResult(target, FileTools.size(target), extractedNodes, started, System.currentTimeMillis());
    }

    static VerificationResult verifyInstalled(File target, RuntimeManifest manifest) {
        if (!target.exists()) return new VerificationResult(false, "Runtime غير مثبت");
        Set<String> paths = new HashSet<>();
        paths.add(RuntimeManifest.normalize(manifest.entryPoints.wine64));
        paths.add(RuntimeManifest.normalize(manifest.entryPoints.wineboot));
        paths.add(RuntimeManifest.normalize(manifest.entryPoints.wineserver));
        for (RuntimeManifest.RootfsFile f : manifest.requiredFiles()) paths.add(f.path);
        for (String p : paths) {
            if (p == null || p.isEmpty()) continue;
            try {
                File f = safeChild(target, p);
                if (!f.exists() && !Files.isSymbolicLink(f.toPath())) return new VerificationResult(false, "ملف أساسي مفقود: /" + p);
                if ((p.endsWith(".sh") || p.contains("/bin/")) && f.isFile() && !f.canExecute()) return new VerificationResult(false, "صلاحية التنفيذ مفقودة: /" + p);
            } catch (Exception e) { return new VerificationResult(false, e.getMessage()); }
        }
        for (RuntimeManifest.RootfsFile f : manifest.requiredFiles()) {
            if ("symlink".equals(f.type)) {
                try { File link=safeChild(target,f.path); if(!Files.isSymbolicLink(link.toPath())) return new VerificationResult(false,"Symlink أساسي مفقود: /"+f.path); }
                catch(Exception e){return new VerificationResult(false,e.getMessage());}
            }
        }
        return new VerificationResult(true, "الملفات الأساسية والروابط والصلاحيات سليمة");
    }

    static void cleanupInterrupted(Context c) {
        File root=StorageLocations.runtimesRoot(c);File[]files=root.listFiles();if(files!=null)for(File f:files)if(f.getName().endsWith(".installing")||f.getName().endsWith(".backup"))FileTools.deleteTree(f);
    }
    private static File safeChild(File root,String relative)throws IOException{RuntimeManifest.validateRelative(relative);File out=new File(root,relative);String base=root.getCanonicalPath()+File.separator;String child=out.getCanonicalPath();if(!child.startsWith(base)&&!child.equals(root.getCanonicalPath()))throw new IOException("مسار TAR غير آمن: "+relative);return out;}
    private static void ensureParentsAreNotSymlinks(File root, File output) throws IOException {
        File parent = output.getParentFile();
        while (parent != null && !parent.equals(root)) {
            if (Files.isSymbolicLink(parent.toPath())) throw new IOException("مسار TAR يمر عبر Symlink: " + output.getPath());
            parent = parent.getParentFile();
        }
    }
    private static void chmod(File f,int mode)throws IOException{if(mode<=0)return;try{Os.chmod(f.getAbsolutePath(),mode);}catch(Exception e){throw new IOException("تعذر ضبط صلاحيات Unix: "+f.getAbsolutePath(),e);}}
    private static void writeText(File f,String text)throws IOException{try(OutputStream out=new FileOutputStream(f)){out.write(text.getBytes(StandardCharsets.UTF_8));}}
    private static String safeId(String id){return id.replaceAll("[^A-Za-z0-9._-]","_");}
    private static String isoNow(){return new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssXXX", Locale.US).format(new Date());}
    private static final class PendingHardLink {
        final File output; final File source; final String relative;
        PendingHardLink(File output, File source, String relative) { this.output=output; this.source=source; this.relative=relative; }
    }
    static final class InstallResult{final File path;final long size,nodes,started,finished;InstallResult(File p,long s,long n,long st,long f){path=p;size=s;nodes=n;started=st;finished=f;}}
    static final class VerificationResult{final boolean ok;final String message;VerificationResult(boolean o,String m){ok=o;message=m;}}
    static final class CancelledException extends IOException{CancelledException(){super("انقطع التثبيت: ألغى المستخدم العملية");}}
}
