package com.gtav.runtimemanager;

import java.io.*;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.channels.FileChannel;
import java.nio.charset.StandardCharsets;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.zip.Inflater;
import java.util.zip.InflaterInputStream;

final class SeekableZipReader implements Closeable {
    private static final int EOCD=0x06054b50,CENTRAL=0x02014b50,LOCAL=0x04034b50,MAX_TAIL=65557;
    private final FileInputStream input; private final FileChannel channel;
    private final Map<String,ZipEntryRecord> entries=new LinkedHashMap<>();
    SeekableZipReader(FileInputStream input)throws IOException{this.input=input;channel=input.getChannel();parse();}
    Map<String,ZipEntryRecord> entries(){return entries;}
    ZipEntryRecord get(String name){return entries.get(RuntimeManifest.normalize(name));}
    boolean contains(String name){return get(name)!=null;}
    byte[] readEntry(String name,int max)throws IOException{try(InputStream in=openEntry(name)){ByteArrayOutputStream out=new ByteArrayOutputStream();byte[]b=new byte[8192];int total=0,n;while((n=in.read(b))!=-1){total+=n;if(total>max)throw new IOException("ملف JSON أكبر من الحد الآمن");out.write(b,0,n);}return out.toByteArray();}}
    InputStream openEntry(String name)throws IOException{
        ZipEntryRecord e=get(name);if(e==null)throw new IOException("الملف غير موجود داخل ZIP: "+name);
        ByteBuffer local=readAt(e.localHeaderOffset,30);if(u32(local,0)!=LOCAL)throw new IOException("Local ZIP header غير صالح");
        int nameLen=u16(local,26),extraLen=u16(local,28);long dataOffset=e.localHeaderOffset+30L+nameLen+extraLen;
        channel.position(dataOffset);InputStream bounded=new BoundedInputStream(input,e.compressedSize);
        if(e.method==0)return bounded;if(e.method==8)return new InflaterInputStream(bounded,new Inflater(true),1024*1024);
        throw new IOException("طريقة ضغط ZIP غير مدعومة: "+e.method);
    }
    private void parse()throws IOException{
        long size=channel.size();if(size<22||size>0xffffffffL)throw new IOException("ZIP64 غير مدعوم في هذا الإصدار");
        int tailSize=(int)Math.min(size,MAX_TAIL);ByteBuffer tail=readAt(size-tailSize,tailSize);int eocd=findBackward(tail,EOCD);
        if(eocd<0)throw new IOException("Central Directory غير موجود");int total=u16(tail,eocd+10);long cdSize=u32(tail,eocd+12),cdOffset=u32(tail,eocd+16);
        if(total==0xffff||cdSize==0xffffffffL||cdOffset==0xffffffffL)throw new IOException("ZIP64 غير مدعوم");
        ByteBuffer cd=readAt(cdOffset,(int)cdSize);int p=0;
        for(int i=0;i<total;i++){
            if(p+46>cd.limit()||u32(cd,p)!=CENTRAL)throw new IOException("Central Directory تالف");
            int flags=u16(cd,p+8),method=u16(cd,p+10);if((flags&1)!=0)throw new IOException("ZIP المشفر غير مدعوم");
            long compressed=u32(cd,p+20),uncompressed=u32(cd,p+24),offset=u32(cd,p+42);
            int nl=u16(cd,p+28),el=u16(cd,p+30),cl=u16(cd,p+32);if(p+46+nl+el+cl>cd.limit())throw new IOException("Central Directory مبتور");
            byte[]nb=new byte[nl];ByteBuffer copy=cd.duplicate();copy.position(p+46);copy.get(nb);String name=RuntimeManifest.normalize(new String(nb,StandardCharsets.UTF_8));RuntimeManifest.validateRelative(name);
            entries.put(name,new ZipEntryRecord(name,method,compressed,uncompressed,offset));p+=46+nl+el+cl;
        }
    }
    private ByteBuffer readAt(long o,int s)throws IOException{ByteBuffer b=ByteBuffer.allocate(s).order(ByteOrder.LITTLE_ENDIAN);channel.position(o);while(b.hasRemaining())if(channel.read(b)<0)throw new EOFException();b.flip();return b;}
    private static int findBackward(ByteBuffer b,int sig){for(int i=b.limit()-4;i>=0;i--)if(u32(b,i)==sig)return i;return-1;}
    private static int u16(ByteBuffer b,int p){return Short.toUnsignedInt(b.getShort(p));}private static long u32(ByteBuffer b,int p){return Integer.toUnsignedLong(b.getInt(p));}
    @Override public void close()throws IOException{input.close();}
}
