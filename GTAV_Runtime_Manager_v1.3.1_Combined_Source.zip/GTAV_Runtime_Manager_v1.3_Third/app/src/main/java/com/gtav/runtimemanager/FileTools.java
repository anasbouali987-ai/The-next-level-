package com.gtav.runtimemanager;

import java.io.File;

final class FileTools {
    static void deleteTree(File f){if(f==null||!f.exists())return;File[]children=f.listFiles();if(children!=null)for(File c:children)deleteTree(c);f.delete();}
    static long size(File f){if(f==null||!f.exists())return 0;if(f.isFile())return f.length();long s=0;File[]c=f.listFiles();if(c!=null)for(File x:c)s+=size(x);return s;}
    static long count(File f){if(f==null||!f.exists())return 0;if(f.isFile())return 1;long n=1;File[]c=f.listFiles();if(c!=null)for(File x:c)n+=count(x);return n;}
}
