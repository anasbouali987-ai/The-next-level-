package com.gtav.runtimemanager;

import org.json.JSONObject;
import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;

final class InstalledRuntime {
    final File path; final String runtimeId,version,installedAt,payloadSha; final int schema; final long size,fileCount;
    InstalledRuntime(File p,String id,String v,String at,String sha,int schema,long size,long count){path=p;runtimeId=id;version=v;installedAt=at;payloadSha=sha;this.schema=schema;this.size=size;fileCount=count;}
    static InstalledRuntime find(File root,String runtimeId){File p=new File(root,runtimeId.replaceAll("[^A-Za-z0-9._-]","_"));File state=new File(p,"installed_runtime.json");if(!state.isFile())return null;
        try{JSONObject o=new JSONObject(Files.readString(state.toPath(), StandardCharsets.UTF_8));if(!"complete".equals(o.optString("install_state")))return null;return new InstalledRuntime(p,o.optString("runtime_id"),o.optString("version"),o.optString("installed_at"),o.optString("payload_sha256"),o.optInt("schema",-1),FileTools.size(p),o.optLong("file_count",FileTools.count(p)));}catch(Exception e){return null;}}
}
