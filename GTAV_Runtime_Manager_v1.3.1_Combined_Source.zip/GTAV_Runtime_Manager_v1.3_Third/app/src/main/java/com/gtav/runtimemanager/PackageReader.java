package com.gtav.runtimemanager;

import android.content.ContentResolver;
import android.database.Cursor;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.provider.DocumentsContract;
import android.provider.OpenableColumns;
import org.json.JSONObject;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;

final class PackageReader {
    private static final int MAX_JSON=32*1024*1024;
    private final ContentResolver resolver;
    PackageReader(ContentResolver resolver){this.resolver=resolver;}
    PackageInfo read(Uri uri)throws Exception{
        Meta meta=meta(uri);
        try(ParcelFileDescriptor pfd=resolver.openFileDescriptor(uri,"r")){
            if(pfd==null)throw new IOException("تعذر فتح الحزمة");
            try(SeekableZipReader zip=new SeekableZipReader(new FileInputStream(pfd.getFileDescriptor()))){
                if(!zip.contains("runtime_manifest.json"))throw new IOException("runtime_manifest.json غير موجود");
                String raw=new String(zip.readEntry("runtime_manifest.json",MAX_JSON),StandardCharsets.UTF_8);
                RuntimeManifest m=new RuntimeManifest(new JSONObject(raw),pretty(raw));validate(m,zip);
                String report=zip.contains("build_report.json")?new String(zip.readEntry("build_report.json",MAX_JSON),StandardCharsets.UTF_8):"";
                return new PackageInfo(uri,meta.name,meta.size,meta.modified,m,zip.get(m.payload.path).uncompressedSize,zip.entries().size(),report);
            }
        }
    }
    SeekableZipReader open(Uri uri)throws Exception{
        ParcelFileDescriptor pfd=resolver.openFileDescriptor(uri,"r");if(pfd==null)throw new IOException("تعذر فتح الحزمة");
        return new SeekableZipReader(new FileInputStream(pfd.getFileDescriptor()));
    }
    private static void validate(RuntimeManifest m,SeekableZipReader zip)throws IOException{
        if(m.schema!=3)throw new IOException("Schema غير مدعوم: "+m.schema);
        if(!"arm64".equalsIgnoreCase(m.host)||!"x86_64".equalsIgnoreCase(m.guest))throw new IOException("المعمارية غير متوافقة");
        if(!"tar+zstd".equalsIgnoreCase(m.payload.format))throw new IOException("صيغة Payload غير مدعومة");
        if(!m.payload.sha256.matches("[0-9a-f]{64}"))throw new IOException("SHA-256 المسجل غير صالح");
        if(!zip.contains(m.payload.path))throw new IOException("Payload غير موجود: "+m.payload.path);
        if(zip.get(m.payload.path).uncompressedSize!=m.payload.sizeBytes)throw new IOException("حجم Payload لا يطابق Manifest");
    }
    private Meta meta(Uri uri){String name="Runtime.zip";long size=-1,modified=-1;
        try(Cursor c=resolver.query(uri,null,null,null,null)){
            if(c!=null&&c.moveToFirst()){int a=c.getColumnIndex(OpenableColumns.DISPLAY_NAME),b=c.getColumnIndex(OpenableColumns.SIZE),d=c.getColumnIndex(DocumentsContract.Document.COLUMN_LAST_MODIFIED);if(a>=0&&!c.isNull(a))name=c.getString(a);if(b>=0&&!c.isNull(b))size=c.getLong(b);if(d>=0&&!c.isNull(d))modified=c.getLong(d);}
        }catch(Exception ignored){}return new Meta(name,size,modified);}
    private static String pretty(String raw){try{return new JSONObject(raw).toString(2);}catch(Exception e){return raw;}}
    private static final class Meta{final String name;final long size,modified;Meta(String n,long s,long m){name=n;size=s;modified=m;}}
}
