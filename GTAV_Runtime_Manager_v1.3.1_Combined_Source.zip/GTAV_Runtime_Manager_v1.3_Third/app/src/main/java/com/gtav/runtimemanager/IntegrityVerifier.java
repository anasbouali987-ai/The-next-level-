package com.gtav.runtimemanager;

import java.io.InputStream;
import java.security.MessageDigest;

final class IntegrityVerifier {
    static Result verify(PackageReader reader,PackageInfo p,OperationProgress progress)throws Exception{
        long started=System.currentTimeMillis();MessageDigest digest=MessageDigest.getInstance("SHA-256");long done=0;
        try(SeekableZipReader zip=reader.open(p.uri);InputStream in=zip.openEntry(p.manifest.payload.path)){
            byte[]buffer=new byte[1024*1024];int n;while((n=in.read(buffer))!=-1){if(progress.isCancelled())return new Result(false,true,"",done,started,System.currentTimeMillis());digest.update(buffer,0,n);done+=n;progress.update("التحقق من SHA-256",done,p.manifest.payload.sizeBytes,p.manifest.payload.path,started);}
        }
        String calculated=hex(digest.digest());return new Result(calculated.equalsIgnoreCase(p.manifest.payload.sha256),false,calculated,done,started,System.currentTimeMillis());
    }
    private static String hex(byte[]b){StringBuilder s=new StringBuilder(64);for(byte v:b)s.append(String.format("%02x",v));return s.toString();}
    static final class Result{final boolean match,cancelled;final String calculated;final long bytes,started,finished;Result(boolean m,boolean c,String h,long b,long s,long f){match=m;cancelled=c;calculated=h;bytes=b;started=s;finished=f;}}
}
