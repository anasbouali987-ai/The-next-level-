package com.gtav.runtimemanager;

import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;

final class RuntimeManifest {
    final int schema;
    final String runtimeId, version, host, guest, libc, integration, rawJson;
    final Payload payload;
    final Components components;
    final EntryPoints entryPoints;
    final List<RootfsFile> rootfsFiles;
    final long expectedExtractedBytes;

    RuntimeManifest(JSONObject root, String rawJson) {
        this.rawJson = rawJson;
        schema = root.optInt("schema_version", -1);
        runtimeId = root.optString("runtime_id", ""); version = root.optString("version", "");
        host = root.optString("host_architecture", ""); guest = root.optString("guest_architecture", "");
        libc = root.optString("libc_model", ""); integration = root.optString("android_integration_model", "");
        JSONObject p = root.optJSONObject("rootfs_payload");
        if (p == null) throw new IllegalArgumentException("rootfs_payload غير موجود في Manifest");
        payload = new Payload(normalize(p.optString("path", "")), p.optString("format", ""),
                p.optString("sha256", "").toLowerCase(), p.optLong("size_bytes", -1));
        JSONObject c = root.optJSONObject("components");
        components = new Components(value(c,"box64"), value(c,"wine"), value(c,"dxvk"), value(c,"debian"));
        JSONObject e = root.optJSONObject("entrypoints");
        entryPoints = new EntryPoints(value(e,"wine64"), value(e,"wineboot"), value(e,"wineserver"));
        rootfsFiles = new ArrayList<>(); long sum = 0;
        JSONArray arr = root.optJSONArray("rootfs_files");
        if (arr != null) for (int i=0;i<arr.length();i++) {
            JSONObject f = arr.optJSONObject(i); if (f == null) continue;
            RootfsFile rf = new RootfsFile(normalize(f.optString("path","")), f.optString("type","file"),
                    f.optString("link_target", ""), f.optInt("mode", 0), f.optLong("size_bytes",0),
                    f.optString("sha256", ""), f.optBoolean("required", false), f.optString("component", "support"));
            rootfsFiles.add(rf); if ("file".equals(rf.type) && rf.sizeBytes > 0) sum += rf.sizeBytes;
        }
        expectedExtractedBytes = sum;
    }

    List<RootfsFile> requiredFiles() {
        List<RootfsFile> out = new ArrayList<>();
        for (RootfsFile f : rootfsFiles) if (f.required) out.add(f);
        return out;
    }
    static String normalize(String n) { String s=n==null?"":n.replace('\\','/'); while(s.startsWith("./"))s=s.substring(2); while(s.startsWith("/"))s=s.substring(1); return s; }
    static void validateRelative(String n) { String s=normalize(n); if(s.isEmpty()||s.equals("..")||s.startsWith("../")||s.contains("/../")) throw new IllegalArgumentException("مسار غير آمن: "+n); }
    private static String value(JSONObject o,String k){return o==null?"":o.optString(k,"");}
    static final class Payload { final String path,format,sha256; final long sizeBytes; Payload(String p,String f,String h,long s){path=p;format=f;sha256=h;sizeBytes=s;} }
    static final class Components { final String box64,wine,dxvk,debian; Components(String b,String w,String d,String de){box64=b;wine=w;dxvk=d;debian=de;} }
    static final class EntryPoints { final String wine64,wineboot,wineserver; EntryPoints(String a,String b,String c){wine64=a;wineboot=b;wineserver=c;} }
    static final class RootfsFile {
        final String path,type,linkTarget,sha256,component; final int mode; final long sizeBytes; final boolean required;
        RootfsFile(String p,String t,String l,int m,long s,String h,boolean r,String c){path=p;type=t;linkTarget=l;mode=m;sizeBytes=s;sha256=h;required=r;component=c;}
    }
}
