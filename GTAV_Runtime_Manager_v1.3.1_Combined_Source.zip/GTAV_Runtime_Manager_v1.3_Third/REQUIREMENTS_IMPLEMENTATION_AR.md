# مطابقة متطلبات GTAV Runtime Manager v1.3

- التحقق المتدفق SHA-256: `IntegrityVerifier.java`
- حفظ نتيجة التحقق وإبطالها عند تغير URI/الحجم/وقت التعديل: `VerificationStore.java`
- شاشة تقدم وإلغاء وسرعة ووقت متبقٍ: `MainActivity.java`
- فحص المساحة وهامش 25%: `MainActivity.requiredSpace`
- Zstandard ثم TAR: `RuntimeInstaller.java`
- Unix modes وSymlinks وHard links: `RuntimeInstaller.java` باستخدام `android.system.Os`
- منع Path Traversal: `RuntimeManifest.validateRelative` و`RuntimeInstaller.safeChild`
- التثبيت الذري `.installing` ونسخة احتياطية عند إعادة التثبيت: `RuntimeInstaller.java`
- تنظيف التثبيت المنقطع: `RuntimeInstaller.cleanupInterrupted`
- التحقق من Entry Points والملفات required: `RuntimeInstaller.verifyInstalled`
- إدارة التثبيت وإعادة التثبيت والحذف وإعادة الفحص: `MainActivity.java`
- حالة التثبيت وملف `installed_runtime.json`: `InstalledRuntime.java` و`RuntimeInstaller.java`
- التقارير وManifest الخام وسجل الأخطاء: `MainActivity.java` و`ErrorLogger.java`
- إعدادات موقع التخزين والتنظيف ومعلومات التطبيق: `StorageLocations.java` و`MainActivity.settings`
- لا توجد طبقة تشغيل PRoot/Box64/Wine/DXVK/Vulkan/EXE/Games في هذا الإصدار.
