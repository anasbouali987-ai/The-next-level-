package com.vx.runtime;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.database.Cursor;
import androidx.core.content.FileProvider;
import android.widget.Button;
import android.widget.TextView;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;
import org.json.JSONObject;

public final class MainActivity extends Activity {
    private static final int PICK_RUNTIME = 2010;
    static { System.loadLibrary("vxdiagnostic"); }
    private native String nativeRunDiagnostics(String filesDir, String nativeLibraryDir, String reportDir);

    private TextView runtimeStatus;
    private TextView output;
    private Button importButton;
    private Button runButton;
    private Button shareButton;
    private File bundleFile;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        setContentView(R.layout.activity_main);
        runtimeStatus = findViewById(R.id.runtimeStatus);
        output = findViewById(R.id.output);
        importButton = findViewById(R.id.importRuntimeButton);
        runButton = findViewById(R.id.runButton);
        shareButton = findViewById(R.id.shareButton);

        importButton.setOnClickListener(v -> chooseRuntime());
        runButton.setOnClickListener(v -> runDiagnostics());
        shareButton.setOnClickListener(v -> shareReport());
        refreshRuntimeStatus();
    }

    private void chooseRuntime() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("application/zip");
        intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{
            "application/zip", "application/octet-stream", "application/x-zip-compressed"
        });
        startActivityForResult(intent, PICK_RUNTIME);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != PICK_RUNTIME || resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        try {
            getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
        } catch (Exception ignored) { }
        installSelectedRuntime(uri);
    }

    private void installSelectedRuntime(Uri uri) {
        setBusy(true);
        String name = displayName(uri);
        output.setText("تم اختيار الملف:\n" + name + "\n\nبدء نسخ الحزمة والتحقق منها…");
        new Thread(() -> {
            try {
                String result = RuntimeImportBridge.install(this, uri, (phase, nodes, bytes, path) -> {
                    String message = "المرحلة: " + phase
                        + "\nالعناصر: " + nodes
                        + "\nالبيانات: " + humanBytes(bytes)
                        + "\nالملف: " + path;
                    runOnUiThread(() -> output.setText(message));
                });
                runOnUiThread(() -> {
                    output.setText("تم تثبيت Runtime بنجاح ✅\n\n" + result);
                    refreshRuntimeStatus();
                    setBusy(false);
                });
            } catch (Throwable error) {
                runOnUiThread(() -> {
                    output.setText("فشل تثبيت Runtime ❌\n\n" + error.getClass().getSimpleName() + ": " + error.getMessage());
                    refreshRuntimeStatus();
                    setBusy(false);
                });
            }
        }, "vx201-runtime-import").start();
    }

    private void refreshRuntimeStatus() {
        try {
            JSONObject info = RuntimeStore.inspect(this);
            boolean installed = info.optBoolean("installed");
            runtimeStatus.setText(
                "Package: " + getPackageName()
                + "\nRuntime: " + (installed ? "DETECTED ✅" : "NOT FOUND")
                + "\nPath: " + info.optString("rootfs_path")
                + (info.optString("runtime_version").isEmpty() ? "" : "\nVersion: " + info.optString("runtime_version"))
            );
            runButton.setEnabled(installed);
        } catch (Exception error) {
            runtimeStatus.setText("تعذر فحص Runtime:\n" + error);
            runButton.setEnabled(false);
        }
    }

    private void setBusy(boolean busy) {
        importButton.setEnabled(!busy);
        runButton.setEnabled(!busy && RuntimeStore.inspect(this).optBoolean("installed"));
        shareButton.setEnabled(!busy && bundleFile != null && bundleFile.isFile());
    }

    private void runDiagnostics() {
        setBusy(true);
        output.setText("Preparing VX 201 diagnostics…\n");
        new Thread(() -> {
            try {
                File base = new File(getFilesDir(), "diagnostic-v2");
                File bin = new File(base, "bin");
                File reports = new File(base, "reports");
                File shared = new File(getCacheDir(), "vx201-share");
                ensureDir(bin); ensureDir(reports); ensureDir(shared);
                extractAsset("diagnostic/hello_static", new File(bin, "hello_static"));
                extractAsset("diagnostic/hello_dynamic_glibc", new File(bin, "hello_dynamic_glibc"));
                extractAsset("diagnostic/hello_x86_64", new File(bin, "hello_x86_64"));

                long started = System.currentTimeMillis();
                String json = nativeRunDiagnostics(getFilesDir().getAbsolutePath(), getApplicationInfo().nativeLibraryDir, reports.getAbsolutePath());
                File jsonFile = new File(reports, "vx_diagnostic_report.json");
                File txtFile = new File(reports, "vx_diagnostic_report.txt");
                File logFile = new File(reports, "android_logcat_best_effort.txt");
                write(jsonFile, json);
                write(txtFile, buildTextSummary(json));
                write(logFile, collectOwnLogcat(started));

                String stamp = new SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(new Date());
                bundleFile = new File(shared, "vx_runtime_diagnostic_" + stamp + ".zip");
                zip(bundleFile, jsonFile, txtFile, logFile);
                runOnUiThread(() -> { output.setText(json); setBusy(false); shareButton.setEnabled(true); });
            } catch (Exception ex) {
                runOnUiThread(() -> { output.setText("Diagnostic controller failed:\n" + ex); setBusy(false); });
            }
        }, "vx201-diagnostics").start();
    }

    private String displayName(Uri uri) {
        try (Cursor cursor = getContentResolver().query(uri, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null)) {
            if (cursor != null && cursor.moveToFirst()) return cursor.getString(0);
        } catch (Exception ignored) { }
        return uri.toString();
    }

    private static String humanBytes(long bytes) {
        if (bytes < 1024) return bytes + " B";
        double value = bytes;
        String[] units = {"KiB", "MiB", "GiB"};
        int index = -1;
        do { value /= 1024.0; index++; } while (value >= 1024 && index < units.length - 1);
        return String.format(Locale.US, "%.2f %s", value, units[index]);
    }

    private static void ensureDir(File dir) throws IOException {
        if (!dir.mkdirs() && !dir.isDirectory()) throw new IOException("Cannot create " + dir);
    }

    private void extractAsset(String asset, File out) throws IOException {
        try (InputStream in = getAssets().open(asset); FileOutputStream fos = new FileOutputStream(out)) {
            byte[] buffer = new byte[65536]; int n; while ((n = in.read(buffer)) > 0) fos.write(buffer, 0, n);
        }
        if (!out.setReadable(true, true) || !out.setExecutable(true, true)) throw new IOException("chmod failed: " + out);
    }

    private String collectOwnLogcat(long startedMs) {
        StringBuilder result = new StringBuilder();
        result.append("Best-effort app-visible logcat only. This does not imply access to tombstones, si_code, si_syscall, or complete system logs.\n");
        Process process = null;
        try {
            process = new ProcessBuilder("logcat", "-d", "--pid=" + android.os.Process.myPid(), "-v", "threadtime", "-t", "800").redirectErrorStream(true).start();
            try (BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream(), StandardCharsets.UTF_8))) {
                String line; while ((line = reader.readLine()) != null) result.append(line).append('\n');
            }
            process.waitFor();
        } catch (Exception ex) {
            result.append("LOGCAT_UNAVAILABLE: ").append(ex).append('\n');
            if (process != null) process.destroy();
        }
        result.append("collection_started_epoch_ms=").append(startedMs).append('\n');
        return result.toString();
    }

    private static String buildTextSummary(String json) {
        return "VX 201 Runtime Diagnostic v2\nThe JSON below is authoritative. Android log collection is best-effort only.\n\n" + json;
    }

    private static void write(File file, String text) throws IOException {
        try (FileOutputStream out = new FileOutputStream(file)) { out.write(text.getBytes(StandardCharsets.UTF_8)); }
    }

    private static void zip(File zip, File... files) throws IOException {
        try (ZipOutputStream out = new ZipOutputStream(new FileOutputStream(zip))) {
            byte[] buffer = new byte[65536];
            for (File file : files) {
                out.putNextEntry(new ZipEntry(file.getName()));
                try (InputStream in = new FileInputStream(file)) { int n; while ((n = in.read(buffer)) > 0) out.write(buffer, 0, n); }
                out.closeEntry();
            }
        }
    }

    private void shareReport() {
        if (bundleFile == null || !bundleFile.isFile()) return;
        Uri uri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", bundleFile);
        Intent intent = new Intent(Intent.ACTION_SEND);
        intent.setType("application/zip");
        intent.putExtra(Intent.EXTRA_STREAM, uri);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        startActivity(Intent.createChooser(intent, "Share VX 201 diagnostic bundle"));
    }
}
