package com.vx.runtime

import android.content.Context
import android.net.Uri

object RuntimeImportBridge {
    interface Listener {
        fun onProgress(phase: String, nodes: Int, bytes: Long, path: String)
    }

    @JvmStatic
    fun install(context: Context, uri: Uri, listener: Listener): String {
        return RuntimeInstaller.install(context, uri) { p ->
            listener.onProgress(p.phase, p.nodes, p.bytes, p.path)
        }.toString(2)
    }
}
