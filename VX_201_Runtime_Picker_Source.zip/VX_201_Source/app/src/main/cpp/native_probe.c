#include <unistd.h>
int main(void){static const char m[]="VX201_ANDROID_NATIVE_OK\n";write(1,m,sizeof(m)-1);_exit(0);}
