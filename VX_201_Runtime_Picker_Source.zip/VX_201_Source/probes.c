#include <unistd.h>
#ifndef PROBE_TEXT
#define PROBE_TEXT "VX201_PROBE_OK\n"
#endif
int main(void){static const char m[]=PROBE_TEXT; return write(1,m,sizeof(m)-1)==(ssize_t)(sizeof(m)-1)?0:2;}
