# VX 201 — Runtime Diagnostic v2

Package: `com.vx.runtime`  
Version code: `201`  
Version name: `201.1-diagnostic-v2`

VX 201 is an evidence-first Android runtime diagnostic. It preserves the installed runtime and stops after the first failed stage.

## Major behavior

- Native JNI controller owns `pipe2(O_CLOEXEC)`, `fork`, `execve`, `poll`, timeout handling, and `waitpid`.
- stdout and stderr are drained concurrently to avoid pipe deadlocks.
- Timeout escalation is `SIGTERM`, 1.5-second grace period, then `SIGKILL`.
- Stage 2 validates both sides of the protocol:
  - successful exec gives CLOEXEC EOF;
  - deliberate missing executable returns exact `ENOENT` in `ChildError`.
- Stage 3 runs an app-owned Android PIE executable from `nativeLibraryDir`.
- ELF evidence includes SHA-256, ownership, mode, location classification, SELinux context when readable, class, machine, entry point, `PT_INTERP`, and host/rootfs interpreter resolution.
- Explicit-loader stages report launcher, target, and guest ELF objects separately.
- Wine and wineserver paths are read from runtime config files when present, with conservative fallbacks.
- The share button sends a ZIP via FileProvider containing JSON, text, and best-effort app-visible logcat.

## Important Android limitations

The probes extracted to `files/diagnostic-v2/bin` intentionally reveal whether Android permits execution from the writable app directory. A failure there is recorded as location evidence and must not automatically be blamed on the probe binary.

App-visible logcat does not guarantee access to tombstones, `si_code`, `si_syscall`, or complete system crash records. VX 201 never treats logcat absence as proof for or against seccomp.

## Signing

An APK can update the existing `com.vx.runtime` installation only when signed by the exact same certificate. The workflow supports repository secrets:

- `VX_KEYSTORE_BASE64`
- `VX_KEYSTORE_PASSWORD`
- `VX_KEY_ALIAS`
- `VX_KEY_PASSWORD`

Without those secrets, the workflow emits a debug-signed APK for fresh/debug-compatible installation and an unsigned release APK. It does not claim either can update an installation signed by another key.

## Runtime file picker (201.2)
VX 201 now lets the user choose `GTAV_Runtime_Package.zip` or a GitHub artifact ZIP containing it through Android's system file picker. The installer verifies `runtime_manifest.json`, SHA-256 of `payload/rootfs.tar.zst`, safely extracts TAR/Zstandard content including symlinks and hard links, validates the core RootFS, then atomically activates it at `files/vx/runtime/rootfs`. Existing Runtime is preserved until the new package passes validation.
