package com.gtav.runtimeinspector;

final class RuntimeManifest {
    final int schemaVersion;
    final String runtimeId, version, host, guest, libc, integration;
    final Payload payload;
    final Components components;
    final EntryPoints entryPoints;

    RuntimeManifest(int schemaVersion, String runtimeId, String version, String host,
                    String guest, String libc, String integration, Payload payload,
                    Components components, EntryPoints entryPoints) {
        this.schemaVersion = schemaVersion; this.runtimeId = runtimeId; this.version = version;
        this.host = host; this.guest = guest; this.libc = libc; this.integration = integration;
        this.payload = payload; this.components = components; this.entryPoints = entryPoints;
    }

    static final class Payload {
        final String path, format, sha256;
        final long sizeBytes;
        final boolean preservesSymlinks, preservesUnixModes;
        Payload(String path, String format, String sha256, long sizeBytes,
                boolean preservesSymlinks, boolean preservesUnixModes) {
            this.path = path; this.format = format; this.sha256 = sha256; this.sizeBytes = sizeBytes;
            this.preservesSymlinks = preservesSymlinks; this.preservesUnixModes = preservesUnixModes;
        }
    }
    static final class Components {
        final String box64, wine, dxvk, debian;
        Components(String box64, String wine, String dxvk, String debian) {
            this.box64 = box64; this.wine = wine; this.dxvk = dxvk; this.debian = debian;
        }
    }
    static final class EntryPoints {
        final String wine64, wineserver, wineboot;
        EntryPoints(String wine64, String wineserver, String wineboot) {
            this.wine64 = wine64; this.wineserver = wineserver; this.wineboot = wineboot;
        }
    }
}
