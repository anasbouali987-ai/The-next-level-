package com.gtav.runtimeinspector;

import java.io.IOException;
import java.io.InputStream;

final class BoundedInputStream extends InputStream {
    private final InputStream source;
    private long remaining;
    BoundedInputStream(InputStream source, long remaining) { this.source = source; this.remaining = remaining; }
    @Override public int read() throws IOException {
        if (remaining <= 0) return -1;
        int value = source.read(); if (value >= 0) remaining--; return value;
    }
    @Override public int read(byte[] b, int off, int len) throws IOException {
        if (remaining <= 0) return -1;
        int count = source.read(b, off, (int)Math.min(len, remaining));
        if (count > 0) remaining -= count; return count;
    }
    @Override public void close() { }
}
