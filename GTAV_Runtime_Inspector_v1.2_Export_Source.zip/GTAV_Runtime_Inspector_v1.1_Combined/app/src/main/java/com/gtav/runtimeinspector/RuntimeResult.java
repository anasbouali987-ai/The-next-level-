package com.gtav.runtimeinspector;

import java.util.Collections;
import java.util.List;

final class RuntimeResult {
    enum Kind { VALID, WARNING, INVALID, WRAPPER }
    final Kind kind;
    final String status;
    final String details;
    final String rawManifest;
    final List<String> errors;
    final List<String> warnings;

    RuntimeResult(Kind kind, String status, String details, String rawManifest,
                  List<String> errors, List<String> warnings) {
        this.kind = kind;
        this.status = status;
        this.details = details;
        this.rawManifest = rawManifest == null ? "" : rawManifest;
        this.errors = Collections.unmodifiableList(errors);
        this.warnings = Collections.unmodifiableList(warnings);
    }
}
