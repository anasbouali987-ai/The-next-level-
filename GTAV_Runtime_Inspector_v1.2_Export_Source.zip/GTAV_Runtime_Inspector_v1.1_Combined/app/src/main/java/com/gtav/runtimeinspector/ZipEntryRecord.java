package com.gtav.runtimeinspector;

final class ZipEntryRecord {
    final String name;
    final int method;
    final long compressedSize, uncompressedSize, localHeaderOffset;
    ZipEntryRecord(String name, int method, long compressedSize, long uncompressedSize, long localHeaderOffset) {
        this.name = name; this.method = method; this.compressedSize = compressedSize;
        this.uncompressedSize = uncompressedSize; this.localHeaderOffset = localHeaderOffset;
    }
}
