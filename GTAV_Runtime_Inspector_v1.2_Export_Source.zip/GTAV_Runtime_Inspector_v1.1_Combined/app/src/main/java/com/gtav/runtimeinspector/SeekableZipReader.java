package com.gtav.runtimeinspector;

import java.io.ByteArrayOutputStream;
import java.io.Closeable;
import java.io.EOFException;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.channels.FileChannel;
import java.nio.charset.StandardCharsets;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.zip.Inflater;
import java.util.zip.InflaterInputStream;

/** Fast random-access reader for ordinary, unencrypted ZIP files below 4 GiB. */
final class SeekableZipReader implements Closeable {
    private static final int EOCD = 0x06054b50, CENTRAL = 0x02014b50, LOCAL = 0x04034b50;
    private static final int MAX_TAIL = 65557;
    private final FileInputStream input;
    private final FileChannel channel;
    private final Map<String, ZipEntryRecord> entries = new LinkedHashMap<>();

    SeekableZipReader(FileInputStream input) throws IOException {
        this.input = input; this.channel = input.getChannel(); parse();
    }
    Map<String, ZipEntryRecord> entries() { return entries; }
    ZipEntryRecord get(String name) { return entries.get(RuntimePackageReader.normalize(name)); }
    boolean contains(String name) { return get(name) != null; }

    byte[] readEntry(String name, int maxBytes) throws IOException {
        ZipEntryRecord e = get(name);
        if (e == null) throw new IOException("الملف غير موجود داخل ZIP: " + name);
        if (e.uncompressedSize > maxBytes) throw new IOException("الملف أكبر من الحد الآمن للقراءة: " + name);
        ByteBuffer local = readAt(e.localHeaderOffset, 30);
        if (u32(local, 0) != LOCAL) throw new IOException("Local ZIP header غير صالح.");
        int nameLen = u16(local, 26), extraLen = u16(local, 28);
        long dataOffset = e.localHeaderOffset + 30L + nameLen + extraLen;
        channel.position(dataOffset);
        InputStream bounded = new BoundedInputStream(input, e.compressedSize);
        InputStream decoded;
        if (e.method == 0) decoded = bounded;
        else if (e.method == 8) decoded = new InflaterInputStream(bounded, new Inflater(true), 8192);
        else throw new IOException("طريقة ضغط ZIP غير مدعومة: " + e.method);
        return readLimited(decoded, maxBytes);
    }

    private void parse() throws IOException {
        long size = channel.size();
        if (size < 22 || size > 0xffffffffL) throw new IOException("ZIP غير مدعوم أو ZIP64؛ سيتم استخدام الفحص المتتابع.");
        int tailSize = (int)Math.min(size, MAX_TAIL);
        ByteBuffer tail = readAt(size - tailSize, tailSize);
        int eocd = findBackward(tail, EOCD);
        if (eocd < 0) throw new IOException("لم يتم العثور على Central Directory.");
        int total = u16(tail, eocd + 10);
        long centralSize = u32(tail, eocd + 12), centralOffset = u32(tail, eocd + 16);
        if (total == 0xffff || centralSize == 0xffffffffL || centralOffset == 0xffffffffL)
            throw new IOException("ZIP64؛ سيتم استخدام الفحص المتتابع.");
        ByteBuffer cd = readAt(centralOffset, (int)centralSize);
        int p = 0;
        for (int i = 0; i < total; i++) {
            if (p + 46 > cd.limit() || u32(cd, p) != CENTRAL) throw new IOException("Central Directory تالف.");
            int flags = u16(cd, p + 8), method = u16(cd, p + 10);
            if ((flags & 1) != 0) throw new IOException("ZIP مشفّر غير مدعوم.");
            long compressed = u32(cd, p + 20), uncompressed = u32(cd, p + 24), localOffset = u32(cd, p + 42);
            int nameLen = u16(cd, p + 28), extraLen = u16(cd, p + 30), commentLen = u16(cd, p + 32);
            if (p + 46 + nameLen + extraLen + commentLen > cd.limit()) throw new IOException("Central Directory مبتور.");
            byte[] nameBytes = new byte[nameLen];
            ByteBuffer copy = cd.duplicate(); copy.position(p + 46); copy.get(nameBytes);
            String name = RuntimePackageReader.normalize(new String(nameBytes, StandardCharsets.UTF_8));
            RuntimePackageReader.validateEntryName(name);
            entries.put(name, new ZipEntryRecord(name, method, compressed, uncompressed, localOffset));
            p += 46 + nameLen + extraLen + commentLen;
        }
    }
    private ByteBuffer readAt(long offset, int size) throws IOException {
        ByteBuffer b = ByteBuffer.allocate(size).order(ByteOrder.LITTLE_ENDIAN);
        channel.position(offset); while (b.hasRemaining()) if (channel.read(b) < 0) throw new EOFException();
        b.flip(); return b;
    }
    private static int findBackward(ByteBuffer b, int sig) {
        for (int i = b.limit() - 4; i >= 0; i--) if (u32(b, i) == sig) return i; return -1;
    }
    private static int u16(ByteBuffer b, int p) { return Short.toUnsignedInt(b.getShort(p)); }
    private static long u32(ByteBuffer b, int p) { return Integer.toUnsignedLong(b.getInt(p)); }
    private static byte[] readLimited(InputStream in, int max) throws IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream(); byte[] buf = new byte[8192]; int total = 0, n;
        while ((n = in.read(buf)) != -1) { total += n; if (total > max) throw new IOException("تم تجاوز الحد الآمن."); out.write(buf, 0, n); }
        return out.toByteArray();
    }
    @Override public void close() throws IOException { input.close(); }
}
