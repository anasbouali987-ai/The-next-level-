package com.gtav.runtimeinspector;

import android.content.ContentResolver;
import android.database.Cursor;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.provider.OpenableColumns;

import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

final class RuntimePackageReader {
    private static final String MANIFEST = "runtime_manifest.json";
    private static final String REPORT = "build_report.json";
    private static final int MAX_JSON = 8 * 1024 * 1024;
    private final ContentResolver resolver;

    interface Progress { void update(String stage, long done, long total); }

    RuntimePackageReader(ContentResolver resolver) { this.resolver = resolver; }

    RuntimeResult read(Uri uri, Progress progress) throws Exception {
        FileMeta meta = fileMeta(uri);
        progress.update("محاولة القراءة السريعة…", 0, meta.size);
        try {
            return readSeekable(uri, meta);
        } catch (Exception fastError) {
            progress.update("القراءة المباشرة غير متاحة؛ جارٍ الفحص المتتابع…", 0, meta.size);
            return readSequential(uri, meta, progress, fastError.getMessage());
        }
    }

    private RuntimeResult readSeekable(Uri uri, FileMeta meta) throws Exception {
        try (ParcelFileDescriptor pfd = resolver.openFileDescriptor(uri, "r")) {
            if (pfd == null) throw new IOException("تعذر فتح الملف.");
            try (SeekableZipReader zip = new SeekableZipReader(new FileInputStream(pfd.getFileDescriptor()))) {
                if (!zip.contains(MANIFEST)) return wrapperOrInvalid(zip.entries());
                String manifestText = new String(zip.readEntry(MANIFEST, MAX_JSON), StandardCharsets.UTF_8);
                String reportText = zip.contains(REPORT)
                        ? new String(zip.readEntry(REPORT, MAX_JSON), StandardCharsets.UTF_8) : null;
                Map<String, Long> entries = new HashMap<>();
                for (ZipEntryRecord e : zip.entries().values()) entries.put(e.name, e.uncompressedSize);
                return validate(meta, manifestText, reportText, entries, "قراءة سريعة عبر Central Directory");
            }
        }
    }

    private RuntimeResult readSequential(Uri uri, FileMeta meta, Progress progress, String fallbackReason) throws Exception {
        Map<String, Long> entries = new HashMap<>();
        String manifestText = null, reportText = null;
        long processed = 0;
        try (InputStream raw = resolver.openInputStream(uri)) {
            if (raw == null) throw new IOException("تعذر فتح الملف.");
            CountingInputStream counting = new CountingInputStream(new BufferedInputStream(raw, 1024 * 1024));
            try (ZipInputStream zip = new ZipInputStream(counting)) {
                ZipEntry e;
                while ((e = zip.getNextEntry()) != null) {
                    String name = normalize(e.getName()); validateEntryName(name);
                    entries.put(name, e.getSize());
                    if (!e.isDirectory() && MANIFEST.equals(name)) manifestText = readLimited(zip, MAX_JSON);
                    else if (!e.isDirectory() && REPORT.equals(name)) reportText = readLimited(zip, MAX_JSON);
                    zip.closeEntry(); processed = counting.count;
                    progress.update("فحص محتويات ZIP…", processed, meta.size);
                }
            }
        }
        if (manifestText == null) {
            RuntimeResult wrapper = wrapperOrInvalidSequential(entries);
            if (wrapper.kind == RuntimeResult.Kind.WRAPPER) return wrapper;
            throw new IOException("runtime_manifest.json غير موجود. سبب الانتقال للفحص المتتابع: " + safe(fallbackReason));
        }
        return validate(meta, manifestText, reportText, entries, "فحص متتابع متوافق مع مزودي الملفات");
    }

    private RuntimeResult validate(FileMeta meta, String manifestText, String reportText,
                                   Map<String, Long> entries, String readMode) throws Exception {
        JSONObject root = new JSONObject(manifestText);
        JSONObject payloadJson = root.optJSONObject("rootfs_payload");
        JSONObject componentsJson = root.optJSONObject("components");
        JSONObject entrypointsJson = root.optJSONObject("entrypoints");
        if (payloadJson == null) throw new IllegalArgumentException("rootfs_payload غير موجود في Manifest.");

        RuntimeManifest manifest = new RuntimeManifest(
                root.optInt("schema_version", -1), root.optString("runtime_id", ""),
                root.optString("version", ""), root.optString("host_architecture", ""),
                root.optString("guest_architecture", ""), root.optString("libc_model", ""),
                root.optString("android_integration_model", ""),
                new RuntimeManifest.Payload(normalize(payloadJson.optString("path", "")),
                        payloadJson.optString("format", ""), payloadJson.optString("sha256", "").toLowerCase(Locale.ROOT),
                        payloadJson.optLong("size_bytes", -1), payloadJson.optBoolean("preserves_symlinks", false),
                        payloadJson.optBoolean("preserves_unix_modes", false)),
                new RuntimeManifest.Components(value(componentsJson, "box64"), value(componentsJson, "wine"),
                        value(componentsJson, "dxvk"), value(componentsJson, "debian")),
                new RuntimeManifest.EntryPoints(value(entrypointsJson, "wine64"), value(entrypointsJson, "wineserver"),
                        value(entrypointsJson, "wineboot")));

        BuildReport report = null;
        if (reportText != null) {
            JSONObject r = new JSONObject(reportText);
            report = new BuildReport(r.optString("runtime_id", ""), r.optString("runtime_version", ""),
                    r.optString("payload_sha256", "").toLowerCase(Locale.ROOT),
                    r.optLong("payload_size_bytes", -1), r.optInt("rootfs_node_count", -1));
        }

        List<String> errors = new ArrayList<>(), warnings = new ArrayList<>();
        if (manifest.schemaVersion != 3) errors.add("schema_version غير مدعوم: " + manifest.schemaVersion);
        if (blank(manifest.runtimeId)) errors.add("runtime_id مفقود.");
        if (blank(manifest.version)) errors.add("version مفقود.");
        if (!"arm64".equalsIgnoreCase(manifest.host)) errors.add("Host غير مدعوم: " + manifest.host);
        if (!"x86_64".equalsIgnoreCase(manifest.guest)) errors.add("Guest غير مدعوم: " + manifest.guest);
        if (!"glibc-rootfs".equalsIgnoreCase(manifest.libc)) warnings.add("libc_model غير متوقع: " + manifest.libc);
        if (!"tar+zstd".equalsIgnoreCase(manifest.payload.format)) errors.add("صيغة Payload غير مدعومة: " + manifest.payload.format);
        if (blank(manifest.payload.path) || !entries.containsKey(manifest.payload.path))
            errors.add("Payload غير موجود: " + manifest.payload.path);
        if (!manifest.payload.sha256.matches("[0-9a-f]{64}")) errors.add("SHA-256 المسجل غير صالح.");
        if (manifest.payload.sizeBytes <= 0) errors.add("حجم Payload المسجل غير صالح.");
        Long actual = entries.get(manifest.payload.path);
        if (actual != null && actual >= 0 && actual != manifest.payload.sizeBytes)
            errors.add("حجم Payload داخل ZIP لا يطابق Manifest.");
        if (!manifest.payload.preservesSymlinks) warnings.add("لا يوجد تأكيد للحفاظ على symbolic links.");
        if (!manifest.payload.preservesUnixModes) warnings.add("لا يوجد تأكيد للحفاظ على Unix modes.");
        if (!"android-native-proot-or-equivalent-required".equals(manifest.integration))
            warnings.add("نموذج دمج Android غير معروف: " + manifest.integration);
        if (blank(manifest.components.box64)) errors.add("إصدار Box64 مفقود.");
        if (blank(manifest.components.wine)) errors.add("إصدار Wine مفقود.");
        if (blank(manifest.components.dxvk)) errors.add("إصدار DXVK مفقود.");
        if (blank(manifest.components.debian)) warnings.add("إصدار Debian مفقود.");
        if (report == null) warnings.add("build_report.json غير موجود.");
        else {
            if (!report.runtimeId.equals(manifest.runtimeId)) errors.add("runtime_id مختلف بين Manifest وBuild Report.");
            if (!report.runtimeVersion.equals(manifest.version)) errors.add("الإصدار مختلف بين Manifest وBuild Report.");
            if (!report.payloadSha256.equals(manifest.payload.sha256)) errors.add("SHA-256 مختلف بين Manifest وBuild Report.");
            if (report.payloadSizeBytes != manifest.payload.sizeBytes) errors.add("حجم Payload مختلف بين Manifest وBuild Report.");
        }

        RuntimeResult.Kind kind = !errors.isEmpty() ? RuntimeResult.Kind.INVALID
                : warnings.isEmpty() ? RuntimeResult.Kind.VALID : RuntimeResult.Kind.WARNING;
        String status = kind == RuntimeResult.Kind.VALID ? "✅ Runtime صالح ومتوافق"
                : kind == RuntimeResult.Kind.WARNING ? "⚠️ Runtime صالح مع تحذيرات"
                : "❌ Runtime غير صالح";
        String details = buildDetails(meta, manifest, report, readMode, errors, warnings, entries.size());
        return new RuntimeResult(kind, status, details, pretty(manifestText), errors, warnings);
    }

    private RuntimeResult wrapperOrInvalid(Map<String, ZipEntryRecord> entries) {
        Map<String, Long> simple = new HashMap<>(); for (ZipEntryRecord e : entries.values()) simple.put(e.name, e.uncompressedSize);
        return wrapperOrInvalidSequential(simple);
    }
    private RuntimeResult wrapperOrInvalidSequential(Map<String, Long> entries) {
        List<String> inner = new ArrayList<>();
        for (String n : entries.keySet()) if (n.toLowerCase(Locale.ROOT).endsWith(".zip")) inner.add(n);
        if (!inner.isEmpty()) {
            return new RuntimeResult(RuntimeResult.Kind.WRAPPER, "📦 تم اكتشاف GitHub Artifact خارجي",
                    "هذا الملف لا يحتوي Manifest مباشرة، لكنه يحتوي حزمة ZIP داخلية:\n• " + String.join("\n• ", inner)
                            + "\n\nاستخرج الملف الخارجي مرة واحدة، ثم اختر GTAV_Runtime_Package.zip من داخله.",
                    "", new ArrayList<>(), new ArrayList<>());
        }
        return new RuntimeResult(RuntimeResult.Kind.INVALID, "❌ الملف ليس حزمة Runtime",
                "runtime_manifest.json غير موجود ولا توجد حزمة ZIP داخلية معروفة.", "", new ArrayList<>(), new ArrayList<>());
    }

    private static String buildDetails(FileMeta meta, RuntimeManifest m, BuildReport report, String mode,
                                       List<String> errors, List<String> warnings, int count) {
        StringBuilder b = new StringBuilder();
        b.append("الملف: ").append(meta.name).append("\nحجم الحزمة: ").append(human(meta.size)).append("\nطريقة القراءة: ").append(mode)
                .append("\nعدد عناصر ZIP: ").append(count).append("\n\n")
                .append("Runtime ID: ").append(show(m.runtimeId)).append("\nVersion: ").append(show(m.version))
                .append("\nSchema: ").append(m.schemaVersion).append("\nHost → Guest: ").append(show(m.host)).append(" → ").append(show(m.guest))
                .append("\nLibc: ").append(show(m.libc)).append("\nWine: ").append(show(m.components.wine))
                .append("\nBox64: ").append(show(m.components.box64)).append("\nDXVK: ").append(show(m.components.dxvk))
                .append("\nDebian: ").append(show(m.components.debian)).append("\nPayload: ").append(show(m.payload.path))
                .append("\nPayload size: ").append(human(m.payload.sizeBytes)).append("\nSHA-256: ").append(shortHash(m.payload.sha256))
                .append("\nBuild report: ").append(report == null ? "غير موجود" : "موجود")
                .append(report != null && report.rootfsNodeCount >= 0 ? "\nRootFS nodes: " + report.rootfsNodeCount : "");
        if (!errors.isEmpty()) { b.append("\n\nالأخطاء:"); for (String e : errors) b.append("\n• ").append(e); }
        if (!warnings.isEmpty()) { b.append("\n\nالتحذيرات:"); for (String w : warnings) b.append("\n• ").append(w); }
        return b.toString();
    }

    static String normalize(String name) {
        String n = name == null ? "" : name.replace('\\', '/');
        while (n.startsWith("./")) n = n.substring(2);
        while (n.startsWith("/")) n = n.substring(1);
        return n;
    }
    static void validateEntryName(String name) {
        if (name.isEmpty() || name.equals("..") || name.startsWith("../") || name.contains("/../"))
            throw new IllegalArgumentException("مسار غير آمن داخل ZIP: " + name);
    }
    private static String readLimited(InputStream in, int max) throws IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream(); byte[] buffer = new byte[8192]; int total = 0, n;
        while ((n = in.read(buffer)) != -1) { total += n; if (total > max) throw new IOException("ملف JSON أكبر من الحد المسموح."); out.write(buffer, 0, n); }
        return out.toString(StandardCharsets.UTF_8.name());
    }
    private static String value(JSONObject obj, String key) { return obj == null ? "" : obj.optString(key, ""); }
    private static String pretty(String text) { try { return new JSONObject(text).toString(2); } catch (Exception e) { return text; } }
    private static boolean blank(String s) { return s == null || s.trim().isEmpty(); }
    private static String show(String s) { return blank(s) ? "—" : s; }
    private static String safe(String s) { return blank(s) ? "غير محدد" : s; }
    private static String shortHash(String s) { return s == null || s.length() < 16 ? show(s) : s.substring(0, 12) + "…" + s.substring(s.length() - 8); }
    private static String human(long bytes) {
        if (bytes < 0) return "غير معروف"; String[] u = {"B","KB","MB","GB"}; double v = bytes; int i=0;
        while (v >= 1024 && i < u.length-1) { v/=1024; i++; }
        return new DecimalFormat(v >= 100 ? "0" : v >= 10 ? "0.0" : "0.00").format(v) + " " + u[i];
    }
    private FileMeta fileMeta(Uri uri) {
        String name = "Runtime.zip"; long size = -1;
        try (Cursor c = resolver.query(uri, new String[]{OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE}, null, null, null)) {
            if (c != null && c.moveToFirst()) {
                int ni = c.getColumnIndex(OpenableColumns.DISPLAY_NAME), si = c.getColumnIndex(OpenableColumns.SIZE);
                if (ni >= 0 && !c.isNull(ni)) name = c.getString(ni);
                if (si >= 0 && !c.isNull(si)) size = c.getLong(si);
            }
        } catch (Exception ignored) { }
        return new FileMeta(name, size);
    }
    private static final class FileMeta { final String name; final long size; FileMeta(String n,long s){name=n;size=s;} }
    private static final class CountingInputStream extends InputStream {
        final InputStream source; long count; CountingInputStream(InputStream s){source=s;}
        @Override public int read() throws IOException { int v=source.read(); if(v>=0)count++; return v; }
        @Override public int read(byte[] b,int o,int l)throws IOException{int n=source.read(b,o,l);if(n>0)count+=n;return n;}
        @Override public long skip(long n)throws IOException{long v=source.skip(n);count+=v;return v;}
        @Override public void close()throws IOException{source.close();}
    }
}
