package com.gtav.runtimeinspector;

final class BuildReport {
    final String runtimeId, runtimeVersion, payloadSha256;
    final long payloadSizeBytes;
    final int rootfsNodeCount;
    BuildReport(String runtimeId, String runtimeVersion, String payloadSha256,
                long payloadSizeBytes, int rootfsNodeCount) {
        this.runtimeId = runtimeId; this.runtimeVersion = runtimeVersion;
        this.payloadSha256 = payloadSha256; this.payloadSizeBytes = payloadSizeBytes;
        this.rootfsNodeCount = rootfsNodeCount;
    }
}
