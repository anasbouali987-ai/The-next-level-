package com.gtav.runtimeinspector;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class MainActivity extends Activity {
    private static final int PICK_RUNTIME = 1001;
    private static final String PREFS = "runtime_inspector";
    private static final String LAST_URI = "last_runtime_uri";

    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private Button selectButton, manifestButton;
    private ProgressBar progress;
    private TextView fileName, statusText, detailsText, manifestText;
    private String rawManifest = "";

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        selectButton = findViewById(R.id.selectButton);
        manifestButton = findViewById(R.id.manifestButton);
        progress = findViewById(R.id.progress);
        fileName = findViewById(R.id.fileName);
        statusText = findViewById(R.id.statusText);
        detailsText = findViewById(R.id.detailsText);
        manifestText = findViewById(R.id.manifestText);
        selectButton.setOnClickListener(v -> chooseRuntime());
        manifestButton.setOnClickListener(v -> toggleManifest());

        String saved = getSharedPreferences(PREFS, MODE_PRIVATE).getString(LAST_URI, null);
        if (saved != null) {
            Uri uri = Uri.parse(saved);
            fileName.setText("آخر ملف: " + displayName(uri));
            inspect(uri);
        }
    }

    private void chooseRuntime() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("application/zip");
        intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{
                "application/zip", "application/x-zip-compressed", "application/octet-stream"
        });
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(intent, PICK_RUNTIME);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != PICK_RUNTIME || resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        int flags = data.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
        try { getContentResolver().takePersistableUriPermission(uri, flags & Intent.FLAG_GRANT_READ_URI_PERMISSION); }
        catch (Exception ignored) { }
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(LAST_URI, uri.toString()).apply();
        fileName.setText(displayName(uri));
        inspect(uri);
    }

    private void inspect(Uri uri) {
        setBusy(true);
        rawManifest = "";
        manifestText.setVisibility(View.GONE);
        manifestButton.setEnabled(false);
        statusText.setText("جارٍ فحص الحزمة…");
        statusText.setTextColor(getColor(R.color.text_primary));
        detailsText.setText("يتم التحقق دون استخراج RootFS.");

        executor.execute(() -> {
            try {
                RuntimeResult result = new RuntimePackageReader(getContentResolver()).read(uri,
                        (stage, done, total) -> runOnUiThread(() -> updateProgress(stage, done, total)));
                runOnUiThread(() -> showResult(result));
            } catch (Exception error) {
                runOnUiThread(() -> showError(error));
            }
        });
    }

    private void updateProgress(String stage, long done, long total) {
        if (total > 0 && done >= 0) {
            progress.setIndeterminate(false);
            progress.setMax(1000);
            progress.setProgress((int)Math.min(1000, (done * 1000L) / total));
            statusText.setText(stage + " " + Math.min(100, (done * 100L) / total) + "%");
        } else {
            progress.setIndeterminate(true);
            statusText.setText(stage);
        }
    }

    private void showResult(RuntimeResult result) {
        setBusy(false);
        statusText.setText(result.status);
        int color = result.kind == RuntimeResult.Kind.VALID ? R.color.valid
                : result.kind == RuntimeResult.Kind.WARNING || result.kind == RuntimeResult.Kind.WRAPPER
                ? R.color.warning : R.color.invalid;
        statusText.setTextColor(getColor(color));
        detailsText.setText(result.details);
        rawManifest = result.rawManifest;
        manifestButton.setEnabled(!rawManifest.trim().isEmpty());
    }

    private void showError(Exception error) {
        setBusy(false);
        statusText.setText("❌ تعذر قراءة الحزمة");
        statusText.setTextColor(getColor(R.color.invalid));
        detailsText.setText(error.getMessage() == null ? error.getClass().getSimpleName() : error.getMessage());
    }

    private void setBusy(boolean busy) {
        selectButton.setEnabled(!busy);
        progress.setVisibility(busy ? View.VISIBLE : View.GONE);
        if (!busy) { progress.setIndeterminate(true); progress.setProgress(0); }
    }

    private void toggleManifest() {
        boolean show = manifestText.getVisibility() != View.VISIBLE;
        manifestText.setVisibility(show ? View.VISIBLE : View.GONE);
        manifestText.setText(rawManifest);
        manifestButton.setText(show ? R.string.hide_manifest : R.string.show_manifest);
    }

    private String displayName(Uri uri) {
        try (Cursor c = getContentResolver().query(uri, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null)) {
            if (c != null && c.moveToFirst()) {
                int i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (i >= 0 && !c.isNull(i)) return c.getString(i);
            }
        } catch (Exception ignored) { }
        return uri.getLastPathSegment() == null ? "Runtime ZIP" : uri.getLastPathSegment();
    }

    @Override protected void onDestroy() {
        executor.shutdownNow();
        super.onDestroy();
    }
}
