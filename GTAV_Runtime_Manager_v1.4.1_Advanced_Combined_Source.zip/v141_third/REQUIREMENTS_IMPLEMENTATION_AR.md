# مطابقة متطلبات التحديث v1.4.0

## المكونات المعمارية

- `RuntimeInstallCoordinator.java`
- `RuntimeInstaller.java`
- `RuntimePreflightChecker.java`
- `RuntimeExtractor.java`
- `RuntimePostVerifier.java`
- `RuntimeCrashReporter.java`
- `RuntimeLogWriter.java`

## آلة الحالات

- `InstallStage.java`
- `InstallSnapshot.java`
- `InstallStateStore.java`

## الذاكرة

- `MemorySnapshot.java`
- `RuntimeManifest.java`: يحتفظ فقط بالملفات المطلوبة والإحصائيات.
- `RuntimeExtractor.java`: Streaming وmetadata على القرص.
- `RuntimeLogWriter.java`: كتابة مباشرة للتقارير والسجلات.

## الاستمرار أثناء التثبيت الطويل

- `RuntimeInstallService.java`: Foreground Service من نوع `dataSync`.
- إشعار تقدم مع زر إلغاء.
- `PARTIAL_WAKE_LOCK` بمهلة قصوى وتحرير في `onDestroy`.
- استعادة الواجهة من حالة `RuntimeInstallCoordinator` عند إعادة إنشاء Activity.

## التنفيذ خارج Main Thread

- `RuntimeInstallCoordinator.java`: Executor مخصص واحد.
- `MainActivity.java`: Executor منفصل للتحقق والتصدير وإعادة الفحص.
- تحديث الواجهة عبر Main Handler أو `runOnUiThread` فقط.

## شاشة التقدم

- عدد الملفات والمجلدات وSymlinks وHard Links.
- الحجم المكتوب والمضغوط المقروء.
- حالة Zstandard وTAR.
- السرعة والزمن المنقضي والمتبقي.
- الذاكرة الحرة والمستخدمة والحد الأقصى.
- تحديث مخنوق إلى نحو 300ms.

## التحقق بعد التثبيت

- `RuntimePostVerifier.java`
- النوع، الحجم، Symlink target، وضع التنفيذ، SHA-256 للملفات المطلوبة.
- مقارنة الإحصائيات عبر `RuntimeInstallPolicy.validateStats`.

## ملف الحالة

- `.installing/install_state.json` أثناء العمل.
- `installed_runtime.json` و`install_state.json` بعد النجاح.
- عدد الملفات والمجلدات والروابط والحجم وآخر ملف وآخر خطأ وحالات المحركات والذاكرة.

## حزمة التشخيص

- `DiagnosticsExporter.java`
- تضم تقارير التحقق والتثبيت والتشخيص والانهيار والسجل والـManifest وملفات الحالة وملخص الجهاز.

## الاختبارات

- `RuntimeInstallPolicyTest`: Payload ناقص.
- `CancellationTokenTest`: إلغاء أثناء الاستخراج.
- `PermissionApplierTest`: فشل chmod.
- `AtomicRuntimeSwapTest`: استعادة `.backup`.

## إصلاح الانهيار السابق

- اختبار `Zstd.versionNumber()` قبل التثبيت.
- فحص وجود Native Zstd لـarm64 داخل APK في Workflow.
- التقاط `UnsatisfiedLinkError` و`OutOfMemoryError` و`Throwable`.
- Crash Handler عام.
- إظهار خطأ منظّم بدل إغلاق التطبيق.
- إعادة نشر الحالة بعد تحرير قفل العملية لإعادة تفعيل الأزرار.
- حذف آمن لا يتبع Symlinks.
