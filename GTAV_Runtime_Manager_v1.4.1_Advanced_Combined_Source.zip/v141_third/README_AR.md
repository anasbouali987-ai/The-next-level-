# GTAV Runtime Manager v1.4.0

إصدار تصحيحي ومعماري مخصص للتحقق من حزمة GTAV Runtime وتثبيتها وإدارتها بأمان. لا يشغّل PRoot أو Box64 أو Wine أو DXVK أو Vulkan أو ملفات EXE أو الألعاب.

## الهدف الأساسي

منع الإغلاق الصامت عند الضغط على **تثبيت Runtime**، وتحويل أي فشل إلى حالة منظّمة وتقرير قابل للمراجعة والتصدير.

## أهم التغييرات

### معمارية التثبيت

تم فصل العمل إلى مكونات مستقلة:

- `RuntimeInstallCoordinator`: إدارة العملية والـThread والحالة والإلغاء.
- `RuntimeInstaller`: ترتيب مراحل التثبيت والتثبيت الذري.
- `RuntimePreflightChecker`: اختبار المساحة والكتابة وchmod وSymlink وrename وZstandard وTAR.
- `RuntimeExtractor`: فك Zstandard واستخراج TAR بصورة متدفقة.
- `RuntimePostVerifier`: التحقق بعد الاستخراج.
- `RuntimeCrashReporter`: حفظ الانهيارات والأخطاء غير المعالجة.
- `RuntimeLogWriter`: كتابة السجلات والتقارير مباشرة إلى الملفات.
- `RuntimeInstallService`: Foreground Service مع إشعار تقدم وزر إلغاء وWakeLock جزئي.

### آلة الحالات

يمر التثبيت بحالات واضحة، منها:

`PREPARING → PREFLIGHT → OPENING_PACKAGE → STARTING_ZSTD → READING_TAR → EXTRACTING → CREATING_HARDLINKS → CREATING_SYMLINKS → APPLYING_PERMISSIONS → POST_VERIFY → FINALIZING → COMPLETED`

وقد ينتهي بـ `FAILED` أو `CANCELLED` دون إغلاق التطبيق.

### الحماية من الانهيار

- التقاط `Throwable` في الحد الأعلى للعملية.
- معالجة مخصصة لـ `OutOfMemoryError` و`UnsatisfiedLinkError`.
- Global Crash Handler داخل `RuntimeManagerApp`.
- تقرير انهيار يحفظ المرحلة، والملف الحالي، والذاكرة، والجهاز، وStack trace.
- إعادة تفعيل الأزرار آليًا بعد النجاح أو الفشل أو الإلغاء.
- إبقاء التثبيت الطويل في Foreground Service، مع تحرير WakeLock حتمي عند النهاية.
- اعتراض زر الرجوع أثناء التثبيت وعرض خيار إلغاء آمن بدل إغلاق الشاشة.

### الذاكرة والتدفق

- لا تُحمّل `rootfs.tar.zst` أو TAR كاملًا في الذاكرة.
- مسار البيانات:

```text
ZIP entry stream
→ ZstdInputStream
→ TarArchiveInputStream
→ Buffered file output
```

- لا تُحفظ قائمة كل ملفات RootFS في الذاكرة؛ يحتفظ التطبيق بالملفات المطلوبة فقط وبالإحصائيات الإجمالية.
- الروابط والصلاحيات المؤجلة تُكتب إلى ملفات metadata مؤقتة بدل قوائم ضخمة.
- السجلات تُكتب مباشرة إلى القرص.
- عرض الذاكرة الحرة والمستخدمة والحد الأقصى أثناء التقدم والتشخيص.

### التحقق والتثبيت

- SHA-256 متدفق للـPayload قبل التثبيت.
- حفظ نتيجة SHA وربطها بـURI والحجم ووقت التعديل.
- تشخيص مسبق فعلي لـZstandard وTAR وchmod وSymlink وAtomic rename.
- منع Path Traversal والمسارات المطلقة ومسارات Windows.
- منع الكتابة خلال Symlink أب.
- استخدام `android.system.Os` لـchmod وSymlink وHard Link.
- تأجيل Symlinks وHard Links إلى ما بعد استخراج الملفات.
- تثبيت داخل `<runtime-id>.installing` ثم نقل ذري إلى المسار النهائي.
- إعادة التثبيت عبر `.backup` مع Rollback عند فشل الترقية.
- حذف آمن لا يتبع Symlinks ولا يسمح بالخروج من مجلد Runtime.

### التحقق بعد التثبيت

يتم التحقق من:

- نوع الملف.
- الحجم.
- هدف Symlink.
- صلاحية التنفيذ.
- SHA-256 للملفات المطلوبة عند توفره.
- Entry points الثلاثة.
- ملفات Wine وBox64 المعلّمة `required`.
- عدد الملفات والمجلدات والروابط والحجم المكتوب مقارنة بالـManifest عندما تتوفر القيم المتوقعة.

### التقارير

يدعم التطبيق:

- تقرير التحقق.
- تقرير التثبيت في النجاح أو الفشل.
- سجل تثبيت حي.
- تقرير الانهيار.
- تقرير التشخيص.
- Manifest الخام.
- `install_state.json` موسع.
- تصدير موحد باسم `GTAV_Runtime_Diagnostics.zip`.

## الاختبارات الآلية

يتضمن المشروع اختبارات لـ:

- رفض Payload ناقص.
- الإلغاء أثناء مرحلة الاستخراج.
- تحويل فشل chmod إلى خطأ منظّم.
- استعادة `.backup` عند فشل ترقية التثبيت المؤقت.

يشغّل Workflow الاختبارات قبل إنشاء APK.

## البناء عبر GitHub Actions

### الطريقة الأولى: رفع المشروع مفكوكًا

ارفع محتويات مجلد المشروع إلى جذر المستودع، مع بقاء الملف:

```text
.github/workflows/build-apk.yml
```

### الطريقة الثانية: رفع Source ZIP

يمكن وضع Source ZIP في المستودع مع ملف Workflow خارجي داخل:

```text
.github/workflows/build-apk.yml
```

سيبحث Workflow عن مشروع Android، وإن لم يجده سيفك أول ZIP ويبحث بداخله.

### تشغيل البناء

1. افتح **Actions**.
2. اختر **Build GTAV Runtime Manager v1.4.0 APK**.
3. اضغط **Run workflow**.
4. نزّل Artifact باسم:

```text
GTAV-Runtime-Manager-v1.4.0-APK
```

يحتوي Artifact على:

- `GTAV-Runtime-Manager-v1.4.0-debug.apk`
- `SHA256SUMS.txt`
- `BUILD_INFO.txt`
- `native-libraries.txt`
- تقرير اختبارات الوحدة، عند توفره.

## فحص مكتبة Zstandard في البناء

يفشل Workflow عمدًا إذا لم يجد مكتبة Zstandard الأصلية لـ:

```text
arm64-v8a
```

وذلك لمنع إنتاج APK يُغلق عند إنشاء `ZstdInputStream` بسبب مكتبة JNI مفقودة.

## متطلبات البناء

- JDK 17
- Gradle 8.11.1
- Android SDK 36
- Android Build Tools 35.0.0

## نطاق الإصدار

هذا الإصدار لا يحتوي على:

- PRoot
- تشغيل Box64
- تشغيل Wine
- Wine Prefix
- Vulkan أو طبقة عرض وصوت
- تشغيل EXE أو الألعاب
- Containers

## تحديث v1.4.1 — Reliability Upgrade

هذه النسخة مبنية فوق معمارية Stability المتقدمة دون حذف أو تبسيط طبقاتها. تمت إضافة:

- سجل تثبيت Append-only بصيغة JSONL لاستعادة تسلسل المراحل بعد قتل Process.
- Watchdog تشخيصي يرصد توقف التقدم ويكتب تقرير الذاكرة والمرحلة والملف الحالي.
- Recovery Manager عند بدء التطبيق لاستعادة `.backup` عند فقدان المجلد النهائي ورصد `.installing` المتروك.
- تضمين سجل المراحل وتقرير Watchdog داخل `GTAV_Runtime_Diagnostics.zip`.
- تحديث Workflow والـAPK إلى v1.4.1 مع اختبارات الوحدة وفحص مكتبة Zstd arm64.

لم تتم إزالة Foreground Service أو State Machine أو Structured Errors أو Atomic Swap أو Memory Monitoring أو اختبارات الأمان.
