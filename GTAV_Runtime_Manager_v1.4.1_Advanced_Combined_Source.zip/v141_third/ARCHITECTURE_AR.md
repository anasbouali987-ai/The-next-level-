# معمارية GTAV Runtime Manager v1.4.0

## تدفق العملية

```text
MainActivity
    ↓ أوامر فقط
RuntimeInstallCoordinator
    ├── Executor واحد + CancellationToken + State Machine
    └── RuntimeInstallService (Foreground + Notification + WakeLock)
         ↓
RuntimeInstaller
    ├── RuntimePreflightChecker
    ├── RuntimeExtractor
    ├── RuntimePostVerifier
    ├── InstallStateStore
    ├── AtomicRuntimeSwap
    ├── RuntimeLogWriter
    └── RuntimeCrashReporter
```

## قواعد الطبقات

- `MainActivity` لا تنفذ ZIP أو Zstd أو TAR.
- `RuntimeInstallCoordinator` يحتفظ بـApplication Context فقط، ولا يحتفظ بـActivity.
- `RuntimeInstaller` ينسق المراحل ولا يتعامل مع عناصر الواجهة.
- `RuntimeExtractor` يعمل بأسلوب Streaming ويعيد `InstallStats` فقط.
- `RuntimePostVerifier` يفحص الملفات المطلوبة وEntry points دون فحص 9001 ملفًا كاملًا.
- `InstallStateStore` يكتب الحالة دوريًا إلى `.installing/install_state.json` ونسخة تشخيصية عامة.

## التثبيت الذري

```text
runtime.installing
    ↓ استخراج + تحقق + ملفات الحالة
runtime الحالي → runtime.backup
runtime.installing → runtime
    ↓ عند النجاح
حذف runtime.backup
```

عند فشل نقل النسخة الجديدة، تُعاد `.backup` إلى المسار النهائي.

## إدارة الذاكرة

- Buffer ثابت 256 KiB للاستخراج.
- لا توجد `readAllBytes()` للـPayload.
- الملفات المطلوبة فقط تُحفظ من `rootfs_files`.
- Symlinks وHard Links وصلاحيات المجلدات المؤجلة تُخزن في ملفات TSV مؤقتة.
- تحديث الواجهة والحالة كل 300ms تقريبًا، وملف الحالة كل ثانية تقريبًا.
