package com.gtav.runtimemanager;

import java.io.IOException;

final class RuntimeInstallPolicy {
    private RuntimeInstallPolicy() {}

    static void requirePayload(boolean present, String message) throws IOException {
        if (!present) throw new IOException(message);
    }

    static void validateStats(RuntimeManifest.ManifestStats expected, InstallStats actual)
            throws RuntimeInstallException {
        if (expected == null || expected.totalNodes() == 0) return;

        // Manifest الحالي يسجل الملفات وSymlinks فقط، بينما TAR قد يحول
        // الملفات ذات inode واحد إلى Hard Links. لذلك نقارن المنظور المنطقي
        // للملفات عندما لا يحتوي Manifest على نوع hardlink مستقل.
        boolean logical = true;
        if (expected.hardLinks > 0) {
            if (expected.files > 0) logical &= expected.files == actual.files;
            logical &= expected.hardLinks == actual.hardLinks;
            if (expected.fileBytes > 0) logical &= expected.fileBytes == actual.writtenBytes;
        } else {
            if (expected.files > 0) {
                logical &= expected.files == actual.files + actual.hardLinks;
            }
            if (expected.fileBytes > 0) {
                logical &= expected.fileBytes ==
                        actual.writtenBytes + actual.hardLinkLogicalBytes;
            }
        }
        if (expected.symlinks > 0) logical &= expected.symlinks == actual.symlinks;

        if (expected.directories > 0) {
            long directoryDifference = Math.abs(expected.directories - actual.directories);
            long allowedDirectoryDifference = Math.max(2, expected.directories / 100);
            logical &= directoryDifference <= allowedDirectoryDifference;
        }

        // حتى إذا لم يسجل الـManifest جميع الأنواع، يجب أن يكون الناتج منطقيًا.
        logical &= actual.files > 0;
        logical &= actual.writtenBytes > 0;

        if (!logical) {
            throw new RuntimeInstallException(
                    InstallErrorCode.POST_VERIFICATION_FAILED,
                    InstallStage.POST_VERIFY,
                    "إحصائيات الاستخراج غير منطقية مقارنة بالـManifest: " +
                            "files=" + actual.files + "/" + expected.files +
                            ", dirs=" + actual.directories + "/" + expected.directories +
                            ", symlinks=" + actual.symlinks + "/" + expected.symlinks +
                            ", hardlinks=" + actual.hardLinks + "/" + expected.hardLinks +
                            ", bytes=" + actual.writtenBytes +
                            "+hardlinkLogical(" + actual.hardLinkLogicalBytes + ")/" +
                            expected.fileBytes
            );
        }
    }
}
