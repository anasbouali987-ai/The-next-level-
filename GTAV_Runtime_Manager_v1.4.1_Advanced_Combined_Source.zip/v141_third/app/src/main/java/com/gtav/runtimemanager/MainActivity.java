package com.gtav.runtimemanager;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

public final class MainActivity extends Activity implements RuntimeInstallCoordinator.Listener {
    private static final int PICK = 1001;
    private static final int EXPORT_FILE = 1002;
    private static final int EXPORT_MANIFEST = 1003;
    private static final String PREFS = "manager";
    private static final String LAST_URI = "last_uri";

    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private final AtomicBoolean localCancelled = new AtomicBoolean(false);

    private RuntimeInstallCoordinator coordinator;
    private PackageInfo pkg;
    private boolean localBusy;
    private long lastTerminalHandled;
    private File pendingExportFile;

    private Button selectButton;
    private Button verifyButton;
    private Button diagnoseButton;
    private Button installButton;
    private Button reinstallButton;
    private Button recheckInstalledButton;
    private Button deleteButton;
    private Button cancelButton;
    private Button exportVerifyButton;
    private Button exportInstallButton;
    private Button exportManifestButton;
    private Button exportDiagnosticsButton;
    private Button errorLogButton;
    private Button crashReportButton;
    private Button deleteCrashButton;
    private Button settingsButton;

    private TextView packageStatus;
    private TextView packageDetails;
    private TextView integrityText;
    private TextView diagnosticText;
    private TextView installStateText;
    private TextView crashText;
    private TextView stageText;
    private TextView progressText;
    private TextView currentFileText;
    private TextView engineText;
    private TextView statsText;
    private TextView memoryText;
    private ProgressBar progressBar;
    private View progressCard;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        coordinator = RuntimeInstallCoordinator.get(this);
        bind();
        refreshCrashState();
        refreshInstalled();
        String saved = getSharedPreferences(PREFS, 0).getString(LAST_URI, "");
        if (!saved.isEmpty()) inspect(Uri.parse(saved));
    }

    @Override
    protected void onStart() {
        super.onStart();
        coordinator.addListener(this);
    }

    @Override
    protected void onStop() {
        coordinator.removeListener(this);
        super.onStop();
    }

    private void bind() {
        selectButton = findViewById(R.id.selectButton);
        verifyButton = findViewById(R.id.verifyButton);
        diagnoseButton = findViewById(R.id.diagnoseButton);
        installButton = findViewById(R.id.installButton);
        reinstallButton = findViewById(R.id.reinstallButton);
        recheckInstalledButton = findViewById(R.id.recheckInstalledButton);
        deleteButton = findViewById(R.id.deleteButton);
        cancelButton = findViewById(R.id.cancelButton);
        exportVerifyButton = findViewById(R.id.exportVerifyButton);
        exportInstallButton = findViewById(R.id.exportInstallButton);
        exportManifestButton = findViewById(R.id.exportManifestButton);
        exportDiagnosticsButton = findViewById(R.id.exportDiagnosticsButton);
        errorLogButton = findViewById(R.id.errorLogButton);
        crashReportButton = findViewById(R.id.crashReportButton);
        deleteCrashButton = findViewById(R.id.deleteCrashButton);
        settingsButton = findViewById(R.id.settingsButton);

        packageStatus = findViewById(R.id.packageStatus);
        packageDetails = findViewById(R.id.packageDetails);
        integrityText = findViewById(R.id.integrityText);
        diagnosticText = findViewById(R.id.diagnosticText);
        installStateText = findViewById(R.id.installStateText);
        crashText = findViewById(R.id.crashText);
        stageText = findViewById(R.id.stageText);
        progressText = findViewById(R.id.progressText);
        currentFileText = findViewById(R.id.currentFileText);
        engineText = findViewById(R.id.engineText);
        statsText = findViewById(R.id.statsText);
        memoryText = findViewById(R.id.memoryText);
        progressBar = findViewById(R.id.progressBar);
        progressCard = findViewById(R.id.progressCard);

        selectButton.setOnClickListener(view -> choose());
        verifyButton.setOnClickListener(view -> verify());
        diagnoseButton.setOnClickListener(view -> diagnose());
        installButton.setOnClickListener(view -> confirmInstall(false));
        reinstallButton.setOnClickListener(view -> confirmInstall(true));
        recheckInstalledButton.setOnClickListener(view -> recheckInstalled());
        deleteButton.setOnClickListener(view -> confirmDelete());
        cancelButton.setOnClickListener(view -> {
            localCancelled.set(true);
            coordinator.cancel();
            stageText.setText("جارٍ إلغاء العملية بأمان…");
        });
        exportVerifyButton.setOnClickListener(view ->
                exportFile(RuntimeLogWriter.verificationReport(this),
                        "GTAV_Runtime_Verification_Report.txt", "text/plain"));
        exportInstallButton.setOnClickListener(view ->
                exportFile(RuntimeLogWriter.installationReport(this),
                        "GTAV_Runtime_Installation_Report.txt", "text/plain"));
        exportManifestButton.setOnClickListener(view -> exportManifest());
        exportDiagnosticsButton.setOnClickListener(view -> exportDiagnostics());
        errorLogButton.setOnClickListener(view ->
                showText("آخر سجل تثبيت", ErrorLogger.read(this), false));
        crashReportButton.setOnClickListener(view ->
                showText("تقرير الانهيار", RuntimeCrashReporter.read(this), false));
        deleteCrashButton.setOnClickListener(view -> {
            RuntimeCrashReporter.delete(this);
            refreshCrashState();
            toast("تم حذف تقرير الانهيار");
        });
        settingsButton.setOnClickListener(view -> settings());
        updateButtons();
    }

    private void choose() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("application/zip");
        intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{
                "application/zip",
                "application/x-zip-compressed",
                "application/octet-stream"
        });
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION |
                Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(intent, PICK);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();

        if (requestCode == PICK) {
            try {
                getContentResolver().takePersistableUriPermission(
                        uri,
                        data.getFlags() & Intent.FLAG_GRANT_READ_URI_PERMISSION
                );
            } catch (Throwable ignored) {
            }
            getSharedPreferences(PREFS, 0).edit().putString(LAST_URI, uri.toString()).apply();
            VerificationStore.clear(this);
            inspect(uri);
            return;
        }

        if (requestCode == EXPORT_MANIFEST) {
            writeManifest(uri);
        } else if (requestCode == EXPORT_FILE) {
            writeFile(uri, pendingExportFile);
        }
    }

    private void inspect(Uri uri) {
        setLocalBusy(true, "قراءة الحزمة");
        io.execute(() -> {
            try {
                PackageInfo read = new PackageReader(getContentResolver()).read(uri);
                runOnUiThread(() -> {
                    pkg = read;
                    showPackage();
                    restoreVerification();
                    refreshInstalled();
                    setLocalBusy(false, "");
                });
            } catch (Throwable error) {
                ErrorLogger.log(this, "قراءة الحزمة", error);
                runOnUiThread(() -> {
                    pkg = null;
                    packageStatus.setText("❌ Runtime تالف أو غير مدعوم");
                    packageStatus.setTextColor(getColor(R.color.invalid));
                    packageDetails.setText(message(error));
                    setLocalBusy(false, "");
                    updateButtons();
                });
            }
        });
    }

    private void showPackage() {
        RuntimeManifest manifest = pkg.manifest;
        File root = StorageLocations.runtimesRoot(this);
        long required = RuntimeInstaller.requiredSpace(manifest);
        long free = root.getUsableSpace();
        packageStatus.setText("✅ Runtime صالح ومتوافق");
        packageStatus.setTextColor(getColor(R.color.valid));
        packageDetails.setText(
                "الملف: " + pkg.displayName +
                        "\nحجم الحزمة: " + Formatters.bytes(pkg.zipSize) +
                        "\nعدد عناصر ZIP: " + pkg.zipEntryCount +
                        "\n\nRuntime ID: " + manifest.runtimeId +
                        "\nVersion: " + manifest.version +
                        "\nSchema: " + manifest.schema +
                        "\nHost → Guest: " + manifest.host + " → " + manifest.guest +
                        "\nWine: " + manifest.components.wine +
                        "\nBox64: " + manifest.components.box64 +
                        "\nDXVK: " + manifest.components.dxvk +
                        "\nPayload: " + manifest.payload.path +
                        "\nPayload size: " + Formatters.bytes(manifest.payload.sizeBytes) +
                        "\nالحجم المتوقع بعد الاستخراج: " +
                        Formatters.bytes(manifest.expectedStats.fileBytes) +
                        "\nالعناصر المتوقعة: " + manifest.expectedStats.totalNodes() +
                        "\nالمساحة المطلوبة مع هامش 25%: " + Formatters.bytes(required) +
                        "\nالمساحة المتوفرة: " + Formatters.bytes(free) +
                        "\nمسار التثبيت: " + root.getAbsolutePath()
        );
        updateButtons();
    }

    private void restoreVerification() {
        VerificationStore.Record record = VerificationStore.validFor(this, pkg);
        if (record != null && record.sha.equalsIgnoreCase(pkg.manifest.payload.sha256)) {
            integrityText.setText(
                    "✅ SHA-256 مطابق (نتيجة محفوظة صالحة)" +
                            "\nآخر تحقق: " + Formatters.date(record.verifiedAt) +
                            "\nالبصمة: " + record.sha
            );
            integrityText.setTextColor(getColor(R.color.valid));
        } else {
            integrityText.setText("⚠️ لم يكتمل الفحص الكامل");
            integrityText.setTextColor(getColor(R.color.warning));
        }
        updateButtons();
    }

    private void verify() {
        if (pkg == null) return;
        localCancelled.set(false);
        setLocalBusy(true, "التحقق من SHA-256");
        io.execute(() -> {
            try {
                IntegrityVerifier.Result result = IntegrityVerifier.verify(
                        new PackageReader(getContentResolver()), pkg, verificationProgress());
                if (!result.cancelled) {
                    VerificationStore.save(this, pkg, result.calculated,
                            result.bytes, result.finished);
                    RuntimeLogWriter.writeVerificationReport(
                            this, pkg, pkg.manifest.payload.sha256,
                            result.calculated, result.match,
                            result.bytes, result.finished);
                }
                runOnUiThread(() -> {
                    if (result.cancelled) {
                        integrityText.setText("⚠️ لم يكتمل الفحص — تم الإلغاء");
                        integrityText.setTextColor(getColor(R.color.warning));
                    } else {
                        integrityText.setText(
                                (result.match ? "✅ SHA-256 مطابق" : "❌ SHA-256 غير مطابق") +
                                        "\nExpected: " + pkg.manifest.payload.sha256 +
                                        "\nCalculated: " + result.calculated +
                                        "\nالبايتات: " + result.bytes +
                                        "\nالمدة: " + Formatters.duration(result.elapsedMs)
                        );
                        integrityText.setTextColor(getColor(
                                result.match ? R.color.valid : R.color.invalid));
                    }
                    setLocalBusy(false, "");
                    updateButtons();
                });
            } catch (Throwable error) {
                ErrorLogger.log(this, "التحقق من SHA-256", error);
                runOnUiThread(() -> {
                    integrityText.setText("❌ فشل التحقق من SHA-256\n" + message(error));
                    integrityText.setTextColor(getColor(R.color.invalid));
                    setLocalBusy(false, "");
                });
            }
        });
    }

    private void diagnose() {
        if (pkg == null) return;
        if (!coordinator.startDiagnostics(pkg)) {
            toast("هناك عملية أخرى قيد التنفيذ");
        }
        updateButtons();
    }

    private void confirmInstall(boolean replace) {
        if (pkg == null) return;
        VerificationStore.Record record = VerificationStore.validFor(this, pkg);
        if (record == null || !record.sha.equalsIgnoreCase(pkg.manifest.payload.sha256)) {
            toast("يجب إكمال تحقق SHA-256 المطابق أولًا");
            return;
        }

        File root = StorageLocations.runtimesRoot(this);
        long required = RuntimeInstaller.requiredSpace(pkg.manifest);
        long free = root.getUsableSpace();
        if (free < required) {
            toast("مساحة غير كافية. المطلوب: " + Formatters.bytes(required) +
                    "، المتاح: " + Formatters.bytes(free));
            return;
        }

        new AlertDialog.Builder(this)
                .setTitle(replace ? "إعادة تثبيت Runtime" : "تثبيت Runtime")
                .setMessage(
                        "سيُجرى تشخيص كامل قبل الاستخراج.\n\n" +
                                "المساحة المطلوبة مع هامش 25%: " + Formatters.bytes(required) +
                                "\nالمساحة المتوفرة: " + Formatters.bytes(free) +
                                "\nالمسار: " + root.getAbsolutePath()
                )
                .setNegativeButton("إلغاء", null)
                .setPositiveButton("بدء", (dialog, which) -> {
                    if (!coordinator.startInstall(pkg, replace)) {
                        toast("هناك عملية تثبيت أخرى قيد التنفيذ");
                    }
                    updateButtons();
                })
                .show();
    }

    private void recheckInstalled() {
        if (pkg == null) return;
        InstalledRuntime installed = InstalledRuntime.find(
                StorageLocations.runtimesRoot(this), pkg.manifest.runtimeId);
        if (installed == null) {
            toast("Runtime غير مثبت");
            return;
        }
        setLocalBusy(true, "التحقق من Runtime المثبت");
        io.execute(() -> {
            try {
                RuntimePostVerifier.Result result = RuntimeInstaller.verifyInstalled(
                        this, installed.path, pkg.manifest,
                        (stage, done, total, compressed, stats, current, zstd, tar, message, force) ->
                                runOnUiThread(() -> updateSimpleProgress(stage.label, done, total, current))
                );
                runOnUiThread(() -> {
                    setLocalBusy(false, "");
                    new AlertDialog.Builder(this)
                            .setTitle("✅ Runtime المثبت سليم")
                            .setMessage(result.message + "\nالملفات المفحوصة: " + result.checkedFiles)
                            .setPositiveButton("حسنًا", null)
                            .show();
                });
            } catch (Throwable error) {
                ErrorLogger.log(this, "إعادة فحص Runtime", error);
                runOnUiThread(() -> {
                    setLocalBusy(false, "");
                    new AlertDialog.Builder(this)
                            .setTitle("❌ فشل فحص Runtime")
                            .setMessage(message(error))
                            .setPositiveButton("حسنًا", null)
                            .show();
                });
            }
        });
    }

    private void confirmDelete() {
        if (pkg == null) return;
        File root = StorageLocations.runtimesRoot(this);
        InstalledRuntime installed = InstalledRuntime.find(root, pkg.manifest.runtimeId);
        if (installed == null) {
            toast("Runtime غير مثبت");
            return;
        }
        new AlertDialog.Builder(this)
                .setTitle("حذف Runtime")
                .setMessage("سيتم حذف Runtime بالكامل وتحرير " + Formatters.bytes(installed.size))
                .setNegativeButton("إلغاء", null)
                .setPositiveButton("حذف", (dialog, which) -> {
                    setLocalBusy(true, "حذف Runtime");
                    io.execute(() -> {
                        try {
                            FileTools.deleteTree(root, installed.path);
                            runOnUiThread(() -> {
                                setLocalBusy(false, "");
                                refreshInstalled();
                                toast("تم حذف Runtime");
                            });
                        } catch (Throwable error) {
                            ErrorLogger.log(this, "حذف Runtime", error);
                            runOnUiThread(() -> {
                                setLocalBusy(false, "");
                                toast("تعذر الحذف: " + message(error));
                            });
                        }
                    });
                })
                .show();
    }

    @Override
    public void onInstallStateChanged(InstallSnapshot snapshot) {
        updateInstallProgress(snapshot);
        if (snapshot.stage == InstallStage.IDLE && !snapshot.message.isEmpty()) {
            diagnosticText.setText("✅ " + snapshot.message +
                    "\nZstandard: " + snapshot.zstdStatus +
                    "\nTAR: " + snapshot.tarStatus +
                    "\nالذاكرة الحرة: " + Formatters.bytes(snapshot.memory.freeBytes));
            diagnosticText.setTextColor(getColor(R.color.valid));
        }

        boolean terminal = snapshot.stage == InstallStage.COMPLETED ||
                snapshot.stage == InstallStage.FAILED ||
                snapshot.stage == InstallStage.CANCELLED;
        if (terminal && snapshot.updatedAt != lastTerminalHandled) {
            lastTerminalHandled = snapshot.updatedAt;
            refreshInstalled();
            refreshCrashState();
            if (snapshot.stage == InstallStage.COMPLETED) {
                toast("تم تثبيت Runtime بنجاح");
            } else if (snapshot.stage == InstallStage.CANCELLED) {
                new AlertDialog.Builder(this)
                        .setTitle("تم إلغاء التثبيت")
                        .setMessage("تم تنظيف مجلد .installing ولم تُمس النسخة السابقة.")
                        .setPositiveButton("حسنًا", null)
                        .show();
            } else {
                new AlertDialog.Builder(this)
                        .setTitle("تعذر إكمال التثبيت")
                        .setMessage(
                                "الكود: " + (snapshot.errorCode == null ? "UNKNOWN" : snapshot.errorCode.name()) +
                                        "\nالمرحلة: " + snapshot.stage.label +
                                        "\nالملف: " + (snapshot.currentFile.isEmpty() ? "—" : snapshot.currentFile) +
                                        "\n\n" + snapshot.message
                        )
                        .setPositiveButton("حسنًا", null)
                        .setNeutralButton("عرض التقرير", (dialog, which) ->
                                showText("تقرير الخطأ", RuntimeCrashReporter.read(this), false))
                        .show();
            }
        }
        updateButtons();
    }

    private void updateInstallProgress(InstallSnapshot snapshot) {
        boolean show = snapshot.running || snapshot.stage == InstallStage.COMPLETED ||
                snapshot.stage == InstallStage.FAILED || snapshot.stage == InstallStage.CANCELLED;
        if (!localBusy) progressCard.setVisibility(show ? View.VISIBLE : View.GONE);
        if (localBusy) return;

        stageText.setText(snapshot.stage.label +
                (snapshot.message.isEmpty() ? "" : " — " + snapshot.message));
        progressBar.setIndeterminate(snapshot.total <= 0);
        if (snapshot.total > 0) {
            int progress = (int) Math.min(1000,
                    snapshot.done * 1000L / Math.max(1, snapshot.total));
            progressBar.setProgress(progress);
            progressText.setText(
                    (progress / 10.0) + "% — " + Formatters.bytes(snapshot.done) +
                            " / " + Formatters.bytes(snapshot.total) +
                            "\nالمضغوط المقروء: " + Formatters.bytes(snapshot.compressedDone) +
                            " — المكتوب: " + Formatters.bytes(snapshot.writtenBytes) +
                            "\nالسرعة: " + Formatters.bytes(snapshot.speedBytesPerSecond) + "/s" +
                            " — المنقضي: " + Formatters.duration(snapshot.elapsedMs) +
                            " — المتبقي: " + (snapshot.etaMs < 0 ? "غير معروف" :
                            Formatters.duration(snapshot.etaMs))
            );
        } else {
            progressText.setText("جارٍ التنفيذ…");
        }
        currentFileText.setText(snapshot.currentFile.isEmpty()
                ? "الملف الحالي: —" : "الملف الحالي: " + snapshot.currentFile);
        engineText.setText("Zstandard: " + snapshot.zstdStatus +
                "\nTAR: " + snapshot.tarStatus);
        statsText.setText(
                "الملفات: " + snapshot.stats.files +
                        " — المجلدات: " + snapshot.stats.directories +
                        "\nSymlinks: " + snapshot.stats.symlinks +
                        " — Hard Links: " + snapshot.stats.hardLinks
        );
        memoryText.setText(
                "الذاكرة الحرة: " + Formatters.bytes(snapshot.memory.freeBytes) +
                        " — المستخدمة: " + Formatters.bytes(snapshot.memory.usedBytes) +
                        "\nالحد الأقصى: " + Formatters.bytes(snapshot.memory.maxBytes)
        );
        cancelButton.setEnabled(snapshot.running);
    }

    private void updateSimpleProgress(String stage, long done, long total, String current) {
        progressCard.setVisibility(View.VISIBLE);
        stageText.setText(stage);
        progressBar.setIndeterminate(total <= 0);
        if (total > 0) progressBar.setProgress((int) Math.min(1000, done * 1000L / total));
        progressText.setText(done + " / " + total);
        currentFileText.setText(current == null ? "" : current);
    }

    private OperationProgress verificationProgress() {
        final long[] lastUi = {0};
        return new OperationProgress() {
            @Override
            public void update(String stage, long done, long total,
                               String currentFile, long startedAtMs) {
                long now = SystemClock.elapsedRealtime();
                if (now - lastUi[0] < 300 && done < total) return;
                lastUi[0] = now;
                runOnUiThread(() -> {
                    progressCard.setVisibility(View.VISIBLE);
                    stageText.setText(stage);
                    progressBar.setIndeterminate(total <= 0);
                    if (total > 0) {
                        int progress = (int) Math.min(1000, done * 1000L / total);
                        progressBar.setProgress(progress);
                        long elapsed = Math.max(1, now - startedAtMs);
                        long speed = done * 1000L / elapsed;
                        long eta = speed > 0 && total > done ? (total - done) * 1000L / speed : -1;
                        progressText.setText(
                                (progress / 10.0) + "% — " + Formatters.bytes(done) +
                                        " / " + Formatters.bytes(total) +
                                        "\nالسرعة: " + Formatters.bytes(speed) + "/s" +
                                        " — المتبقي: " + (eta < 0 ? "غير معروف" : Formatters.duration(eta))
                        );
                    }
                    currentFileText.setText("الملف الحالي: " + currentFile);
                    MemorySnapshot memory = MemorySnapshot.capture();
                    memoryText.setText("الذاكرة الحرة: " + Formatters.bytes(memory.freeBytes) +
                            " — المستخدمة: " + Formatters.bytes(memory.usedBytes) +
                            "\nالحد الأقصى: " + Formatters.bytes(memory.maxBytes));
                });
            }

            @Override public boolean isCancelled() { return localCancelled.get(); }
        };
    }

    private void refreshInstalled() {
        if (pkg == null) {
            installStateText.setText("اختر حزمة لمعرفة حالة Runtime المقابل");
            installStateText.setTextColor(getColor(R.color.warning));
            updateButtons();
            return;
        }
        InstalledRuntime installed = InstalledRuntime.find(
                StorageLocations.runtimesRoot(this), pkg.manifest.runtimeId);
        if (installed == null) {
            installStateText.setText("Runtime غير مثبت");
            installStateText.setTextColor(getColor(R.color.warning));
        } else {
            installStateText.setText(
                    "✅ Runtime مثبت" +
                            "\nالإصدار: " + installed.version +
                            "\nتاريخ التثبيت: " + installed.installedAt +
                            "\nالحجم المستخدم: " + Formatters.bytes(installed.size) +
                            "\nالملفات: " + installed.stats.files +
                            " — المجلدات: " + installed.stats.directories +
                            "\nSymlinks: " + installed.stats.symlinks +
                            " — Hard Links: " + installed.stats.hardLinks +
                            "\nالمسار: " + installed.path.getAbsolutePath()
            );
            installStateText.setTextColor(getColor(R.color.valid));
        }
        updateButtons();
    }

    private void refreshCrashState() {
        boolean has = RuntimeCrashReporter.exists(this);
        crashText.setText(has
                ? "⚠️ يوجد تقرير خطأ/انهيار محفوظ ويمكن مراجعته أو تصديره ضمن حزمة التشخيص."
                : "لا يوجد تقرير انهيار محفوظ.");
        crashText.setTextColor(getColor(has ? R.color.warning : R.color.valid));
        updateButtons();
    }

    private void setLocalBusy(boolean value, String stage) {
        localBusy = value;
        localCancelled.set(false);
        if (value) {
            progressCard.setVisibility(View.VISIBLE);
            stageText.setText(stage);
            progressBar.setIndeterminate(true);
            progressText.setText("جارٍ البدء…");
            currentFileText.setText("الملف الحالي: —");
            engineText.setText("Zstandard: —\nTAR: —");
            statsText.setText("الملفات: 0 — المجلدات: 0\nSymlinks: 0 — Hard Links: 0");
            MemorySnapshot memory = MemorySnapshot.capture();
            memoryText.setText("الذاكرة الحرة: " + Formatters.bytes(memory.freeBytes) +
                    " — المستخدمة: " + Formatters.bytes(memory.usedBytes) +
                    "\nالحد الأقصى: " + Formatters.bytes(memory.maxBytes));
        } else if (!coordinator.current().running) {
            progressCard.setVisibility(View.GONE);
        }
        updateButtons();
    }

    private void updateButtons() {
        boolean busy = localBusy || coordinator.isRunning();
        boolean hasPackage = pkg != null;
        VerificationStore.Record record = hasPackage ? VerificationStore.validFor(this, pkg) : null;
        boolean verified = record != null && record.sha.equalsIgnoreCase(pkg.manifest.payload.sha256);
        InstalledRuntime installed = hasPackage ? InstalledRuntime.find(
                StorageLocations.runtimesRoot(this), pkg.manifest.runtimeId) : null;

        selectButton.setEnabled(!busy);
        verifyButton.setEnabled(hasPackage && !busy);
        diagnoseButton.setEnabled(hasPackage && !busy);
        installButton.setEnabled(hasPackage && verified && !busy && installed == null);
        reinstallButton.setEnabled(hasPackage && verified && !busy && installed != null);
        recheckInstalledButton.setEnabled(hasPackage && !busy && installed != null);
        deleteButton.setEnabled(hasPackage && !busy && installed != null);
        cancelButton.setEnabled(busy);
        exportVerifyButton.setEnabled(!busy && RuntimeLogWriter.verificationReport(this).isFile());
        exportInstallButton.setEnabled(!busy && RuntimeLogWriter.installationReport(this).isFile());
        exportManifestButton.setEnabled(hasPackage && !busy);
        exportDiagnosticsButton.setEnabled(!busy);
        errorLogButton.setEnabled(!busy);
        crashReportButton.setEnabled(!busy && RuntimeCrashReporter.exists(this));
        deleteCrashButton.setEnabled(!busy && RuntimeCrashReporter.exists(this));
        settingsButton.setEnabled(!busy);
    }

    private void exportFile(File source, String name, String type) {
        if (source == null || !source.isFile()) {
            toast("لا يوجد تقرير متاح");
            return;
        }
        pendingExportFile = source;
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType(type);
        intent.putExtra(Intent.EXTRA_TITLE, name);
        startActivityForResult(intent, EXPORT_FILE);
    }

    private void exportManifest() {
        if (pkg == null) return;
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("application/json");
        intent.putExtra(Intent.EXTRA_TITLE, "runtime_manifest.json");
        startActivityForResult(intent, EXPORT_MANIFEST);
    }

    private void exportDiagnostics() {
        setLocalBusy(true, "إنشاء حزمة التشخيص");
        io.execute(() -> {
            try {
                File diagnostics = DiagnosticsExporter.create(this, pkg);
                runOnUiThread(() -> {
                    setLocalBusy(false, "");
                    exportFile(diagnostics, "GTAV_Runtime_Diagnostics.zip", "application/zip");
                });
            } catch (Throwable error) {
                ErrorLogger.log(this, "إنشاء حزمة التشخيص", error);
                runOnUiThread(() -> {
                    setLocalBusy(false, "");
                    toast("تعذر إنشاء حزمة التشخيص: " + message(error));
                });
            }
        });
    }

    private void writeFile(Uri destination, File source) {
        if (source == null || !source.isFile()) {
            toast("ملف التصدير غير متاح");
            return;
        }
        io.execute(() -> {
            try (BufferedInputStream input = new BufferedInputStream(
                    new FileInputStream(source), 128 * 1024);
                 OutputStream raw = getContentResolver().openOutputStream(destination, "wt")) {
                if (raw == null) throw new IOException("تعذر فتح ملف الحفظ");
                try (BufferedOutputStream output = new BufferedOutputStream(raw, 128 * 1024)) {
                    byte[] buffer = new byte[128 * 1024];
                    int read;
                    while ((read = input.read(buffer)) != -1) output.write(buffer, 0, read);
                }
                runOnUiThread(() -> toast("تم تصدير الملف بنجاح"));
            } catch (Throwable error) {
                ErrorLogger.log(this, "تصدير ملف", error);
                runOnUiThread(() -> toast("تعذر التصدير: " + message(error)));
            }
        });
    }

    private void writeManifest(Uri destination) {
        if (pkg == null) return;
        io.execute(() -> {
            try (OutputStream output = getContentResolver().openOutputStream(destination, "wt")) {
                if (output == null) throw new IOException("تعذر فتح ملف الحفظ");
                OutputStreamWriter writer = new OutputStreamWriter(output, StandardCharsets.UTF_8);
                writer.write(pkg.manifest.rawJson);
                writer.flush();
                runOnUiThread(() -> toast("تم تصدير Manifest بنجاح"));
            } catch (Throwable error) {
                ErrorLogger.log(this, "تصدير Manifest", error);
                runOnUiThread(() -> toast("تعذر التصدير: " + message(error)));
            }
        });
    }

    private void settings() {
        String[] items = {
                "التخزين الداخلي الآمن (مفضل)",
                "مجلد التطبيق الخارجي"
        };
        int checked = "external_app".equals(StorageLocations.mode(this)) ? 1 : 0;
        MemorySnapshot memory = MemorySnapshot.capture();
        new AlertDialog.Builder(this)
                .setTitle("الإعدادات")
                .setSingleChoiceItems(items, checked, (dialog, which) -> {
                    StorageLocations.setMode(this, which == 1 ? "external_app" : "internal");
                    RuntimeInstaller.recoverInterrupted(this);
                    dialog.dismiss();
                    refreshInstalled();
                    if (pkg != null) showPackage();
                })
                .setNeutralButton("حذف الملفات المؤقتة", (dialog, which) -> {
                    RuntimeInstaller.recoverInterrupted(this);
                    toast("تم حذف الملفات المؤقتة واستعادة backup عند الحاجة");
                })
                .setNegativeButton("معلومات التطبيق", (dialog, which) -> showText(
                        "معلومات التطبيق",
                        "GTAV Runtime Manager v1.4.0\n" +
                                "Android API: " + android.os.Build.VERSION.SDK_INT +
                                "\nABIs: " + java.util.Arrays.toString(android.os.Build.SUPPORTED_ABIS) +
                                "\nMemory free: " + Formatters.bytes(memory.freeBytes) +
                                "\nMemory used: " + Formatters.bytes(memory.usedBytes) +
                                "\nMemory max: " + Formatters.bytes(memory.maxBytes) +
                                "\n\nإدارة Runtime فقط، دون PRoot أو Wine أو تشغيل ألعاب.",
                        false
                ))
                .show();
    }

    private void showText(String title, String text, boolean allowClear) {
        TextView view = new TextView(this);
        view.setText(text);
        view.setTextIsSelectable(true);
        view.setPadding(40, 30, 40, 30);
        AlertDialog.Builder builder = new AlertDialog.Builder(this)
                .setTitle(title)
                .setView(view)
                .setPositiveButton("إغلاق", null);
        if (allowClear) {
            builder.setNeutralButton("مسح", (dialog, which) -> ErrorLogger.clear(this));
        }
        builder.show();
    }

    @Override
    public void onBackPressed() {
        if (coordinator != null && coordinator.isRunning()) {
            new AlertDialog.Builder(this)
                    .setTitle("التثبيت جارٍ")
                    .setMessage("هل تريد إلغاء العملية بأمان؟ ستبقى في التطبيق حتى اكتمال التنظيف.")
                    .setNegativeButton("متابعة التثبيت", null)
                    .setPositiveButton("إلغاء العملية", (dialog, which) -> {
                        coordinator.cancel();
                        stageText.setText("جارٍ إلغاء العملية وتنظيف .installing…");
                    })
                    .show();
            return;
        }
        if (localBusy) {
            new AlertDialog.Builder(this)
                    .setTitle("عملية قيد التنفيذ")
                    .setMessage("ألغِ العملية أولًا أو انتظر حتى تنتهي.")
                    .setPositiveButton("حسنًا", null)
                    .show();
            return;
        }
        super.onBackPressed();
    }

    private static String message(Throwable error) {
        return error.getMessage() == null ? error.getClass().getSimpleName() : error.getMessage();
    }

    private void toast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }

    @Override
    protected void onDestroy() {
        localCancelled.set(true);
        io.shutdownNow();
        super.onDestroy();
    }
}
