package com.gtav.runtimemanager;

import android.content.Context;
import android.os.Build;
import android.system.Os;

import com.github.luben.zstd.Zstd;
import com.github.luben.zstd.ZstdInputStream;

import org.apache.commons.compress.archivers.tar.TarArchiveEntry;
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream;

import java.io.BufferedInputStream;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

final class RuntimePreflightChecker {
    static final class Check {
        final String name;
        final boolean ok;
        final String details;

        Check(String name, boolean ok, String details) {
            this.name = name;
            this.ok = ok;
            this.details = details;
        }
    }

    static final class Result {
        final boolean ok;
        final String zstdStatus;
        final String tarStatus;
        final MemorySnapshot memory;
        final List<Check> checks;
        final File reportFile;

        Result(boolean ok, String zstdStatus, String tarStatus, MemorySnapshot memory,
               List<Check> checks, File reportFile) {
            this.ok = ok;
            this.zstdStatus = zstdStatus;
            this.tarStatus = tarStatus;
            this.memory = memory;
            this.checks = checks;
            this.reportFile = reportFile;
        }
    }

    Result check(Context context, PackageReader reader, PackageInfo pkg,
                 File runtimesRoot, long requiredBytes, CancellationToken token,
                 InstallProgressSink progress) throws RuntimeInstallException {
        List<Check> checks = new ArrayList<>();
        String zstdStatus = "غير مهيأ";
        String tarStatus = "غير مهيأ";
        MemorySnapshot memory = MemorySnapshot.capture();
        File probeRoot = new File(runtimesRoot, ".preflight-" + System.nanoTime());

        progress.update(InstallStage.PREFLIGHT, 0, 8, 0, new InstallStats(), "",
                zstdStatus, tarStatus, "بدء التشخيص", true);

        try {
            token.throwIfCancelled(InstallStage.PREFLIGHT);
            checkSpace(runtimesRoot, requiredBytes);
            checks.add(new Check("المساحة", true,
                    "المتاح " + Formatters.bytes(runtimesRoot.getUsableSpace()) +
                            " / المطلوب " + Formatters.bytes(requiredBytes)));
            progress.update(InstallStage.PREFLIGHT, 1, 8, 0, new InstallStats(), "",
                    zstdStatus, tarStatus, "تم فحص المساحة", true);

            if (!probeRoot.mkdirs()) {
                throw new RuntimeInstallException(InstallErrorCode.TEMP_DIRECTORY_FAILED,
                        InstallStage.PREFLIGHT, "تعذر إنشاء مجلد التشخيص");
            }
            File probeFile = new File(probeRoot, "probe.txt");
            try (FileOutputStream output = new FileOutputStream(probeFile)) {
                output.write("GTAV".getBytes(StandardCharsets.UTF_8));
                output.getFD().sync();
            }
            checks.add(new Check("الكتابة", true, probeFile.getAbsolutePath()));
            progress.update(InstallStage.PREFLIGHT, 2, 8, 0, new InstallStats(), probeFile.getName(),
                    zstdStatus, tarStatus, "تم اختبار الكتابة", true);

            new PermissionApplier(new PermissionApplier.AndroidOps())
                    .apply(probeFile, 0600, InstallStage.PREFLIGHT);
            checks.add(new Check("chmod", true, "تم تطبيق 0600"));
            progress.update(InstallStage.PREFLIGHT, 3, 8, 0, new InstallStats(), probeFile.getName(),
                    zstdStatus, tarStatus, "تم اختبار chmod", true);

            File link = new File(probeRoot, "probe-link");
            Os.symlink("probe.txt", link.getAbsolutePath());
            String target = Os.readlink(link.getAbsolutePath());
            if (!"probe.txt".equals(target)) {
                throw new RuntimeInstallException(InstallErrorCode.SYMLINK_FAILED,
                        InstallStage.PREFLIGHT, "هدف Symlink التجريبي غير متوقع");
            }
            checks.add(new Check("Symlink", true, target));
            progress.update(InstallStage.PREFLIGHT, 4, 8, 0, new InstallStats(), link.getName(),
                    zstdStatus, tarStatus, "تم اختبار Symlink", true);

            File renameFrom = new File(probeRoot, "rename-from");
            File renameTo = new File(probeRoot, "rename-to");
            if (!renameFrom.mkdir() || !renameFrom.renameTo(renameTo)) {
                throw new RuntimeInstallException(InstallErrorCode.ATOMIC_RENAME_FAILED,
                        InstallStage.PREFLIGHT, "مكان التثبيت لا يدعم إعادة التسمية المطلوبة");
            }
            checks.add(new Check("Atomic rename", true, "مدعوم داخل نظام الملفات نفسه"));
            progress.update(InstallStage.PREFLIGHT, 5, 8, 0, new InstallStats(), renameTo.getName(),
                    zstdStatus, tarStatus, "تم اختبار rename", true);

            token.throwIfCancelled(InstallStage.PREFLIGHT);
            try {
                int version = Zstd.versionNumber();
                zstdStatus = "جاهز (" + version + ")";
                checks.add(new Check("Zstandard", true, zstdStatus));
            } catch (Throwable error) {
                throw new RuntimeInstallException(
                        InstallErrorCode.ZSTD_NATIVE_LIBRARY_FAILED,
                        InstallStage.PREFLIGHT,
                        "تعذر تحميل مكتبة Zstandard الأصلية على " +
                                java.util.Arrays.toString(Build.SUPPORTED_ABIS),
                        error
                );
            }
            progress.update(InstallStage.PREFLIGHT, 6, 8, 0, new InstallStats(), pkg.manifest.payload.path,
                    zstdStatus, tarStatus, "تم تحميل Zstandard", true);

            try (SeekableZipReader zip = reader.open(pkg.uri)) {
                if (!zip.contains(pkg.manifest.payload.path)) {
                    throw new RuntimeInstallException(
                            InstallErrorCode.PAYLOAD_NOT_FOUND,
                            InstallStage.PREFLIGHT,
                            "Payload غير موجود: " + pkg.manifest.payload.path
                    );
                }
                try (InputStream payload = zip.openEntry(pkg.manifest.payload.path);
                     ZstdInputStream zstd = new ZstdInputStream(new BufferedInputStream(payload, 256 * 1024));
                     TarArchiveInputStream tar = new TarArchiveInputStream(
                             new BufferedInputStream(zstd, 256 * 1024))) {
                    TarArchiveEntry first = tar.getNextTarEntry();
                    if (first == null || first.getName() == null || first.getName().isEmpty()) {
                        throw new RuntimeInstallException(InstallErrorCode.TAR_INVALID,
                                InstallStage.PREFLIGHT, "لم يتم العثور على أول TAR entry");
                    }
                    String firstName = first.getName();
                    if (!(".".equals(firstName) || "./".equals(firstName))) {
                        try {
                            RuntimeManifest.validateRelative(firstName);
                        } catch (IllegalArgumentException unsafe) {
                            throw new RuntimeInstallException(
                                    InstallErrorCode.TAR_UNSAFE_PATH,
                                    InstallStage.PREFLIGHT,
                                    unsafe.getMessage(), firstName, unsafe);
                        }
                    }
                    tarStatus = "جاهز — أول عنصر: " + firstName;
                    checks.add(new Check("TAR", true, tarStatus));
                }
            } catch (RuntimeInstallException error) {
                throw error;
            } catch (UnsatisfiedLinkError error) {
                throw new RuntimeInstallException(InstallErrorCode.ZSTD_NATIVE_LIBRARY_FAILED,
                        InstallStage.PREFLIGHT, "فشل محرك Zstandard الأصلي", error);
            } catch (Throwable error) {
                throw new RuntimeInstallException(InstallErrorCode.TAR_INVALID,
                        InstallStage.PREFLIGHT, "تعذر فك أول كتلة وقراءة TAR", error);
            }
            progress.update(InstallStage.PREFLIGHT, 7, 8, 0, new InstallStats(), pkg.manifest.payload.path,
                    zstdStatus, tarStatus, "تم اختبار Zstd وTAR", true);

            memory = MemorySnapshot.capture();
            checks.add(new Check("الذاكرة", true,
                    "free=" + Formatters.bytes(memory.freeBytes) +
                            ", used=" + Formatters.bytes(memory.usedBytes) +
                            ", max=" + Formatters.bytes(memory.maxBytes)));
            File report = writeReport(context, checks, zstdStatus, tarStatus, memory, true, "");
            progress.update(InstallStage.PREFLIGHT, 8, 8, 0, new InstallStats(), "",
                    zstdStatus, tarStatus, "اكتمل التشخيص بنجاح", true);
            return new Result(true, zstdStatus, tarStatus, memory, checks, report);
        } catch (RuntimeInstallException error) {
            checks.add(new Check("النتيجة", false, error.getMessage()));
            writeReport(context, checks, zstdStatus, tarStatus, MemorySnapshot.capture(), false,
                    error.code.name() + ": " + error.getMessage());
            throw error;
        } catch (OutOfMemoryError error) {
            RuntimeInstallException wrapped = new RuntimeInstallException(
                    InstallErrorCode.OUT_OF_MEMORY,
                    InstallStage.PREFLIGHT,
                    "نفدت ذاكرة التطبيق أثناء التشخيص",
                    error
            );
            checks.add(new Check("الذاكرة", false, wrapped.getMessage()));
            writeReport(context, checks, zstdStatus, tarStatus, MemorySnapshot.capture(), false,
                    wrapped.code.name());
            throw wrapped;
        } catch (Throwable error) {
            RuntimeInstallException wrapped = new RuntimeInstallException(
                    InstallErrorCode.UNKNOWN,
                    InstallStage.PREFLIGHT,
                    "فشل تشخيص بيئة التثبيت: " + message(error),
                    error
            );
            checks.add(new Check("النتيجة", false, wrapped.getMessage()));
            writeReport(context, checks, zstdStatus, tarStatus, MemorySnapshot.capture(), false,
                    wrapped.code.name());
            throw wrapped;
        } finally {
            FileTools.deleteTreeQuietly(runtimesRoot, probeRoot, null);
        }
    }

    private static void checkSpace(File root, long requiredBytes) throws RuntimeInstallException {
        long free = root.getUsableSpace();
        if (free < requiredBytes) {
            throw new RuntimeInstallException(InstallErrorCode.NO_SPACE, InstallStage.PREFLIGHT,
                    "مساحة غير كافية. المطلوب " + Formatters.bytes(requiredBytes) +
                            " والمتاح " + Formatters.bytes(free));
        }
    }

    private static File writeReport(Context context, List<Check> checks,
                                    String zstd, String tar, MemorySnapshot memory,
                                    boolean success, String error) {
        File report = RuntimeLogWriter.diagnosticReport(context);
        try (BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(
                new FileOutputStream(report, false), StandardCharsets.UTF_8), 32 * 1024)) {
            writer.write("GTAV Runtime Installation Diagnostic Report\n");
            writer.write("===========================================\n");
            writer.write("Result: " + (success ? "SUCCESS" : "FAILED") + "\n");
            writer.write("Zstandard: " + zstd + "\n");
            writer.write("TAR: " + tar + "\n");
            writer.write("Memory free: " + memory.freeBytes + "\n");
            writer.write("Memory used: " + memory.usedBytes + "\n");
            writer.write("Memory max: " + memory.maxBytes + "\n");
            if (!error.isEmpty()) writer.write("Error: " + error + "\n");
            writer.write("\nChecks\n------\n");
            for (Check check : checks) {
                writer.write((check.ok ? "PASS" : "FAIL") + " | " + check.name + " | " + check.details + "\n");
            }
        } catch (Throwable ignored) {
        }
        return report;
    }

    private static String message(Throwable error) {
        return error.getMessage() == null ? error.getClass().getSimpleName() : error.getMessage();
    }
}
