package com.gtav.runtimemanager;

import android.content.Context;
import android.os.SystemClock;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;

final class RuntimeInstaller {
    static final class InstallResult {
        final File path;
        final long size;
        final InstallStats stats;
        final long startedWallClock;
        final long finishedWallClock;
        final long elapsedMs;
        final File logFile;

        InstallResult(File path, long size, InstallStats stats,
                      long startedWallClock, long finishedWallClock,
                      long elapsedMs, File logFile) {
            this.path = path;
            this.size = size;
            this.stats = stats.copy();
            this.startedWallClock = startedWallClock;
            this.finishedWallClock = finishedWallClock;
            this.elapsedMs = elapsedMs;
            this.logFile = logFile;
        }
    }

    private final Context context;
    private final PackageReader reader;
    private final RuntimePreflightChecker preflightChecker;
    private final RuntimeExtractor extractor;
    private final RuntimePostVerifier postVerifier;

    RuntimeInstaller(Context context) {
        this.context = context.getApplicationContext();
        this.reader = new PackageReader(this.context.getContentResolver());
        this.preflightChecker = new RuntimePreflightChecker();
        this.extractor = new RuntimeExtractor();
        this.postVerifier = new RuntimePostVerifier();
    }

    InstallResult install(PackageInfo pkg, boolean replace,
                          CancellationToken token, InstallProgressSink upstream)
            throws RuntimeInstallException {
        long startedWall = System.currentTimeMillis();
        long startedElapsed = SystemClock.elapsedRealtime();
        File root = StorageLocations.runtimesRoot(context);
        String safeId = RuntimePaths.safeId(pkg.manifest.runtimeId);
        File target = new File(root, safeId);
        File temp = new File(root, safeId + ".installing");
        File backup = new File(root, safeId + ".backup");
        RuntimeLogWriter log = null;
        InstallStateStore stateStore = null;
        PersistingSink progress = null;
        InstallStats stats = new InstallStats();

        try {
            log = new RuntimeLogWriter(context, "install");
            log.log("INSTALL_REQUESTED runtime=" + pkg.manifest.runtimeId + " replace=" + replace);
            recoverForRuntime(root, target, temp, backup, log);

            if (target.exists() && !replace) {
                throw new RuntimeInstallException(
                        InstallErrorCode.RUNTIME_ALREADY_INSTALLED,
                        InstallStage.PREPARING,
                        "Runtime مثبت مسبقًا"
                );
            }

            if (!temp.mkdirs()) {
                throw new RuntimeInstallException(
                        InstallErrorCode.TEMP_DIRECTORY_FAILED,
                        InstallStage.PREPARING,
                        "تعذر إنشاء مجلد التثبيت المؤقت: " + temp.getAbsolutePath()
                );
            }

            stateStore = new InstallStateStore(context, temp, pkg);
            progress = new PersistingSink(upstream, stateStore, startedElapsed);
            progress.update(InstallStage.PREPARING, 0,
                    Math.max(1, pkg.manifest.expectedStats.fileBytes),
                    0, stats, "", "غير مهيأ", "غير مهيأ",
                    "تم إنشاء مجلد .installing", true);

            long requiredBytes = requiredSpace(pkg.manifest);
            RuntimePreflightChecker.Result preflight = preflightChecker.check(
                    context, reader, pkg, root, requiredBytes, token, progress);
            log.log("PREFLIGHT_OK zstd=" + preflight.zstdStatus + " tar=" + preflight.tarStatus);

            token.throwIfCancelled(InstallStage.PREPARING);
            VerificationStore.Record verification = VerificationStore.validFor(context, pkg);
            if (verification == null ||
                    !verification.sha.equalsIgnoreCase(pkg.manifest.payload.sha256)) {
                throw new RuntimeInstallException(
                        InstallErrorCode.POST_VERIFICATION_FAILED,
                        InstallStage.PREPARING,
                        "نتيجة تحقق SHA-256 الكاملة غير موجودة أو غير صالحة"
                );
            }

            stats = extractor.extract(reader, pkg, temp, token, progress, log);
            progress.update(InstallStage.POST_VERIFY, 0,
                    Math.max(1, pkg.manifest.requiredFiles.size()),
                    pkg.manifest.payload.sizeBytes, stats, "",
                    "جاهز", "جاهز", "بدء التحقق بعد التثبيت", true);
            RuntimePostVerifier.Result verificationResult = postVerifier.verify(
                    temp, pkg.manifest, stats, token, progress, log);
            log.log("POST_VERIFICATION_RESULT " + verificationResult.message);

            ensurePackageUnchanged(pkg);
            token.throwIfCancelled(InstallStage.FINALIZING);

            writeText(new File(temp, "runtime_manifest.json"), pkg.manifest.rawJson);
            // اكتب حالة النجاح داخل المجلد المؤقت ولكن بمسار التثبيت النهائي.
            // هكذا تدخل ملفات الحالة ضمن عملية النقل الذرية نفسها.
            InstallStateStore.writeComplete(temp, target, pkg, stats);

            progress.update(InstallStage.FINALIZING, 0, 1,
                    pkg.manifest.payload.sizeBytes, stats, "",
                    "جاهز", "جاهز", "تنفيذ التثبيت الذري", true);
            try {
                AtomicRuntimeSwap.promote(
                        temp,
                        target,
                        backup,
                        replace,
                        new AtomicRuntimeSwap.AndroidOps(root, log)
                );
            } catch (IOException error) {
                throw new RuntimeInstallException(
                        InstallErrorCode.ATOMIC_RENAME_FAILED,
                        InstallStage.FINALIZING,
                        "فشل إنهاء التثبيت الذري أو استعادة النسخة الاحتياطية",
                        error
                );
            }

            // فشل نسخ الحالة العالمية لا يجب أن يحول تثبيتًا ذريًا ناجحًا إلى فشل.
            try {
                InstallStateStore.writeGlobalComplete(context, target, pkg, stats);
            } catch (Throwable stateError) {
                log.error("GLOBAL_COMPLETE_STATE_WRITE_FAILED", stateError);
            }

            long finishedWall = System.currentTimeMillis();
            long elapsed = SystemClock.elapsedRealtime() - startedElapsed;
            try {
                progress.publishCompleted(pkg.manifest.payload.sizeBytes, stats);
            } catch (Throwable progressError) {
                log.error("COMPLETION_PROGRESS_PUBLISH_FAILED", progressError);
            }
            log.log("INSTALL_COMPLETED elapsed_ms=" + elapsed);
            try {
                RuntimeLogWriter.copy(log.file(), RuntimeLogWriter.lastInstallLog(context));
            } catch (Throwable copyError) {
                log.error("LAST_INSTALL_LOG_COPY_FAILED", copyError);
            }

            InstallResult result = new InstallResult(
                    target,
                    FileTools.size(target),
                    stats,
                    startedWall,
                    finishedWall,
                    elapsed,
                    log.file()
            );
            try {
                RuntimeLogWriter.writeInstallationReport(context, pkg, result);
            } catch (Throwable reportError) {
                log.error("INSTALL_REPORT_WRITE_FAILED", reportError);
            }
            return result;
        } catch (OutOfMemoryError error) {
            RuntimeInstallException wrapped = new RuntimeInstallException(
                    InstallErrorCode.OUT_OF_MEMORY,
                    progress == null ? InstallStage.PREPARING : progress.lastStage,
                    "نفدت ذاكرة التطبيق أثناء التثبيت",
                    error
            );
            fail(root, temp, backup, target, pkg, progress, stateStore, log, wrapped);
            throw wrapped;
        } catch (RuntimeInstallException error) {
            fail(root, temp, backup, target, pkg, progress, stateStore, log, error);
            throw error;
        } catch (Throwable error) {
            RuntimeInstallException wrapped = new RuntimeInstallException(
                    InstallErrorCode.UNKNOWN,
                    progress == null ? InstallStage.PREPARING : progress.lastStage,
                    "خطأ غير متوقع أثناء التثبيت: " + message(error),
                    error
            );
            fail(root, temp, backup, target, pkg, progress, stateStore, log, wrapped);
            throw wrapped;
        } finally {
            if (log != null) log.close();
        }
    }

    RuntimePreflightChecker.Result diagnose(PackageInfo pkg,
                                             CancellationToken token,
                                             InstallProgressSink progress)
            throws RuntimeInstallException {
        File root = StorageLocations.runtimesRoot(context);
        return preflightChecker.check(context, reader, pkg, root,
                requiredSpace(pkg.manifest), token, progress);
    }

    static RuntimePostVerifier.Result verifyInstalled(Context context, File target,
                                                       RuntimeManifest manifest,
                                                       InstallProgressSink progress)
            throws RuntimeInstallException {
        CancellationToken token = new CancellationToken();
        InstallStats stats = InstalledRuntime.readStats(target);
        try (RuntimeLogWriter log = new RuntimeLogWriter(context, "recheck")) {
            return new RuntimePostVerifier().verify(target, manifest, stats, token, progress, log);
        } catch (RuntimeInstallException error) {
            throw error;
        } catch (Throwable error) {
            throw new RuntimeInstallException(InstallErrorCode.POST_VERIFICATION_FAILED,
                    InstallStage.POST_VERIFY, "فشل إعادة فحص Runtime المثبت", error);
        }
    }

    static void recoverInterrupted(Context context) {
        File root = StorageLocations.runtimesRoot(context);
        File[] files = root.listFiles();
        if (files == null) return;
        for (File file : files) {
            String name = file.getName();
            if (name.endsWith(".installing")) {
                FileTools.deleteTreeQuietly(root, file, null);
            }
        }
        for (File file : files) {
            String name = file.getName();
            if (!name.endsWith(".backup")) continue;
            String baseName = name.substring(0, name.length() - ".backup".length());
            File target = new File(root, baseName);
            if (!target.exists()) {
                file.renameTo(target);
            } else {
                FileTools.deleteTreeQuietly(root, file, null);
            }
        }
    }

    static long requiredSpace(RuntimeManifest manifest) {
        long base = Math.max(manifest.expectedStats.fileBytes,
                Math.max(manifest.payload.sizeBytes * 3L, 1));
        return (long) Math.ceil(base * 1.25d);
    }

    private void ensurePackageUnchanged(PackageInfo pkg) throws RuntimeInstallException {
        PackageReader.SourceMeta current = reader.sourceMeta(pkg.uri);
        boolean sizeChanged = current.size >= 0 && pkg.zipSize >= 0 && current.size != pkg.zipSize;
        boolean timeChanged = current.modified >= 0 && pkg.modifiedAt >= 0 &&
                current.modified != pkg.modifiedAt;
        if (sizeChanged || timeChanged) {
            throw new RuntimeInstallException(
                    InstallErrorCode.PACKAGE_CHANGED,
                    InstallStage.POST_VERIFY,
                    "تغيرت الحزمة أثناء التثبيت"
            );
        }
    }

    private static void recoverForRuntime(File root, File target, File temp,
                                          File backup, RuntimeLogWriter log)
            throws RuntimeInstallException {
        try {
            if (backup.exists() && !target.exists()) {
                if (!backup.renameTo(target)) {
                    throw new IOException("تعذر استعادة .backup");
                }
                log.log("BACKUP_RESTORED");
            } else if (backup.exists()) {
                FileTools.deleteTree(root, backup);
                log.log("STALE_BACKUP_DELETED");
            }
            if (FileTools.existsNoFollow(temp)) {
                FileTools.deleteTree(root, temp);
                log.log("INTERRUPTED_TEMP_DELETED");
            }
        } catch (Throwable error) {
            throw new RuntimeInstallException(
                    InstallErrorCode.ATOMIC_RENAME_FAILED,
                    InstallStage.PREPARING,
                    "تعذر استعادة حالة التثبيت السابقة",
                    error
            );
        }
    }

    private void fail(File root, File temp, File backup, File target,
                             PackageInfo pkg, PersistingSink progress,
                             InstallStateStore stateStore, RuntimeLogWriter log,
                             RuntimeInstallException error) {
        if (log != null) log.error(error.code.name(), error);
        RuntimeLogWriter.writeInstallationFailureReport(
                context, pkg, error, progress == null ? null : progress.lastSnapshot());
        if (progress != null) {
            InstallStage stage = error.code == InstallErrorCode.CANCELLED
                    ? InstallStage.CANCELLED : InstallStage.FAILED;
            progress.updateFailure(stage, error);
        } else if (stateStore != null) {
            InstallSnapshot snapshot = new InstallSnapshot(
                    InstallStage.FAILED, false, 0, 0, 0, 0,
                    new InstallStats(), error.currentFile, "غير معروف", "غير معروف",
                    error.getMessage(), error.code, stackSummary(error),
                    SystemClock.elapsedRealtime(), SystemClock.elapsedRealtime(),
                    0, 0, -1, MemorySnapshot.capture());
            stateStore.update(snapshot, error.getMessage(), true);
        }

        if (log != null) {
            try { RuntimeLogWriter.copy(log.file(), RuntimeLogWriter.lastInstallLog(context)); }
            catch (Throwable ignored) {}
        }

        FileTools.deleteTreeQuietly(root, temp, log);
        if (backup.exists() && !target.exists()) {
            backup.renameTo(target);
        }
    }

    private static void writeText(File file, String text) throws RuntimeInstallException {
        try (FileOutputStream output = new FileOutputStream(file, false)) {
            output.write(text.getBytes(StandardCharsets.UTF_8));
            output.getFD().sync();
        } catch (Throwable error) {
            throw new RuntimeInstallException(InstallErrorCode.FILE_WRITE_FAILED,
                    InstallStage.FINALIZING,
                    "تعذر حفظ Manifest داخل Runtime المثبت",
                    file.getAbsolutePath(), error);
        }
    }

    private static String message(Throwable error) {
        return error.getMessage() == null ? error.getClass().getSimpleName() : error.getMessage();
    }

    private static String stackSummary(Throwable error) {
        java.io.StringWriter output = new java.io.StringWriter();
        error.printStackTrace(new java.io.PrintWriter(output));
        String value = output.toString();
        return value.length() > 16 * 1024 ? value.substring(0, 16 * 1024) : value;
    }

    private static final class PersistingSink implements InstallProgressSink {
        private final InstallProgressSink upstream;
        private final InstallStateStore stateStore;
        private final long startedElapsed;
        private long lastDone;
        private long lastTime;
        InstallStage lastStage = InstallStage.PREPARING;
        private InstallSnapshot lastSnapshot = InstallSnapshot.idle();

        PersistingSink(InstallProgressSink upstream, InstallStateStore stateStore,
                       long startedElapsed) {
            this.upstream = upstream;
            this.stateStore = stateStore;
            this.startedElapsed = startedElapsed;
            this.lastTime = startedElapsed;
        }

        @Override
        public synchronized void update(InstallStage stage, long done, long total,
                                        long compressedDone, InstallStats stats,
                                        String currentFile, String zstdStatus,
                                        String tarStatus, String message, boolean force) {
            lastStage = stage;
            long now = SystemClock.elapsedRealtime();
            long elapsed = Math.max(0, now - startedElapsed);
            long deltaTime = Math.max(1, now - lastTime);
            long speed = Math.max(0, (done - lastDone) * 1000L / deltaTime);
            if (speed == 0 && elapsed > 0) speed = Math.max(0, done * 1000L / elapsed);
            long eta = speed > 0 && total > done ? (total - done) * 1000L / speed : -1;
            boolean running = stage != InstallStage.COMPLETED &&
                    stage != InstallStage.FAILED && stage != InstallStage.CANCELLED;
            lastSnapshot = new InstallSnapshot(
                    stage, running, done, total, compressedDone,
                    stats == null ? 0 : stats.writtenBytes,
                    stats, currentFile, zstdStatus, tarStatus, message,
                    null, "", startedElapsed, now, elapsed, speed, eta,
                    MemorySnapshot.capture()
            );
            stateStore.update(lastSnapshot, "", force);
            upstream.update(stage, done, total, compressedDone, stats, currentFile,
                    zstdStatus, tarStatus, message, force);
            lastDone = done;
            lastTime = now;
        }

        InstallSnapshot lastSnapshot() {
            return lastSnapshot;
        }

        void publishCompleted(long compressedBytes, InstallStats stats) {
            long now = SystemClock.elapsedRealtime();
            InstallSnapshot complete = new InstallSnapshot(
                    InstallStage.COMPLETED, false, 1, 1,
                    compressedBytes, stats == null ? 0 : stats.writtenBytes,
                    stats, "", "جاهز", "جاهز", "تم تثبيت Runtime بنجاح",
                    null, "", startedElapsed, now, now - startedElapsed,
                    0, 0, MemorySnapshot.capture()
            );
            lastStage = InstallStage.COMPLETED;
            lastSnapshot = complete;
            // لا نستخدم stateStore المحلي هنا لأن مجلد .installing نُقل بالفعل.
            upstream.update(InstallStage.COMPLETED, 1, 1, compressedBytes,
                    stats, "", "جاهز", "جاهز", complete.message, true);
        }

        void updateFailure(InstallStage terminal, RuntimeInstallException error) {
            long now = SystemClock.elapsedRealtime();
            InstallSnapshot failed = new InstallSnapshot(
                    terminal, false, lastSnapshot.done, lastSnapshot.total,
                    lastSnapshot.compressedDone, lastSnapshot.writtenBytes,
                    lastSnapshot.stats, error.currentFile.isEmpty()
                    ? lastSnapshot.currentFile : error.currentFile,
                    lastSnapshot.zstdStatus, lastSnapshot.tarStatus,
                    error.getMessage(), error.code, stackSummary(error),
                    startedElapsed, now, now - startedElapsed,
                    lastSnapshot.speedBytesPerSecond, lastSnapshot.etaMs,
                    MemorySnapshot.capture()
            );
            stateStore.update(failed, error.getMessage(), true);
            upstream.update(terminal, failed.done, failed.total,
                    failed.compressedDone, failed.stats, failed.currentFile,
                    failed.zstdStatus, failed.tarStatus, failed.message, true);
        }
    }
}
