package com.gtav.runtimemanager;

import android.app.Application;

public final class RuntimeManagerApp extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
        RuntimeCrashReporter.install(this);
        RuntimeRecoveryManager.recover(this);
        RuntimeInstaller.recoverInterrupted(this);
    }
}
