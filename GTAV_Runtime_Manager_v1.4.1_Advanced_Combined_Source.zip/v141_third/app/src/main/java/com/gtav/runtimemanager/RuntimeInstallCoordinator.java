package com.gtav.runtimemanager;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;

import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

final class RuntimeInstallCoordinator {
    interface Listener {
        void onInstallStateChanged(InstallSnapshot snapshot);
    }

    private static volatile RuntimeInstallCoordinator instance;
    private static volatile Context staticAppContext;

    static RuntimeInstallCoordinator get(Context context) {
        if (instance == null) {
            synchronized (RuntimeInstallCoordinator.class) {
                if (instance == null) {
                    instance = new RuntimeInstallCoordinator(context.getApplicationContext());
                }
            }
        }
        return instance;
    }

    static Context applicationContext() {
        if (staticAppContext == null) {
            throw new IllegalStateException("RuntimeInstallCoordinator لم تتم تهيئته");
        }
        return staticAppContext;
    }

    private final Context appContext;
    private final ExecutorService executor = Executors.newSingleThreadExecutor(runnable -> {
        Thread thread = new Thread(runnable, "gtav-runtime-installer");
        thread.setPriority(Thread.NORM_PRIORITY - 1);
        return thread;
    });
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final CopyOnWriteArrayList<Listener> listeners = new CopyOnWriteArrayList<>();
    private final AtomicBoolean running = new AtomicBoolean(false);
    private volatile InstallSnapshot current = InstallSnapshot.idle();
    private volatile CancellationToken token;
    private volatile RuntimeInstaller.InstallResult lastResult;
    private final RuntimeInstallJournal journal;
    private volatile RuntimeInstallWatchdog watchdog;

    private RuntimeInstallCoordinator(Context context) {
        appContext = context;
        staticAppContext = context;
        journal = new RuntimeInstallJournal(context);
    }

    void addListener(Listener listener) {
        if (listener == null) return;
        listeners.addIfAbsent(listener);
        mainHandler.post(() -> listener.onInstallStateChanged(current));
    }

    void removeListener(Listener listener) {
        listeners.remove(listener);
    }

    InstallSnapshot current() { return current; }
    boolean isRunning() { return running.get(); }
    RuntimeInstaller.InstallResult lastResult() { return lastResult; }

    boolean startInstall(PackageInfo pkg, boolean replace) {
        if (pkg == null || !running.compareAndSet(false, true)) return false;
        token = new CancellationToken();
        lastResult = null;
        watchdog = new RuntimeInstallWatchdog(appContext);
        try {
            RuntimeInstallService.begin(appContext);
        } catch (Throwable serviceError) {
            // لا نُسقط التطبيق إن منع النظام الخدمة؛ يظل التثبيت في Executor
            // ويُسجل السبب داخل تقرير الانهيار التشخيصي.
            RuntimeCrashReporter.record(appContext, "foreground-service-start",
                    serviceError, current);
        }
        long started = SystemClock.elapsedRealtime();
        CoordinatorSink sink = new CoordinatorSink(started);
        executor.execute(() -> {
            try {
                RuntimeInstaller installer = new RuntimeInstaller(appContext);
                lastResult = installer.install(pkg, replace, token, sink);
                if (current.stage != InstallStage.COMPLETED) {
                    long now = SystemClock.elapsedRealtime();
                    publish(new InstallSnapshot(
                            InstallStage.COMPLETED, false, 1, 1,
                            pkg.manifest.payload.sizeBytes,
                            lastResult.stats.writtenBytes,
                            lastResult.stats, "", "جاهز", "جاهز",
                            "تم تثبيت Runtime بنجاح", null, "",
                            started, now, now - started, 0, 0,
                            MemorySnapshot.capture()
                    ));
                }
            } catch (RuntimeInstallException error) {
                handleFailure(error, sink, started);
            } catch (OutOfMemoryError error) {
                RuntimeInstallException wrapped = new RuntimeInstallException(
                        InstallErrorCode.OUT_OF_MEMORY,
                        current.stage,
                        "نفدت ذاكرة التطبيق أثناء تنفيذ عملية التثبيت",
                        error
                );
                handleFailure(wrapped, sink, started);
            } catch (Throwable error) {
                RuntimeInstallException wrapped = new RuntimeInstallException(
                        InstallErrorCode.UNKNOWN,
                        current.stage,
                        "خطأ غير متوقع: " + message(error),
                        error
                );
                handleFailure(wrapped, sink, started);
            } finally {
                running.set(false);
                token = null;
                // أعد نشر الحالة نفسها بعد تحرير قفل العملية حتى تُفعّل الأزرار
                // تلقائيًا بعد النجاح أو الفشل أو الإلغاء.
                publish(current);
                RuntimeInstallWatchdog activeWatchdog = watchdog;
                watchdog = null;
                if (activeWatchdog != null) activeWatchdog.close();
                RuntimeInstallService.finish(appContext);
            }
        });
        return true;
    }

    boolean startDiagnostics(PackageInfo pkg) {
        if (pkg == null || !running.compareAndSet(false, true)) return false;
        token = new CancellationToken();
        long started = SystemClock.elapsedRealtime();
        CoordinatorSink sink = new CoordinatorSink(started);
        executor.execute(() -> {
            try {
                RuntimeInstaller installer = new RuntimeInstaller(appContext);
                RuntimePreflightChecker.Result result = installer.diagnose(pkg, token, sink);
                publish(new InstallSnapshot(
                        InstallStage.IDLE, false, 1, 1, 0, 0,
                        new InstallStats(), "", result.zstdStatus, result.tarStatus,
                        "اكتمل تشخيص بيئة التثبيت بنجاح", null, "",
                        started, SystemClock.elapsedRealtime(),
                        SystemClock.elapsedRealtime() - started, 0, -1,
                        result.memory
                ));
            } catch (RuntimeInstallException error) {
                handleFailure(error, sink, started);
            } catch (Throwable error) {
                RuntimeInstallException wrapped = new RuntimeInstallException(
                        InstallErrorCode.UNKNOWN,
                        InstallStage.PREFLIGHT,
                        "فشل التشخيص: " + message(error),
                        error
                );
                handleFailure(wrapped, sink, started);
            } finally {
                running.set(false);
                token = null;
                publish(current);
            }
        });
        return true;
    }

    void cancel() {
        CancellationToken active = token;
        if (active != null) active.cancel();
    }

    private void handleFailure(RuntimeInstallException error, CoordinatorSink sink, long started) {
        InstallStage terminal = error.code == InstallErrorCode.CANCELLED
                ? InstallStage.CANCELLED : InstallStage.FAILED;
        InstallSnapshot before = current;
        InstallSnapshot failed = new InstallSnapshot(
                terminal,
                false,
                before.done,
                before.total,
                before.compressedDone,
                before.writtenBytes,
                before.stats,
                error.currentFile.isEmpty() ? before.currentFile : error.currentFile,
                before.zstdStatus,
                before.tarStatus,
                error.getMessage(),
                error.code,
                stackSummary(error),
                started,
                SystemClock.elapsedRealtime(),
                SystemClock.elapsedRealtime() - started,
                before.speedBytesPerSecond,
                before.etaMs,
                MemorySnapshot.capture()
        );
        publish(failed);
        RuntimeCrashReporter.record(appContext, "handled-install-error", error, failed);
        try (RuntimeLogWriter log = new RuntimeLogWriter(appContext, "coordinator-error")) {
            log.error(error.code.name(), error);
            RuntimeLogWriter.copy(log.file(), RuntimeLogWriter.lastInstallLog(appContext));
        } catch (Throwable ignored) {
        }
    }

    private void publish(InstallSnapshot snapshot) {
        current = snapshot;
        if (snapshot != null) {
            journal.append(snapshot, "state");
            RuntimeInstallWatchdog activeWatchdog = watchdog;
            if (activeWatchdog != null) activeWatchdog.observe(snapshot);
        }
        if (snapshot != null && snapshot.stage != InstallStage.IDLE) {
            RuntimeInstallService.update(appContext, snapshot);
        }
        mainHandler.post(() -> {
            for (Listener listener : listeners) {
                try {
                    listener.onInstallStateChanged(snapshot);
                } catch (Throwable ignored) {
                }
            }
        });
    }

    private final class CoordinatorSink implements InstallProgressSink {
        private final long started;
        private long lastPublished;
        private long lastDone;
        private long lastMeasure;
        private InstallStage lastStage = InstallStage.IDLE;

        CoordinatorSink(long started) {
            this.started = started;
            lastMeasure = started;
        }

        @Override
        public synchronized void update(InstallStage stage, long done, long total,
                                        long compressedDone, InstallStats stats,
                                        String currentFile, String zstdStatus,
                                        String tarStatus, String message, boolean force) {
            long now = SystemClock.elapsedRealtime();
            boolean stageChanged = stage != lastStage;
            if (!force && !stageChanged && now - lastPublished < 300) return;

            long deltaTime = Math.max(1, now - lastMeasure);
            long speed = Math.max(0, (done - lastDone) * 1000L / deltaTime);
            long elapsed = Math.max(0, now - started);
            if (speed == 0 && elapsed > 0) speed = Math.max(0, done * 1000L / elapsed);
            long eta = speed > 0 && total > done ? (total - done) * 1000L / speed : -1;
            boolean active = stage != InstallStage.COMPLETED &&
                    stage != InstallStage.FAILED && stage != InstallStage.CANCELLED &&
                    stage != InstallStage.IDLE;

            publish(new InstallSnapshot(
                    stage,
                    active,
                    done,
                    total,
                    compressedDone,
                    stats == null ? 0 : stats.writtenBytes,
                    stats,
                    currentFile,
                    zstdStatus,
                    tarStatus,
                    message,
                    null,
                    "",
                    started,
                    now,
                    elapsed,
                    speed,
                    eta,
                    MemorySnapshot.capture()
            ));
            lastPublished = now;
            lastDone = done;
            lastMeasure = now;
            lastStage = stage;
        }
    }

    private static String message(Throwable error) {
        return error.getMessage() == null ? error.getClass().getSimpleName() : error.getMessage();
    }

    private static String stackSummary(Throwable error) {
        java.io.StringWriter writer = new java.io.StringWriter();
        error.printStackTrace(new java.io.PrintWriter(writer));
        String value = writer.toString();
        return value.length() > 16 * 1024 ? value.substring(0, 16 * 1024) : value;
    }
}
