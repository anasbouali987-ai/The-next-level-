# GTAV Runtime Manager v1.7.0 — Experiment 4 Comprehensive

هذه هي **التجربة الرابعة النهائية الشاملة** لمرحلة **Execution Foundation**. بُنيت بعد المقارنة الجراحية بين التجارب الثلاث، واختارت نواة التنفيذ المنضبطة من التجربة A، وسلسلة PRoot والبناء والاسترداد من التجربة C، مع الاحتفاظ فقط ببساطة المسار المفاهيمي من التجربة B.

> هذه النسخة لا تدّعي تشغيل GTA V. هدفها إثبات سلسلة التنفيذ الأساسية بصورة قابلة للقياس والتشخيص والاسترداد.

## معيار النجاح الوحيد

```text
Android ARM64
→ Android-native PRoot
→ Debian/glibc RootFS
→ Box64
→ Wine + clean external Prefix
→ cmd.exe /c echo WINE_RUNTIME_OK
```

لا تُعلن الجلسة ناجحة إلا باجتماع الشروط:

```text
WINE_RUNTIME_OK
Exit Code: 0
Session state: COMPLETED
No orphan processes: true
Base RootFS unchanged
```

## النطاق المنفذ

- مزود Runtime موثوق: `InstalledRuntimeProvider → VerifiedInstalledRuntime`.
- جلسة واحدة عالميًا عبر `FileLock`، مع Session ID صارم.
- آلة حالات قانونية تمنع القفز بين المراحل.
- PRoot واحد واضح: `ProotIsolationEngine`.
- فصل Android/Bionic عن glibc Guest.
- Bind mounts موحدة ومسموح بها فقط.
- RootFS أساسي read-mostly، وكل الكتابات في session/prefix/cache/profile.
- Box64 version gate + ELF x86_64 حقيقي.
- Wine version + clean prefix + wineboot + Console smoke test.
- سجل كامل على القرص وذيل محدود للواجهة.
- تتبع PID + parent PID + birth ticks + علامة `GTAV_SESSION_ID`.
- تنظيف تدريجي TERM/KILL وفحص حقيقي للعملية اليتيمة.
- Recovery لكل الجلسات المتقطعة، لا لآخر جلسة فقط.
- تقارير مستقلة لكل جلسة مع مرآة `latest` للواجهة.
- Feature Flags ذات حالات Requested/Available/Validated/Enabled مع Evidence.

## خارج نطاق v1.7.0

العرض، الصوت، Vulkan، DXVK، الإدخال ومكتبة الألعاب موجودة فقط في `BackendCapabilityRegistry` بحالة `DECLARED_NOT_IMPLEMENTED`. لا يوجد Manager وهمي يعلن قدرة غير منفذة.

## هيكل البيانات

```text
files/
├── runtimes/                    # Runtime المثبت؛ لا يكتب Execution Domain داخله
├── prefixes/<runtime>/<session>/# Prefix تشخيصي نظيف خاص بالجلسة
├── sessions/exec-<uuid>/
│   ├── execution_state.json
│   ├── execution_log.txt
│   ├── process_tree.json
│   ├── runtime_session_report.txt
│   ├── reports/
│   │   ├── preflight/
│   │   └── diagnostics/
│   └── fs/                      # home/tmp/run/var-tmp/etc الخاصة بالجلسة
├── cache/
├── profiles/
└── reports/execution/latest/    # مرآة واجهة فقط؛ ليست المصدر التاريخي
```

## PRoot

لا تُقبل حزمة PRoot عامة مبنية لمسار تطبيق آخر. يجب أن تكون AArch64 ومبنية بـprefix:

```text
/data/data/com.gtav.runtimemanager/files/usr
```

أداة التجهيز:

```bash
TERMUX_PACKAGES_REF=<40-hex immutable commit> \
  bash tools/provision-execution-components.sh
```

أو Bundle مسبق موثوق، بشرط وجود SHA-256 إلزامي:

```bash
PROOT_COMPONENT_BUNDLE_URL=... \
PROOT_COMPONENT_BUNDLE_SHA256=... \
  bash tools/provision-execution-components.sh
```

## البناء والتحقق

المسار المرجعي هو `.github/workflows/build-apk.yml`. الـWorkflow يحتاج متغير مستودع:

```text
TERMUX_PACKAGES_COMMIT=<full 40-character commit>
```

ثم يبني PRoot، يشغّل الاختبارات، يفحص Debug/Release APK من الداخل، ويتحقق من:

- PRoot = ELF AArch64.
- loader موجود.
- `hello-x86_64` = ELF x86_64.
- Zstandard arm64 موجود في APK.
- ملفات التنفيذ موجودة في Debug وRelease.
- `EXECUTION_COMPONENTS_SHA256.txt` يطابق **كل** ملفات `assets/execution` داخل APK وعند التثبيت الداخلي.
- تُحذف صفحات manual والتوثيق من payload قبل إنشاء الـManifest، لأن Android يعامل أسماء `.gz` داخل assets معالجةً خاصة تغيّر الاسم والمحتوى.

## حدود الإثبات

نجاح الترجمة والاختبارات الساكنة لا يثبت السلسلة على الجهاز. اعتماد Stable يتطلب تشغيل التشخيص على Android ARM64 حقيقي وحفظ حزمة الجلسة التي تحقق معيار النجاح أعلاه.

## حد الثقة المتبقي

`VerifiedInstalledRuntime` يثبت اتساق التثبيت المحلي والـManifest والبصمات، لكنه لا يثبت هوية ناشر حزمة Runtime بتوقيع رقمي. قبل توزيع إنتاجي عام يجب توقيع `runtime_manifest.json` بمفتاح إصدار والتحقق منه داخل التطبيق. هذا لا يمنع اختبار Execution Foundation بالحزمة الحالية، لكنه يبقى بوابة أمان للإصدار الإنتاجي.
