# مصفوفة تنفيذ التجربة الرابعة الشاملة

| المجال | المكوّن الحاسم | القرار |
|---|---|---|
| Runtime trust | `InstalledRuntimeProvider`, `VerifiedInstalledRuntime` | لا تنفيذ قبل Installed + Verified + Ready |
| Session ownership | `RuntimeSessionManager` | AtomicBoolean + cross-process FileLock + owner birth ticks |
| State lifecycle | `ExecutionStateMachine` | انتقالات قانونية، وCOMPLETED بعد CLEANING_UP فقط |
| Single process | `RuntimeProcessRunner` | stdout/stderr متوازيان، timeout monotonic، cancel، bounded tail |
| Process tree | `RuntimeProcessSupervisor` | parent tree + session environment scan + PID reuse protection |
| Recovery | `RuntimeExecutionRecovery` | فحص كل session غير نهائية وتنظيف identities المحفوظة |
| PRoot | `ProotIsolationEngine` | تنفيذ واحد، Android-native AArch64، custom app prefix |
| Binds | `RuntimeBindMount`, `RuntimeMountManager` | allow-list typed؛ لا broad storage bind |
| Environment | `RuntimeEnvironmentBuilder` | Host Bionic allow-list + Guest `env -i` |
| RootFS integrity | `RuntimeMutationGuard` | metadata tree + critical hashes قبل/بعد |
| Box64 | `Box64EnvironmentBuilder`, `Box64SmokeTest` | version + ELF x86_64 token + exit 0 |
| Wine Prefix | `WinePrefixManager` | clean per-session prefix + FileLock + state JSON |
| Wine | `WineManager` | version + wineboot + cmd smoke + wineserver cleanup |
| Console | `RuntimeConsoleStore` | full disk log + 2000-line UI tail + 32 KiB line cap |
| Reports | `RuntimeExecutionReporter` | per-session source of truth + latest mirror |
| Feature flags | `ExecutionFeatureFlags` | Requested/Available/Validated/Enabled + evidence |
| Future backends | `BackendCapabilityRegistry` | typed `DECLARED_NOT_IMPLEMENTED` فقط |
| Android lifecycle | `RuntimeExecutionService` | foreground adapter؛ execution logic يبقى خارج Service |
| PRoot packaging | `tools/provision-execution-components.sh` | immutable commit أو SHA-verified bundle |
| CI | `.github/workflows/build-apk.yml` | Debug/Release/androidTest + APK payload inspection |
| Source integrity | `SOURCE_MANIFEST_SHA256.txt` | قائمة SHA قابلة لإعادة التوليد والتحقق |
