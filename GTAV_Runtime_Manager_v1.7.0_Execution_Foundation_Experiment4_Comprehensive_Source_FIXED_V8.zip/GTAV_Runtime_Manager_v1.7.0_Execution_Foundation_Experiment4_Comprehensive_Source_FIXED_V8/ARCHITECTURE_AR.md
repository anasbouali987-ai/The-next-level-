# معمارية التجربة الرابعة الشاملة

## 1. حد الثقة بين التثبيت والتنفيذ

```text
Installation Domain
       │
       ▼
InstalledRuntimeProvider
       │  ينشئ وحده
       ▼
VerifiedInstalledRuntime
       │
       ▼
Execution Domain
```

`VerifiedInstalledRuntime` لا يملك constructor عامًا. المزود يرفض Runtime غير مكتمل، متغير بعد التحقق، غامض الاختيار، خارج مجلد التطبيق، أو يفتقد الملفات المطلوبة/نقاط التشغيل.

## 2. ملكية المسؤوليات

| المكوّن | المسؤولية الوحيدة |
|---|---|
| `RuntimeExecutionManager` | تنسيق البوابات والنتيجة النهائية؛ لا ينفذ تفاصيل Process أو PRoot |
| `RuntimeSessionManager` | إنشاء Session + cross-process global lock + owner identity |
| `ExecutionStateMachine` | فرض الانتقالات القانونية |
| `RuntimeLauncher` | تحويل Guest command إلى خطة تنفيذ |
| `RuntimeProcessRunner` | تشغيل عملية واحدة وتفريغ stdout/stderr والمهلة والإلغاء |
| `RuntimeProcessSupervisor` | تتبع الشجرة والهوية والتنظيف ومنع PID reuse |
| `ProotIsolationEngine` | بناء argv لـPRoot فقط |
| `RuntimeMountManager` | Bind allow-list ومسارات الكتابة |
| `RuntimeEnvironmentBuilder` | فصل Host Bionic وGuest glibc |
| `WinePrefixManager` | Prefix نظيف وقفل وحالة CREATING/INITIALIZING/READY/CORRUPTED |
| `RuntimeConsoleStore` | Full file log + bounded UI tail |
| `RuntimeExecutionReporter` | تقارير per-session ومرآة latest |
| `RuntimeExecutionRecovery` | تنظيف كل جلسة متقطعة وفق PID birth identity |

## 3. آلة الحالات

```text
IDLE
  → PREPARING
  → VALIDATING
  → STARTING_PROOT
  → ENTERING_ROOTFS
  → RUNNING_BOX64
  → STARTING_WINE
  → RUNNING
  → STOPPING
  → CLEANING_UP
  → COMPLETED | FAILED | CANCELLED | TIMED_OUT | RECOVERY_REQUIRED
```

لا يمكن بلوغ `COMPLETED` قبل `CLEANING_UP`. حالة التنفيذ وحالة التنظيف منفصلتان في `RuntimeExecutionSnapshot`.

## 4. بيئة Host وGuest

### Android Host

- Android-native PRoot وloader والمكتبات التابعة.
- Host `LD_LIBRARY_PATH` يخص Bionic فقط.
- قائمة صغيرة مسموح بها من متغيرات Android الموروثة.
- `GTAV_SESSION_ID` و`GTAV_RUNTIME_ID` لتتبع الملكية.

### glibc Guest

- يبدأ عبر `/usr/bin/env -i`.
- `LD_LIBRARY_PATH` خاص بـglibc.
- `BOX64_LD_LIBRARY_PATH` خاص بمكتبات x86_64.
- `WINEPREFIX=/mnt/wineprefix` خارج RootFS.
- لا ينتقل Host `LD_LIBRARY_PATH` إلى Guest.

## 5. سياسة RootFS

الهدف الدقيق:

```text
The installed base RootFS is immutable/read-mostly.
All guest writes are redirected to session- or prefix-owned paths.
```

تُربط `/root` و`/tmp` و`/run` و`/var/tmp` وملفات `/etc` الديناميكية من مجلد الجلسة. `RuntimeMutationGuard` يقارن الشجرة الأساسية قبل التنفيذ وبعده، ويحسب SHA-256 للملفات الحرجة والمطلوبة.

## 6. ملكية العمليات

التتبع لا يعتمد على PID وحده، بل:

```text
pid + parentPid + /proc start ticks + command + GTAV_SESSION_ID
```

أثناء الجلسة تُلتقط الأبناء من `/proc/<pid>/task/<pid>/children`، وتُمسح بيئة عمليات UID نفسها لاكتشاف Wine processes التي أعادت parent. عند التنظيف: `wineserver -w`، ثم `wineserver -k`، ثم TERM، ثم KILL، ثم إثبات عدم بقاء أي هوية مسجلة حية.

## 7. Prefix

كل تشخيص يستخدم Prefix خاصًا بالجلسة، فلا ينجح smoke test بسبب بقايا تشغيل سابق. الحالة تحفظ في JSON، ولا تصبح `READY` إلا بعد نجاح Wine gate والتنظيف والتقرير النهائي. الإلغاء أو المهلة أو فشل Wine يجعلها `CORRUPTED`.

## 8. التقارير

المصدر التاريخي هو مجلد الجلسة. `latest` نسخة للعرض والتصدير السريع فقط. هذا يمنع خلط تقارير جلسات مختلفة ويجعل Recovery قابلًا للتدقيق.
