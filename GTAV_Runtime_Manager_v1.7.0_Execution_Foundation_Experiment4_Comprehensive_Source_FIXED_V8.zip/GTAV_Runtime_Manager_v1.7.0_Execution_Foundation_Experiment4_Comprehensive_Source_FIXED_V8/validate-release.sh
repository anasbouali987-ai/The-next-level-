#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT"

bash tools/verify-source-manifest.sh
bash tools/provision-execution-components.sh
bash tools/verify-source-boundaries.sh
bash tools/verify-execution-architecture.sh

if [[ -x "$ROOT/gradlew" ]]; then
  GRADLE=("$ROOT/gradlew")
elif command -v gradle >/dev/null 2>&1; then
  GRADLE=(gradle)
else
  echo "Gradle غير موجود. استخدم GitHub Actions أو ثبّت Gradle 8.11.1." >&2
  exit 2
fi

"${GRADLE[@]}" --no-daemon clean testDebugUnitTest lintDebug \
  assembleDebug assembleRelease assembleDebugAndroidTest validateAllNativePackaging
cat <<'MSG'
نجحت بوابات المصدر والبناء وNative/Execution Packaging.
الخطوة الإلزامية على جهاز Android ARM64 يحتوي Runtime مثبتًا:
  gradle connectedDebugAndroidTest
ثم شغّل التشخيص الكامل من التطبيق حتى WINE_RUNTIME_OK.
MSG
