#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

bash tools/verify-source-manifest.sh
bash tools/verify-source-boundaries.sh
bash tools/verify-execution-architecture.sh

while IFS= read -r -d '' script; do bash -n "$script"; done < <(find . -type f -name '*.sh' -print0)

python3 - <<'PY'
from pathlib import Path
import xml.etree.ElementTree as ET
root=Path('.')
xmls=list((root/'app/src').rglob('*.xml'))
for p in xmls: ET.parse(p)
print(f'XML_OK files={len(xmls)}')
try:
    import yaml
except Exception:
    print('YAML_SKIPPED: install PyYAML for workflow parsing')
else:
    for p in (root/'.github/workflows').glob('*.yml'):
        yaml.safe_load(p.read_text())
    print('YAML_OK')
PY

hello="app/src/main/assets/execution/hello-x86_64"
sha256sum --check --strict execution-components/HELLO_X86_64_SHA256.txt
[[ -f "$hello" ]] || { echo X86_64_TEST_NOT_PACKAGED >&2; exit 1; }
readelf -h "$hello" | grep -q 'Advanced Micro Devices X86-64' || {
  echo X86_64_TEST_WRONG_ABI >&2; exit 1;
}
echo SOURCE_ONLY_VALIDATION_OK
