#!/usr/bin/env python3
"""Patch Termux build paths for the GTAV Runtime Manager private app prefix."""

from __future__ import annotations

import argparse
import re
from pathlib import Path


def _has_literal(text: str, key: str, value: str) -> bool:
    pattern = (
        rf"(?m)^[ \t]*(?:export[ \t]+)?{re.escape(key)}[ \t]*="
        rf"[ \t]*{re.escape(value)}[ \t]*(?:#.*)?$"
    )
    return re.search(pattern, text) is not None


def patch_properties(path: Path, package: str, data_dir: str, prefix: str) -> set[str]:
    text = path.read_text(encoding="utf-8")

    # Modern Termux derives HOME and PREFIX from canonical *_SUBDIR values.
    # Older revisions may assign final paths directly. Patching both forms keeps
    # the custom app prefix coherent without treating a derived HOME as missing.
    replacements = {
        "TERMUX_APP__PACKAGE_NAME": f'"{package}"',
        "TERMUX_APP__DATA_DIR": f'"{data_dir}"',
        "TERMUX__ROOTFS": f'"{data_dir}/files"',
        "TERMUX__ROOTFS_SUBDIR": '"files"',
        "TERMUX__HOME": f'"{data_dir}/files/home"',
        "TERMUX__HOME_SUBDIR": '"home"',
        "TERMUX__PREFIX": f'"{prefix}"',
        "TERMUX__PREFIX_SUBDIR": '"usr"',
        "TERMUX_APP_PACKAGE": f'"{package}"',
        "TERMUX_PREFIX": f'"{prefix}"',
    }

    changed: set[str] = set()
    for key, value in replacements.items():
        # Replace only simple assignments. Conditional derived assignments stay
        # intact and consume the patched canonical variables.
        pattern = rf"(?m)^([ \t]*(?:export[ \t]+)?{re.escape(key)}[ \t]*=).*$"
        updated, count = re.subn(pattern, rf"\g<1>{value}", text)
        if count:
            text = updated
            changed.add(key)

    missing_direct = sorted(
        {"TERMUX_APP__PACKAGE_NAME", "TERMUX_APP__DATA_DIR"} - changed
    )
    if missing_direct:
        raise RuntimeError(
            "Required Termux properties not patched: " + ", ".join(missing_direct)
        )

    alternatives = {
        "ROOTFS": ({"TERMUX__ROOTFS"}, {"TERMUX__ROOTFS_SUBDIR"}),
        "HOME": ({"TERMUX__HOME"}, {"TERMUX__HOME_SUBDIR"}),
        "PREFIX": ({"TERMUX__PREFIX"}, {"TERMUX__PREFIX_SUBDIR"}),
    }
    missing_groups = [
        label
        for label, choices in alternatives.items()
        if not any(choice <= changed for choice in choices)
    ]
    if missing_groups:
        raise RuntimeError(
            "Required Termux path chain not patched: " + ", ".join(missing_groups)
        )

    path.write_text(text, encoding="utf-8")

    # Static verification avoids sourcing the large properties.sh on the host;
    # that file expects the complete Termux build environment and repo metadata.
    checks = {
        "TERMUX_APP__PACKAGE_NAME": _has_literal(
            text, "TERMUX_APP__PACKAGE_NAME", f'"{package}"'
        ),
        "TERMUX_APP__DATA_DIR": _has_literal(
            text, "TERMUX_APP__DATA_DIR", f'"{data_dir}"'
        ),
        "TERMUX__ROOTFS": (
            _has_literal(text, "TERMUX__ROOTFS", f'"{data_dir}/files"')
            or _has_literal(text, "TERMUX__ROOTFS_SUBDIR", '"files"')
        ),
        "TERMUX__HOME": (
            _has_literal(text, "TERMUX__HOME", f'"{data_dir}/files/home"')
            or _has_literal(text, "TERMUX__HOME_SUBDIR", '"home"')
        ),
        "TERMUX__PREFIX": (
            _has_literal(text, "TERMUX__PREFIX", f'"{prefix}"')
            or _has_literal(text, "TERMUX__PREFIX_SUBDIR", '"usr"')
        ),
    }
    failed = [key for key, ok in checks.items() if not ok]
    if failed:
        raise RuntimeError(
            "Patched Termux path verification failed: " + ", ".join(failed)
        )

    return changed


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("properties", type=Path)
    parser.add_argument("package")
    parser.add_argument("data_dir")
    parser.add_argument("prefix")
    args = parser.parse_args()

    if not args.properties.is_file():
        parser.error(f"Termux properties file not found: {args.properties}")

    try:
        changed = patch_properties(
            args.properties, args.package, args.data_dir, args.prefix
        )
    except RuntimeError as exc:
        parser.exit(1, f"{exc}\n")

    print("Patched Termux assignments:", ", ".join(sorted(changed)))
    print("Verified custom package/data/rootfs/home/prefix path chain")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
