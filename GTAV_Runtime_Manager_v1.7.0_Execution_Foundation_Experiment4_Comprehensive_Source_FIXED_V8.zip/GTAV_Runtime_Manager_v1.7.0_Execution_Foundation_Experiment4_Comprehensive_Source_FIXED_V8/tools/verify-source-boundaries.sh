#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
SRC="$ROOT/app/src"
ALLOWED='app/src/main/java/com/gtav/runtimemanager/compression/zstd/AndroidZstdJniEngine.java'

violations="$({
  grep -RIlE 'import[[:space:]]+com\.github\.luben\.zstd|\bnew[[:space:]]+ZstdInputStream\b|\bZstd\.' \
    "$SRC" --include='*.java' --include='*.kt' || true
} | sed "s#^$ROOT/##" | grep -vFx "$ALLOWED" || true)"

if [[ -n "$violations" ]]; then
  echo "Direct Zstandard usage outside AndroidZstdJniEngine:" >&2
  echo "$violations" >&2
  exit 1
fi

main_activity="$ROOT/app/src/main/java/com/gtav/runtimemanager/MainActivity.java"
count="$(grep -c 'protected void onDestroy()' "$main_activity" || true)"
if [[ "$count" != "1" ]]; then
  echo "Expected exactly one MainActivity.onDestroy(), found $count" >&2
  exit 1
fi

if grep -RInE 'GTAV Runtime Manager v1\.(4|5|6)|versionName[[:space:]]*=[[:space:]]*"1\.(4|5|6)' \
  "$ROOT/app/src" "$ROOT/app/build.gradle.kts"; then
  echo "Stale application version found in runtime source/build files" >&2
  exit 1
fi

echo "Source boundaries passed."
