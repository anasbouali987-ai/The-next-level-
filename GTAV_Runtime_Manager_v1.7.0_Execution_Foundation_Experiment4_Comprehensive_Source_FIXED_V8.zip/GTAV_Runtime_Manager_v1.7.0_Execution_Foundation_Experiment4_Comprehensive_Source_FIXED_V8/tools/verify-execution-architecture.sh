#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
EXEC="$ROOT/app/src/main/java/com/gtav/runtimemanager/execution"
INSTALL="$ROOT/app/src/main/java/com/gtav/runtimemanager"
required=(
  RuntimeExecutionValidator RuntimeExecutionManager RuntimeSessionManager RuntimeLauncher
  ExecutionStateMachine ExecutionErrorCode ExecutionPaths CleanupState
  RuntimeEnvironmentBuilder RuntimeMountManager RuntimeProcessRunner RuntimeProcessSupervisor
  IsolationEngine LinuxEnvironmentEngine ProotIsolationEngine RuntimeExecutionReporter
  RuntimeConsoleStore RuntimeExecutionService RuntimeBindMount Box64EnvironmentBuilder
  Box64SmokeTest Box64Manager Box64ConfigManager WineManager WinePrefixManager ExecutionFeatureFlags
  BackendCapabilityRegistry RuntimeMutationGuard RuntimeExecutionRecovery RuntimeExecutionStateStore
)
for name in "${required[@]}"; do
  [[ -f "$EXEC/$name.java" ]] || { echo "Missing execution component: $name"; exit 1; }
done
[[ -f "$INSTALL/InstalledRuntimeProvider.java" ]] || { echo "Missing InstalledRuntimeProvider"; exit 1; }
[[ -f "$INSTALL/VerifiedInstalledRuntime.java" ]] || { echo "Missing VerifiedInstalledRuntime"; exit 1; }
# The stable installation domain must not import execution internals.
violations="$(grep -RIl 'com\.gtav\.runtimemanager\.execution' "$INSTALL" --include='*.java' \
  | grep -v '/MainActivity.java$' | grep -v '/RuntimeManagerApp.java$' | grep -v '/RuntimeCrashReporter.java$' \
  | grep -v '/DiagnosticsExporter.java$' | grep -v '/execution/' || true)"
if [[ -n "$violations" ]]; then
  echo "Installation-domain files depend on execution internals:" >&2
  echo "$violations" >&2
  exit 1
fi
# Runtime rootfs mutation calls are forbidden in execution code.
if grep -RInE 'FileOutputStream\([^\n]*rootfs|new FileOutputStream\([^\n]*runtime\.rootfs|Os\.chmod\([^\n]*rootfs|setExecutable\([^\n]*rootfs' "$EXEC" --include='*.java'; then
  echo "Execution domain contains a possible Runtime mutation" >&2
  exit 1
fi
if grep -RInE 'hasOrphans\([^)]*\)[^{]*\{[[:space:]]*return[[:space:]]+false' "$EXEC" --include='*.java'; then
  echo "A hard-coded no-orphans result is forbidden" >&2
  exit 1
fi
if ! grep -q 'ExecutionStage.CLEANING_UP' "$EXEC/ExecutionStateMachine.java" || \
   ! grep -q 'ExecutionStage.COMPLETED' "$EXEC/ExecutionStateMachine.java"; then
  echo "Execution state machine does not enforce cleanup before completion" >&2
  exit 1
fi
if grep -RIn 'reports/execution/execution_state.json' "$EXEC" --include='*.java'; then
  echo "Global execution state file is forbidden; reports must be session-scoped" >&2
  exit 1
fi
echo "Execution architecture boundaries passed."
