#!/usr/bin/env python3
"""Regression tests for old and modern Termux properties layouts."""

from __future__ import annotations

import subprocess
import tempfile
from pathlib import Path

from patch_termux_properties import patch_properties

PACKAGE = "com.gtav.runtimemanager"
DATA = f"/data/data/{PACKAGE}"
PREFIX = f"{DATA}/files/usr"
EXPECTED = [PACKAGE, DATA, f"{DATA}/files", f"{DATA}/files/home", PREFIX]

MODERN = r'''TERMUX_APP__PACKAGE_NAME="com.termux"
TERMUX_APP_PACKAGE="$TERMUX_APP__PACKAGE_NAME"
TERMUX_APP__DATA_DIR="/data/data/$TERMUX_APP__PACKAGE_NAME"
TERMUX__ROOTFS_SUBDIR="files"
TERMUX__ROOTFS="$TERMUX_APP__DATA_DIR/$TERMUX__ROOTFS_SUBDIR"
TERMUX__HOME_SUBDIR="home"
[[ "$TERMUX__ROOTFS" != "/" ]] && TERMUX__HOME="$TERMUX__ROOTFS/$TERMUX__HOME_SUBDIR" || \
 TERMUX__HOME="/$TERMUX__HOME_SUBDIR"
TERMUX__PREFIX_SUBDIR="usr"
[[ "$TERMUX__ROOTFS" != "/" ]] && TERMUX__PREFIX="$TERMUX__ROOTFS${TERMUX__PREFIX_SUBDIR:+"/$TERMUX__PREFIX_SUBDIR"}" || \
 TERMUX__PREFIX="/$TERMUX__PREFIX_SUBDIR"
TERMUX_PREFIX="$TERMUX__PREFIX"
'''

OLD = r'''TERMUX_APP__PACKAGE_NAME="com.termux"
TERMUX_APP__DATA_DIR="/data/data/com.termux"
TERMUX__ROOTFS="/data/data/com.termux/files"
TERMUX__HOME="/data/data/com.termux/files/home"
TERMUX__PREFIX="/data/data/com.termux/files/usr"
TERMUX_APP_PACKAGE="com.termux"
TERMUX_PREFIX="/data/data/com.termux/files/usr"
'''


def effective_values(path: Path) -> list[str]:
    command = r'''
source "$1"
printf '%s\n' \
  "$TERMUX_APP__PACKAGE_NAME" \
  "$TERMUX_APP__DATA_DIR" \
  "$TERMUX__ROOTFS" \
  "$TERMUX__HOME" \
  "$TERMUX__PREFIX"
'''
    result = subprocess.run(
        ["bash", "-euo", "pipefail", "-c", command, "_", str(path)],
        check=True,
        text=True,
        capture_output=True,
    )
    return result.stdout.splitlines()


def run_case(name: str, source: str) -> None:
    with tempfile.TemporaryDirectory(prefix=f"termux-{name}-") as temp:
        path = Path(temp) / "properties.sh"
        path.write_text(source, encoding="utf-8")
        patch_properties(path, PACKAGE, DATA, PREFIX)
        actual = effective_values(path)
        if actual != EXPECTED:
            raise AssertionError(f"{name}: expected {EXPECTED!r}, got {actual!r}")
        print(f"TERMUX_PROPERTIES_PATCH_{name.upper()}_OK")


def main() -> int:
    run_case("modern", MODERN)
    run_case("old", OLD)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
