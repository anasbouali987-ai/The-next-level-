#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
OUT="SOURCE_MANIFEST_SHA256.txt"
TMP="${OUT}.tmp"
: > "$TMP"
while IFS= read -r -d '' file; do
  rel="${file#./}"
  sha256sum "$rel" >> "$TMP"
done < <(find . -type f \
  ! -path './.git/*' \
  ! -path './.github/*' \
  ! -path './.gradle/*' \
  ! -path './.termux-packages/*' \
  ! -path './app/build/*' \
  ! -path './build/*' \
  ! -name "$OUT" \
  ! -name "${OUT}.tmp" \
  -print0 | sort -z)
mv "$TMP" "$OUT"
echo "Generated $OUT ($(wc -l < "$OUT") files)"
