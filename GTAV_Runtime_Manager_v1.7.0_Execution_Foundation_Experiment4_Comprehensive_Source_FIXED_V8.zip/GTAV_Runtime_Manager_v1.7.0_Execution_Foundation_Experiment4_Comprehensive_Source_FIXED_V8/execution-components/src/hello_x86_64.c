#include <stdio.h>
int main(void) { puts("BOX64_SMOKE_TEST_OK"); return 0; }
