# قرارات التجربة الرابعة بعد المقارنة الجراحية

## الخلاصة

```text
A = أفضل نواة تنفيذ وحالات وتقارير وحماية RootFS
C = أفضل PRoot provisioning وWorkflow وFileLock وRecovery
B = مسار مفاهيمي بسيط فقط؛ لم يُعتمد تنفيذه المختصر
```

## ما تم أخذه من A

- آلة حالات صريحة بدل stage updates الحرة.
- Process Runner مستقل عن Supervisor.
- تقارير مستقلة لكل جلسة.
- Error codes typed.
- Console file-first وUI bounded tail.
- RootFS mutation detection أعمق.
- Feature capabilities مع Evidence.

## ما تم أخذه من C

- بناء PRoot مخصص لمسار التطبيق.
- PRoot loader ومكتباته داخل Assets ثم atomic provisioning.
- global `FileLock` بين العمليات.
- PID birth ticks وRecovery بعد موت التطبيق.
- فحص APK النهائي في Debug وRelease.
- GitHub Workflow كامل للبناء والتقارير.
- رفض اختيار Runtime تلقائيًا عند وجود أكثر من واحد.

## ما رُفض من B

- `hasOrphans() = false` دون فحص.
- تقارير شكلية لا تحمل أدلة.
- Manager واحد يجمع كل المسؤوليات.
- PRoot placeholder غير موجود فعليًا.
- إعلان نجاح من دون Process Tree حقيقية.

## التعارضات التي حُسمت

| التعارض | القرار النهائي |
|---|---|
| A تستخدم in-process lock، C تستخدم FileLock | اعتماد الاثنين: AtomicBoolean + cross-process FileLock |
| A تمسح Host environment، C تورّثها كاملة | Host allow-list صريحة، وGuest يبدأ بـ`env -i` |
| A تقارير per-session، C تقارير عالمية | per-session مصدر الحقيقة + latest mirror فقط |
| A Recovery حالة فقط، C Recovery عمليات | Recovery لكل جلسة مع PID birth identity |
| A Prefix lock منطقي، C OS FileLock | OS FileLock + state machine للـPrefix |
| A حماية شجرة قوية، C حماية أخف | شجرة كاملة metadata + hashes للملفات الحرجة |
| C stages بلا transitions | اعتماد State Machine منضبطة |
| C يعتمد Termux master | اشتراط commit كامل ثابت أو Bundle SHA-verified |

## ما لم يُدمج عمدًا

- لا توجد Display/Audio/Vulkan/DXVK/Input managers فارغة.
- لا يوجد fallback يعلن النجاح عند غياب PRoot أو خطأ ABI.
- لا يُعاد استخدام Prefix تشخيص قديم.
- لا يكتب Execution Domain داخل RootFS الأساسي.
- لا يُعتبر ظهور النص وحده نجاحًا؛ يلزم exit 0 + cleanup + no orphans + unchanged RootFS.
