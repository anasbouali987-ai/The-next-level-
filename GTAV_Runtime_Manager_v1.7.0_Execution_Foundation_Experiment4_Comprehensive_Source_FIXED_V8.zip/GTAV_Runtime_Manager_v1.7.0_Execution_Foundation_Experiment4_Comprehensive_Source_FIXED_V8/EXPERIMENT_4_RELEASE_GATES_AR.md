# بوابات إصدار التجربة الرابعة

## Source Gate

- SOURCE_MANIFEST SHA-256 مطابق.
- لا Imports عكسية من Installation Domain إلى Execution Domain.
- لا استعمال مباشر لـzstd-jni خارج Engine المحدد.
- كل معرف session/runtime/prefix يرفض القيم غير الصالحة بدل تنظيفها.

## Packaging Gate

- PRoot وloader موجودان في APK.
- Manifest بصمات مكونات التنفيذ موجود ومطابق للملفات الحرجة داخل APK.
- PRoot ELF machine = AArch64 (183).
- hello ELF machine = x86_64 (62).
- ملفات التنفيذ موجودة في Debug وRelease.
- Zstd arm64 موجود.
- `EXECUTION_COMPONENTS.txt` و`FEATURE_FLAGS.txt` وSHA256SUMS مولدة آليًا.

## Runtime Gate

```text
ROOTFS_TRUE_OK
LINUX_RUNTIME_OK
BOX64_SMOKE_TEST_OK
WINE_RUNTIME_OK
Exit Code: 0
Session state: COMPLETED
No orphan processes: true
RootFS mutation check: PASS
```

## Failure Injection Gate

- PRoot مفقود/ABI خاطئ.
- hello مفقود/ABI خاطئ.
- Runtime تغير بعد التحقق.
- مساحة غير كافية.
- Prefix locked/corrupted.
- timeout وcancel في كل مرحلة.
- موت التطبيق أثناء Box64 وwineboot وcleanup.
- PID reuse simulation.
- report write failure.

أي فشل غير مصنف يمنع Stable.

## Production Trust Gate

قبل التوزيع العام: توقيع Runtime Manifest بمفتاح ناشر والتحقق منه داخل التطبيق. SHA-256 وحده يثبت سلامة البيانات، لا هوية المصدر.
