# تقرير تنفيذ التجربة الرابعة الشاملة

## المخرجات الرئيسية

### الثقة والاختيار

- `VerifiedInstalledRuntime` لا يُنشأ خارج الحزمة إلا عبر Provider.
- فحص canonical paths، Manifest identity، payload SHA، required files، symlinks ونقاط التشغيل.
- رفض الاختيار الغامض عند تعدد Runtime.

### الجلسات والحالات

- Session ID بنمط صارم وغير قابل للتنظيف الصامت أو collision.
- قفل global حقيقي بين عمليات التطبيق مع PID/start ticks في owner report.
- State Machine تمنع `COMPLETED` قبل `CLEANING_UP`.
- execution state وcleanup state منفصلان.

### العمليات

- stdout وstderr يفرغان بالتوازي قبل `waitFor`.
- حد 32 KiB للسطر و500 سطر لكل tail و2000 سطر للواجهة.
- مهلة monotonic وإلغاء غير متسابق مع cleanup.
- Supervisor يلتقط الأبناء والعمليات المعاد parent عبر session marker.
- TERM → grace → KILL → orphan verification.

### PRoot/RootFS

- تنفيذ واحد فقط لـPRoot.
- Manifest SHA-256 مستقل لمكونات التنفيذ، يُتحقق منه قبل التثبيت وبعده وعند فحص APK.
- نموذج `RuntimeBindMount` موحد مع Purpose وRequired وReadOnly intent.
- كل الكتابات الضرورية خارج base RootFS.
- guest يبدأ ببيئة نظيفة.

### Box64/Wine

- ELF x86_64 ثابت حقيقي داخل المصدر.
- Box64 version ثم smoke token.
- Prefix نظيف خاص بكل جلسة.
- Wine version ثم wineboot ثم `cmd.exe /c echo WINE_RUNTIME_OK`.
- Prefix READY لا يُكتب إلا بعد اكتمال السلسلة والتنظيف.

### التقارير والاسترداد

- تقارير مستقلة لكل جلسة.
- Process tree يحتوي birth ticks وcommand وalive state.
- Recovery يجول كل sessions غير النهائية وينظف هوياتها المسجلة.
- Latest directory لا يحل محل السجل التاريخي.

## شروط الاعتماد

لا يعتمد Stable من بناء ناجح فقط. يلزم على جهاز Android ARM64:

1. 20 جلسة كاملة متتالية.
2. 3 Prefixes نظيفة جديدة.
3. 3 حالات قتل للتطبيق أثناء مراحل مختلفة ثم Recovery نظيف.
4. إلغاء ومهلة في كل بوابة.
5. صفر orphan process.
6. صفر تعديل في base RootFS.
7. حزمة تقارير كاملة لكل تشغيل.
