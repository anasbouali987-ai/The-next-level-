# قائمة اعتماد v1.7.0

## البناء

- [ ] Debug APK بُني ومرّ `verifyDebugNativePackaging`.
- [ ] Release APK بُني ومرّ `verifyReleaseNativePackaging`.
- [ ] Zstandard ARM64 موجود في كلا APKs.
- [ ] `assets/execution/usr/bin/proot` موجود وELF AArch64.
- [ ] `assets/execution/usr/libexec/proot/loader` موجود وELF AArch64.
- [ ] لا توجد سلاسل `/data/data/com.termux` في PRoot أو loader.
- [ ] `assets/execution/hello-x86_64` موجود وELF x86_64.
- [ ] `EXECUTION_COMPONENTS.txt`, `FEATURE_FLAGS.txt`, `BUILD_INFO.txt`, `SHA256SUMS.txt` موجودة.

## التثبيت المستقر

- [ ] SHA-256 للحزمة مطابق.
- [ ] Runtime مثبت وحالته complete.
- [ ] الملفات المطلوبة وSymlinks وHard Links سليمة.
- [ ] إعادة التثبيت والحذف ما زالا يعملان.

## بوابات الجهاز

- [ ] PRoot `--version` Exit 0.
- [ ] `/bin/true` Exit 0.
- [ ] `/bin/echo LINUX_RUNTIME_OK` مطابق.
- [ ] `/bin/sh -c 'echo LINUX_RUNTIME_OK'` مطابق.
- [ ] `box64 --version` Exit 0.
- [ ] `hello-x86_64` يطبع `BOX64_SMOKE_TEST_OK`.
- [ ] `wine64 --version` Exit 0.
- [ ] `wineboot -u` يكمل داخل Prefix خارجي.
- [ ] `cmd.exe /c echo WINE_RUNTIME_OK` يطبع النص ويعيد 0.
- [ ] Session state = COMPLETED.
- [ ] Process tree report يؤكد عدم وجود عمليات يتيمة.
- [ ] قتل التطبيق أثناء التشغيل ثم إعادة فتحه ينظف الجلسة المتقطعة دون PID خاطئ.
- [ ] كل Session تحتفظ بتقاريرها ولا تستبدل جلسة أخرى.
- [ ] RuntimeMutationGuard لم يكتشف أي تغيير في base RootFS.
- [ ] Prefix جديد خاص بالجلسة انتقل إلى READY بعد النجاح فقط.
- [ ] الإلغاء والـtimeout لا يتركان PRoot/Box64/Wine في الخلفية.

## خارج النطاق

- [ ] لا يتم إعلان Display أو Audio أو Graphics أو DXVK أو Input أو Game Library كجاهزة.
