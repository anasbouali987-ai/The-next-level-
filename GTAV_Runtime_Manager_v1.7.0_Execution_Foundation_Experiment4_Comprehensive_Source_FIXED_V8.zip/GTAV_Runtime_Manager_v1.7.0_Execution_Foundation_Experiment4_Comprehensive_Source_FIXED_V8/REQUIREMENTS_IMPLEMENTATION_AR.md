# مطابقة متطلبات v1.7.0 — Experiment 4

| المتطلب | التنفيذ الفعلي |
|---|---|
| PRoot + RootFS + Box64 + Wine Console + Prefix | `RuntimeExecutionManager` ببوابات متسلسلة |
| Runtime مثبت ومتحقق فقط | `InstalledRuntimeProvider` + constructor غير عام لـ`VerifiedInstalledRuntime` |
| Runtime read-mostly | writable binds خارج RootFS + `RuntimeMutationGuard` |
| Session State Machine | `ExecutionStateMachine` + `ExecutionStage` + `CleanupState` |
| قفل جلسة واحدة | AtomicBoolean + `.global-execution.lock` FileLock |
| Console ملفي محدود الذاكرة | `RuntimeConsoleStore` |
| Foreground lifecycle | `RuntimeExecutionService` مع timeout hook |
| PRoot تنفيذ واحد | `ProotIsolationEngine` |
| Bind model موحد | `RuntimeBindMount` مع Purpose/ReadOnly/Required |
| فصل Bionic/glibc | Host allow-list + Guest `/usr/bin/env -i` |
| Box64 smoke حقيقي | `hello-x86_64` + output token + exit 0 |
| Prefix خارج RootFS | clean per-session diagnostic prefix + FileLock + state JSON |
| Wine Console | version + wineboot + cmd echo |
| شجرة عمليات حقيقية | child traversal + environment marker + PID birth ticks |
| عدم وجود orphan | TERM/KILL ثم live identity verification |
| Recovery | جولة على كل `sessions/exec-*` غير النهائية |
| تقارير مستقلة | `sessions/<id>/...` + latest mirror للواجهة فقط |
| Feature Flags متعددة الأبعاد | Requested/Available/Validated/Enabled/Evidence |
| Future Backends | typed registry بحالة `DECLARED_NOT_IMPLEMENTED` |
| Workflow | PRoot pinned source، Debug/Release/androidTest، APK payload checks |
| Source integrity | generate/verify SHA-256 manifest |
| الحفاظ على Installer | installation code/tests preserved؛ Execution لا يعيد الاستخراج أو chmod للـRootFS |

## المراحل الداخلية المغلقة

- alpha1: process/session/console/service.
- alpha2: PRoot + RootFS.
- alpha3: Box64 + ELF smoke.
- alpha4: Wine + clean Prefix + Console.
- RC: cleanup/recovery/per-session reports/failure injection.
- Stable: لا يُعلن إلا بعد Device Acceptance Gate.
