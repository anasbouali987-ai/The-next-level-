# ملاحظات الترقية إلى v1.7.0-exp4

- `versionCode=10` و`versionName=1.7.0-exp4`.
- لا تغيير في عقد حزمة Runtime المثبتة؛ Execution يستهلكها عبر Provider فقط.
- `VerifiedInstalledRuntime` أصبح غير قابل للإنشاء اعتباطيًا خارج حزمة التطبيق.
- Runtime ID وSession ID تُرفض عند عدم المطابقة بدل sanitization الصامت.
- أضيف cross-process FileLock إلى جانب القفل المحلي.
- التقارير انتقلت من ملفات عالمية قابلة للاستبدال إلى مجلد مستقل لكل Session.
- أضيف `CleanupState` و`CLEANING_UP/TIMED_OUT/RECOVERY_REQUIRED`.
- أضيف Recovery لكل الجلسات مع PID birth ticks.
- Prefix التشخيص أصبح جديدًا لكل جلسة وله حالات مستقلة.
- Host environment أصبح allow-list، وGuest يبدأ بـ`env -i`.
- `/dev` الكامل لم يعد bind؛ تُربط الأجهزة الأساسية فقط مع `/dev/shm` خاص بالجلسة.
- PRoot build يتطلب commit كامل ثابت أو Bundle مع SHA-256 إلزامي.
- Source manifest أصبح قابلًا للتوليد والتحقق عبر أدوات مستقلة.
- Display/Audio/Vulkan/DXVK/Input/Game Library ما زالت خارج النطاق ولا تُعلن متاحة.
