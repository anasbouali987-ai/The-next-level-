# تحقق البناء — v1.7.0 Experiment 4

## أكواد الفشل الأساسية

```text
PROOT_SOURCE_REF_REQUIRED
PROOT_SOURCE_REF_NOT_IMMUTABLE
PROOT_BUNDLE_SHA256_REQUIRED
PROOT_NOT_PACKAGED
PROOT_LOADER_NOT_PACKAGED
PROOT_WRONG_ABI
PROOT_LOADER_WRONG_ABI
PROOT_WRONG_PREFIX
X86_64_TEST_NOT_PACKAGED
X86_64_TEST_WRONG_ABI
EXECUTION_COMPONENT_MANIFEST_NOT_PACKAGED
EXECUTION_COMPONENT_HASH_MISMATCH
EXECUTION_COMPONENT_FILE_SET_MISMATCH
EXECUTION_ASSET_GZIP_SUFFIX_UNSAFE
ZSTD_NOT_PACKAGED
```

## Gradle Gates

```text
verifyZstdAarContents
verifyNoDirectZstdUsage
verifyExecutionSourceComponents
verifyDebugNativePackaging
verifyReleaseNativePackaging
validateAllNativePackaging
```

## مخرجات Workflow

```text
GTAV-Runtime-Manager-v1.7.0-exp4-debug.apk
GTAV-Runtime-Manager-v1.7.0-exp4-release-unsigned.apk
GTAV-Runtime-Manager-v1.7.0-exp4-androidTest.apk
APK_NATIVE_LIBS.txt
EXECUTION_COMPONENTS.txt
FEATURE_FLAGS.txt
BUILD_INFO.txt
SHA256SUMS.txt
```

Release APK غير موقع عمدًا؛ لا يُوصف بأنه صالح للتوزيع قبل توقيعه بمفتاح الإصدار والتحقق من البصمة.
