package com.gtav.runtimemanager.execution;

import com.gtav.runtimemanager.VerifiedInstalledRuntime;

import java.util.Arrays;
import java.util.Collections;

public final class WineManager {
    public RuntimeCommand version(VerifiedInstalledRuntime runtime) {
        return new RuntimeCommand(runtime.wine64GuestPath(), Collections.singletonList("--version"), 30_000, "wine");
    }
    public RuntimeCommand wineboot(VerifiedInstalledRuntime runtime) {
        return new RuntimeCommand(runtime.winebootGuestPath(), Arrays.asList("-u"), 120_000, "");
    }
    public RuntimeCommand consoleSmoke(VerifiedInstalledRuntime runtime) {
        return new RuntimeCommand(runtime.wine64GuestPath(),
                Arrays.asList("cmd.exe", "/c", "echo", "WINE_RUNTIME_OK"), 60_000, "WINE_RUNTIME_OK");
    }
    public RuntimeCommand waitServer(VerifiedInstalledRuntime runtime) {
        return new RuntimeCommand(runtime.wineserverGuestPath(), Collections.singletonList("-w"), 30_000, "");
    }
    public RuntimeCommand killServer(VerifiedInstalledRuntime runtime) {
        return new RuntimeCommand(runtime.wineserverGuestPath(), Collections.singletonList("-k"), 15_000, "");
    }
}
