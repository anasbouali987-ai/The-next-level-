package com.gtav.runtimemanager.execution;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.regex.Pattern;

/** Writes an immutable report set for one session and mirrors only the latest view for the UI. */
public final class RuntimeExecutionReporter {
    private static final Pattern SAFE_NAME = Pattern.compile("[A-Za-z0-9._-]{1,128}");
    private final Context context;
    private final RuntimeSession session;

    public RuntimeExecutionReporter(Context context, RuntimeSession session) {
        this.context = context.getApplicationContext();
        this.session = session;
    }

    public RuntimeSession session() { return session; }

    public File file(String name) { return new File(session.directory, safeName(name)); }
    public File reportFile(String name) { return new File(session.reportsDir, safeName(name)); }
    public File preflightFile(String name) { return new File(session.preflightDir, safeName(name)); }
    public File diagnosticFile(String name) { return new File(session.diagnosticsDir, safeName(name)); }

    public synchronized void writeText(String name, String text) throws RuntimeExecutionException {
        writeAndMirror(file(name), name, text == null ? "" : text);
    }

    public synchronized void writeReport(String name, String text) throws RuntimeExecutionException {
        writeAndMirror(reportFile(name), name, text == null ? "" : text);
    }

    public synchronized void writePreflight(String name, String text) throws RuntimeExecutionException {
        writeAndMirror(preflightFile(name), name, text == null ? "" : text);
    }

    public synchronized void writeDiagnostic(String name, String text) throws RuntimeExecutionException {
        writeAndMirror(diagnosticFile(name), name, text == null ? "" : text);
    }

    public synchronized void appendText(String name, String text) throws RuntimeExecutionException {
        File destination = file(name);
        try (FileOutputStream out = new FileOutputStream(destination, true)) {
            out.write((text == null ? "" : text).getBytes(StandardCharsets.UTF_8));
            out.getFD().sync();
        } catch (Throwable error) {
            throw new RuntimeExecutionException(ExecutionErrorCode.REPORT_WRITE_FAILED,
                    ExecutionStage.CLEANING_UP, "تعذر إلحاق التقرير: " + name, error);
        }
        mirror(destination, name);
    }

    public synchronized void writeSnapshot(RuntimeExecutionSnapshot snapshot) throws RuntimeExecutionException {
        try {
            writeAndMirror(session.stateFile, "execution_state.json", snapshot.toJson().toString(2));
            AtomicFileWriter.writeText(new File(ExecutionPaths.latestReports(context), "last_session_id.txt"), session.id + "\n");
        } catch (RuntimeExecutionException error) {
            throw error;
        } catch (Throwable error) {
            throw new RuntimeExecutionException(ExecutionErrorCode.REPORT_WRITE_FAILED,
                    snapshot.stage, "تعذر حفظ حالة الجلسة", error);
        }
    }

    public synchronized void writeProcessTree(long mainPid,
                                               List<RuntimeProcessSupervisor.ProcessRecord> records)
            throws RuntimeExecutionException {
        try {
            JSONObject json = new JSONObject();
            json.put("schema_version", 2);
            json.put("session_id", session.id);
            json.put("runtime_id", session.runtimeId);
            json.put("main_pid", mainPid);
            JSONArray detailed = new JSONArray();
            for (RuntimeProcessSupervisor.ProcessRecord record : records) {
                JSONObject item = new JSONObject();
                item.put("pid", record.pid);
                item.put("parent_pid", record.parentPid);
                item.put("start_ticks", record.startTicks);
                item.put("command", record.command);
                item.put("alive", record.alive());
                detailed.put(item);
            }
            json.put("processes", detailed);
            json.put("captured_at", System.currentTimeMillis());
            writeAndMirror(session.processTreeFile, "process_tree.json", json.toString(2));
        } catch (RuntimeExecutionException error) {
            throw error;
        } catch (Throwable error) {
            throw new RuntimeExecutionException(ExecutionErrorCode.REPORT_WRITE_FAILED,
                    ExecutionStage.CLEANING_UP, "تعذر حفظ شجرة العمليات", error);
        }
    }

    public static File file(Context context, String name) {
        return new File(ExecutionPaths.latestReports(context), safeName(name));
    }

    public static File sessionDirectory(Context context, String sessionId) {
        return new File(ExecutionPaths.sessions(context), ExecutionPaths.requireSafeId(sessionId, "sessionId"));
    }

    public static synchronized void writeLatestText(Context context, String name, String text) {
        try { AtomicFileWriter.writeText(file(context, name), text == null ? "" : text); } catch (Throwable ignored) {}
    }

    private void writeAndMirror(File destination, String latestName, String text)
            throws RuntimeExecutionException {
        try {
            AtomicFileWriter.writeText(destination, text);
            mirror(destination, latestName);
        } catch (Throwable error) {
            throw new RuntimeExecutionException(ExecutionErrorCode.REPORT_WRITE_FAILED,
                    ExecutionStage.CLEANING_UP, "تعذر كتابة التقرير: " + latestName, error);
        }
    }

    private void mirror(File source, String name) throws RuntimeExecutionException {
        try {
            File latest = file(context, name);
            AtomicFileWriter.copy(source, latest);
        } catch (Throwable error) {
            throw new RuntimeExecutionException(ExecutionErrorCode.REPORT_WRITE_FAILED,
                    ExecutionStage.CLEANING_UP, "تعذر تحديث أحدث تقرير: " + name, error);
        }
    }

    private static String safeName(String name) {
        if (name == null || !SAFE_NAME.matcher(name).matches() || name.contains("..")) {
            throw new IllegalArgumentException("اسم تقرير غير صالح: " + name);
        }
        return name;
    }

}
