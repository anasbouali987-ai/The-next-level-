package com.gtav.runtimemanager;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Immutable execution-facing view; only InstalledRuntimeProvider can construct it. */
public final class VerifiedInstalledRuntime {
    private final File rootfs;
    private final String runtimeId;
    private final String version;
    private final int schema;
    private final String payloadSha256;
    private final String manifestSha256;
    private final long verifiedAt;
    private final String box64Version;
    private final String wineVersion;
    private final String box64GuestPath;
    private final String wine64GuestPath;
    private final String winebootGuestPath;
    private final String wineserverGuestPath;
    private final List<String> requiredFiles;

    VerifiedInstalledRuntime(File rootfs, String runtimeId, String version, int schema,
                             String payloadSha256, String manifestSha256, long verifiedAt,
                             String box64Version, String wineVersion,
                             String box64GuestPath, String wine64GuestPath,
                             String winebootGuestPath, String wineserverGuestPath,
                             List<String> requiredFiles) {
        this.rootfs = rootfs;
        this.runtimeId = runtimeId;
        this.version = version;
        this.schema = schema;
        this.payloadSha256 = payloadSha256;
        this.manifestSha256 = manifestSha256;
        this.verifiedAt = verifiedAt;
        this.box64Version = box64Version;
        this.wineVersion = wineVersion;
        this.box64GuestPath = box64GuestPath;
        this.wine64GuestPath = wine64GuestPath;
        this.winebootGuestPath = winebootGuestPath;
        this.wineserverGuestPath = wineserverGuestPath;
        this.requiredFiles = Collections.unmodifiableList(new ArrayList<>(requiredFiles));
    }

    public File rootfs() { return rootfs; }
    public String runtimeId() { return runtimeId; }
    public String version() { return version; }
    public int schema() { return schema; }
    public String payloadSha256() { return payloadSha256; }
    public String manifestSha256() { return manifestSha256; }
    public long verifiedAt() { return verifiedAt; }
    public String box64Version() { return box64Version; }
    public String wineVersion() { return wineVersion; }
    public String box64GuestPath() { return box64GuestPath; }
    public String wine64GuestPath() { return wine64GuestPath; }
    public String winebootGuestPath() { return winebootGuestPath; }
    public String wineserverGuestPath() { return wineserverGuestPath; }
    public List<String> requiredFiles() { return requiredFiles; }
}
