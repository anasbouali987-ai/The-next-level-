package com.gtav.runtimemanager.execution;

import com.gtav.runtimemanager.VerifiedInstalledRuntime;

public interface IsolationEngine {
    String name();
    RuntimeLaunchPlan buildPlan(VerifiedInstalledRuntime runtime, RuntimeSession session,
                                RuntimeMountManager.MountPlan mounts,
                                RuntimeEnvironment environment, RuntimeCommand command)
            throws RuntimeExecutionException;
}
