package com.gtav.runtimemanager;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

final class RuntimeManifest {
    final int schema;
    final String runtimeId;
    final String version;
    final String host;
    final String guest;
    final String libc;
    final String integration;
    final String rawJson;
    final Payload payload;
    final Components components;
    final EntryPoints entryPoints;
    final List<RootfsFile> requiredFiles;
    final ManifestStats expectedStats;

    RuntimeManifest(JSONObject root, String rawJson) {
        this.rawJson = rawJson;
        schema = root.optInt("schema_version", -1);
        runtimeId = root.optString("runtime_id", "");
        version = root.optString("version", "");
        host = root.optString("host_architecture", "");
        guest = root.optString("guest_architecture", "");
        libc = root.optString("libc_model", "");
        integration = root.optString("android_integration_model", "");

        JSONObject payloadJson = root.optJSONObject("rootfs_payload");
        if (payloadJson == null) {
            throw new IllegalArgumentException("rootfs_payload غير موجود في Manifest");
        }
        payload = new Payload(
                normalize(payloadJson.optString("path", "")),
                payloadJson.optString("format", ""),
                payloadJson.optString("sha256", "").toLowerCase(),
                payloadJson.optLong("size_bytes", -1)
        );

        JSONObject componentJson = root.optJSONObject("components");
        components = new Components(
                value(componentJson, "box64"),
                value(componentJson, "wine"),
                value(componentJson, "dxvk"),
                value(componentJson, "debian")
        );

        JSONObject entryJson = root.optJSONObject("entrypoints");
        entryPoints = new EntryPoints(
                normalize(value(entryJson, "wine64")),
                normalize(value(entryJson, "wineboot")),
                normalize(value(entryJson, "wineserver"))
        );

        List<RootfsFile> required = new ArrayList<>();
        ManifestStats totals = new ManifestStats();
        JSONArray files = root.optJSONArray("rootfs_files");
        if (files != null) {
            for (int index = 0; index < files.length(); index++) {
                JSONObject file = files.optJSONObject(index);
                if (file == null) continue;

                String type = file.optString("type", "file");
                long size = Math.max(0, file.optLong("size_bytes", 0));
                totals.add(type, size);

                if (file.optBoolean("required", false)) {
                    required.add(new RootfsFile(
                            normalize(file.optString("path", "")),
                            type,
                            file.optString("link_target", ""),
                            file.optInt("mode", 0),
                            size,
                            file.optString("sha256", "").toLowerCase(),
                            true,
                            file.optString("component", "support")
                    ));
                }
            }
        }
        requiredFiles = Collections.unmodifiableList(required);
        expectedStats = totals;
    }

    List<RootfsFile> requiredFiles() {
        return requiredFiles;
    }

    static String normalize(String name) {
        String value = name == null ? "" : name.replace('\\', '/');
        while (value.startsWith("./")) value = value.substring(2);
        while (value.startsWith("/")) value = value.substring(1);
        return value;
    }

    static void validateRelative(String raw) {
        if (raw == null || raw.indexOf('\0') >= 0) {
            throw new IllegalArgumentException("مسار يحتوي على محرف غير صالح");
        }
        String path = raw.replace('\\', '/');
        if (path.isEmpty() || path.startsWith("/") || path.matches("^[A-Za-z]:.*")) {
            throw new IllegalArgumentException("مسار غير آمن: " + raw);
        }
        String normalized = normalize(path);
        if (normalized.isEmpty() || normalized.length() > 4096) {
            throw new IllegalArgumentException("مسار غير آمن: " + raw);
        }
        String[] segments = normalized.split("/", -1);
        for (String segment : segments) {
            if ("..".equals(segment)) {
                throw new IllegalArgumentException("مسار غير آمن: " + raw);
            }
        }
    }

    private static String value(JSONObject object, String key) {
        return object == null ? "" : object.optString(key, "");
    }

    static final class Payload {
        final String path;
        final String format;
        final String sha256;
        final long sizeBytes;

        Payload(String path, String format, String sha256, long sizeBytes) {
            this.path = path;
            this.format = format;
            this.sha256 = sha256;
            this.sizeBytes = sizeBytes;
        }
    }

    static final class Components {
        final String box64;
        final String wine;
        final String dxvk;
        final String debian;

        Components(String box64, String wine, String dxvk, String debian) {
            this.box64 = box64;
            this.wine = wine;
            this.dxvk = dxvk;
            this.debian = debian;
        }
    }

    static final class EntryPoints {
        final String wine64;
        final String wineboot;
        final String wineserver;

        EntryPoints(String wine64, String wineboot, String wineserver) {
            this.wine64 = wine64;
            this.wineboot = wineboot;
            this.wineserver = wineserver;
        }
    }

    static final class RootfsFile {
        final String path;
        final String type;
        final String linkTarget;
        final int mode;
        final long sizeBytes;
        final String sha256;
        final boolean required;
        final String component;

        RootfsFile(String path, String type, String linkTarget, int mode, long sizeBytes,
                   String sha256, boolean required, String component) {
            this.path = path;
            this.type = type;
            this.linkTarget = linkTarget;
            this.mode = mode;
            this.sizeBytes = sizeBytes;
            this.sha256 = sha256;
            this.required = required;
            this.component = component;
        }
    }

    static final class ManifestStats {
        long files;
        long directories;
        long symlinks;
        long hardLinks;
        long fileBytes;

        void add(String type, long size) {
            if ("directory".equals(type) || "dir".equals(type)) {
                directories++;
            } else if ("symlink".equals(type)) {
                symlinks++;
            } else if ("hardlink".equals(type) || "hard_link".equals(type)) {
                hardLinks++;
            } else {
                files++;
                fileBytes += size;
            }
        }

        long totalNodes() {
            return files + directories + symlinks + hardLinks;
        }
    }
}
