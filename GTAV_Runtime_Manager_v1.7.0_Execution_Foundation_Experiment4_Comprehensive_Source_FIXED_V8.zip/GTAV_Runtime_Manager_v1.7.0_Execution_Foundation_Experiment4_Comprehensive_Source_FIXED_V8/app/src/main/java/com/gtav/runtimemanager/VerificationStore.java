package com.gtav.runtimemanager;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONObject;

final class VerificationStore {
    private static final String PREFS="verification_cache",KEY="record";
    static void save(Context c,PackageInfo p,String calculated,long bytes,long when){
        try{JSONObject o=new JSONObject();o.put("uri",p.uri.toString());o.put("zip_size",p.zipSize);o.put("modified_at",p.modifiedAt);o.put("calculated_sha256",calculated);o.put("bytes",bytes);o.put("verified_at",when);c.getSharedPreferences(PREFS,0).edit().putString(KEY,o.toString()).apply();}catch(Exception ignored){}
    }
    static Record validFor(Context c,PackageInfo p){
        try{String raw=c.getSharedPreferences(PREFS,0).getString(KEY,"");if(raw.isEmpty())return null;JSONObject o=new JSONObject(raw);
            if(!p.uri.toString().equals(o.optString("uri")))return null;if(p.zipSize!=o.optLong("zip_size",-2))return null;
            long savedMod=o.optLong("modified_at",-1);if(p.modifiedAt>=0&&savedMod>=0&&p.modifiedAt!=savedMod)return null;
            return new Record(o.optString("calculated_sha256",""),o.optLong("bytes",0),o.optLong("verified_at",0));
        }catch(Exception e){return null;}
    }
    static void clear(Context c){c.getSharedPreferences(PREFS,0).edit().clear().apply();}
    static final class Record{final String sha;final long bytes,verifiedAt;Record(String s,long b,long v){sha=s;bytes=b;verifiedAt=v;}}
}
