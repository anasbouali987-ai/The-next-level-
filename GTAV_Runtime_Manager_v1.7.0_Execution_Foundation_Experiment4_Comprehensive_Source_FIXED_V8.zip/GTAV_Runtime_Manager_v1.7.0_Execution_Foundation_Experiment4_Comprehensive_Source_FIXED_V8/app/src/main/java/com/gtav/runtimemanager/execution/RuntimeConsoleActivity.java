package com.gtav.runtimemanager.execution;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.gtav.runtimemanager.R;
import com.gtav.runtimemanager.UiInsets;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.OutputStream;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Dedicated live console; full logs remain on disk while the view shows only a bounded tail. */
public final class RuntimeConsoleActivity extends Activity implements RuntimeExecutionManager.Listener,
        RuntimeConsoleStore.Listener {
    private static final int EXPORT = 7001;
    private RuntimeExecutionManager manager;
    private TextView state;
    private TextView consoleView;
    private File pending;
    private RuntimeConsoleStore boundStore;
    private final ExecutorService io = Executors.newSingleThreadExecutor();

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_runtime_console);
        UiInsets.apply(this);
        manager = RuntimeExecutionManager.get(this);
        state = findViewById(R.id.consoleStateText);
        consoleView = findViewById(R.id.consoleText);
        Button stop = findViewById(R.id.consoleStopButton);
        Button cancel = findViewById(R.id.consoleCancelButton);
        Button copy = findViewById(R.id.consoleCopyButton);
        Button export = findViewById(R.id.consoleExportButton);
        Button clear = findViewById(R.id.consoleClearButton);
        stop.setOnClickListener(v -> manager.stop());
        cancel.setOnClickListener(v -> manager.cancel());
        copy.setOnClickListener(v -> copy());
        export.setOnClickListener(v -> export());
        clear.setOnClickListener(v -> { RuntimeConsoleStore store = manager.console(); if (store != null) store.clearUiTail(); consoleView.setText(""); });
        refreshConsole();
    }

    @Override protected void onStart() {
        super.onStart();
        manager.addListener(this);
        bindConsoleStore();
    }
    @Override protected void onStop() {
        if (boundStore != null) boundStore.removeListener(this);
        boundStore = null;
        manager.removeListener(this);
        super.onStop();
    }
    @Override public void onExecutionSnapshot(RuntimeExecutionSnapshot s) {
        runOnUiThread(() -> {
            bindConsoleStore();
            long elapsed = s.startedAt > 0 ? Math.max(0, System.currentTimeMillis() - s.startedAt) : 0;
            state.setText("Session: " + s.sessionId + "\nState: " + s.stage +
                    "\nCommand: " + s.command + "\nPID: " + s.pid + "\nChildren: " + s.childPids +
                    "\nStarted: " + (s.startedAt > 0 ? new java.util.Date(s.startedAt) : "—") +
                    "\nElapsed: " + (elapsed / 1000.0) + " s" +
                    "\nExit Code: " + (s.exitCode == Integer.MIN_VALUE ? "—" : s.exitCode));
            refreshConsole();
        });
    }
    @Override public void onConsoleLine(String line) { runOnUiThread(this::refreshConsole); }
    private void bindConsoleStore() {
        RuntimeConsoleStore current = manager.console();
        if (current == boundStore) return;
        if (boundStore != null) boundStore.removeListener(this);
        boundStore = current;
        if (boundStore != null) boundStore.addListener(this);
    }
    private void refreshConsole() {
        RuntimeConsoleStore store = manager.console();
        consoleView.setText(store == null ? "لا يوجد سجل حي" : store.tailText());
    }
    private void copy() {
        ClipboardManager clipboard = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
        clipboard.setPrimaryClip(ClipData.newPlainText("Runtime console", consoleView.getText()));
        Toast.makeText(this, "تم نسخ السجل", Toast.LENGTH_SHORT).show();
    }
    private void export() {
        RuntimeConsoleStore store = manager.console();
        pending = store != null ? store.file() : RuntimeExecutionReporter.file(this, "execution_log.txt");
        if (pending == null || !pending.isFile()) { Toast.makeText(this, "لا يوجد سجل", Toast.LENGTH_SHORT).show(); return; }
        Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE)
                .setType("text/plain").putExtra(Intent.EXTRA_TITLE, "GTAV_Runtime_Execution_Log.txt");
        startActivityForResult(i, EXPORT);
    }
    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (request != EXPORT || result != RESULT_OK || data == null || data.getData() == null || pending == null) return;
        Uri uri = data.getData();
        io.execute(() -> {
            try (BufferedInputStream in = new BufferedInputStream(new FileInputStream(pending))) {
                OutputStream raw = getContentResolver().openOutputStream(uri, "wt");
                if (raw == null) throw new java.io.IOException("تعذر فتح ملف الحفظ");
                try (BufferedOutputStream out = new BufferedOutputStream(raw)) {
                    byte[] b = new byte[64 * 1024]; int n; while ((n = in.read(b)) != -1) out.write(b, 0, n);
                }
                runOnUiThread(() -> Toast.makeText(this, "تم التصدير", Toast.LENGTH_SHORT).show());
            } catch (Throwable e) { runOnUiThread(() -> Toast.makeText(this, e.toString(), Toast.LENGTH_LONG).show()); }
        });
    }
    @Override protected void onDestroy() { io.shutdownNow(); super.onDestroy(); }
}
