package com.gtav.runtimemanager;

final class InstallSnapshot {
    final InstallStage stage;
    final boolean running;
    final long done;
    final long total;
    final long compressedDone;
    final long writtenBytes;
    final InstallStats stats;
    final String currentFile;
    final String zstdStatus;
    final String tarStatus;
    final String message;
    final InstallErrorCode errorCode;
    final String errorDetails;
    final long startedAt;
    final long updatedAt;
    final long elapsedMs;
    final long speedBytesPerSecond;
    final long etaMs;
    final MemorySnapshot memory;

    InstallSnapshot(InstallStage stage, boolean running, long done, long total,
                    long compressedDone, long writtenBytes, InstallStats stats,
                    String currentFile, String zstdStatus, String tarStatus,
                    String message, InstallErrorCode errorCode, String errorDetails,
                    long startedAt, long updatedAt, long elapsedMs,
                    long speedBytesPerSecond, long etaMs, MemorySnapshot memory) {
        this.stage = stage;
        this.running = running;
        this.done = done;
        this.total = total;
        this.compressedDone = compressedDone;
        this.writtenBytes = writtenBytes;
        this.stats = stats == null ? new InstallStats() : stats.copy();
        this.currentFile = currentFile == null ? "" : currentFile;
        this.zstdStatus = zstdStatus == null ? "غير مهيأ" : zstdStatus;
        this.tarStatus = tarStatus == null ? "غير مهيأ" : tarStatus;
        this.message = message == null ? "" : message;
        this.errorCode = errorCode;
        this.errorDetails = errorDetails == null ? "" : errorDetails;
        this.startedAt = startedAt;
        this.updatedAt = updatedAt;
        this.elapsedMs = elapsedMs;
        this.speedBytesPerSecond = speedBytesPerSecond;
        this.etaMs = etaMs;
        this.memory = memory == null ? MemorySnapshot.capture() : memory;
    }

    static InstallSnapshot idle() {
        long now = android.os.SystemClock.elapsedRealtime();
        return new InstallSnapshot(InstallStage.IDLE, false, 0, 0, 0, 0,
                new InstallStats(), "", "غير مهيأ", "غير مهيأ", "",
                null, "", now, now, 0, 0, -1, MemorySnapshot.capture());
    }
}
