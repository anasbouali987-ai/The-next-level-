package com.gtav.runtimemanager.execution;

public final class RuntimeExecutionException extends Exception {
    public final ExecutionErrorCode typedCode;
    public final String code;
    public final ExecutionStage stage;
    public final boolean recoverable;

    public RuntimeExecutionException(ExecutionErrorCode code, ExecutionStage stage, String message) {
        this(code, stage, message, null, true);
    }

    public RuntimeExecutionException(ExecutionErrorCode code, ExecutionStage stage,
                                     String message, boolean recoverable) {
        this(code, stage, message, null, recoverable);
    }

    public RuntimeExecutionException(ExecutionErrorCode code, ExecutionStage stage,
                                     String message, Throwable cause) {
        this(code, stage, message, cause, true);
    }

    public RuntimeExecutionException(ExecutionErrorCode code, ExecutionStage stage,
                                     String message, Throwable cause, boolean recoverable) {
        super(message, cause);
        this.typedCode = code == null ? ExecutionErrorCode.INTERNAL_ERROR : code;
        this.code = this.typedCode.name();
        this.stage = stage == null ? ExecutionStage.FAILED : stage;
        this.recoverable = recoverable;
    }

    /** Compatibility constructor for legacy call sites while preserving stable enum codes. */
    public RuntimeExecutionException(String code, ExecutionStage stage, String message) {
        this(ExecutionErrorCode.from(code), stage, message, null, true);
    }

    public RuntimeExecutionException(String code, ExecutionStage stage, String message, Throwable cause) {
        this(ExecutionErrorCode.from(code), stage, message, cause, true);
    }
}
