package com.gtav.runtimemanager;

import android.system.ErrnoException;
import android.system.Os;
import android.system.OsConstants;

import java.io.File;
import java.io.IOException;

final class RuntimePaths {
    private RuntimePaths() {}

    static File safeChild(File root, String relative) throws IOException {
        try {
            RuntimeManifest.validateRelative(relative);
        } catch (IllegalArgumentException error) {
            throw new IOException(error.getMessage(), error);
        }
        String normalized = RuntimeManifest.normalize(relative);
        File base = root.getAbsoluteFile();
        File child = new File(base, normalized).getAbsoluteFile();
        String basePath = base.getAbsolutePath();
        String childPath = child.getAbsolutePath();
        if (!childPath.equals(basePath) && !childPath.startsWith(basePath + File.separator)) {
            throw new IOException("مسار TAR غير آمن: " + relative);
        }
        return child;
    }

    static void ensureParentsAreNotSymlinks(File root, File output) throws IOException {
        File base = root.getAbsoluteFile();
        File parent = output.getParentFile();
        while (parent != null && !parent.equals(base)) {
            if (isSymlink(parent)) {
                throw new IOException("مسار TAR يمر عبر Symlink: " + output.getAbsolutePath());
            }
            parent = parent.getParentFile();
        }
    }

    static boolean isSymlink(File file) throws IOException {
        try {
            return OsConstants.S_ISLNK(Os.lstat(file.getAbsolutePath()).st_mode);
        } catch (ErrnoException error) {
            if (error.errno == OsConstants.ENOENT) return false;
            throw new IOException("تعذر فحص نوع المسار: " + file.getAbsolutePath(), error);
        }
    }

    static String safeId(String runtimeId) {
        return runtimeId.replaceAll("[^A-Za-z0-9._-]", "_");
    }
}
