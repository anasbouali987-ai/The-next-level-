package com.gtav.runtimemanager;

interface OperationProgress {
    void update(String stage, long done, long total, String currentFile, long startedAtMs);
    boolean isCancelled();
}
