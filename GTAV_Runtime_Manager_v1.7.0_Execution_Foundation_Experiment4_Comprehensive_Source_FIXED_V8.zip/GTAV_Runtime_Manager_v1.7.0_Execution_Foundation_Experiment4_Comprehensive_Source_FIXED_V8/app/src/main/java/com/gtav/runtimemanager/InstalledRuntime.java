package com.gtav.runtimemanager;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

final class InstalledRuntime {
    final File path;
    final String runtimeId;
    final String version;
    final String installedAt;
    final String payloadSha;
    final int schema;
    final long size;
    final InstallStats stats;

    InstalledRuntime(File path, String runtimeId, String version, String installedAt,
                     String payloadSha, int schema, long size, InstallStats stats) {
        this.path = path;
        this.runtimeId = runtimeId;
        this.version = version;
        this.installedAt = installedAt;
        this.payloadSha = payloadSha;
        this.schema = schema;
        this.size = size;
        this.stats = stats;
    }

    static InstalledRuntime find(File root, String runtimeId) {
        File path = new File(root, RuntimePaths.safeId(runtimeId));
        File state = new File(path, "installed_runtime.json");
        if (!state.isFile()) return null;
        try {
            JSONObject json = new JSONObject(readSmallText(state, 2 * 1024 * 1024));
            if (!"complete".equals(json.optString("install_state"))) return null;
            InstallStats stats = statsFrom(json);
            return new InstalledRuntime(
                    path,
                    json.optString("runtime_id"),
                    json.optString("version"),
                    json.optString("installed_at"),
                    json.optString("payload_sha256"),
                    json.optInt("schema", -1),
                    FileTools.size(path),
                    stats
            );
        } catch (Throwable error) {
            return null;
        }
    }

    static InstallStats readStats(File target) {
        File state = new File(target, "installed_runtime.json");
        if (!state.isFile()) return new InstallStats();
        try {
            return statsFrom(new JSONObject(readSmallText(state, 2 * 1024 * 1024)));
        } catch (Throwable error) {
            return new InstallStats();
        }
    }

    private static InstallStats statsFrom(JSONObject json) {
        InstallStats stats = new InstallStats();
        stats.files = json.optLong("file_count", 0);
        stats.directories = json.optLong("directory_count", 0);
        stats.symlinks = json.optLong("symlink_count", 0);
        stats.hardLinks = json.optLong("hardlink_count", 0);
        stats.writtenBytes = json.optLong("installed_size_bytes", 0);
        return stats;
    }

    private static String readSmallText(File file, int maxBytes) throws Exception {
        try (InputStream input = new FileInputStream(file);
             ByteArrayOutputStream output = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[16 * 1024];
            int total = 0;
            int read;
            while ((read = input.read(buffer)) != -1) {
                total += read;
                if (total > maxBytes) throw new IllegalStateException("ملف الحالة كبير بصورة غير متوقعة");
                output.write(buffer, 0, read);
            }
            return output.toString(StandardCharsets.UTF_8.name());
        }
    }
}
