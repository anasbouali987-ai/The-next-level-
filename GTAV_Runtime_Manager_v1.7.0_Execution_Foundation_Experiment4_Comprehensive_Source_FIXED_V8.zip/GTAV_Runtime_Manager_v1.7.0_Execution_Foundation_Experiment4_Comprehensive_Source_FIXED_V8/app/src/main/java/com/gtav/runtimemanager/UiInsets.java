package com.gtav.runtimemanager;

import android.app.Activity;
import android.graphics.Insets;
import android.os.Build;
import android.view.View;
import android.view.WindowInsets;

/** Keeps framework-only Activities clear of system bars on edge-to-edge Android releases. */
public final class UiInsets {
    private UiInsets() {}

    public static void apply(Activity activity) {
        if (Build.VERSION.SDK_INT < 30) return;
        View content = activity.findViewById(android.R.id.content);
        if (content == null) return;
        final int left = content.getPaddingLeft();
        final int top = content.getPaddingTop();
        final int right = content.getPaddingRight();
        final int bottom = content.getPaddingBottom();
        content.setOnApplyWindowInsetsListener((view, insets) -> {
            Insets bars = insets.getInsets(WindowInsets.Type.systemBars() |
                    WindowInsets.Type.displayCutout());
            view.setPadding(left + bars.left, top + bars.top,
                    right + bars.right, bottom + bars.bottom);
            return insets;
        });
        content.requestApplyInsets();
    }
}
