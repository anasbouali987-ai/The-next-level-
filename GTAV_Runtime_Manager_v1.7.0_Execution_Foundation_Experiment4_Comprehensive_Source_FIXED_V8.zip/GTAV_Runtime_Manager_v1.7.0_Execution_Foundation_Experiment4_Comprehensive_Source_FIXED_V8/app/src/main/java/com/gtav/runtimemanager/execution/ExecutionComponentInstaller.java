package com.gtav.runtimemanager.execution;

import android.content.Context;
import android.content.res.AssetManager;
import android.system.Os;
import android.system.OsConstants;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.security.MessageDigest;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Installs and verifies the Android/Bionic execution payload from APK assets. */
public final class ExecutionComponentInstaller {
    public static final String ASSET_ROOT = "execution/usr";
    public static final String ASSET_MANIFEST = "execution/EXECUTION_COMPONENTS_SHA256.txt";
    public static final String VERSION = "1.7.0-exp4-components-3";
    private static final Pattern MANIFEST_LINE = Pattern.compile("^([0-9a-fA-F]{64})  (.+)$");
    private static final int MAX_MANIFEST_BYTES = 4 * 1024 * 1024;
    private static final int MAX_COMPONENTS = 50_000;

    public static final class Report {
        public final File proot;
        public final File loader;
        public final File helloX8664;
        public final String message;

        Report(File proot, File loader, File helloX8664, String message) {
            this.proot = proot;
            this.loader = loader;
            this.helloX8664 = helloX8664;
            this.message = message;
        }
    }

    public synchronized Report provision(Context context) throws Exception {
        Context app = context.getApplicationContext();
        AssetManager assets = app.getAssets();
        Map<String, String> expected = readManifest(assets);
        File files = app.getFilesDir();
        File usr = new File(files, "usr");
        File state = new File(usr, ".execution_components_version");
        File proot = new File(usr, "bin/proot");
        File loader = new File(usr, "libexec/proot/loader");
        boolean current = state.isFile() && VERSION.equals(readText(state)) &&
                verifyUsrRoot(usr, expected);
        if (!current) installAtomically(assets, files, usr, expected);
        if (!verifyUsrRoot(usr, expected)) {
            throw new RuntimeExecutionException(ExecutionErrorCode.EXECUTION_COMPONENTS_INVALID,
                    ExecutionStage.PREPARING, "فشل تحقق SHA-256 لمكونات PRoot المثبتة", false);
        }

        proot = new File(usr, "bin/proot");
        loader = new File(usr, "libexec/proot/loader");
        makeExecutable(proot);
        makeExecutable(loader);

        File hello = new File(ExecutionPaths.cache(app), "hello-x86_64");
        copyAsset(assets, "execution/hello-x86_64", hello);
        makeExecutable(hello);
        requireExpectedHash(hello, expected, "hello-x86_64");
        return new Report(proot, loader, hello,
                current ? "components-current-and-verified" : "components-provisioned-atomically-and-verified");
    }

    private static void installAtomically(AssetManager assets, File filesDir, File destination,
                                          Map<String, String> expected) throws Exception {
        File temp = new File(filesDir, "usr.installing");
        File backup = new File(filesDir, "usr.backup");
        deleteTree(temp);
        if (!temp.mkdirs() && !temp.isDirectory()) throw new IllegalStateException("تعذر إنشاء: " + temp);
        copyTree(assets, ASSET_ROOT, temp);
        makeExecutable(new File(temp, "bin/proot"));
        makeExecutable(new File(temp, "libexec/proot/loader"));
        writeText(new File(temp, ".execution_components_version"), VERSION);
        if (!verifyUsrRoot(temp, expected)) {
            deleteTree(temp);
            throw new RuntimeExecutionException(ExecutionErrorCode.EXECUTION_COMPONENTS_INVALID,
                    ExecutionStage.PREPARING, "فشل تحقق SHA-256 لمكونات APK قبل التثبيت", false);
        }
        syncTreeDirectories(temp);

        deleteTree(backup);
        boolean hadOld = destination.exists();
        if (hadOld && !destination.renameTo(backup)) {
            deleteTree(temp);
            throw new IllegalStateException("تعذر حفظ نسخة مكونات التنفيذ السابقة");
        }
        syncDirectory(filesDir);
        if (!temp.renameTo(destination)) {
            boolean restored = !hadOld || backup.renameTo(destination);
            syncDirectory(filesDir);
            deleteTree(temp);
            if (!restored) throw new IllegalStateException("فشل تثبيت المكونات وفشل Rollback");
            throw new IllegalStateException("تعذر تثبيت مكونات التنفيذ ذريًا");
        }
        syncDirectory(destination);
        syncDirectory(filesDir);
        if (!verifyUsrRoot(destination, expected)) {
            deleteTree(destination);
            boolean restored = hadOld && backup.renameTo(destination);
            syncDirectory(filesDir);
            if (!restored) throw new IllegalStateException("فشل تحقق المكونات وفشل Rollback");
            throw new RuntimeExecutionException(ExecutionErrorCode.EXECUTION_COMPONENTS_INVALID,
                    ExecutionStage.PREPARING, "فشل تحقق المكونات بعد التبديل الذري", false);
        }
        deleteTree(backup);
        syncDirectory(filesDir);
    }

    private static Map<String, String> readManifest(AssetManager assets) throws Exception {
        byte[] bytes;
        try (InputStream input = assets.open(ASSET_MANIFEST, AssetManager.ACCESS_STREAMING);
             ByteArrayOutputStream output = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[32 * 1024];
            int total = 0, read;
            while ((read = input.read(buffer)) != -1) {
                total += read;
                if (total > MAX_MANIFEST_BYTES) throw new IllegalStateException("Execution manifest أكبر من الحد");
                output.write(buffer, 0, read);
            }
            bytes = output.toByteArray();
        }
        LinkedHashMap<String, String> expected = new LinkedHashMap<>();
        String text = new String(bytes, StandardCharsets.UTF_8);
        for (String line : text.split("\\r?\\n")) {
            if (line.trim().isEmpty()) continue;
            Matcher matcher = MANIFEST_LINE.matcher(line);
            if (!matcher.matches()) throw new IllegalStateException("سطر غير صالح في Execution manifest");
            String path = normalizeManifestPath(matcher.group(2));
            if (expected.put(path, matcher.group(1).toLowerCase(Locale.US)) != null) {
                throw new IllegalStateException("مسار مكرر في Execution manifest: " + path);
            }
            if (expected.size() > MAX_COMPONENTS) throw new IllegalStateException("عدد مكونات التنفيذ أكبر من الحد");
        }
        for (String required : new String[]{"usr/bin/proot", "usr/libexec/proot/loader", "hello-x86_64"}) {
            if (!expected.containsKey(required)) throw new IllegalStateException("Execution manifest يفتقد: " + required);
        }
        return expected;
    }

    private static String normalizeManifestPath(String raw) {
        if (raw == null || raw.isEmpty() || raw.startsWith("/") || raw.indexOf('\0') >= 0 || raw.indexOf('\\') >= 0) {
            throw new IllegalStateException("مسار مكوّن غير صالح");
        }
        String[] parts = raw.split("/");
        for (String part : parts) {
            if (part.isEmpty() || part.equals(".") || part.equals("..")) {
                throw new IllegalStateException("مسار مكوّن غير صالح: " + raw);
            }
        }
        if (!raw.equals("hello-x86_64") && !raw.startsWith("usr/")) {
            throw new IllegalStateException("مسار خارج نطاق مكونات التنفيذ: " + raw);
        }
        return raw;
    }

    private static boolean verifyUsrRoot(File usrRoot, Map<String, String> expected) throws Exception {
        if (!usrRoot.isDirectory() || Files.isSymbolicLink(usrRoot.toPath())) return false;
        Set<String> expectedFiles = new HashSet<>();
        for (Map.Entry<String, String> entry : expected.entrySet()) {
            if (!entry.getKey().startsWith("usr/")) continue;
            String relative = entry.getKey().substring(4);
            expectedFiles.add(relative);
            File file = checkedChild(usrRoot, relative);
            if (!file.isFile() || Files.isSymbolicLink(file.toPath()) ||
                    !entry.getValue().equals(sha256(file))) return false;
        }
        if (expectedFiles.isEmpty()) return false;
        Set<String> actualFiles = new HashSet<>();
        collectFiles(usrRoot, usrRoot, actualFiles);
        actualFiles.remove(".execution_components_version");
        return actualFiles.equals(expectedFiles);
    }

    private static void collectFiles(File root, File current, Set<String> out) throws Exception {
        File[] children = current.listFiles();
        if (children == null) throw new IllegalStateException("تعذر سرد مكونات التنفيذ: " + current);
        for (File child : children) {
            if (Files.isSymbolicLink(child.toPath())) throw new IllegalStateException("Symlink غير مسموح في assets: " + child);
            if (child.isDirectory()) collectFiles(root, child, out);
            else if (child.isFile()) {
                String rootPath = root.getCanonicalPath();
                String path = child.getCanonicalPath();
                if (!path.startsWith(rootPath + File.separator)) throw new IllegalStateException("مسار مكوّن يهرب من usr");
                out.add(path.substring(rootPath.length() + 1).replace(File.separatorChar, '/'));
                if (out.size() > MAX_COMPONENTS) throw new IllegalStateException("عدد ملفات usr أكبر من الحد");
            } else throw new IllegalStateException("نوع مكوّن غير مدعوم: " + child);
        }
    }

    private static File checkedChild(File root, String relative) throws Exception {
        File child = new File(root, relative).getCanonicalFile();
        String rootPath = root.getCanonicalPath();
        if (!child.getPath().startsWith(rootPath + File.separator)) throw new IllegalStateException("مسار مكوّن يهرب من usr");
        return child;
    }

    private static void requireExpectedHash(File file, Map<String, String> expected, String key) throws Exception {
        String hash = expected.get(key);
        if (hash == null || !hash.equals(sha256(file))) {
            throw new RuntimeExecutionException(ExecutionErrorCode.EXECUTION_COMPONENTS_INVALID,
                    ExecutionStage.PREPARING, "SHA-256 غير متطابق: " + key, false);
        }
    }

    private static String sha256(File file) throws Exception {
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        try (BufferedInputStream input = new BufferedInputStream(new FileInputStream(file), 128 * 1024)) {
            byte[] buffer = new byte[128 * 1024];
            int read;
            while ((read = input.read(buffer)) != -1) digest.update(buffer, 0, read);
        }
        StringBuilder out = new StringBuilder(64);
        for (byte value : digest.digest()) out.append(String.format(Locale.US, "%02x", value));
        return out.toString();
    }

    private static void copyTree(AssetManager assets, String assetPath, File destination) throws Exception {
        String[] children = assets.list(assetPath);
        if (children == null) throw new IllegalStateException("تعذر سرد أصل التنفيذ: " + assetPath);
        if (children.length == 0) {
            copyAsset(assets, assetPath, destination);
            return;
        }
        if (!destination.exists() && !destination.mkdirs() && !destination.isDirectory()) {
            throw new IllegalStateException("تعذر إنشاء: " + destination);
        }
        for (String child : children) copyTree(assets, assetPath + "/" + child, new File(destination, child));
    }

    private static void copyAsset(AssetManager assets, String assetPath, File destination) throws Exception {
        File parent = destination.getParentFile();
        if (parent != null && !parent.exists() && !parent.mkdirs() && !parent.isDirectory()) {
            throw new IllegalStateException("تعذر إنشاء: " + parent);
        }
        File tmp = new File(parent, destination.getName() + ".tmp");
        try (InputStream raw = assets.open(assetPath, AssetManager.ACCESS_STREAMING);
             BufferedInputStream input = new BufferedInputStream(raw, 128 * 1024);
             FileOutputStream file = new FileOutputStream(tmp, false);
             BufferedOutputStream output = new BufferedOutputStream(file, 128 * 1024)) {
            byte[] buffer = new byte[128 * 1024];
            int read;
            while ((read = input.read(buffer)) != -1) output.write(buffer, 0, read);
            output.flush();
            file.getFD().sync();
        }
        if (destination.exists() && !destination.delete()) throw new IllegalStateException("تعذر استبدال: " + destination);
        if (!tmp.renameTo(destination)) throw new IllegalStateException("تعذر تثبيت: " + destination);
    }

    private static void makeExecutable(File file) throws Exception {
        if (!file.isFile()) throw new IllegalStateException("مكوّن التنفيذ مفقود: " + file);
        try { Os.chmod(file.getAbsolutePath(), 0700); }
        catch (Throwable error) {
            if (!file.setExecutable(true, true)) throw new IllegalStateException("تعذر جعل الملف قابلاً للتنفيذ: " + file, error);
        }
    }

    private static String readText(File file) throws Exception {
        try (InputStream in = new FileInputStream(file)) {
            byte[] data = new byte[(int) Math.min(file.length(), 128)];
            int read = in.read(data);
            return read < 0 ? "" : new String(data, 0, read, StandardCharsets.UTF_8).trim();
        }
    }

    private static void writeText(File file, String text) throws Exception {
        try (FileOutputStream out = new FileOutputStream(file, false)) {
            out.write(text.getBytes(StandardCharsets.UTF_8));
            out.getFD().sync();
        }
    }

    private static void syncTreeDirectories(File root) throws Exception {
        File[] children = root.listFiles();
        if (children != null) for (File child : children) if (child.isDirectory()) syncTreeDirectories(child);
        syncDirectory(root);
    }

    private static void syncDirectory(File directory) throws Exception {
        java.io.FileDescriptor descriptor = null;
        try {
            descriptor = Os.open(directory.getAbsolutePath(), OsConstants.O_RDONLY, 0);
            Os.fsync(descriptor);
        } finally {
            if (descriptor != null) try { Os.close(descriptor); } catch (Throwable ignored) {}
        }
    }

    private static void deleteTree(File file) throws Exception {
        if (file == null || (!file.exists() && !Files.isSymbolicLink(file.toPath()))) return;
        if (Files.isSymbolicLink(file.toPath())) {
            Files.deleteIfExists(file.toPath());
            return;
        }
        if (file.isDirectory()) {
            File[] children = file.listFiles();
            if (children != null) for (File child : children) deleteTree(child);
        }
        Files.deleteIfExists(file.toPath());
    }
}
