package com.gtav.runtimemanager;

import android.content.Context;
import android.os.Build;
import android.system.Os;


import org.apache.commons.compress.archivers.tar.TarArchiveEntry;
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream;

import java.io.BufferedInputStream;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.io.InputStream;

import com.gtav.runtimemanager.compression.zstd.ZstdHealthResult;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

final class RuntimePreflightChecker {
    private final CompressionManager compressionManager;
    private final NativeLibraryManager nativeLibraryManager;
    private final RuntimePlatformValidator platformValidator;

    RuntimePreflightChecker(CompressionManager compressionManager, NativeLibraryManager nativeLibraryManager,
                            RuntimePlatformValidator platformValidator) {
        this.compressionManager = compressionManager;
        this.nativeLibraryManager = nativeLibraryManager;
        this.platformValidator = platformValidator;
    }
    static final class Check {
        final String name;
        final boolean ok;
        final String details;

        Check(String name, boolean ok, String details) {
            this.name = name;
            this.ok = ok;
            this.details = details;
        }
    }

    static final class Result {
        final boolean ok;
        final String zstdStatus;
        final String tarStatus;
        final MemorySnapshot memory;
        final List<Check> checks;
        final File reportFile;

        Result(boolean ok, String zstdStatus, String tarStatus, MemorySnapshot memory,
               List<Check> checks, File reportFile) {
            this.ok = ok;
            this.zstdStatus = zstdStatus;
            this.tarStatus = tarStatus;
            this.memory = memory;
            this.checks = checks;
            this.reportFile = reportFile;
        }
    }

    Result check(Context context, PackageReader reader, PackageInfo pkg,
                 File runtimesRoot, long requiredBytes, CancellationToken token,
                 InstallProgressSink progress) throws RuntimeInstallException {
        List<Check> checks = new ArrayList<>();
        String zstdStatus = "غير مهيأ";
        String tarStatus = "غير مهيأ";
        MemorySnapshot memory = MemorySnapshot.capture();
        File probeRoot = new File(runtimesRoot, ".preflight-" + System.nanoTime());

        progress.update(InstallStage.PREFLIGHT, 0, 9, 0, new InstallStats(), "",
                zstdStatus, tarStatus, "بدء التشخيص", true);

        try {
            token.throwIfCancelled(InstallStage.PREFLIGHT);
            checkSpace(runtimesRoot, requiredBytes);
            checks.add(new Check("المساحة", true,
                    "المتاح " + Formatters.bytes(runtimesRoot.getUsableSpace()) +
                            " / المطلوب " + Formatters.bytes(requiredBytes)));
            progress.update(InstallStage.PREFLIGHT, 1, 9, 0, new InstallStats(), "",
                    zstdStatus, tarStatus, "تم فحص المساحة", true);

            token.throwIfCancelled(InstallStage.PREFLIGHT_PLATFORM);
            RuntimePlatformValidator.Report platformReport =
                    platformValidator.validatePlatformOnly(context);
            for (RuntimePlatformValidator.Check check : platformReport.checks) {
                checks.add(new Check("Platform/" + check.code, check.ok, check.details));
            }
            if (!platformReport.ready()) {
                throw new RuntimeInstallException(
                        InstallErrorCode.PLATFORM_UNSUPPORTED,
                        InstallStage.PREFLIGHT_PLATFORM,
                        "منصة Android أو نظام الملفات لا يجتاز متطلبات التثبيت\n" +
                                platformReport.format()
                );
            }
            progress.update(InstallStage.PREFLIGHT_PLATFORM, 2, 9, 0, new InstallStats(), "",
                    zstdStatus, tarStatus, "تم فحص منصة Android", true);

            if (!probeRoot.mkdirs()) {
                throw new RuntimeInstallException(InstallErrorCode.TEMP_DIRECTORY_FAILED,
                        InstallStage.PREFLIGHT, "تعذر إنشاء مجلد التشخيص");
            }
            File probeFile = new File(probeRoot, "probe.txt");
            try (FileOutputStream output = new FileOutputStream(probeFile)) {
                output.write("GTAV".getBytes(StandardCharsets.UTF_8));
                output.getFD().sync();
            }
            checks.add(new Check("الكتابة", true, probeFile.getAbsolutePath()));
            progress.update(InstallStage.PREFLIGHT, 3, 9, 0, new InstallStats(), probeFile.getName(),
                    zstdStatus, tarStatus, "تم اختبار الكتابة", true);

            new PermissionApplier(new PermissionApplier.AndroidOps())
                    .apply(probeFile, 0600, InstallStage.PREFLIGHT);
            checks.add(new Check("chmod", true, "تم تطبيق 0600"));
            progress.update(InstallStage.PREFLIGHT, 4, 9, 0, new InstallStats(), probeFile.getName(),
                    zstdStatus, tarStatus, "تم اختبار chmod", true);

            File link = new File(probeRoot, "probe-link");
            Os.symlink("probe.txt", link.getAbsolutePath());
            String target = Os.readlink(link.getAbsolutePath());
            if (!"probe.txt".equals(target)) {
                throw new RuntimeInstallException(InstallErrorCode.SYMLINK_FAILED,
                        InstallStage.PREFLIGHT, "هدف Symlink التجريبي غير متوقع");
            }
            checks.add(new Check("Symlink", true, target));
            progress.update(InstallStage.PREFLIGHT, 5, 9, 0, new InstallStats(), link.getName(),
                    zstdStatus, tarStatus, "تم اختبار Symlink", true);

            File renameFrom = new File(probeRoot, "rename-from");
            File renameTo = new File(probeRoot, "rename-to");
            if (!renameFrom.mkdir() || !renameFrom.renameTo(renameTo)) {
                throw new RuntimeInstallException(InstallErrorCode.ATOMIC_RENAME_FAILED,
                        InstallStage.PREFLIGHT, "مكان التثبيت لا يدعم إعادة التسمية المطلوبة");
            }
            checks.add(new Check("Atomic rename", true, "مدعوم داخل نظام الملفات نفسه"));
            progress.update(InstallStage.PREFLIGHT, 6, 9, 0, new InstallStats(), renameTo.getName(),
                    zstdStatus, tarStatus, "تم اختبار rename", true);

            token.throwIfCancelled(InstallStage.PREFLIGHT_ZSTD_NATIVE);
            progress.update(InstallStage.PREFLIGHT_ZSTD_NATIVE, 6, 9, 0, new InstallStats(), "",
                    zstdStatus, tarStatus, "zstd-native-library", true);
            NativeLibraryManager.Report nativeReport = nativeLibraryManager.inspect(context, "not attempted");
            if (!nativeReport.abiCompatible) {
                throw new RuntimeInstallException(InstallErrorCode.ZSTD_ABI_MISMATCH,
                        InstallStage.PREFLIGHT_ZSTD_NATIVE,
                        "الجهاز لا يدعم ABI المطلوب: " + nativeReport.summary());
            }
            if (!nativeReport.hasZstd()) {
                throw new RuntimeInstallException(InstallErrorCode.ZSTD_NOT_PACKAGED,
                        InstallStage.PREFLIGHT_ZSTD_NATIVE,
                        "مكتبة Zstandard غير موجودة داخل التطبيق: " + nativeReport.nativeLibraryDir);
            }
            ZstdHealthResult roundTrip = compressionManager.roundTrip();
            if (!roundTrip.ok) {
                throw zstdFailure(roundTrip, InstallErrorCode.ZSTD_ROUND_TRIP_FAILED);
            }
            ZstdHealthResult streaming = compressionManager.streaming();
            if (!streaming.ok) {
                throw zstdFailure(streaming, InstallErrorCode.ZSTD_STREAM_TEST_FAILED);
            }
            zstdStatus = "جاهز — " + compressionManager.engineName() + " (" + compressionManager.version() + ")";
            checks.add(new Check("Zstandard native", true, nativeReport.primaryZstd().getAbsolutePath()));
            checks.add(new Check("Zstandard round-trip", true, roundTrip.details));
            checks.add(new Check("Zstandard streaming", true, streaming.details));
            progress.update(InstallStage.PREFLIGHT_ZSTD_STREAMING, 7, 9, 0, new InstallStats(), "",
                    zstdStatus, tarStatus, "تم اختبار Zstandard وJNI", true);

            try (SeekableZipReader zip = reader.open(pkg.uri)) {
                if (!zip.contains(pkg.manifest.payload.path)) {
                    throw new RuntimeInstallException(
                            InstallErrorCode.PAYLOAD_NOT_FOUND,
                            InstallStage.PREFLIGHT,
                            "Payload غير موجود: " + pkg.manifest.payload.path
                    );
                }
                try (InputStream payload = zip.openEntry(pkg.manifest.payload.path);
                     InputStream zstd = compressionManager.openZstdStream(new BufferedInputStream(payload, 256 * 1024), InstallStage.PREFLIGHT_TAR);
                     TarArchiveInputStream tar = new TarArchiveInputStream(
                             new BufferedInputStream(zstd, 256 * 1024))) {
                    TarArchiveEntry first = tar.getNextTarEntry();
                    if (first == null || first.getName() == null || first.getName().isEmpty()) {
                        throw new RuntimeInstallException(InstallErrorCode.TAR_INVALID,
                                InstallStage.PREFLIGHT_TAR, "لم يتم العثور على أول TAR entry");
                    }
                    String firstName = first.getName();
                    if (!(".".equals(firstName) || "./".equals(firstName))) {
                        try {
                            RuntimeManifest.validateRelative(firstName);
                        } catch (IllegalArgumentException unsafe) {
                            throw new RuntimeInstallException(
                                    InstallErrorCode.TAR_UNSAFE_PATH,
                                    InstallStage.PREFLIGHT_TAR,
                                    unsafe.getMessage(), firstName, unsafe);
                        }
                    }
                    tarStatus = "جاهز — أول عنصر: " + firstName;
                    checks.add(new Check("TAR", true, tarStatus));
                }
            } catch (RuntimeInstallException error) {
                throw error;
            } catch (UnsatisfiedLinkError error) {
                throw new RuntimeInstallException(InstallErrorCode.ZSTD_NATIVE_LIBRARY_FAILED,
                        InstallStage.PREFLIGHT_TAR, "فشل محرك Zstandard الأصلي", error);
            } catch (Throwable error) {
                throw new RuntimeInstallException(InstallErrorCode.TAR_INVALID,
                        InstallStage.PREFLIGHT_TAR, "تعذر فك أول كتلة وقراءة TAR", error);
            }
            progress.update(InstallStage.PREFLIGHT_TAR, 8, 9, 0, new InstallStats(), pkg.manifest.payload.path,
                    zstdStatus, tarStatus, "تم اختبار Zstd وTAR", true);

            memory = MemorySnapshot.capture();
            checks.add(new Check("الذاكرة", true,
                    "free=" + Formatters.bytes(memory.freeBytes) +
                            ", used=" + Formatters.bytes(memory.usedBytes) +
                            ", max=" + Formatters.bytes(memory.maxBytes)));
            File report = writeReport(context, checks, zstdStatus, tarStatus, memory, true, "");
            progress.update(InstallStage.PREFLIGHT, 9, 9, 0, new InstallStats(), "",
                    zstdStatus, tarStatus, "اكتمل التشخيص بنجاح", true);
            return new Result(true, zstdStatus, tarStatus, memory, checks, report);
        } catch (RuntimeInstallException error) {
            checks.add(new Check("النتيجة", false, error.getMessage()));
            writeReport(context, checks, zstdStatus, tarStatus, MemorySnapshot.capture(), false,
                    error.code.name() + ": " + error.getMessage());
            throw error;
        } catch (OutOfMemoryError error) {
            RuntimeInstallException wrapped = new RuntimeInstallException(
                    InstallErrorCode.OUT_OF_MEMORY,
                    InstallStage.PREFLIGHT,
                    "نفدت ذاكرة التطبيق أثناء التشخيص",
                    error
            );
            checks.add(new Check("الذاكرة", false, wrapped.getMessage()));
            writeReport(context, checks, zstdStatus, tarStatus, MemorySnapshot.capture(), false,
                    wrapped.code.name());
            throw wrapped;
        } catch (Throwable error) {
            RuntimeInstallException wrapped = new RuntimeInstallException(
                    InstallErrorCode.UNKNOWN,
                    InstallStage.PREFLIGHT,
                    "فشل تشخيص بيئة التثبيت: " + message(error),
                    error
            );
            checks.add(new Check("النتيجة", false, wrapped.getMessage()));
            writeReport(context, checks, zstdStatus, tarStatus, MemorySnapshot.capture(), false,
                    wrapped.code.name());
            throw wrapped;
        } finally {
            FileTools.deleteTreeQuietly(runtimesRoot, probeRoot, null);
        }
    }

    private static RuntimeInstallException zstdFailure(ZstdHealthResult result, InstallErrorCode fallback) {
        InstallErrorCode code = fallback;
        try { code = InstallErrorCode.valueOf(result.code); } catch (Throwable ignored) { }
        return new RuntimeInstallException(code, InstallStage.PREFLIGHT_ZSTD_NATIVE,
                "فشل اختبار Zstandard: " + result.details, result.error);
    }

    private static void checkSpace(File root, long requiredBytes) throws RuntimeInstallException {
        long free = root.getUsableSpace();
        if (free < requiredBytes) {
            throw new RuntimeInstallException(InstallErrorCode.NO_SPACE, InstallStage.PREFLIGHT,
                    "مساحة غير كافية. المطلوب " + Formatters.bytes(requiredBytes) +
                            " والمتاح " + Formatters.bytes(free));
        }
    }

    private static File writeReport(Context context, List<Check> checks,
                                    String zstd, String tar, MemorySnapshot memory,
                                    boolean success, String error) {
        File report = RuntimeLogWriter.diagnosticReport(context);
        try (BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(
                new FileOutputStream(report, false), StandardCharsets.UTF_8), 32 * 1024)) {
            writer.write("GTAV Runtime Installation Diagnostic Report\n");
            writer.write("===========================================\n");
            writer.write("Result: " + (success ? "SUCCESS" : "FAILED") + "\n");
            writer.write("Zstandard: " + zstd + "\n");
            writer.write("TAR: " + tar + "\n");
            writer.write("Memory free: " + memory.freeBytes + "\n");
            writer.write("Memory used: " + memory.usedBytes + "\n");
            writer.write("Memory max: " + memory.maxBytes + "\n");
            if (!error.isEmpty()) writer.write("Error: " + error + "\n");
            writer.write("\nChecks\n------\n");
            for (Check check : checks) {
                writer.write((check.ok ? "PASS" : "FAIL") + " | " + check.name + " | " + check.details + "\n");
            }
        } catch (Throwable ignored) {
        }
        return report;
    }

    private static String message(Throwable error) {
        return error.getMessage() == null ? error.getClass().getSimpleName() : error.getMessage();
    }
}
