package com.gtav.runtimemanager;

import android.content.Context;
import java.io.File;

final class StorageLocations {
    private static final String PREFS="settings",KEY="location";
    static File runtimesRoot(Context c){String mode=c.getSharedPreferences(PREFS,0).getString(KEY,"internal");File base;
        if("external_app".equals(mode)&&c.getExternalFilesDir(null)!=null)base=c.getExternalFilesDir(null);else base=c.getFilesDir();
        File f=new File(base,"runtimes");if(!f.exists())f.mkdirs();return f;}
    static String mode(Context c){return c.getSharedPreferences(PREFS,0).getString(KEY,"internal");}
    static void setMode(Context c,String mode){c.getSharedPreferences(PREFS,0).edit().putString(KEY,mode).apply();}
}
