package com.gtav.runtimemanager.execution;

import android.os.SystemClock;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.reflect.Field;
import java.nio.charset.StandardCharsets;
import java.util.ArrayDeque;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

/** Runs exactly one process and drains stdout/stderr concurrently. */
public final class RuntimeProcessRunner {
    public interface Observer {
        void onStarted(Process process, long pid);
        default void onPoll() {}
        default void onFinished(Process process, RuntimeExecutionResult result) {}
    }

    private static final int TAIL_LINES = 500;
    private static final int MAX_LINE_CHARS = 32 * 1024;
    private static final Set<String> HOST_ALLOWLIST = new HashSet<>(Arrays.asList(
            "ANDROID_DATA", "ANDROID_ROOT", "ANDROID_ART_ROOT", "ANDROID_I18N_ROOT",
            "ANDROID_RUNTIME_ROOT", "EXTERNAL_STORAGE", "ASEC_MOUNTPOINT",
            "BOOTCLASSPATH", "DEX2OATBOOTCLASSPATH", "SYSTEMSERVERCLASSPATH"
    ));

    public RuntimeExecutionResult run(RuntimeLaunchPlan plan, RuntimeConsoleStore console,
                                      ExecutionCancellationToken cancellation,
                                      Observer observer) throws Exception {
        long startedWall = System.currentTimeMillis();
        long startedMono = SystemClock.elapsedRealtime();
        ProcessBuilder builder = new ProcessBuilder(plan.hostArgv);
        builder.directory(plan.workingDirectory);
        Map<String, String> env = builder.environment();
        env.clear();
        try {
            Map<String, String> inherited = System.getenv();
            for (String name : HOST_ALLOWLIST) {
                String value = inherited.get(name);
                if (value != null && !value.isEmpty()) env.put(name, value);
            }
        } catch (Throwable ignored) {}
        env.putAll(plan.environment.host);

        if (console != null) console.append("SYSTEM", "HOST ARGV: " + String.join(" ", plan.hostArgv));
        Process process;
        try { process = builder.start(); }
        catch (Throwable error) {
            throw new RuntimeExecutionException(ExecutionErrorCode.PROCESS_START_FAILED,
                    ExecutionStage.PREPARING, "تعذر بدء العملية: " + plan.name, error);
        }
        try { process.getOutputStream().close(); } catch (Throwable ignored) {}
        long pid = pidOf(process);
        if (observer != null) observer.onStarted(process, pid);

        ArrayDeque<String> stdout = new ArrayDeque<>();
        ArrayDeque<String> stderr = new ArrayDeque<>();
        CountDownLatch pumps = new CountDownLatch(2);
        Thread outThread = pump("STDOUT", process.getInputStream(), stdout, console, pumps);
        Thread errThread = pump("STDERR", process.getErrorStream(), stderr, console, pumps);
        boolean timedOut = false;
        boolean cancelled = false;
        long deadline = plan.timeoutMs > 0 ? startedMono + plan.timeoutMs : Long.MAX_VALUE;
        try {
            while (true) {
                if (observer != null) observer.onPoll();
                if (cancellation != null && cancellation.isCancelled()) {
                    cancelled = true;
                    process.destroy();
                    break;
                }
                try {
                    if (process.waitFor(100, TimeUnit.MILLISECONDS)) break;
                } catch (NoSuchMethodError unsupported) {
                    try { process.exitValue(); break; }
                    catch (IllegalThreadStateException running) { Thread.sleep(100); }
                }
                if (SystemClock.elapsedRealtime() >= deadline) {
                    timedOut = true;
                    process.destroy();
                    break;
                }
            }
            if (timedOut || cancelled) {
                if (!waitFor(process, 1500)) process.destroyForcibly();
            }
            int exit;
            try { exit = process.waitFor(); } catch (Throwable error) { exit = -1; }
            pumps.await(5, TimeUnit.SECONDS);
            RuntimeExecutionResult result = new RuntimeExecutionResult(exit, pid, startedWall,
                    System.currentTimeMillis(), timedOut, cancelled,
                    joinTail(stdout), joinTail(stderr));
            if (observer != null) observer.onFinished(process, result);
            return result;
        } finally {
            outThread.interrupt();
            errThread.interrupt();
            try { process.getInputStream().close(); } catch (Throwable ignored) {}
            try { process.getErrorStream().close(); } catch (Throwable ignored) {}
        }
    }

    private static Thread pump(String channel, InputStream stream, ArrayDeque<String> tail,
                               RuntimeConsoleStore console, CountDownLatch done) {
        Thread thread = new Thread(() -> {
            try (BufferedReader reader = new BufferedReader(
                    new InputStreamReader(stream, StandardCharsets.UTF_8), 64 * 1024)) {
                String line;
                while ((line = reader.readLine()) != null) {
                    if (line.length() > MAX_LINE_CHARS) {
                        line = line.substring(0, MAX_LINE_CHARS) + "…[TRUNCATED]";
                    }
                    synchronized (tail) {
                        tail.addLast(line);
                        while (tail.size() > TAIL_LINES) tail.removeFirst();
                    }
                    if (console != null) console.append(channel, line);
                }
            } catch (Throwable error) {
                if (console != null) console.append("SYSTEM", channel + " pump: " + error);
            } finally { done.countDown(); }
        }, "runtime-" + channel.toLowerCase(java.util.Locale.US));
        thread.setDaemon(true);
        thread.start();
        return thread;
    }

    private static String joinTail(ArrayDeque<String> tail) {
        synchronized (tail) { return String.join("\n", tail); }
    }

    private static boolean waitFor(Process process, long timeoutMs) throws InterruptedException {
        try { return process.waitFor(timeoutMs, TimeUnit.MILLISECONDS); }
        catch (NoSuchMethodError error) {
            long end = SystemClock.elapsedRealtime() + timeoutMs;
            while (SystemClock.elapsedRealtime() < end) {
                try { process.exitValue(); return true; }
                catch (IllegalThreadStateException running) { Thread.sleep(50); }
            }
            return false;
        }
    }

    static long pidOf(Process process) {
        try {
            java.lang.reflect.Method method = process.getClass().getMethod("pid");
            Object value = method.invoke(process);
            if (value instanceof Number) return ((Number) value).longValue();
        } catch (Throwable ignored) {}
        for (String name : new String[]{"pid", "mPid"}) {
            try {
                Field field = process.getClass().getDeclaredField(name);
                field.setAccessible(true);
                return ((Number) field.get(process)).longValue();
            } catch (Throwable ignored) {}
        }
        return -1;
    }
}
