package com.gtav.runtimemanager.execution;

/** Marker contract for a Linux guest environment engine. */
public interface LinuxEnvironmentEngine extends IsolationEngine {}
