package com.gtav.runtimemanager.execution;

import android.content.Context;

import com.gtav.runtimemanager.VerifiedInstalledRuntime;

import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.nio.channels.FileChannel;
import java.nio.channels.FileLock;

/** Creates and exclusively owns a clean, session-scoped Wine diagnostic prefix outside RootFS. */
public final class WinePrefixManager implements AutoCloseable {
    public static final class PrefixLease {
        public final File root;
        public final File stateFile;
        public final String sessionId;
        PrefixLease(File root, File stateFile, String sessionId) {
            this.root = root;
            this.stateFile = stateFile;
            this.sessionId = sessionId;
        }
    }

    private FileChannel channel;
    private FileLock lock;
    private PrefixLease lease;

    public PrefixLease acquire(Context context, VerifiedInstalledRuntime runtime,
                               RuntimeSession session) throws Exception {
        if (lease != null) throw new IllegalStateException("Prefix lease already acquired");
        File prefix = ExecutionPaths.diagnosticPrefix(context, runtime.runtimeId(), session.id);
        assertOutsideRootfs(runtime.rootfs(), prefix);
        File lockFile = new File(prefix, ".manager.lock");
        channel = new FileOutputStream(lockFile, true).getChannel();
        try { lock = channel.tryLock(); }
        catch (java.nio.channels.OverlappingFileLockException error) { lock = null; }
        if (lock == null) throw new RuntimeExecutionException(
                ExecutionErrorCode.WINE_PREFIX_LOCKED, ExecutionStage.PREPARING,
                "Wine Prefix مستخدم بواسطة جلسة أخرى");
        lease = new PrefixLease(prefix, new File(prefix, "prefix_state.json"), session.id);
        writeState(runtime, WinePrefixState.CREATING, "Fresh diagnostic prefix allocated");
        return lease;
    }

    public PrefixLease lease() {
        if (lease == null) throw new IllegalStateException("Prefix lease not acquired");
        return lease;
    }

    public void markInitializing(VerifiedInstalledRuntime runtime) throws Exception {
        writeState(runtime, WinePrefixState.INITIALIZING, "wineboot started");
    }

    public void markReady(VerifiedInstalledRuntime runtime) throws Exception {
        writeState(runtime, WinePrefixState.READY, "wineboot and cmd.exe smoke test passed");
    }

    public void markCorrupted(VerifiedInstalledRuntime runtime, String reason) {
        try { writeState(runtime, WinePrefixState.CORRUPTED, reason); } catch (Throwable ignored) {}
    }

    public void cleanTransientLocks() {
        if (lease == null) return;
        for (String name : new String[]{".update-timestamp", "wineserver.pid"}) {
            File file = new File(lease.root, name);
            if (file.isFile() && file.length() == 0) file.delete();
        }
    }

    private void writeState(VerifiedInstalledRuntime runtime, WinePrefixState state, String message)
            throws Exception {
        if (lease == null) return;
        JSONObject json = new JSONObject();
        json.put("schema_version", 1);
        json.put("state", state.name());
        json.put("session_id", lease.sessionId);
        json.put("runtime_id", runtime.runtimeId());
        json.put("runtime_version", runtime.version());
        json.put("wine_version", runtime.wineVersion());
        json.put("architecture", "win64");
        json.put("updated_at", System.currentTimeMillis());
        json.put("message", message == null ? "" : message);
        AtomicFileWriter.writeText(lease.stateFile, json.toString(2));
    }

    private static void assertOutsideRootfs(File rootfs, File prefix) throws Exception {
        String root = rootfs.getCanonicalPath();
        String target = prefix.getCanonicalPath();
        if (target.equals(root) || target.startsWith(root + File.separator)) {
            throw new RuntimeExecutionException(ExecutionErrorCode.RUNTIME_MUTATED,
                    ExecutionStage.PREPARING, "Wine Prefix يجب أن يكون خارج RootFS", false);
        }
    }

    @Override public void close() {
        try { if (lock != null && lock.isValid()) lock.release(); } catch (Throwable ignored) {}
        try { if (channel != null) channel.close(); } catch (Throwable ignored) {}
        lock = null;
        channel = null;
        lease = null;
    }
}
