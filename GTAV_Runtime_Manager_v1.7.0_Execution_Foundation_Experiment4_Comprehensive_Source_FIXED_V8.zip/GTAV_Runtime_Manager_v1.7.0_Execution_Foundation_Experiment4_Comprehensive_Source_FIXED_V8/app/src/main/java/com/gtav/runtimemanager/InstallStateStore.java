package com.gtav.runtimemanager;

import android.content.Context;

import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

final class InstallStateStore {
    private final Context context;
    private final File localState;
    private final PackageInfo pkg;
    private long lastWriteElapsed;

    InstallStateStore(Context context, File tempRoot, PackageInfo pkg) {
        this.context = context.getApplicationContext();
        this.localState = new File(tempRoot, "install_state.json");
        this.pkg = pkg;
    }

    synchronized void update(InstallSnapshot snapshot, String lastError, boolean force) {
        long now = android.os.SystemClock.elapsedRealtime();
        if (!force && now - lastWriteElapsed < 1000) return;
        lastWriteElapsed = now;
        try {
            JSONObject state = new JSONObject();
            state.put("runtime_id", pkg.manifest.runtimeId);
            state.put("version", pkg.manifest.version);
            state.put("schema", pkg.manifest.schema);
            state.put("stage", snapshot.stage.name());
            state.put("stage_label", snapshot.stage.label);
            state.put("install_state", snapshot.running ? "running" : snapshot.stage.name().toLowerCase(Locale.US));
            state.put("file_count", snapshot.stats.files);
            state.put("directory_count", snapshot.stats.directories);
            state.put("symlink_count", snapshot.stats.symlinks);
            state.put("hardlink_count", snapshot.stats.hardLinks);
            state.put("installed_size_bytes", snapshot.stats.writtenBytes);
            state.put("hardlink_logical_bytes", snapshot.stats.hardLinkLogicalBytes);
            state.put("last_file", snapshot.currentFile);
            state.put("last_error", lastError == null ? "" : lastError);
            state.put("zstd_status", snapshot.zstdStatus);
            state.put("tar_status", snapshot.tarStatus);
            state.put("memory_free", snapshot.memory.freeBytes);
            state.put("memory_used", snapshot.memory.usedBytes);
            state.put("memory_max", snapshot.memory.maxBytes);
            state.put("source_uri", pkg.uri.toString());
            state.put("payload_sha256", pkg.manifest.payload.sha256);
            state.put("updated_at", isoNow());
            writeAtomic(localState, state.toString(2));
            writeAtomic(RuntimeLogWriter.lastInstallState(context), state.toString(2));
        } catch (Throwable ignored) {
        }
    }

    static void writeComplete(File stateRoot, File installedRoot,
                              PackageInfo pkg, InstallStats stats) throws IOException {
        String json = completeJson(installedRoot, pkg, stats);
        writeAtomic(new File(stateRoot, "installed_runtime.json"), json);
        writeAtomic(new File(stateRoot, "install_state.json"), json);
    }

    static void writeGlobalComplete(Context context, File installedRoot,
                                    PackageInfo pkg, InstallStats stats) throws IOException {
        writeAtomic(RuntimeLogWriter.lastInstallState(context),
                completeJson(installedRoot, pkg, stats));
    }

    private static String completeJson(File installedRoot, PackageInfo pkg,
                                       InstallStats stats) throws IOException {
        try {
            JSONObject state = new JSONObject();
            state.put("runtime_id", pkg.manifest.runtimeId);
            state.put("version", pkg.manifest.version);
            state.put("schema", pkg.manifest.schema);
            state.put("installed_at", isoNow());
            state.put("rootfs_path", installedRoot.getAbsolutePath());
            state.put("payload_sha256", pkg.manifest.payload.sha256);
            state.put("install_state", "complete");
            state.put("stage", InstallStage.COMPLETED.name());
            state.put("file_count", stats.files);
            state.put("directory_count", stats.directories);
            state.put("symlink_count", stats.symlinks);
            state.put("hardlink_count", stats.hardLinks);
            state.put("installed_size_bytes", stats.writtenBytes);
            state.put("hardlink_logical_bytes", stats.hardLinkLogicalBytes);
            state.put("source_uri", pkg.uri.toString());
            return state.toString(2);
        } catch (Exception error) {
            throw new IOException("تعذر إنشاء ملف حالة التثبيت النهائي", error);
        }
    }

    private static void writeAtomic(File destination, String text) throws IOException {
        File parent = destination.getParentFile();
        if (parent != null && !parent.exists() && !parent.mkdirs()) {
            throw new IOException("تعذر إنشاء مجلد التقرير");
        }
        File temporary = new File(destination.getParentFile(), destination.getName() + ".tmp");
        try (FileOutputStream output = new FileOutputStream(temporary, false)) {
            output.write(text.getBytes(StandardCharsets.UTF_8));
            output.getFD().sync();
        }
        if (destination.exists() && !destination.delete()) {
            throw new IOException("تعذر استبدال ملف الحالة");
        }
        if (!temporary.renameTo(destination)) {
            throw new IOException("تعذر تثبيت ملف الحالة");
        }
    }

    private static String isoNow() {
        return new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssXXX", Locale.US).format(new Date());
    }
}
