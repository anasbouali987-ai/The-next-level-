package com.gtav.runtimemanager;

enum InstallStage {
    IDLE("جاهز"),
    PREFLIGHT("تشخيص بيئة التثبيت"),
    PREFLIGHT_PLATFORM("فحص منصة Android ونظام الملفات"),
    PREFLIGHT_ZSTD_NATIVE("فحص مكتبة Zstandard الأصلية"),
    PREFLIGHT_ZSTD_STREAMING("اختبار Zstandard Streaming"),
    PREFLIGHT_TAR("اختبار TAR داخل الحزمة"),
    PREPARING("تجهيز التثبيت الذري"),
    OPENING_PACKAGE("قراءة الحزمة"),
    STARTING_ZSTD("تهيئة محرك Zstandard"),
    READING_TAR("تهيئة قارئ TAR"),
    EXTRACTING("استخراج RootFS"),
    CREATING_SYMLINKS("إنشاء الروابط الرمزية"),
    CREATING_HARDLINKS("إنشاء Hard Links"),
    APPLYING_PERMISSIONS("تطبيق صلاحيات Unix"),
    POST_VERIFY("التحقق بعد التثبيت"),
    FINALIZING("إنهاء التثبيت الذري"),
    COMPLETED("اكتمل التثبيت"),
    FAILED("فشل التثبيت"),
    CANCELLED("تم إلغاء التثبيت");

    final String label;
    InstallStage(String label) { this.label = label; }
}
