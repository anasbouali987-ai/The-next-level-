package com.gtav.runtimemanager;

import android.content.Context;

import java.io.File;

/** Reconciles interrupted atomic installs before a new session begins. */
final class RuntimeRecoveryManager {
    private RuntimeRecoveryManager() {}

    static void recover(Context context) {
        Context app = context.getApplicationContext();
        File root = StorageLocations.runtimesRoot(app);
        File[] children = root.listFiles();
        if (children == null) return;
        try (RuntimeLogWriter log = new RuntimeLogWriter(app, "startup-recovery")) {
            for (File child : children) {
                String name = child.getName();
                if (name.endsWith(".backup")) {
                    File target = new File(root, name.substring(0, name.length() - ".backup".length()));
                    if (!target.exists()) {
                        if (child.renameTo(target)) log.log("RESTORED_BACKUP " + target.getName());
                        else log.log("FAILED_RESTORE_BACKUP " + child.getAbsolutePath());
                    }
                } else if (name.endsWith(".installing")) {
                    log.log("FOUND_INTERRUPTED_INSTALL " + child.getAbsolutePath());
                    // Keep the directory for diagnostics. It is removed by the next explicit install.
                }
            }
        } catch (Throwable error) {
            RuntimeCrashReporter.record(app, "startup-recovery", error, InstallSnapshot.idle());
        }
    }
}
