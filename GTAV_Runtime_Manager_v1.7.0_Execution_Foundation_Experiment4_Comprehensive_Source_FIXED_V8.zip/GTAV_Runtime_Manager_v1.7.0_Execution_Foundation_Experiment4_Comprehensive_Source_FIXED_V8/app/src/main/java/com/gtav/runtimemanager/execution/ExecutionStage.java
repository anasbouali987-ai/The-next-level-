package com.gtav.runtimemanager.execution;

public enum ExecutionStage {
    IDLE("خامل"),
    PREPARING("تجهيز الجلسة"),
    VALIDATING("التحقق من بيئة التشغيل"),
    STARTING_PROOT("تشغيل PRoot"),
    ENTERING_ROOTFS("دخول RootFS"),
    RUNNING_BOX64("اختبار Box64"),
    STARTING_WINE("تهيئة Wine"),
    RUNNING("تشغيل أمر Windows"),
    STOPPING("طلب إيقاف الجلسة"),
    CLEANING_UP("تنظيف شجرة العمليات"),
    COMPLETED("اكتملت الجلسة"),
    FAILED("فشلت الجلسة"),
    CANCELLED("أُلغيت الجلسة"),
    TIMED_OUT("انتهت مهلة الجلسة"),
    RECOVERY_REQUIRED("تحتاج الجلسة إلى استرداد");

    public final String label;
    ExecutionStage(String label) { this.label = label; }

    public boolean terminal() {
        return this == COMPLETED || this == FAILED || this == CANCELLED ||
                this == TIMED_OUT || this == RECOVERY_REQUIRED;
    }
}
