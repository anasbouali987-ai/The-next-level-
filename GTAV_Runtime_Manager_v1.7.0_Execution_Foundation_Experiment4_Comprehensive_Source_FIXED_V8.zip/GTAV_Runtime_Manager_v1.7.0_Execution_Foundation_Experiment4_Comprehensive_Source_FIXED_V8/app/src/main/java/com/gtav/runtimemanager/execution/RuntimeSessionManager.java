package com.gtav.runtimemanager.execution;

import android.content.Context;

import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.nio.channels.FileChannel;
import java.nio.channels.FileLock;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicBoolean;

/** Owns the single active execution session and a cross-process file lock. */
public final class RuntimeSessionManager {
    private final Context context;
    private final AtomicBoolean localBusy = new AtomicBoolean(false);
    private FileChannel lockChannel;
    private FileLock globalLock;
    private RuntimeSession active;

    public RuntimeSessionManager(Context context) { this.context = context.getApplicationContext(); }

    public synchronized RuntimeSession create(String runtimeId) throws Exception {
        String validatedRuntime = ExecutionPaths.requireSafeId(runtimeId, "runtimeId");
        if (!localBusy.compareAndSet(false, true)) {
            throw new RuntimeExecutionException(ExecutionErrorCode.SESSION_CONFLICT,
                    ExecutionStage.PREPARING, "توجد جلسة تشغيل قيد التنفيذ");
        }
        try {
            File global = new File(ExecutionPaths.sessions(context), ".global-execution.lock");
            lockChannel = new FileOutputStream(global, true).getChannel();
            try { globalLock = lockChannel.tryLock(); }
            catch (java.nio.channels.OverlappingFileLockException error) { globalLock = null; }
            if (globalLock == null) {
                throw new RuntimeExecutionException(ExecutionErrorCode.SESSION_CONFLICT,
                        ExecutionStage.PREPARING, "توجد جلسة تشغيل أخرى في عملية مختلفة");
            }
            String stamp = new SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(new Date());
            String id = "exec-" + stamp + "-" + UUID.randomUUID().toString().substring(0, 12);
            active = new RuntimeSession(id, validatedRuntime, ExecutionPaths.session(context, id));
            JSONObject owner = new JSONObject();
            owner.put("schema_version", 1);
            owner.put("session_id", active.id);
            owner.put("runtime_id", active.runtimeId);
            owner.put("owner_pid", android.os.Process.myPid());
            owner.put("owner_start_ticks", RuntimeProcessSupervisor.readStartTicks(android.os.Process.myPid()));
            owner.put("created_at", active.createdAt);
            AtomicFileWriter.writeText(active.lockFile, owner.toString(2));
            return active;
        } catch (Throwable error) {
            release();
            if (error instanceof Exception) throw (Exception) error;
            throw new RuntimeException(error);
        }
    }

    public synchronized RuntimeSession active() { return active; }

    public synchronized void release() {
        if (active != null && active.lockFile.exists() && !active.lockFile.delete()) {
            active.lockFile.deleteOnExit();
        }
        active = null;
        try { if (globalLock != null && globalLock.isValid()) globalLock.release(); } catch (Throwable ignored) {}
        try { if (lockChannel != null) lockChannel.close(); } catch (Throwable ignored) {}
        globalLock = null;
        lockChannel = null;
        localBusy.set(false);
    }

}
