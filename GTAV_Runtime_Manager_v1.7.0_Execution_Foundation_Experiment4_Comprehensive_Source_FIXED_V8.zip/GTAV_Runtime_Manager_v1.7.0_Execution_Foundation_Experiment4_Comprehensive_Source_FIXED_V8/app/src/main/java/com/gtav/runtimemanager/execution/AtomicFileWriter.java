package com.gtav.runtimemanager.execution;

import android.system.Os;
import android.system.OsConstants;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;

/** Crash-resistant same-directory atomic file replacement for session evidence. */
final class AtomicFileWriter {
    private AtomicFileWriter() {}

    static void writeText(File destination, String text) throws Exception {
        File parent = requireParent(destination);
        File tmp = temporary(destination);
        try {
            try (FileOutputStream out = new FileOutputStream(tmp, false)) {
                out.write((text == null ? "" : text).getBytes(StandardCharsets.UTF_8));
                out.getFD().sync();
            }
            replace(tmp, destination);
            syncDirectory(parent);
        } finally {
            if (tmp.exists()) tmp.delete();
        }
    }

    static void copy(File source, File destination) throws Exception {
        File parent = requireParent(destination);
        File tmp = temporary(destination);
        try {
            try (FileInputStream in = new FileInputStream(source);
                 FileOutputStream out = new FileOutputStream(tmp, false)) {
                byte[] buffer = new byte[64 * 1024];
                int read;
                while ((read = in.read(buffer)) != -1) out.write(buffer, 0, read);
                out.getFD().sync();
            }
            replace(tmp, destination);
            syncDirectory(parent);
        } finally {
            if (tmp.exists()) tmp.delete();
        }
    }

    private static File requireParent(File destination) {
        File parent = destination.getParentFile();
        if (parent == null) throw new IllegalArgumentException("Destination has no parent");
        if (!parent.exists() && !parent.mkdirs() && !parent.isDirectory()) {
            throw new IllegalStateException("تعذر إنشاء مجلد التقرير");
        }
        return parent;
    }

    private static File temporary(File destination) {
        return new File(destination.getParentFile(), destination.getName() + ".tmp-" +
                android.os.Process.myPid() + "-" + Thread.currentThread().getId());
    }

    private static void replace(File source, File destination) throws Exception {
        Os.rename(source.getAbsolutePath(), destination.getAbsolutePath());
    }

    private static void syncDirectory(File directory) throws Exception {
        java.io.FileDescriptor descriptor = null;
        try {
            descriptor = Os.open(directory.getAbsolutePath(),
                    OsConstants.O_RDONLY, 0);
            Os.fsync(descriptor);
        } finally {
            if (descriptor != null) try { Os.close(descriptor); } catch (Throwable ignored) {}
        }
    }
}
