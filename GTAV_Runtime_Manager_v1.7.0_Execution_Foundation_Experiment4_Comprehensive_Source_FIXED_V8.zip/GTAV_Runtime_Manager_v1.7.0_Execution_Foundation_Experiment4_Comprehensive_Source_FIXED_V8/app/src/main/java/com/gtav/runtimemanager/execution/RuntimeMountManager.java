package com.gtav.runtimemanager.execution;

import android.content.Context;

import com.gtav.runtimemanager.VerifiedInstalledRuntime;

import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Creates explicit allow-listed binds; phone storage is never broadly exposed. */
public final class RuntimeMountManager {
    public static final class MountPlan {
        public final List<RuntimeBindMount> mounts;
        public final File winePrefix;
        public final File profile;
        public final File cache;
        public final File helloX8664;

        MountPlan(List<RuntimeBindMount> mounts, File winePrefix, File profile,
                  File cache, File helloX8664) {
            this.mounts = Collections.unmodifiableList(new ArrayList<>(mounts));
            this.winePrefix = winePrefix;
            this.profile = profile;
            this.cache = cache;
            this.helloX8664 = helloX8664;
        }
    }

    public MountPlan build(Context context, VerifiedInstalledRuntime runtime,
                           RuntimeSession session, WinePrefixManager.PrefixLease prefixLease,
                           File helloX8664) throws Exception {
        File prefix = prefixLease.root;
        File profile = ExecutionPaths.profile(context, runtime.runtimeId());
        File cache = ExecutionPaths.runtimeCache(context, runtime.runtimeId());
        File sessionHello = copySessionTestBinary(helloX8664, session.guestShareDir);
        validateWritable(prefix, "Wine Prefix");
        validateWritable(profile, "Profile");
        validateWritable(cache, "Cache");
        validateWritable(session.directory, "Session");

        List<RuntimeBindMount> mounts = new ArrayList<>();
        // Only a dedicated guest-share directory is visible inside the guest. State, logs and
        // reports remain host-only evidence and cannot be tampered with by Wine/Box64.
        mounts.add(new RuntimeBindMount(session.guestShareDir, "/mnt/gtav-session", false, true,
                RuntimeBindMount.Purpose.SESSION));
        mounts.add(new RuntimeBindMount(session.tmpDir, "/tmp", false, true,
                RuntimeBindMount.Purpose.TEMP));
        mounts.add(new RuntimeBindMount(session.runDir, "/run", false, true,
                RuntimeBindMount.Purpose.TEMP));
        mounts.add(new RuntimeBindMount(session.varTmpDir, "/var/tmp", false, true,
                RuntimeBindMount.Purpose.TEMP));
        mounts.add(new RuntimeBindMount(session.varCacheDir, "/var/cache", false, true,
                RuntimeBindMount.Purpose.CACHE));
        mounts.add(new RuntimeBindMount(session.varLogDir, "/var/log", false, true,
                RuntimeBindMount.Purpose.TEMP));
        mounts.add(new RuntimeBindMount(prefix, "/mnt/wineprefix", false, true,
                RuntimeBindMount.Purpose.PREFIX));
        // /root is session-owned so a smoke test can never pass because of stale home state.
        mounts.add(new RuntimeBindMount(session.homeDir, "/root", false, true,
                RuntimeBindMount.Purpose.HOME));
        mounts.add(new RuntimeBindMount(profile, "/mnt/gtav-profile", false, true,
                RuntimeBindMount.Purpose.PROFILE));
        mounts.add(new RuntimeBindMount(cache, "/mnt/runtime-cache", false, true,
                RuntimeBindMount.Purpose.CACHE));
        mounts.add(new RuntimeBindMount(session.resolvConf, "/etc/resolv.conf", true, true,
                RuntimeBindMount.Purpose.SYSTEM_BRIDGE));
        mounts.add(new RuntimeBindMount(session.hostsFile, "/etc/hosts", true, true,
                RuntimeBindMount.Purpose.SYSTEM_BRIDGE));
        mounts.add(new RuntimeBindMount(session.hostnameFile, "/etc/hostname", true, true,
                RuntimeBindMount.Purpose.SYSTEM_BRIDGE));
        if (new File("/proc").isDirectory()) mounts.add(new RuntimeBindMount(
                new File("/proc"), "/proc", true, false, RuntimeBindMount.Purpose.SYSTEM_BRIDGE));
        // Do not expose the complete Android /dev tree. Bind only the basic devices required by
        // the console runtime, and provide session-owned shared memory.
        addDeviceIfPresent(mounts, "/dev/null", true);
        addDeviceIfPresent(mounts, "/dev/zero", true);
        addDeviceIfPresent(mounts, "/dev/urandom", true);
        addDeviceIfPresent(mounts, "/dev/random", false);
        mounts.add(new RuntimeBindMount(session.devShmDir, "/dev/shm", false, true,
                RuntimeBindMount.Purpose.DEVICE));
        validateMountSet(mounts, runtime.rootfs());
        return new MountPlan(mounts, prefix, profile, cache, sessionHello);
    }

    private static File copySessionTestBinary(File source, File guestShare) throws Exception {
        if (source == null || !source.isFile()) throw new RuntimeExecutionException(
                ExecutionErrorCode.EXECUTION_COMPONENTS_INVALID, ExecutionStage.PREPARING,
                "ملف اختبار x86_64 مفقود");
        File destination = new File(guestShare, "hello-x86_64");
        File tmp = new File(guestShare, "hello-x86_64.tmp");
        try (java.io.FileInputStream input = new java.io.FileInputStream(source);
             FileOutputStream output = new FileOutputStream(tmp, false)) {
            byte[] buffer = new byte[128 * 1024];
            int read;
            while ((read = input.read(buffer)) != -1) output.write(buffer, 0, read);
            output.getFD().sync();
        }
        if (destination.exists() && !destination.delete()) throw new IllegalStateException("تعذر استبدال test binary");
        if (!tmp.renameTo(destination)) throw new IllegalStateException("تعذر تثبيت test binary");
        if (!destination.setExecutable(true, true)) throw new IllegalStateException("test binary غير قابل للتنفيذ");
        return destination;
    }

    private static void addDeviceIfPresent(List<RuntimeBindMount> mounts, String path, boolean required) {
        File device = new File(path);
        if (device.exists() || required) mounts.add(new RuntimeBindMount(
                device, path, false, required, RuntimeBindMount.Purpose.DEVICE));
    }

    private static void validateMountSet(List<RuntimeBindMount> mounts, File rootfs) throws Exception {
        Set<String> guestPaths = new HashSet<>();
        String root = rootfs.getCanonicalPath();
        for (RuntimeBindMount mount : mounts) {
            if (!guestPaths.add(mount.guestPath)) {
                throw new RuntimeExecutionException(ExecutionErrorCode.RUNTIME_NOT_READY,
                        ExecutionStage.PREPARING, "Guest bind مكرر: " + mount.guestPath);
            }
            if (mount.required && !mount.hostPath.exists()) {
                throw new RuntimeExecutionException(ExecutionErrorCode.RUNTIME_NOT_READY,
                        ExecutionStage.PREPARING, "مصدر Bind مفقود: " + mount.hostPath);
            }
            String host = mount.hostPath.getCanonicalPath();
            if (!mount.readOnly && (host.equals(root) || host.startsWith(root + File.separator))) {
                throw new RuntimeExecutionException(ExecutionErrorCode.RUNTIME_MUTATED,
                        ExecutionStage.PREPARING, "يُمنع ربط RootFS كمصدر قابل للكتابة", false);
            }
        }
    }

    private static void validateWritable(File directory, String label) throws Exception {
        File probe = new File(directory, ".write-probe-" + android.os.Process.myPid());
        try (FileOutputStream out = new FileOutputStream(probe, false)) {
            out.write(1);
            out.getFD().sync();
        }
        if (!probe.delete()) probe.deleteOnExit();
        if (!directory.canWrite()) throw new IllegalStateException(label + " غير قابل للكتابة");
    }

    public static String format(List<RuntimeBindMount> mounts) {
        StringBuilder out = new StringBuilder();
        out.append("NOTE: PRoot does not provide a kernel-enforced read-only mount.\n");
        out.append("readOnly=true is a policy declaration and integrity is checked after execution.\n\n");
        for (RuntimeBindMount mount : mounts) out.append(mount).append('\n');
        return out.toString();
    }
}
