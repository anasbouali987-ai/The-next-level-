package com.gtav.runtimemanager;

import android.content.Context;

import java.io.File;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.Executor;

/** Runs the startup readiness check off the UI thread and persists its latest report. */
final class StartupDiagnostic {
    interface Listener {
        void onComplete(RuntimePlatformValidator.Report report, Throwable error);
    }

    private StartupDiagnostic() { }

    static File reportFile(Context context) {
        return new File(RuntimeLogWriter.reportsDir(context), "startup_diagnostic.txt");
    }

    static void run(Context context, Executor executor, Listener listener) {
        Context app = context.getApplicationContext();
        executor.execute(() -> {
            RuntimePlatformValidator.Report report = null;
            Throwable failure = null;
            try {
                CompressionManager compression = CompressionManager.createDefault();
                report = new RuntimePlatformValidator().validateQuick(
                        app, compression, new NativeLibraryManager());
                writeReport(app, report.format());
            } catch (Throwable error) {
                failure = error;
                writeReport(app, "STARTUP DIAGNOSTIC FAILED\n" + stack(error));
            }
            listener.onComplete(report, failure);
        });
    }

    private static void writeReport(Context context, String text) {
        try (FileOutputStream output = new FileOutputStream(reportFile(context), false)) {
            output.write(text.getBytes(StandardCharsets.UTF_8));
            output.getFD().sync();
        } catch (Throwable ignored) { }
    }

    private static String stack(Throwable error) {
        java.io.StringWriter writer = new java.io.StringWriter();
        error.printStackTrace(new java.io.PrintWriter(writer));
        return writer.toString();
    }
}
