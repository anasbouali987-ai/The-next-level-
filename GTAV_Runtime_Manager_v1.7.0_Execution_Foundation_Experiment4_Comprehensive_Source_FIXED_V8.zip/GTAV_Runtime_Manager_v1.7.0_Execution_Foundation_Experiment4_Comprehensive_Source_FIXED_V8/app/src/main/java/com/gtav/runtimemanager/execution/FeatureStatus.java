package com.gtav.runtimemanager.execution;

/** Independent evidence-bearing feature lifecycle, not a single Boolean. */
public final class FeatureStatus {
    public final ExecutionFeature feature;
    public final boolean requested;
    public final boolean available;
    public final boolean validated;
    public final boolean enabled;
    public final FeatureState state;
    public final String reason;
    public final String evidence;

    FeatureStatus(ExecutionFeature feature, boolean requested, boolean available,
                  boolean validated, boolean enabled, FeatureState state,
                  String reason, String evidence) {
        this.feature = feature;
        this.requested = requested;
        this.available = available;
        this.validated = validated;
        this.enabled = enabled;
        this.state = state;
        this.reason = reason == null ? "" : reason;
        this.evidence = evidence == null ? "" : evidence;
    }
}
