package com.gtav.runtimemanager.execution;

public final class RuntimeExecutionResult {
    public final int exitCode;
    public final long pid;
    public final long startedAt;
    public final long finishedAt;
    public final boolean timedOut;
    public final boolean cancelled;
    public final String stdoutTail;
    public final String stderrTail;

    RuntimeExecutionResult(int exitCode, long pid, long startedAt, long finishedAt,
                           boolean timedOut, boolean cancelled, String stdoutTail, String stderrTail) {
        this.exitCode = exitCode;
        this.pid = pid;
        this.startedAt = startedAt;
        this.finishedAt = finishedAt;
        this.timedOut = timedOut;
        this.cancelled = cancelled;
        this.stdoutTail = stdoutTail;
        this.stderrTail = stderrTail;
    }

    public boolean success(String expected) {
        return !timedOut && !cancelled && exitCode == 0 &&
                (expected == null || expected.isEmpty() || stdoutTail.contains(expected));
    }
}
