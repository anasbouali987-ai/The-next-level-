package com.gtav.runtimemanager;

import android.system.Os;

import java.io.File;
import java.io.IOException;

final class PermissionApplier {
    interface Ops {
        void chmod(File file, int mode) throws Exception;
    }

    static final class AndroidOps implements Ops {
        @Override
        public void chmod(File file, int mode) throws Exception {
            Os.chmod(file.getAbsolutePath(), mode);
        }
    }

    private final Ops ops;

    PermissionApplier(Ops ops) {
        this.ops = ops;
    }

    void apply(File file, int mode, InstallStage stage) throws RuntimeInstallException {
        if (mode <= 0) return;
        try {
            ops.chmod(file, mode);
        } catch (Throwable error) {
            throw new RuntimeInstallException(
                    InstallErrorCode.CHMOD_FAILED,
                    stage,
                    "تعذر ضبط صلاحيات Unix: " + file.getAbsolutePath(),
                    file.getAbsolutePath(),
                    error
            );
        }
    }
}
