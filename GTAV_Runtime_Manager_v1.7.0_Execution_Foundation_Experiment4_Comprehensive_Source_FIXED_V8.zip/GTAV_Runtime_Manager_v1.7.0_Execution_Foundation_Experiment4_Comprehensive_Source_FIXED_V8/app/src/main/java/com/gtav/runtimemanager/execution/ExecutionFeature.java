package com.gtav.runtimemanager.execution;

public enum ExecutionFeature {
    PROOT, BOX64, WINE, DISPLAY, AUDIO, GRAPHICS, DXVK, INPUT, GAME_LIBRARY
}
