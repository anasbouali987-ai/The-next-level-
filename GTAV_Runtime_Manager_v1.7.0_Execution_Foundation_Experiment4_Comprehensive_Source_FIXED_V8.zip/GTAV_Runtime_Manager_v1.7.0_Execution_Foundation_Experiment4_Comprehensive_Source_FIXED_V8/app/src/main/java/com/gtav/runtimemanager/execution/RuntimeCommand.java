package com.gtav.runtimemanager.execution;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class RuntimeCommand {
    public final String executable;
    public final List<String> arguments;
    public final long timeoutMs;
    public final String expectedOutput;

    public RuntimeCommand(String executable, List<String> arguments, long timeoutMs, String expectedOutput) {
        if (executable == null || executable.isEmpty() || executable.indexOf('\0') >= 0) {
            throw new IllegalArgumentException("Executable غير صالح");
        }
        this.executable = executable;
        this.arguments = Collections.unmodifiableList(new ArrayList<>(arguments));
        this.timeoutMs = timeoutMs;
        this.expectedOutput = expectedOutput == null ? "" : expectedOutput;
        for (String argument : this.arguments) {
            if (argument == null || argument.indexOf('\0') >= 0) throw new IllegalArgumentException("Argument غير صالح");
        }
    }

    public List<String> argv() {
        ArrayList<String> result = new ArrayList<>();
        result.add(executable);
        result.addAll(arguments);
        return result;
    }

    public String display() { return String.join(" ", argv()); }
}
