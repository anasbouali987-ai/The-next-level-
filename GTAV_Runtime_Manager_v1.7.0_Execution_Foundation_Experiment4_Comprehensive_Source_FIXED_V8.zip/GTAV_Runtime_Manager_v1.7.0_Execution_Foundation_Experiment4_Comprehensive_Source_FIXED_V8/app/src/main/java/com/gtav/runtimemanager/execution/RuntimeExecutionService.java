package com.gtav.runtimemanager.execution;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;

import com.gtav.runtimemanager.MainActivity;
import com.gtav.runtimemanager.R;

/** Foreground owner for long-running PRoot/Box64/Wine sessions. */
public final class RuntimeExecutionService extends Service implements RuntimeExecutionManager.Listener {
    public static final String ACTION_START = "com.gtav.runtimemanager.execution.START";
    public static final String ACTION_STOP = "com.gtav.runtimemanager.execution.STOP";
    public static final String ACTION_FINISH = "com.gtav.runtimemanager.execution.FINISH";
    public static final String ACTION_REFRESH = "com.gtav.runtimemanager.execution.REFRESH";
    private static final String CHANNEL = "runtime_execution";
    private static final int ID = 1700;
    private RuntimeExecutionManager manager;
    private PowerManager.WakeLock wakeLock;

    public static void refresh(Context context, RuntimeExecutionSnapshot snapshot) {
        if (!snapshot.running) return;
        try { context.startService(new Intent(context, RuntimeExecutionService.class).setAction(ACTION_REFRESH)); }
        catch (Throwable ignored) {}
    }

    @Override public void onCreate() {
        super.onCreate();
        manager = RuntimeExecutionManager.get(this);
        manager.addListener(this);
        createChannel();
        PowerManager power = (PowerManager) getSystemService(POWER_SERVICE);
        wakeLock = power.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "GTAVRuntime:Execution");
        wakeLock.setReferenceCounted(false);
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? ACTION_START : intent.getAction();
        if (ACTION_STOP.equals(action)) {
            manager.stop();
            return START_NOT_STICKY;
        }
        if (ACTION_FINISH.equals(action)) {
            stopForeground(STOP_FOREGROUND_REMOVE);
            stopSelf();
            return START_NOT_STICKY;
        }
        if (wakeLock != null && !wakeLock.isHeld()) wakeLock.acquire(6 * 60 * 60 * 1000L);
        startForeground(ID, notification(manager.current()));
        return START_NOT_STICKY;
    }

    @Override public void onExecutionSnapshot(RuntimeExecutionSnapshot snapshot) {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        nm.notify(ID, notification(snapshot));
        if (snapshot.stage.terminal() && !snapshot.running) {
            if (wakeLock != null && wakeLock.isHeld()) wakeLock.release();
        }
    }

    private Notification notification(RuntimeExecutionSnapshot snapshot) {
        Intent open = new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent openPi = PendingIntent.getActivity(this, 1, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Intent stop = new Intent(this, RuntimeExecutionService.class).setAction(ACTION_STOP);
        PendingIntent stopPi = PendingIntent.getService(this, 2, stop,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        long elapsed = snapshot.startedAt > 0 ? Math.max(0, System.currentTimeMillis() - snapshot.startedAt) / 1000 : 0;
        String text = snapshot.stage.label + " — " + (snapshot.command.isEmpty() ? snapshot.message : snapshot.command) +
                " — " + elapsed + "s";
        Notification.Builder builder = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, CHANNEL) : new Notification.Builder(this);
        return builder.setSmallIcon(android.R.drawable.stat_sys_download)
                .setContentTitle("GTAV Runtime Execution")
                .setContentText(text)
                .setStyle(new Notification.BigTextStyle().bigText(text))
                .setContentIntent(openPi)
                .setOngoing(snapshot.running)
                .addAction(new Notification.Action.Builder(android.R.drawable.ic_menu_close_clear_cancel, "إيقاف", stopPi).build())
                .build();
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT < 26) return;
        NotificationChannel channel = new NotificationChannel(CHANNEL, "Runtime Execution",
                NotificationManager.IMPORTANCE_LOW);
        channel.setDescription("PRoot / Box64 / Wine execution sessions");
        ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(channel);
    }

    @Override
    public void onTimeout(int startId, int fgsType) {
        if (manager != null) manager.cancel();
        stopForeground(STOP_FOREGROUND_REMOVE);
        stopSelf(startId);
    }

    @Override public IBinder onBind(Intent intent) { return null; }
    @Override public void onDestroy() {
        manager.removeListener(this);
        if (wakeLock != null && wakeLock.isHeld()) wakeLock.release();
        super.onDestroy();
    }
}
