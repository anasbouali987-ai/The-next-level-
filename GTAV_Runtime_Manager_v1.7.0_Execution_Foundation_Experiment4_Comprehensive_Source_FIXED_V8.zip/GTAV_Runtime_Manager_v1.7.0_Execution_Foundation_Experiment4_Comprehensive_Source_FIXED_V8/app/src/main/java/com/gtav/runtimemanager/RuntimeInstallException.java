package com.gtav.runtimemanager;

import java.io.IOException;

final class RuntimeInstallException extends IOException {
    final InstallErrorCode code;
    final InstallStage stage;
    final String currentFile;

    RuntimeInstallException(InstallErrorCode code, InstallStage stage, String message) {
        this(code, stage, message, "", null);
    }

    RuntimeInstallException(InstallErrorCode code, InstallStage stage, String message, Throwable cause) {
        this(code, stage, message, "", cause);
    }

    RuntimeInstallException(InstallErrorCode code, InstallStage stage, String message,
                            String currentFile, Throwable cause) {
        super(message, cause);
        this.code = code;
        this.stage = stage;
        this.currentFile = currentFile == null ? "" : currentFile;
    }
}
