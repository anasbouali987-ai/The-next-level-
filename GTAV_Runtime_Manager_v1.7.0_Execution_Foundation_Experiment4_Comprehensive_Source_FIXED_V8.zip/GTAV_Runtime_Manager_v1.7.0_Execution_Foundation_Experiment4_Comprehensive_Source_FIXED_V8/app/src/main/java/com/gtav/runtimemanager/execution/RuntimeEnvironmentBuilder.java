package com.gtav.runtimemanager.execution;

import android.content.Context;

import com.gtav.runtimemanager.VerifiedInstalledRuntime;

import java.io.File;
import java.util.LinkedHashMap;
import java.util.Map;

/** Builds strictly separated Android/Bionic host and glibc guest environments. */
public final class RuntimeEnvironmentBuilder {
    public RuntimeEnvironment build(Context context, VerifiedInstalledRuntime runtime,
                                    RuntimeSession session, File winePrefix) {
        File usr = ExecutionPaths.usr(context);
        String androidLibs = new File(usr, "lib").getAbsolutePath();
        String guestLibs = "/usr/local/lib:/usr/lib:/lib";
        String box64Libs = "/usr/lib/x86_64-linux-gnu:/lib/x86_64-linux-gnu:/usr/local/lib64";

        Map<String, String> host = new LinkedHashMap<>();
        host.put("PATH", new File(usr, "bin").getAbsolutePath() + ":/system/bin:/system/xbin");
        host.put("HOME", context.getFilesDir().getAbsolutePath());
        host.put("TMPDIR", session.tmpDir.getAbsolutePath());
        host.put("PROOT_LOADER", ExecutionPaths.loader(context).getAbsolutePath());
        host.put("PROOT_TMP_DIR", session.prootTmpDir.getAbsolutePath());
        host.put("ANDROID_LD_LIBRARY_PATH", androidLibs);
        host.put("LD_LIBRARY_PATH", androidLibs); // Consumed by the Android-native PRoot executable only.
        host.put("GTAV_SESSION_ID", session.id);
        host.put("GTAV_RUNTIME_ID", runtime.runtimeId());

        Map<String, String> guest = new LinkedHashMap<>();
        guest.put("HOME", "/root");
        guest.put("USER", "root");
        guest.put("LOGNAME", "root");
        guest.put("SHELL", "/bin/sh");
        guest.put("PATH", "/opt/gtav-runtime/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin");
        guest.put("TMPDIR", "/tmp");
        guest.put("XDG_RUNTIME_DIR", "/run/user/0");
        guest.put("XDG_CACHE_HOME", "/mnt/runtime-cache/xdg");
        guest.put("XDG_CONFIG_HOME", "/root/.config");
        guest.put("LANG", "C.UTF-8");
        guest.put("LC_ALL", "C.UTF-8");
        // GUEST_LD_LIBRARY_PATH is recorded as an explicit architecture boundary;
        // LD_LIBRARY_PATH is the variable the glibc guest loader actually consumes.
        guest.put("GUEST_LD_LIBRARY_PATH", guestLibs);
        guest.put("LD_LIBRARY_PATH", guestLibs);
        guest.put("BOX64_LD_LIBRARY_PATH", box64Libs);
        guest.put("BOX64_PATH", "/usr/local/bin:/usr/bin:/bin");
        guest.putAll(new Box64EnvironmentBuilder().build(true));
        guest.put("WINEPREFIX", "/mnt/wineprefix");
        guest.put("WINEARCH", "win64");
        guest.put("WINEDEBUG", "-all");
        guest.put("GTAV_RUNTIME_ID", runtime.runtimeId());
        guest.put("GTAV_SESSION_ID", session.id);
        return new RuntimeEnvironment(host, guest);
    }
}
