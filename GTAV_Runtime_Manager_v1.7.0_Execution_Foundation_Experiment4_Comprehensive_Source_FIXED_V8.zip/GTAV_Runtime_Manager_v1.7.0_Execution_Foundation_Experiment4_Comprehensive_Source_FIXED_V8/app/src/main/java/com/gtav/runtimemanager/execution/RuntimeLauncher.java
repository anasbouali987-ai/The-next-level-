package com.gtav.runtimemanager.execution;

import com.gtav.runtimemanager.VerifiedInstalledRuntime;

/** Builds an immutable launch plan; it never starts a process itself. */
public final class RuntimeLauncher {
    private final IsolationEngine isolationEngine;
    public RuntimeLauncher(IsolationEngine isolationEngine) { this.isolationEngine = isolationEngine; }

    public RuntimeLaunchPlan plan(VerifiedInstalledRuntime runtime, RuntimeSession session,
                                  RuntimeMountManager.MountPlan mounts,
                                  RuntimeEnvironment environment, RuntimeCommand command)
            throws RuntimeExecutionException {
        return isolationEngine.buildPlan(runtime, session, mounts, environment, command);
    }
}
