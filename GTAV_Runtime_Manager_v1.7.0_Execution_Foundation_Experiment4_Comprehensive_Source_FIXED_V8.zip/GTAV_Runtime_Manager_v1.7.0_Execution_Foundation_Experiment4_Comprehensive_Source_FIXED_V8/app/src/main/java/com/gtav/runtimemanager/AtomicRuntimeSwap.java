package com.gtav.runtimemanager;

import java.io.File;
import java.io.IOException;

final class AtomicRuntimeSwap {
    interface Ops {
        boolean exists(File file);
        boolean rename(File from, File to);
        void delete(File file) throws Exception;
    }

    static final class AndroidOps implements Ops {
        private final File allowedRoot;
        private final RuntimeLogWriter log;

        AndroidOps(File allowedRoot, RuntimeLogWriter log) {
            this.allowedRoot = allowedRoot;
            this.log = log;
        }

        @Override public boolean exists(File file) { return file.exists(); }
        @Override public boolean rename(File from, File to) { return from.renameTo(to); }
        @Override public void delete(File file) throws Exception {
            FileTools.deleteTree(allowedRoot, file);
        }
    }

    private AtomicRuntimeSwap() {}

    static void promote(File temp, File target, File backup, boolean replace, Ops ops)
            throws IOException {
        boolean movedOld = false;
        if (ops.exists(target)) {
            if (!replace) throw new IOException("Runtime مثبت مسبقًا");
            if (ops.exists(backup)) {
                try { ops.delete(backup); } catch (Exception error) {
                    throw new IOException("تعذر حذف النسخة الاحتياطية القديمة", error);
                }
            }
            if (!ops.rename(target, backup)) {
                throw new IOException("تعذر تجهيز النسخة الاحتياطية");
            }
            movedOld = true;
        }

        if (!ops.rename(temp, target)) {
            if (movedOld && ops.exists(backup)) {
                ops.rename(backup, target);
            }
            throw new IOException("تعذر ترقية التثبيت المؤقت إلى Runtime النهائي");
        }

        if (movedOld && ops.exists(backup)) {
            try {
                ops.delete(backup);
            } catch (Exception ignored) {
                // الترقية نجحت بالفعل. اترك .backup ليُنظف عند التشغيل التالي
                // بدل إعلان فشل زائف بعد تثبيت النسخة الجديدة.
            }
        }
    }
}
