package com.gtav.runtimemanager;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

final class Formatters {
    static String bytes(long b){if(b<0)return"غير معروف";String[]u={"B","KB","MB","GB","TB"};double v=b;int i=0;while(v>=1024&&i<u.length-1){v/=1024;i++;}return new DecimalFormat(v>=100?"0":v>=10?"0.0":"0.00").format(v)+" "+u[i];}
    static String duration(long ms){long s=Math.max(0,ms/1000);return String.format(Locale.US,"%02d:%02d:%02d",s/3600,(s%3600)/60,s%60);}
    static String date(long ms){return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss",Locale.US).format(new Date(ms));}
}
