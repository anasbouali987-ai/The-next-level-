package com.gtav.runtimemanager.execution;

import android.content.Context;
import android.os.Build;

import com.gtav.runtimemanager.VerifiedInstalledRuntime;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/** Execution-only preflight. It never changes the installed Runtime. */
public final class RuntimeExecutionValidator {
    public static final class Report {
        public boolean prootPackaged;
        public boolean prootExecutable;
        public boolean prootVersionOk;
        public boolean readyForProot;
        public boolean box64Executable;
        public boolean readyForBox64;
        public boolean wineEntrypointsReady;
        public boolean readyForWine;
        public String prootMessage = "";
        public String box64Message = "";
        public String wineMessage = "";
        public final List<String> checks = new ArrayList<>();

        public boolean ready() { return readyForProot && readyForBox64 && readyForWine; }
        public String format() {
            StringBuilder out = new StringBuilder();
            for (String check : checks) out.append(check).append('\n');
            out.append("PRoot: ").append(prootMessage).append('\n');
            out.append("Box64: ").append(box64Message).append('\n');
            out.append("Wine: ").append(wineMessage).append('\n');
            return out.toString();
        }
    }

    public Report validate(Context context, VerifiedInstalledRuntime runtime,
                           ExecutionComponentInstaller.Report components) {
        Report report = new Report();
        boolean arm64 = Arrays.asList(Build.SUPPORTED_ABIS).contains("arm64-v8a");
        report.checks.add((arm64 ? "✅" : "❌") + " Device ABI: " + Arrays.toString(Build.SUPPORTED_ABIS));
        report.checks.add("Android API: " + Build.VERSION.SDK_INT);
        report.checks.add("SELinux: " + readSelinux());
        report.checks.add("Seccomp: " + readProcStatus("Seccomp"));
        report.checks.add("NoNewPrivs: " + readProcStatus("NoNewPrivs"));
        report.checks.add("/proc: " + new File("/proc").canRead());
        report.checks.add("/dev: " + new File("/dev").canRead());

        report.prootPackaged = components.proot.isFile() && components.loader.isFile();
        report.prootExecutable = report.prootPackaged && components.proot.canExecute() && components.loader.canExecute();
        try {
            ElfInspector.Result prootElf = ElfInspector.inspect(components.proot);
            ElfInspector.Result loaderElf = ElfInspector.inspect(components.loader);
            report.prootVersionOk = prootElf.isAarch64() && loaderElf.isAarch64();
            report.prootMessage = components.proot.getAbsolutePath() + " — " + prootElf.description +
                    "\nLoader: " + components.loader.getAbsolutePath() + " — " + loaderElf.description;
        } catch (Throwable error) {
            report.prootMessage = error.toString();
        }
        report.readyForProot = arm64 && report.prootPackaged && report.prootExecutable && report.prootVersionOk;
        try {
            ElfInspector.Result helloElf = ElfInspector.inspect(components.helloX8664);
            report.checks.add((helloElf.isX8664() ? "✅" : "❌") + " hello-x86_64: " + helloElf.description);
            if (!helloElf.isX8664()) report.readyForProot = false;
        } catch (Throwable error) {
            report.checks.add("❌ hello-x86_64: " + error);
            report.readyForProot = false;
        }

        File box64 = guestFile(runtime, runtime.box64GuestPath());
        report.box64Executable = box64.isFile() && box64.canExecute();
        report.readyForBox64 = report.readyForProot && report.box64Executable;
        report.box64Message = runtime.box64GuestPath() + " — executable=" + report.box64Executable;

        File wine64 = guestFile(runtime, runtime.wine64GuestPath());
        File wineboot = guestFile(runtime, runtime.winebootGuestPath());
        File wineserver = guestFile(runtime, runtime.wineserverGuestPath());
        report.wineEntrypointsReady = executable(wine64) && executable(wineboot) && executable(wineserver);
        report.readyForWine = report.readyForBox64 && report.wineEntrypointsReady;
        report.wineMessage = "wine64=" + executable(wine64) + ", wineboot=" + executable(wineboot) +
                ", wineserver=" + executable(wineserver);
        return report;
    }

    private static boolean executable(File f) { return f.isFile() && f.canExecute(); }
    private static File guestFile(VerifiedInstalledRuntime runtime, String path) {
        return new File(runtime.rootfs(), path.startsWith("/") ? path.substring(1) : path);
    }
    private static String readProcStatus(String key) {
        try (java.io.BufferedReader reader = new java.io.BufferedReader(
                new java.io.FileReader("/proc/self/status"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.startsWith(key + ":")) return line.substring(line.indexOf(':') + 1).trim();
            }
        } catch (Throwable ignored) {}
        return "unknown";
    }
    private static String readSelinux() {
        try {
            File enforce = new File("/sys/fs/selinux/enforce");
            if (!enforce.isFile()) return "unavailable";
            try (java.io.FileInputStream in = new java.io.FileInputStream(enforce)) {
                int value = in.read(); return value == '1' ? "enforcing" : "permissive";
            }
        } catch (Throwable error) { return "unknown: " + error.getClass().getSimpleName(); }
    }
}
