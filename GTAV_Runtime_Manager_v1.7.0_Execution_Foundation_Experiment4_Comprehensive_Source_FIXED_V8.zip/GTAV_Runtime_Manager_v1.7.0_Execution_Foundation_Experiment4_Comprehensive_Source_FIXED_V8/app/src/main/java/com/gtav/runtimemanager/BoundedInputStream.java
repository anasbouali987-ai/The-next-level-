package com.gtav.runtimemanager;

import java.io.IOException;
import java.io.InputStream;

final class BoundedInputStream extends InputStream {
    private final InputStream source; private long remaining;
    BoundedInputStream(InputStream source, long remaining) { this.source = source; this.remaining = remaining; }
    @Override public int read() throws IOException { if (remaining <= 0) return -1; int v = source.read(); if (v >= 0) remaining--; return v; }
    @Override public int read(byte[] b, int o, int l) throws IOException {
        if (remaining <= 0) return -1; int n = source.read(b, o, (int)Math.min(l, remaining)); if (n > 0) remaining -= n; return n;
    }
    @Override public void close() { }
}
