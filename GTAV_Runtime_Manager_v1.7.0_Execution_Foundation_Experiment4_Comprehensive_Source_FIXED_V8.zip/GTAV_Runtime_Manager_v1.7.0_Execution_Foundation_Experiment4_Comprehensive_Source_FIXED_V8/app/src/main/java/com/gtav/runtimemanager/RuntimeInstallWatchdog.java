package com.gtav.runtimemanager;

import android.content.Context;
import android.os.SystemClock;

import java.io.File;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

/** Records diagnostic snapshots when progress appears stalled without aborting the install. */
final class RuntimeInstallWatchdog implements AutoCloseable {
    private final Context context;
    private final ScheduledExecutorService scheduler;
    private final AtomicBoolean closed = new AtomicBoolean(false);
    private volatile long lastProgressAt = SystemClock.elapsedRealtime();
    private volatile long lastDone;
    private volatile InstallSnapshot lastSnapshot = InstallSnapshot.idle();

    RuntimeInstallWatchdog(Context context) {
        this.context = context.getApplicationContext();
        scheduler = Executors.newSingleThreadScheduledExecutor(r -> {
            Thread t = new Thread(r, "gtav-install-watchdog");
            t.setDaemon(true);
            return t;
        });
        scheduler.scheduleAtFixedRate(this::check, 30, 30, TimeUnit.SECONDS);
    }

    void observe(InstallSnapshot snapshot) {
        if (snapshot == null) return;
        InstallStage previousStage = lastSnapshot.stage;
        lastSnapshot = snapshot;
        if (snapshot.done != lastDone || snapshot.stage != previousStage) {
            lastDone = snapshot.done;
            lastProgressAt = SystemClock.elapsedRealtime();
        }
    }

    private void check() {
        if (closed.get()) return;
        InstallSnapshot snapshot = lastSnapshot;
        if (snapshot == null || !snapshot.running) return;
        long stalledMs = SystemClock.elapsedRealtime() - lastProgressAt;
        if (stalledMs < 90_000) return;
        try {
            File file = new File(RuntimeLogWriter.reportsDir(context), "watchdog_report.txt");
            MemorySnapshot memory = MemorySnapshot.capture();
            String text = "GTAV Runtime Install Watchdog\n" +
                    "================================\n" +
                    "Stage: " + snapshot.stage.name() + "\n" +
                    "Current file: " + snapshot.currentFile + "\n" +
                    "Done: " + snapshot.done + "\n" +
                    "Total: " + snapshot.total + "\n" +
                    "Written bytes: " + snapshot.writtenBytes + "\n" +
                    "Stalled ms: " + stalledMs + "\n" +
                    "Memory free: " + memory.freeBytes + "\n" +
                    "Memory used: " + memory.usedBytes + "\n" +
                    "Memory max: " + memory.maxBytes + "\n";
            try (FileOutputStream out = new FileOutputStream(file, false)) {
                out.write(text.getBytes(StandardCharsets.UTF_8));
                out.getFD().sync();
            }
            lastProgressAt = SystemClock.elapsedRealtime();
        } catch (Throwable error) {
            RuntimeCrashReporter.record(context, "watchdog", error, snapshot);
        }
    }

    @Override public void close() {
        if (closed.compareAndSet(false, true)) scheduler.shutdownNow();
    }
}
