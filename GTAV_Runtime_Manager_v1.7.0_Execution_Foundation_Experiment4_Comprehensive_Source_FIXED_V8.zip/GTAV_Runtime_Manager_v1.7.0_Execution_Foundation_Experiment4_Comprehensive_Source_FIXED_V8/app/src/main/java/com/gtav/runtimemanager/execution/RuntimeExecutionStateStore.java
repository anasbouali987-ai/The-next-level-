package com.gtav.runtimemanager.execution;

/** Persists state through the session-scoped reporter. */
public final class RuntimeExecutionStateStore {
    private final RuntimeExecutionReporter reporter;
    public RuntimeExecutionStateStore(RuntimeExecutionReporter reporter) { this.reporter = reporter; }
    public void save(RuntimeExecutionSnapshot snapshot) throws RuntimeExecutionException {
        reporter.writeSnapshot(snapshot);
    }
}
