package com.gtav.runtimemanager;

import android.content.Context;
import android.os.Build;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.io.PrintWriter;

final class RuntimeCrashReporter {
    private RuntimeCrashReporter() {}

    static File file(Context context) {
        return new File(RuntimeLogWriter.reportsDir(context), "crash_report.txt");
    }

    static void install(Context context) {
        Context app = context.getApplicationContext();
        Thread.UncaughtExceptionHandler previous = Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler((thread, error) -> {
            InstallSnapshot snapshot = null;
            try {
                snapshot = RuntimeInstallCoordinator.get(app).current();
            } catch (Throwable ignored) {
            }
            record(app, thread.getName(), error, snapshot);
            if (previous != null) previous.uncaughtException(thread, error);
        });
    }

    static synchronized void record(Context context, String threadName,
                                    Throwable error, InstallSnapshot snapshot) {
        try (BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(
                new FileOutputStream(file(context), false), StandardCharsets.UTF_8), 32 * 1024)) {
            writer.write("GTAV Runtime Manager Crash Report\n");
            writer.write("=================================\n");
            writer.write("App version: " + BuildConfig.VERSION_NAME + "\n");
            writer.write("Thread: " + threadName + "\n");
            writer.write("Android API: " + Build.VERSION.SDK_INT + "\n");
            writer.write("Device: " + Build.MANUFACTURER + " " + Build.MODEL + "\n");
            writer.write("ABIs: " + java.util.Arrays.toString(Build.SUPPORTED_ABIS) + "\n");
            NativeLibraryManager.Report nativeReport = new NativeLibraryManager().inspect(context,
                    error == null ? "not attempted" : throwableChain(error));
            writer.write(nativeReport.format());
            try {
                com.gtav.runtimemanager.execution.RuntimeExecutionSnapshot execution =
                        com.gtav.runtimemanager.execution.RuntimeExecutionManager.get(context).current();
                writer.write("Execution stage: " + execution.stage.name() + "\n");
                writer.write("Execution session: " + execution.sessionId + "\n");
                writer.write("Execution command: " + execution.command + "\n");
                writer.write("Execution PID: " + execution.pid + "\n");
                writer.write("Execution children: " + execution.childPids + "\n");
                writer.write("Execution error code: " + execution.errorCode + "\n");
            } catch (Throwable ignored) {}
            if (snapshot != null) {
                writer.write("Install stage: " + snapshot.stage.name() + "\n");
                writer.write("Current file: " + snapshot.currentFile + "\n");
                writer.write("Files: " + snapshot.stats.files + "\n");
                writer.write("Written bytes: " + snapshot.writtenBytes + "\n");
                writer.write("Memory free: " + snapshot.memory.freeBytes + "\n");
                writer.write("Memory used: " + snapshot.memory.usedBytes + "\n");
                writer.write("Memory max: " + snapshot.memory.maxBytes + "\n");
            }
            writer.write("\nStack trace\n-----------\n");
            PrintWriter print = new PrintWriter(writer);
            error.printStackTrace(print);
            print.flush();
        } catch (Throwable ignored) {
        }
    }

    private static String throwableChain(Throwable error) {
        StringBuilder value = new StringBuilder();
        Throwable current = error;
        while (current != null) {
            if (value.length() > 0) value.append(" <- ");
            value.append(current.getClass().getName()).append(": ").append(current.getMessage());
            current = current.getCause();
        }
        return value.toString();
    }

    static boolean exists(Context context) { return file(context).isFile(); }
    static String read(Context context) { return RuntimeLogWriter.readTail(file(context), 256 * 1024); }
    static boolean delete(Context context) { return !file(context).exists() || file(context).delete(); }
}
