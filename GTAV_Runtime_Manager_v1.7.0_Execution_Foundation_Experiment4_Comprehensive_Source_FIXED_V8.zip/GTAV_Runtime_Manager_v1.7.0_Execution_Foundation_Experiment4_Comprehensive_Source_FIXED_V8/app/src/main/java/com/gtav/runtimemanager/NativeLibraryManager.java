package com.gtav.runtimemanager;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.os.Build;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

/** Runtime view of packaged native libraries and the device ABI environment. */
final class NativeLibraryManager {
    static final class Report {
        final String nativeLibraryDir;
        final List<File> libraries;
        final List<File> zstdLibraries;
        final String[] deviceAbis;
        final String requestedAbi;
        final String classLoader;
        final String searchPath;
        final String loadMessage;
        final boolean abiCompatible;

        Report(String nativeLibraryDir, List<File> libraries, List<File> zstdLibraries,
               String[] deviceAbis, String requestedAbi, String classLoader,
               String searchPath, String loadMessage) {
            this.nativeLibraryDir = nativeLibraryDir;
            this.libraries = Collections.unmodifiableList(new ArrayList<>(libraries));
            this.zstdLibraries = Collections.unmodifiableList(new ArrayList<>(zstdLibraries));
            this.deviceAbis = deviceAbis.clone();
            this.requestedAbi = requestedAbi;
            this.classLoader = classLoader;
            this.searchPath = searchPath;
            this.loadMessage = loadMessage == null ? "not attempted" : loadMessage;
            this.abiCompatible = Arrays.asList(deviceAbis).contains(requestedAbi);
        }

        boolean hasZstd() { return !zstdLibraries.isEmpty(); }
        File primaryZstd() { return hasZstd() ? zstdLibraries.get(0) : null; }

        String summary() {
            return "requestedAbi=" + requestedAbi +
                    ", deviceAbis=" + Arrays.toString(deviceAbis) +
                    ", nativeLibraryDir=" + nativeLibraryDir +
                    ", zstd=" + zstdLibraries;
        }

        String format() {
            StringBuilder out = new StringBuilder();
            out.append("Native library diagnostics\n")
                    .append("==========================\n")
                    .append("Requested APK ABI: ").append(requestedAbi).append('\n')
                    .append("Device ABIs: ").append(Arrays.toString(deviceAbis)).append('\n')
                    .append("ABI compatible: ").append(abiCompatible).append('\n')
                    .append("Native library dir: ").append(nativeLibraryDir).append('\n')
                    .append("ClassLoader: ").append(classLoader).append('\n')
                    .append("Search path: ").append(searchPath).append('\n')
                    .append("Zstandard packaged: ").append(hasZstd()).append('\n')
                    .append("Zstandard libraries: ").append(zstdLibraries).append('\n')
                    .append("JNI load status: ").append(loadMessage).append('\n')
                    .append("All native libraries:\n");
            for (File library : libraries) {
                out.append(" - ").append(library.getName())
                        .append(" (").append(library.length()).append(" bytes)\n");
            }
            return out.toString();
        }
    }

    Report inspect(Context context, String loadMessage) {
        Context app = context.getApplicationContext();
        ApplicationInfo info = app.getApplicationInfo();
        String nativeDir = info.nativeLibraryDir == null ? "" : info.nativeLibraryDir.trim();
        File root = nativeDir.isEmpty() ? null : new File(nativeDir);
        List<File> all = new ArrayList<>();
        List<File> zstd = new ArrayList<>();
        File[] files = root == null ? null : root.listFiles();
        if (files != null) {
            for (File file : files) {
                if (!file.isFile() || !file.getName().endsWith(".so")) continue;
                all.add(file);
                if (file.getName().toLowerCase(Locale.US).contains("zstd")) zstd.add(file);
            }
        }
        Collections.sort(all, (left, right) -> left.getName().compareTo(right.getName()));
        Collections.sort(zstd, (left, right) -> left.getName().compareTo(right.getName()));
        ClassLoader loader = app.getClassLoader();
        return new Report(
                root == null ? "" : root.getAbsolutePath(),
                all,
                zstd,
                Build.SUPPORTED_ABIS,
                BuildConfig.REQUESTED_ABI,
                loader == null ? "null" : loader.toString(),
                System.getProperty("java.library.path", ""),
                loadMessage
        );
    }
}
