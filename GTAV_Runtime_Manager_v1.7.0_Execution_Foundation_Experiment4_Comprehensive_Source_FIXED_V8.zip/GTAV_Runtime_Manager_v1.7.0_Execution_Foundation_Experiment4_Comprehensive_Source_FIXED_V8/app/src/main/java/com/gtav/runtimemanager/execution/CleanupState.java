package com.gtav.runtimemanager.execution;

public enum CleanupState {
    NOT_STARTED,
    IN_PROGRESS,
    COMPLETED,
    FAILED
}
