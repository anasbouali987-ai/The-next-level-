package com.gtav.runtimemanager;

import android.content.Context;
import android.os.Build;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

final class RuntimeLogWriter implements AutoCloseable {
    private final File file;
    private final BufferedWriter writer;

    RuntimeLogWriter(Context context, String prefix) throws IOException {
        File directory = logsDir(context);
        String stamp = new SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(new Date());
        file = new File(directory, prefix + "-" + stamp + ".log");
        writer = new BufferedWriter(new OutputStreamWriter(
                new FileOutputStream(file, true), StandardCharsets.UTF_8), 32 * 1024);
        log("LOG_START app=" + BuildConfig.VERSION_NAME + " android=" + Build.VERSION.SDK_INT + " device=" + Build.MANUFACTURER + "/" + Build.MODEL);
    }

    synchronized void log(String message) {
        try {
            writer.write("[" + now() + "] " + message);
            writer.newLine();
            writer.flush();
        } catch (IOException ignored) {
        }
    }

    synchronized void error(String operation, Throwable error) {
        try {
            writer.write("[" + now() + "] ERROR " + operation);
            writer.newLine();
            PrintWriter print = new PrintWriter(writer);
            error.printStackTrace(print);
            print.flush();
            writer.flush();
        } catch (Throwable ignored) {
        }
    }

    File file() { return file; }

    @Override
    public synchronized void close() {
        try { writer.flush(); } catch (IOException ignored) {}
        try { writer.close(); } catch (IOException ignored) {}
    }

    static File logsDir(Context context) {
        File directory = new File(context.getFilesDir(), "logs");
        if (!directory.exists()) directory.mkdirs();
        return directory;
    }

    static File reportsDir(Context context) {
        File directory = new File(context.getFilesDir(), "reports");
        if (!directory.exists()) directory.mkdirs();
        return directory;
    }

    static File verificationReport(Context context) {
        return new File(reportsDir(context), "verification_report.txt");
    }

    static File installationReport(Context context) {
        return new File(reportsDir(context), "installation_report.txt");
    }

    static File diagnosticReport(Context context) {
        return new File(reportsDir(context), "diagnostic_report.txt");
    }

    static File lastInstallState(Context context) {
        return new File(reportsDir(context), "last_install_state.json");
    }

    static File lastInstallLog(Context context) {
        return new File(reportsDir(context), "last_install.log");
    }

    static void copy(File source, File destination) throws IOException {
        if (source == null || !source.isFile()) return;
        try (InputStream input = new FileInputStream(source);
             OutputStream output = new FileOutputStream(destination)) {
            byte[] buffer = new byte[128 * 1024];
            int read;
            while ((read = input.read(buffer)) != -1) output.write(buffer, 0, read);
        }
    }

    static String readTail(File file, int maxBytes) {
        if (file == null || !file.isFile()) return "لا يوجد ملف متاح.";
        try (java.io.RandomAccessFile random = new java.io.RandomAccessFile(file, "r")) {
            long length = random.length();
            long start = Math.max(0, length - maxBytes);
            random.seek(start);
            byte[] bytes = new byte[(int) (length - start)];
            random.readFully(bytes);
            String text = new String(bytes, java.nio.charset.StandardCharsets.UTF_8);
            return start > 0 ? "… تم عرض نهاية الملف فقط …\n" + text : text;
        } catch (IOException error) {
            return "تعذر قراءة الملف: " + error.getMessage();
        }
    }

    static void writeVerificationReport(Context context, PackageInfo pkg,
                                        String expected, String calculated,
                                        boolean match, long bytes, long when) throws IOException {
        try (BufferedWriter writer = utf8Writer(verificationReport(context), false)) {
            writer.write("GTAV Runtime Verification Report\n");
            writer.write("================================\n");
            writer.write("Expected SHA-256: " + expected + "\n");
            writer.write("Calculated SHA-256: " + calculated + "\n");
            writer.write("Match: " + match + "\n");
            writer.write("Bytes checked: " + bytes + "\n");
            writer.write("Verification date: " + Formatters.date(when) + "\n");
            writer.write("Source URI: " + pkg.uri + "\n");
            writer.write("ZIP size: " + pkg.zipSize + "\n");
            writer.write("Last modified: " + pkg.modifiedAt + "\n");
        }
    }

    static void writeInstallationReport(Context context, PackageInfo pkg,
                                        RuntimeInstaller.InstallResult result) throws IOException {
        try (BufferedWriter writer = utf8Writer(installationReport(context), false)) {
            writer.write("GTAV Runtime Installation Report\n");
            writer.write("================================\n");
            writer.write("Runtime ID: " + pkg.manifest.runtimeId + "\n");
            writer.write("Version: " + pkg.manifest.version + "\n");
            writer.write("Result: SUCCESS\n");
            writer.write("Path: " + result.path.getAbsolutePath() + "\n");
            writer.write("Installed size: " + result.size + "\n");
            writer.write("Files: " + result.stats.files + "\n");
            writer.write("Directories: " + result.stats.directories + "\n");
            writer.write("Symlinks: " + result.stats.symlinks + "\n");
            writer.write("Hard links: " + result.stats.hardLinks + "\n");
            writer.write("Written bytes: " + result.stats.writtenBytes + "\n");
            writer.write("Hard-link logical bytes: " + result.stats.hardLinkLogicalBytes + "\n");
            writer.write("Started: " + Formatters.date(result.startedWallClock) + "\n");
            writer.write("Finished: " + Formatters.date(result.finishedWallClock) + "\n");
            writer.write("Duration: " + Formatters.duration(result.elapsedMs) + "\n");
            writer.write("Payload SHA-256: " + pkg.manifest.payload.sha256 + "\n");
        }
    }


    static void writeInstallationFailureReport(Context context, PackageInfo pkg,
                                               RuntimeInstallException error,
                                               InstallSnapshot snapshot) {
        try (BufferedWriter writer = utf8Writer(installationReport(context), false)) {
            writer.write("GTAV Runtime Installation Report\n");
            writer.write("================================\n");
            if (pkg != null) {
                writer.write("Runtime ID: " + pkg.manifest.runtimeId + "\n");
                writer.write("Version: " + pkg.manifest.version + "\n");
                writer.write("Source URI: " + pkg.uri + "\n");
            }
            writer.write("Result: FAILED\n");
            writer.write("Error code: " + error.code.name() + "\n");
            writer.write("Stage: " + error.stage.name() + "\n");
            writer.write("Current file: " + error.currentFile + "\n");
            writer.write("Message: " + error.getMessage() + "\n");
            if (snapshot != null) {
                writer.write("Files: " + snapshot.stats.files + "\n");
                writer.write("Directories: " + snapshot.stats.directories + "\n");
                writer.write("Symlinks: " + snapshot.stats.symlinks + "\n");
                writer.write("Hard links: " + snapshot.stats.hardLinks + "\n");
                writer.write("Written bytes: " + snapshot.stats.writtenBytes + "\n");
                writer.write("Hard-link logical bytes: " + snapshot.stats.hardLinkLogicalBytes + "\n");
                writer.write("Memory free: " + snapshot.memory.freeBytes + "\n");
                writer.write("Memory used: " + snapshot.memory.usedBytes + "\n");
                writer.write("Memory max: " + snapshot.memory.maxBytes + "\n");
            }
            writer.write("\nStack trace\n-----------\n");
            PrintWriter print = new PrintWriter(writer);
            error.printStackTrace(print);
            print.flush();
        } catch (Throwable ignored) {
        }
    }

    private static BufferedWriter utf8Writer(File file, boolean append) throws IOException {
        return new BufferedWriter(new OutputStreamWriter(
                new FileOutputStream(file, append), StandardCharsets.UTF_8), 32 * 1024);
    }
    private static String now() {
        return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.US).format(new Date());
    }
}
