package com.gtav.runtimemanager.execution;

import android.content.Context;
import com.gtav.runtimemanager.BuildConfig;
import com.gtav.runtimemanager.VerifiedInstalledRuntime;

import java.util.Collections;
import java.util.EnumMap;
import java.util.Map;

/** Capability-aware feature flags: requested -> available -> validated -> enabled. */
public final class ExecutionFeatureFlags {
    private final EnumMap<ExecutionFeature, FeatureStatus> values = new EnumMap<>(ExecutionFeature.class);

    public static ExecutionFeatureFlags evaluate(Context context, VerifiedInstalledRuntime runtime,
                                                  RuntimeExecutionValidator.Report report) {
        ExecutionFeatureFlags flags = new ExecutionFeatureFlags();
        flags.set(ExecutionFeature.PROOT, BuildConfig.FEATURE_PROOT_REQUESTED,
                report.prootPackaged, report.prootExecutable && report.prootVersionOk,
                false, report.prootMessage, "execution_preflight.txt");
        flags.set(ExecutionFeature.BOX64, BuildConfig.FEATURE_BOX64_REQUESTED,
                report.box64Executable, report.readyForBox64, false,
                report.box64Message, "execution_preflight.txt");
        flags.set(ExecutionFeature.WINE, BuildConfig.FEATURE_WINE_REQUESTED,
                report.wineEntrypointsReady, report.readyForWine, false,
                report.wineMessage, "execution_preflight.txt");
        flags.setDeferred(ExecutionFeature.DISPLAY, BuildConfig.FEATURE_DISPLAY_REQUESTED);
        flags.setDeferred(ExecutionFeature.AUDIO, BuildConfig.FEATURE_AUDIO_REQUESTED);
        flags.setDeferred(ExecutionFeature.GRAPHICS, BuildConfig.FEATURE_GRAPHICS_REQUESTED);
        flags.setDeferred(ExecutionFeature.DXVK, BuildConfig.FEATURE_DXVK_REQUESTED);
        flags.setDeferred(ExecutionFeature.INPUT, BuildConfig.FEATURE_INPUT_REQUESTED);
        flags.setDeferred(ExecutionFeature.GAME_LIBRARY, BuildConfig.FEATURE_GAME_LIBRARY_REQUESTED);
        return flags;
    }

    private void set(ExecutionFeature feature, boolean requested, boolean available,
                     boolean validated, boolean enabled, String reason, String evidence) {
        FeatureState state = !requested ? FeatureState.NOT_REQUESTED :
                !available ? FeatureState.UNAVAILABLE :
                        !validated ? FeatureState.AVAILABLE :
                                enabled ? FeatureState.ENABLED : FeatureState.VALIDATED;
        values.put(feature, new FeatureStatus(feature, requested, available, validated,
                enabled, state, reason, evidence));
    }

    private void setDeferred(ExecutionFeature feature, boolean requested) {
        values.put(feature, new FeatureStatus(feature, requested, false, false, false,
                requested ? FeatureState.EXPERIMENTAL : FeatureState.NOT_REQUESTED,
                "DECLARED_NOT_IMPLEMENTED_IN_V1_7", "BackendCapabilityRegistry"));
    }

    public synchronized void markEnabled(ExecutionFeature feature, String evidence) {
        FeatureStatus current = values.get(feature);
        if (current == null || !current.requested || !current.available || !current.validated) return;
        values.put(feature, new FeatureStatus(feature, true, true, true, true,
                FeatureState.ENABLED, "Runtime gate passed", evidence));
    }

    public synchronized void markFailed(ExecutionFeature feature, String reason) {
        FeatureStatus current = values.get(feature);
        if (current == null || !current.requested) return;
        values.put(feature, new FeatureStatus(feature, true, current.available,
                false, false, FeatureState.UNAVAILABLE, reason, current.evidence));
    }

    public FeatureStatus get(ExecutionFeature feature) { return values.get(feature); }
    public boolean enabled(ExecutionFeature feature) {
        FeatureStatus status = values.get(feature);
        return status != null && status.enabled;
    }
    public Map<ExecutionFeature, FeatureStatus> all() { return Collections.unmodifiableMap(values); }

    public String format() {
        StringBuilder out = new StringBuilder();
        out.append("BUILD_VARIANT=").append(BuildConfig.EXECUTION_BUILD_VARIANT).append('\n');
        out.append("EXECUTION_SCHEMA_VERSION=").append(BuildConfig.EXECUTION_SCHEMA_VERSION).append('\n');
        for (ExecutionFeature feature : ExecutionFeature.values()) {
            FeatureStatus status = values.get(feature);
            if (status == null) continue;
            out.append('[').append(feature.name()).append("]\n");
            out.append("Requested=").append(status.requested).append('\n');
            out.append("Available=").append(status.available).append('\n');
            out.append("Validated=").append(status.validated).append('\n');
            out.append("Enabled=").append(status.enabled).append('\n');
            out.append("State=").append(status.state.name()).append('\n');
            out.append("Reason=").append(status.reason).append('\n');
            out.append("Evidence=").append(status.evidence).append("\n\n");
        }
        return out.toString();
    }
}
