package com.gtav.runtimemanager.execution;

public enum FeatureState {
    NOT_REQUESTED, REQUESTED, AVAILABLE, VALIDATED, ENABLED, UNAVAILABLE, EXPERIMENTAL
}
