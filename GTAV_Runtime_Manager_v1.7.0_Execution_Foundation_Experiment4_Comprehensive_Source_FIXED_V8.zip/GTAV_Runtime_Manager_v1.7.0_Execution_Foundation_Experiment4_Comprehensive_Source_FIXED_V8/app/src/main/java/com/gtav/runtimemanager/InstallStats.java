package com.gtav.runtimemanager;

final class InstallStats {
    long files;
    long directories;
    long symlinks;
    long hardLinks;
    long writtenBytes;
    // الحجم المنطقي لمسارات Hard Link كما يراها Manifest عند تصنيفها كملفات.
    long hardLinkLogicalBytes;

    long totalNodes() {
        return files + directories + symlinks + hardLinks;
    }

    InstallStats copy() {
        InstallStats copy = new InstallStats();
        copy.files = files;
        copy.directories = directories;
        copy.symlinks = symlinks;
        copy.hardLinks = hardLinks;
        copy.writtenBytes = writtenBytes;
        copy.hardLinkLogicalBytes = hardLinkLogicalBytes;
        return copy;
    }
}
