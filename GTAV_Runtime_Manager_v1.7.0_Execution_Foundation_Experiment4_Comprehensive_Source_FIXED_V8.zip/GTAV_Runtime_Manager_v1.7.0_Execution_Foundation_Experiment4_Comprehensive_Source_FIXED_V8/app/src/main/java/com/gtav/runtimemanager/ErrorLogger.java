package com.gtav.runtimemanager;

import android.content.Context;

import java.io.File;

final class ErrorLogger {
    private ErrorLogger() {}

    static void log(Context context, String operation, Throwable error) {
        try (RuntimeLogWriter writer = new RuntimeLogWriter(context, "error")) {
            writer.error(operation, error);
            RuntimeLogWriter.copy(writer.file(), RuntimeLogWriter.lastInstallLog(context));
        } catch (Throwable ignored) {
        }
    }

    static String read(Context context) {
        File file = RuntimeLogWriter.lastInstallLog(context);
        return RuntimeLogWriter.readTail(file, 256 * 1024);
    }

    static void clear(Context context) {
        RuntimeLogWriter.lastInstallLog(context).delete();
    }
}
