package com.gtav.runtimemanager;

import android.content.Context;

import org.json.JSONObject;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** Append-only journal used to reconstruct the last installation session after process death. */
final class RuntimeInstallJournal {
    private final File file;

    RuntimeInstallJournal(Context context) {
        file = new File(RuntimeLogWriter.reportsDir(context), "install_journal.jsonl");
    }

    synchronized void append(InstallSnapshot snapshot, String event) {
        if (snapshot == null) return;
        try {
            JSONObject row = new JSONObject();
            row.put("time", new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX", Locale.US).format(new Date()));
            row.put("event", event == null ? "progress" : event);
            row.put("stage", snapshot.stage.name());
            row.put("running", snapshot.running);
            row.put("done", snapshot.done);
            row.put("total", snapshot.total);
            row.put("compressed_done", snapshot.compressedDone);
            row.put("written_bytes", snapshot.writtenBytes);
            row.put("current_file", snapshot.currentFile);
            row.put("message", snapshot.message);
            row.put("error_code", snapshot.errorCode == null ? "" : snapshot.errorCode.name());
            row.put("files", snapshot.stats.files);
            row.put("directories", snapshot.stats.directories);
            row.put("symlinks", snapshot.stats.symlinks);
            row.put("hardlinks", snapshot.stats.hardLinks);
            row.put("memory_free", snapshot.memory.freeBytes);
            row.put("memory_used", snapshot.memory.usedBytes);
            row.put("memory_max", snapshot.memory.maxBytes);
            try (BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(
                    new FileOutputStream(file, true), StandardCharsets.UTF_8), 16 * 1024)) {
                writer.write(row.toString());
                writer.newLine();
                writer.flush();
            }
        } catch (Throwable error) {
            RuntimeCrashReporter.record(RuntimeInstallCoordinator.applicationContext(),
                    "journal-write", error, snapshot);
        }
    }

    File file() { return file; }
}
