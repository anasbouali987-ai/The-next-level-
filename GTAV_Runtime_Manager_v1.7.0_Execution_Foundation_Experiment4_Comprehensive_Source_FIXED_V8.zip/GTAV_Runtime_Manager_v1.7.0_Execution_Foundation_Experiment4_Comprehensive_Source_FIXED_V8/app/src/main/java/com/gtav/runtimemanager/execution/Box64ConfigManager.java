package com.gtav.runtimemanager.execution;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;

/** Central source of BOX64_* settings; callers never scatter Box64 flags across the app. */
public final class Box64ConfigManager {
    public enum Profile { DIAGNOSTIC, NORMAL }

    public Map<String, String> configuration(Profile profile) {
        boolean diagnostic = profile == Profile.DIAGNOSTIC;
        LinkedHashMap<String, String> env = new LinkedHashMap<>();
        env.put("BOX64_LOG", diagnostic ? "1" : "0");
        env.put("BOX64_DYNAREC", "1");
        env.put("BOX64_DYNAREC_BIGBLOCK", "1");
        env.put("BOX64_DYNAREC_LOG", diagnostic ? "1" : "0");
        env.put("BOX64_NOBANNER", diagnostic ? "0" : "1");
        env.put("BOX64_SHOWSEGV", "1");
        env.put("BOX64_SHOWBT", diagnostic ? "1" : "0");
        return Collections.unmodifiableMap(env);
    }

    public String format(Profile profile) {
        StringBuilder out = new StringBuilder("Box64 profile: ").append(profile).append('\n');
        for (Map.Entry<String, String> item : configuration(profile).entrySet()) {
            out.append(item.getKey()).append('=').append(item.getValue()).append('\n');
        }
        return out.toString();
    }
}
