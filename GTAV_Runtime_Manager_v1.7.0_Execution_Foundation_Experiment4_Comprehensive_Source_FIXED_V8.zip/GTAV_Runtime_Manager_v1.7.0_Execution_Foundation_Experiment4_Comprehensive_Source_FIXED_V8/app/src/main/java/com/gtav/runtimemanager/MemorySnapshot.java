package com.gtav.runtimemanager;

final class MemorySnapshot {
    final long freeBytes;
    final long usedBytes;
    final long maxBytes;

    MemorySnapshot(long freeBytes, long usedBytes, long maxBytes) {
        this.freeBytes = freeBytes;
        this.usedBytes = usedBytes;
        this.maxBytes = maxBytes;
    }

    static MemorySnapshot capture() {
        Runtime runtime = Runtime.getRuntime();
        long total = runtime.totalMemory();
        long free = runtime.freeMemory();
        return new MemorySnapshot(free, total - free, runtime.maxMemory());
    }
}
