package com.gtav.runtimemanager;

import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;

final class CountingInputStream extends FilterInputStream {
    long count;
    CountingInputStream(InputStream in) { super(in); }
    @Override public int read() throws IOException { int v = super.read(); if (v >= 0) count++; return v; }
    @Override public int read(byte[] b, int o, int l) throws IOException { int n = super.read(b,o,l); if (n > 0) count += n; return n; }
}
