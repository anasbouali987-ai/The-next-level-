package com.gtav.runtimemanager;

import android.os.SystemClock;

import java.io.BufferedInputStream;
import java.io.InputStream;
import java.security.MessageDigest;

final class IntegrityVerifier {
    static Result verify(PackageReader reader, PackageInfo pkg, OperationProgress progress)
            throws Exception {
        long startedWall = System.currentTimeMillis();
        long startedElapsed = SystemClock.elapsedRealtime();
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        long done = 0;
        try (SeekableZipReader zip = reader.open(pkg.uri);
             InputStream input = new BufferedInputStream(
                     zip.openEntry(pkg.manifest.payload.path), 256 * 1024)) {
            byte[] buffer = new byte[256 * 1024];
            int read;
            while ((read = input.read(buffer)) != -1) {
                if (progress.isCancelled()) {
                    return new Result(false, true, "", done, startedWall,
                            System.currentTimeMillis(),
                            SystemClock.elapsedRealtime() - startedElapsed);
                }
                digest.update(buffer, 0, read);
                done += read;
                progress.update("التحقق من SHA-256", done,
                        pkg.manifest.payload.sizeBytes,
                        pkg.manifest.payload.path,
                        startedElapsed);
            }
        }
        String calculated = hex(digest.digest());
        return new Result(
                calculated.equalsIgnoreCase(pkg.manifest.payload.sha256),
                false,
                calculated,
                done,
                startedWall,
                System.currentTimeMillis(),
                SystemClock.elapsedRealtime() - startedElapsed
        );
    }

    private static String hex(byte[] bytes) {
        StringBuilder hex = new StringBuilder(64);
        for (byte value : bytes) hex.append(String.format("%02x", value));
        return hex.toString();
    }

    static final class Result {
        final boolean match;
        final boolean cancelled;
        final String calculated;
        final long bytes;
        final long started;
        final long finished;
        final long elapsedMs;

        Result(boolean match, boolean cancelled, String calculated, long bytes,
               long started, long finished, long elapsedMs) {
            this.match = match;
            this.cancelled = cancelled;
            this.calculated = calculated;
            this.bytes = bytes;
            this.started = started;
            this.finished = finished;
            this.elapsedMs = elapsedMs;
        }
    }
}
