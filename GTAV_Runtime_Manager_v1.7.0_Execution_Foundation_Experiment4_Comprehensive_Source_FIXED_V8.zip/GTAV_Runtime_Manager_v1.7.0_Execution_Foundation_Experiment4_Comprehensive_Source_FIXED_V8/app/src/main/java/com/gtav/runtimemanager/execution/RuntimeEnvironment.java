package com.gtav.runtimemanager.execution;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;

public final class RuntimeEnvironment {
    public final Map<String, String> host;
    public final Map<String, String> guest;

    RuntimeEnvironment(Map<String, String> host, Map<String, String> guest) {
        this.host = Collections.unmodifiableMap(new LinkedHashMap<>(host));
        this.guest = Collections.unmodifiableMap(new LinkedHashMap<>(guest));
    }

    public String format() {
        StringBuilder out = new StringBuilder("[Android/Bionic host]\n");
        for (Map.Entry<String, String> e : host.entrySet()) out.append(e.getKey()).append('=').append(e.getValue()).append('\n');
        out.append("\n[glibc guest]\n");
        for (Map.Entry<String, String> e : guest.entrySet()) out.append(e.getKey()).append('=').append(e.getValue()).append('\n');
        return out.toString();
    }
}
