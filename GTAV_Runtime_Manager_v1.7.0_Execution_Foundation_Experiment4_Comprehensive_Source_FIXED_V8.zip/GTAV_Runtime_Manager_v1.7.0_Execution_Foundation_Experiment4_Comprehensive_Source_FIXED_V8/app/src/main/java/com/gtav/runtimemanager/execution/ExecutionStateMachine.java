package com.gtav.runtimemanager.execution;

import java.util.EnumMap;
import java.util.EnumSet;

/** Enforces the only legal lifecycle of an execution session. */
public final class ExecutionStateMachine {
    private static final EnumMap<ExecutionStage, EnumSet<ExecutionStage>> ALLOWED = build();
    private ExecutionStage stage = ExecutionStage.IDLE;

    public synchronized ExecutionStage current() { return stage; }

    public synchronized void resetForNewSession() throws RuntimeExecutionException {
        if (stage != ExecutionStage.IDLE && !stage.terminal()) {
            throw invalid(stage, ExecutionStage.PREPARING);
        }
        stage = ExecutionStage.PREPARING;
    }

    public synchronized void transition(ExecutionStage next) throws RuntimeExecutionException {
        if (next == stage) return; // Heartbeat/update within the same stage.
        EnumSet<ExecutionStage> allowed = ALLOWED.get(stage);
        if (allowed == null || !allowed.contains(next)) throw invalid(stage, next);
        stage = next;
    }

    public synchronized void restore(ExecutionStage restored) { stage = restored == null ? ExecutionStage.IDLE : restored; }

    public static boolean canTransition(ExecutionStage from, ExecutionStage to) {
        if (from == to) return true;
        EnumSet<ExecutionStage> allowed = ALLOWED.get(from);
        return allowed != null && allowed.contains(to);
    }

    private static RuntimeExecutionException invalid(ExecutionStage from, ExecutionStage to) {
        return new RuntimeExecutionException(ExecutionErrorCode.INVALID_STATE_TRANSITION, from,
                "انتقال غير صالح: " + from + " -> " + to, false);
    }

    private static EnumMap<ExecutionStage, EnumSet<ExecutionStage>> build() {
        EnumMap<ExecutionStage, EnumSet<ExecutionStage>> map = new EnumMap<>(ExecutionStage.class);
        map.put(ExecutionStage.IDLE, EnumSet.of(ExecutionStage.PREPARING));
        map.put(ExecutionStage.PREPARING, EnumSet.of(ExecutionStage.VALIDATING, ExecutionStage.STOPPING,
                ExecutionStage.FAILED, ExecutionStage.CANCELLED, ExecutionStage.RECOVERY_REQUIRED));
        map.put(ExecutionStage.VALIDATING, EnumSet.of(ExecutionStage.STARTING_PROOT, ExecutionStage.STOPPING,
                ExecutionStage.FAILED, ExecutionStage.CANCELLED, ExecutionStage.TIMED_OUT));
        map.put(ExecutionStage.STARTING_PROOT, EnumSet.of(ExecutionStage.ENTERING_ROOTFS, ExecutionStage.STOPPING,
                ExecutionStage.FAILED, ExecutionStage.CANCELLED, ExecutionStage.TIMED_OUT));
        map.put(ExecutionStage.ENTERING_ROOTFS, EnumSet.of(ExecutionStage.RUNNING_BOX64, ExecutionStage.STOPPING,
                ExecutionStage.FAILED, ExecutionStage.CANCELLED, ExecutionStage.TIMED_OUT));
        map.put(ExecutionStage.RUNNING_BOX64, EnumSet.of(ExecutionStage.STARTING_WINE, ExecutionStage.STOPPING,
                ExecutionStage.FAILED, ExecutionStage.CANCELLED, ExecutionStage.TIMED_OUT));
        map.put(ExecutionStage.STARTING_WINE, EnumSet.of(ExecutionStage.RUNNING, ExecutionStage.STOPPING,
                ExecutionStage.FAILED, ExecutionStage.CANCELLED, ExecutionStage.TIMED_OUT));
        map.put(ExecutionStage.RUNNING, EnumSet.of(ExecutionStage.STOPPING, ExecutionStage.CLEANING_UP,
                ExecutionStage.FAILED, ExecutionStage.CANCELLED, ExecutionStage.TIMED_OUT));
        map.put(ExecutionStage.STOPPING, EnumSet.of(ExecutionStage.CLEANING_UP, ExecutionStage.FAILED,
                ExecutionStage.CANCELLED, ExecutionStage.TIMED_OUT));
        map.put(ExecutionStage.CLEANING_UP, EnumSet.of(ExecutionStage.COMPLETED, ExecutionStage.FAILED,
                ExecutionStage.CANCELLED, ExecutionStage.TIMED_OUT, ExecutionStage.RECOVERY_REQUIRED));
        for (ExecutionStage terminal : EnumSet.of(ExecutionStage.COMPLETED, ExecutionStage.FAILED,
                ExecutionStage.CANCELLED, ExecutionStage.TIMED_OUT, ExecutionStage.RECOVERY_REQUIRED)) {
            map.put(terminal, EnumSet.of(ExecutionStage.PREPARING));
        }
        return map;
    }
}
