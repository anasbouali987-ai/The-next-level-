package com.gtav.runtimemanager;

import android.system.ErrnoException;
import android.system.Os;
import android.system.OsConstants;
import android.system.StructStat;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.List;

final class RuntimePostVerifier {
    static final class Result {
        final boolean ok;
        final String message;
        final long checkedFiles;

        Result(boolean ok, String message, long checkedFiles) {
            this.ok = ok;
            this.message = message;
            this.checkedFiles = checkedFiles;
        }
    }

    Result verify(File root, RuntimeManifest manifest, InstallStats stats,
                  CancellationToken token, InstallProgressSink progress,
                  RuntimeLogWriter log) throws RuntimeInstallException {
        RuntimeInstallPolicy.validateStats(manifest.expectedStats, stats);

        List<RuntimeManifest.RootfsFile> files = new ArrayList<>(manifest.requiredFiles());
        addEntryPoint(files, manifest.entryPoints.wine64);
        addEntryPoint(files, manifest.entryPoints.wineboot);
        addEntryPoint(files, manifest.entryPoints.wineserver);

        long checked = 0;
        for (RuntimeManifest.RootfsFile required : files) {
            token.throwIfCancelled(InstallStage.POST_VERIFY);
            verifyOne(root, required);
            checked++;
            progress.update(InstallStage.POST_VERIFY, checked, Math.max(1, files.size()),
                    0, stats, required.path, "جاهز", "جاهز",
                    "التحقق من الملفات الأساسية", false);
        }

        log.log("POST_VERIFY_OK checked=" + checked);
        return new Result(true,
                "الملفات الأساسية وأنواعها وأحجامها وروابطها وصلاحياتها سليمة",
                checked);
    }

    private static void addEntryPoint(List<RuntimeManifest.RootfsFile> files, String path) {
        if (path == null || path.isEmpty()) return;
        for (RuntimeManifest.RootfsFile file : files) {
            if (file.path.equals(path)) return;
        }
        files.add(new RuntimeManifest.RootfsFile(path, "file", "", 0755,
                -1, "", true, "entrypoint"));
    }

    private static void verifyOne(File root, RuntimeManifest.RootfsFile expected)
            throws RuntimeInstallException {
        try {
            File file = RuntimePaths.safeChild(root, expected.path);
            StructStat stat = Os.lstat(file.getAbsolutePath());
            String type = expected.type == null ? "file" : expected.type;

            if ("symlink".equals(type)) {
                if (!OsConstants.S_ISLNK(stat.st_mode)) {
                    fail("النوع غير صحيح؛ المتوقع Symlink", expected.path);
                }
                String target = Os.readlink(file.getAbsolutePath());
                if (!expected.linkTarget.isEmpty() && !expected.linkTarget.equals(target)) {
                    fail("هدف Symlink غير مطابق: " + target + " != " + expected.linkTarget,
                            expected.path);
                }
                return;
            }

            if ("directory".equals(type) || "dir".equals(type)) {
                if (!OsConstants.S_ISDIR(stat.st_mode)) {
                    fail("النوع غير صحيح؛ المتوقع مجلد", expected.path);
                }
                return;
            }

            if ("hardlink".equals(type) || "hard_link".equals(type)) {
                if (!OsConstants.S_ISREG(stat.st_mode) || stat.st_nlink < 2) {
                    fail("النوع غير صحيح؛ المتوقع Hard Link", expected.path);
                }
            } else if (!OsConstants.S_ISREG(stat.st_mode)) {
                fail("النوع غير صحيح؛ المتوقع ملف عادي", expected.path);
            }

            if (expected.sizeBytes >= 0 && stat.st_size != expected.sizeBytes) {
                fail("حجم الملف غير مطابق: " + stat.st_size + " != " + expected.sizeBytes,
                        expected.path);
            }

            if ((expected.mode & 0111) != 0 && (stat.st_mode & 0111) == 0) {
                fail("صلاحية التنفيذ مفقودة", expected.path);
            }

            if (expected.sha256 != null && expected.sha256.matches("[0-9a-fA-F]{64}")) {
                String calculated = sha256(file);
                if (!expected.sha256.equalsIgnoreCase(calculated)) {
                    fail("SHA-256 للملف المطلوب غير مطابق", expected.path);
                }
            }
        } catch (RuntimeInstallException error) {
            throw error;
        } catch (ErrnoException error) {
            throw new RuntimeInstallException(
                    InstallErrorCode.POST_VERIFICATION_FAILED,
                    InstallStage.POST_VERIFY,
                    "ملف أساسي مفقود أو غير قابل للفحص: " + expected.path +
                            " (errno=" + error.errno + ")",
                    expected.path,
                    error
            );
        } catch (Throwable error) {
            throw new RuntimeInstallException(
                    InstallErrorCode.POST_VERIFICATION_FAILED,
                    InstallStage.POST_VERIFY,
                    "فشل فحص الملف الأساسي: " + expected.path,
                    expected.path,
                    error
            );
        }
    }

    private static String sha256(File file) throws Exception {
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        try (BufferedInputStream input = new BufferedInputStream(
                new FileInputStream(file), 256 * 1024)) {
            byte[] buffer = new byte[256 * 1024];
            int read;
            while ((read = input.read(buffer)) != -1) digest.update(buffer, 0, read);
        }
        StringBuilder hex = new StringBuilder(64);
        for (byte value : digest.digest()) hex.append(String.format("%02x", value));
        return hex.toString();
    }

    private static void fail(String message, String path) throws RuntimeInstallException {
        throw new RuntimeInstallException(
                InstallErrorCode.POST_VERIFICATION_FAILED,
                InstallStage.POST_VERIFY,
                message + ": /" + path,
                path,
                null
        );
    }
}
