package com.gtav.runtimemanager.execution;

import android.content.Context;

import java.io.File;
import java.io.IOException;
import java.util.regex.Pattern;

/** Centralizes every writable path used by the execution domain. */
public final class ExecutionPaths {
    private static final Pattern SAFE_ID = Pattern.compile("[A-Za-z0-9][A-Za-z0-9._-]{2,127}");

    private ExecutionPaths() {}

    public static File usr(Context context) { return ensure(new File(context.getFilesDir(), "usr")); }
    public static File proot(Context context) { return new File(usr(context), "bin/proot"); }
    public static File loader(Context context) { return new File(usr(context), "libexec/proot/loader"); }
    public static File sessions(Context context) { return ensure(new File(context.getFilesDir(), "sessions")); }
    public static File prefixes(Context context) { return ensure(new File(context.getFilesDir(), "prefixes")); }
    public static File cache(Context context) { return ensure(new File(context.getFilesDir(), "cache/execution")); }
    public static File logs(Context context) { return ensure(new File(context.getFilesDir(), "logs/execution")); }
    public static File profiles(Context context) { return ensure(new File(context.getFilesDir(), "profiles")); }
    public static File latestReports(Context context) { return ensure(new File(context.getFilesDir(), "reports/execution/latest")); }
    public static File componentState(Context context) { return new File(usr(context), ".execution_components_version"); }

    public static File session(Context context, String id) {
        return ensureChild(sessions(context), requireSafeId(id, "sessionId"));
    }

    public static File runtimePrefixRoot(Context context, String runtimeId) {
        return ensureChild(prefixes(context), requireSafeId(runtimeId, "runtimeId"));
    }

    /** A clean diagnostic prefix belongs to exactly one execution session. */
    public static File diagnosticPrefix(Context context, String runtimeId, String sessionId) {
        File diagnostic = ensure(new File(runtimePrefixRoot(context, runtimeId), "diagnostics"));
        return ensureChild(diagnostic, requireSafeId(sessionId, "sessionId"));
    }

    public static File profile(Context context, String runtimeId) {
        return ensureChild(profiles(context), requireSafeId(runtimeId, "runtimeId"));
    }

    public static File runtimeCache(Context context, String runtimeId) {
        return ensureChild(cache(context), requireSafeId(runtimeId, "runtimeId"));
    }

    public static File ensure(File file) {
        if (!file.exists() && !file.mkdirs() && !file.isDirectory()) {
            throw new IllegalStateException("تعذر إنشاء المسار: " + file.getAbsolutePath());
        }
        if (!file.isDirectory()) throw new IllegalStateException("المسار ليس مجلدًا: " + file);
        return file;
    }

    public static String requireSafeId(String value, String label) {
        if (value == null || !SAFE_ID.matcher(value).matches()) {
            throw new IllegalArgumentException(label + " غير صالح: " + value);
        }
        return value;
    }

    private static File ensureChild(File parent, String name) {
        try {
            File child = new File(parent, name);
            String parentPath = parent.getCanonicalPath();
            String childPath = child.getCanonicalPath();
            if (!childPath.startsWith(parentPath + File.separator)) {
                throw new IllegalArgumentException("المسار يخرج عن الجذر المسموح");
            }
            return ensure(child);
        } catch (IOException error) {
            throw new IllegalStateException("تعذر تثبيت المسار الآمن", error);
        }
    }
}
