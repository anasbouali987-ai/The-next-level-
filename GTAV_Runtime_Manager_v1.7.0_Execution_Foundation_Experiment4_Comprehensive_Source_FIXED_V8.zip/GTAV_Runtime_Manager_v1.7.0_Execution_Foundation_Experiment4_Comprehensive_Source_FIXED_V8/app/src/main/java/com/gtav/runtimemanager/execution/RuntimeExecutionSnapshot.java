package com.gtav.runtimemanager.execution;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class RuntimeExecutionSnapshot {
    public final String sessionId;
    public final String runtimeId;
    public final ExecutionStage stage;
    public final CleanupState cleanupState;
    public final boolean running;
    public final String message;
    public final String command;
    public final long pid;
    public final List<Long> childPids;
    public final int exitCode;
    public final long startedAt;
    public final long updatedAt;
    public final String lastStdout;
    public final String lastStderr;
    public final String errorCode;
    public final boolean noOrphans;

    RuntimeExecutionSnapshot(String sessionId, String runtimeId, ExecutionStage stage,
                             CleanupState cleanupState, boolean running, String message,
                             String command, long pid, List<Long> childPids, int exitCode,
                             long startedAt, long updatedAt, String lastStdout,
                             String lastStderr, String errorCode, boolean noOrphans) {
        this.sessionId = sessionId == null ? "" : sessionId;
        this.runtimeId = runtimeId == null ? "" : runtimeId;
        this.stage = stage == null ? ExecutionStage.IDLE : stage;
        this.cleanupState = cleanupState == null ? CleanupState.NOT_STARTED : cleanupState;
        this.running = running;
        this.message = message == null ? "" : message;
        this.command = command == null ? "" : command;
        this.pid = pid;
        this.childPids = childPids == null ? Collections.emptyList() :
                Collections.unmodifiableList(new ArrayList<>(childPids));
        this.exitCode = exitCode;
        this.startedAt = startedAt;
        this.updatedAt = updatedAt;
        this.lastStdout = lastStdout == null ? "" : lastStdout;
        this.lastStderr = lastStderr == null ? "" : lastStderr;
        this.errorCode = errorCode == null ? "" : errorCode;
        this.noOrphans = noOrphans;
    }

    public static RuntimeExecutionSnapshot idle() {
        return new RuntimeExecutionSnapshot("", "", ExecutionStage.IDLE,
                CleanupState.NOT_STARTED, false, "", "", -1,
                Collections.emptyList(), Integer.MIN_VALUE, 0,
                System.currentTimeMillis(), "", "", "", true);
    }

    public JSONObject toJson() throws Exception {
        JSONObject json = new JSONObject();
        json.put("schema_version", 2);
        json.put("session_id", sessionId);
        json.put("runtime_id", runtimeId);
        json.put("stage", stage.name());
        json.put("cleanup_state", cleanupState.name());
        json.put("running", running);
        json.put("message", message);
        json.put("command", command);
        json.put("pid", pid);
        JSONArray children = new JSONArray();
        for (Long child : childPids) children.put(child);
        json.put("child_pids", children);
        json.put("exit_code", exitCode);
        json.put("started_at", startedAt);
        json.put("updated_at", updatedAt);
        json.put("last_stdout", lastStdout);
        json.put("last_stderr", lastStderr);
        json.put("error_code", errorCode);
        json.put("no_orphans", noOrphans);
        return json;
    }

    public static RuntimeExecutionSnapshot fromJson(JSONObject json) {
        List<Long> children = new ArrayList<>();
        JSONArray array = json.optJSONArray("child_pids");
        if (array != null) for (int i = 0; i < array.length(); i++) children.add(array.optLong(i));
        ExecutionStage stage;
        CleanupState cleanup;
        try { stage = ExecutionStage.valueOf(json.optString("stage", "IDLE")); }
        catch (Throwable ignored) { stage = ExecutionStage.RECOVERY_REQUIRED; }
        try { cleanup = CleanupState.valueOf(json.optString("cleanup_state", "NOT_STARTED")); }
        catch (Throwable ignored) { cleanup = CleanupState.NOT_STARTED; }
        return new RuntimeExecutionSnapshot(
                json.optString("session_id", ""), json.optString("runtime_id", ""), stage,
                cleanup, json.optBoolean("running", false), json.optString("message", ""),
                json.optString("command", ""), json.optLong("pid", -1), children,
                json.optInt("exit_code", Integer.MIN_VALUE), json.optLong("started_at", 0),
                json.optLong("updated_at", 0), json.optString("last_stdout", ""),
                json.optString("last_stderr", ""), json.optString("error_code", ""),
                json.optBoolean("no_orphans", false));
    }
}
