package com.gtav.runtimemanager.compression.zstd;

public final class ZstdHealthResult {
    public final boolean ok;
    public final String code;
    public final String details;
    public final Throwable error;

    private ZstdHealthResult(boolean ok, String code, String details, Throwable error) {
        this.ok = ok;
        this.code = code;
        this.details = details == null ? "" : details;
        this.error = error;
    }

    public static ZstdHealthResult success(String details) {
        return new ZstdHealthResult(true, "OK", details, null);
    }

    public static ZstdHealthResult failure(String code, String details, Throwable error) {
        String safeCode = code == null || code.isEmpty() ? "ZSTD_ENGINE_FAILED" : code;
        String safeDetails = details;
        if ((safeDetails == null || safeDetails.isEmpty()) && error != null) {
            safeDetails = error.getClass().getSimpleName() +
                    (error.getMessage() == null ? "" : ": " + error.getMessage());
        }
        return new ZstdHealthResult(false, safeCode, safeDetails, error);
    }
}
