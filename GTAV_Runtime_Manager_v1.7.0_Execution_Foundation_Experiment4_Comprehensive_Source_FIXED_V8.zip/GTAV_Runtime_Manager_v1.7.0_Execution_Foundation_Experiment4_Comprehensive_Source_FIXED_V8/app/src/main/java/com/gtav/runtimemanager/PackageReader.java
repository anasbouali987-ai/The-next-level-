package com.gtav.runtimemanager;

import android.content.ContentResolver;
import android.database.Cursor;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.provider.DocumentsContract;
import android.provider.OpenableColumns;

import org.json.JSONObject;

import java.io.IOException;
import java.nio.charset.StandardCharsets;

final class PackageReader {
    private static final int MAX_JSON_BYTES = 32 * 1024 * 1024;
    private final ContentResolver resolver;

    PackageReader(ContentResolver resolver) {
        this.resolver = resolver;
    }

    PackageInfo read(Uri uri) throws Exception {
        Meta meta = meta(uri);
        try (SeekableZipReader zip = open(uri)) {
            RuntimeInstallPolicy.requirePayload(zip.contains("runtime_manifest.json"),
                    "runtime_manifest.json غير موجود");
            String raw = new String(
                    zip.readEntry("runtime_manifest.json", MAX_JSON_BYTES),
                    StandardCharsets.UTF_8
            );
            String pretty = pretty(raw);
            RuntimeManifest manifest = new RuntimeManifest(new JSONObject(raw), pretty);
            validate(manifest, zip);
            String report = zip.contains("build_report.json")
                    ? new String(zip.readEntry("build_report.json", MAX_JSON_BYTES), StandardCharsets.UTF_8)
                    : "";
            return new PackageInfo(
                    uri,
                    meta.name,
                    meta.size,
                    meta.modified,
                    manifest,
                    zip.get(manifest.payload.path).uncompressedSize,
                    zip.entries().size(),
                    report
            );
        }
    }

    SourceMeta sourceMeta(Uri uri) {
        Meta meta = meta(uri);
        return new SourceMeta(meta.size, meta.modified);
    }

    SeekableZipReader open(Uri uri) throws Exception {
        ParcelFileDescriptor descriptor = resolver.openFileDescriptor(uri, "r");
        if (descriptor == null) throw new IOException("تعذر فتح الحزمة");

        /*
         * Ownership of the ParcelFileDescriptor is transferred to
         * ParcelFileDescriptor.AutoCloseInputStream inside SeekableZipReader.
         * This keeps the descriptor strongly reachable for the whole ZIP read
         * and prevents Android from finalizing it during long extraction.
         */
        try {
            return new SeekableZipReader(descriptor);
        } catch (Throwable error) {
            try {
                descriptor.close();
            } catch (Throwable ignored) {
            }
            throw error;
        }
    }

    private static void validate(RuntimeManifest manifest, SeekableZipReader zip) throws IOException {
        if (manifest.schema != 3) throw new IOException("Schema غير مدعوم: " + manifest.schema);
        if (!"arm64".equalsIgnoreCase(manifest.host) ||
                !"x86_64".equalsIgnoreCase(manifest.guest)) {
            throw new IOException("المعمارية غير متوافقة");
        }
        if (!"tar+zstd".equalsIgnoreCase(manifest.payload.format)) {
            throw new IOException("صيغة Payload غير مدعومة");
        }
        if (!manifest.payload.sha256.matches("[0-9a-f]{64}")) {
            throw new IOException("SHA-256 المسجل غير صالح");
        }
        RuntimeInstallPolicy.requirePayload(zip.contains(manifest.payload.path),
                "Payload غير موجود: " + manifest.payload.path);
        if (zip.get(manifest.payload.path).uncompressedSize != manifest.payload.sizeBytes) {
            throw new IOException("حجم Payload لا يطابق Manifest");
        }
    }

    private Meta meta(Uri uri) {
        String name = "Runtime.zip";
        long size = -1;
        long modified = -1;
        try (Cursor cursor = resolver.query(uri, null, null, null, null)) {
            if (cursor != null && cursor.moveToFirst()) {
                int nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                int sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE);
                int modifiedIndex = cursor.getColumnIndex(DocumentsContract.Document.COLUMN_LAST_MODIFIED);
                if (nameIndex >= 0 && !cursor.isNull(nameIndex)) name = cursor.getString(nameIndex);
                if (sizeIndex >= 0 && !cursor.isNull(sizeIndex)) size = cursor.getLong(sizeIndex);
                if (modifiedIndex >= 0 && !cursor.isNull(modifiedIndex)) modified = cursor.getLong(modifiedIndex);
            }
        } catch (Exception ignored) {
        }
        return new Meta(name, size, modified);
    }

    private static String pretty(String raw) {
        try {
            return new JSONObject(raw).toString(2);
        } catch (Exception ignored) {
            return raw;
        }
    }

    static final class SourceMeta {
        final long size;
        final long modified;

        SourceMeta(long size, long modified) {
            this.size = size;
            this.modified = modified;
        }
    }

    private static final class Meta {
        final String name;
        final long size;
        final long modified;

        Meta(String name, long size, long modified) {
            this.name = name;
            this.size = size;
            this.modified = modified;
        }
    }
}
