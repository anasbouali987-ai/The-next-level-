package com.gtav.runtimemanager.execution;

import android.content.Context;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicLong;

/** Full log is streamed to the session file; only a bounded tail is retained for UI. */
public final class RuntimeConsoleStore implements AutoCloseable {
    public interface Listener { void onConsoleLine(String line); }
    private static final int MAX_UI_LINES = 2_000;
    private static final int MAX_LINE_CHARS = 32 * 1024;
    private final File file;
    private final BufferedWriter writer;
    private final BufferedWriter latestWriter;
    private final ArrayDeque<String> tail = new ArrayDeque<>();
    private final CopyOnWriteArrayList<Listener> listeners = new CopyOnWriteArrayList<>();
    private final AtomicLong sequence = new AtomicLong();

    public RuntimeConsoleStore(Context context, RuntimeSession session) throws Exception {
        file = session.consoleFile;
        writer = new BufferedWriter(new OutputStreamWriter(
                new FileOutputStream(file, true), StandardCharsets.UTF_8), 64 * 1024);
        File latest = RuntimeExecutionReporter.file(context, "execution_log.txt");
        latestWriter = new BufferedWriter(new OutputStreamWriter(
                new FileOutputStream(latest, false), StandardCharsets.UTF_8), 64 * 1024);
    }

    public synchronized void append(String channel, String text) { append(channel, -1, text); }

    public synchronized void append(String channel, long pid, String text) {
        if (text == null) return;
        String[] lines = text.replace("\r", "").split("\n", -1);
        for (String value : lines) {
            if (value.isEmpty() && lines.length > 1) continue;
            if (value.length() > MAX_LINE_CHARS) value = value.substring(0, MAX_LINE_CHARS) + "…[TRUNCATED]";
            long seq = sequence.incrementAndGet();
            String line = "[" + String.format(Locale.US, "%08d", seq) + "] [" + time() + "] [" +
                    normalizeChannel(channel) + "]" + (pid > 0 ? " [pid=" + pid + "]" : "") + " " + value;
            try {
                writer.write(line); writer.newLine(); writer.flush();
                latestWriter.write(line); latestWriter.newLine(); latestWriter.flush();
            } catch (Throwable ignored) {}
            tail.addLast(line);
            while (tail.size() > MAX_UI_LINES) tail.removeFirst();
            for (Listener listener : listeners) {
                try { listener.onConsoleLine(line); } catch (Throwable ignored) {}
            }
        }
    }

    public synchronized String tailText() { return String.join("\n", tail); }
    public synchronized List<String> tailLines() { return new ArrayList<>(tail); }
    public File file() { return file; }
    public void addListener(Listener listener) { if (listener != null) listeners.addIfAbsent(listener); }
    public void removeListener(Listener listener) { listeners.remove(listener); }
    public synchronized void clearUiTail() { tail.clear(); }

    @Override public synchronized void close() {
        try { writer.flush(); writer.close(); } catch (Throwable ignored) {}
        try { latestWriter.flush(); latestWriter.close(); } catch (Throwable ignored) {}
    }

    private static String normalizeChannel(String value) {
        if ("STDOUT".equals(value) || "STDERR".equals(value) || "SYSTEM".equals(value)) return value;
        return "SYSTEM";
    }

    private static String time() {
        return new SimpleDateFormat("HH:mm:ss.SSS", Locale.US).format(new Date());
    }
}
