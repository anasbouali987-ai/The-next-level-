package com.gtav.runtimemanager.compression.zstd;

public final class ZstdErrorClassifier {
    private ZstdErrorClassifier() { }

    public static String classify(Throwable error) {
        Throwable current = error;
        while (current != null) {
            if (current instanceof UnsatisfiedLinkError) return "ZSTD_DLOPEN_FAILED";
            if (current instanceof NoClassDefFoundError ||
                    current instanceof ExceptionInInitializerError) {
                return "ZSTD_JNI_INIT_FAILED";
            }
            if (current instanceof OutOfMemoryError) return "OUT_OF_MEMORY";
            current = current.getCause();
        }
        return "ZSTD_ENGINE_FAILED";
    }

    public static String describe(Throwable error) {
        if (error == null) return "unknown error";
        StringBuilder output = new StringBuilder();
        Throwable current = error;
        int depth = 0;
        while (current != null && depth++ < 6) {
            if (output.length() > 0) output.append(" <- ");
            output.append(current.getClass().getSimpleName());
            if (current.getMessage() != null && !current.getMessage().isEmpty()) {
                output.append(": ").append(current.getMessage());
            }
            current = current.getCause();
        }
        return output.toString();
    }
}
