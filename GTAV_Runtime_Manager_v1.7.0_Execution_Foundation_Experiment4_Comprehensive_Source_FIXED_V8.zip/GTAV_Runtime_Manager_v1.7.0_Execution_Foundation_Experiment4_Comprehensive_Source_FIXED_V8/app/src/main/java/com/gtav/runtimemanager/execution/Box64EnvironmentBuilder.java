package com.gtav.runtimemanager.execution;

import java.util.LinkedHashMap;
import java.util.Map;

public final class Box64EnvironmentBuilder {
    private final Box64ConfigManager config = new Box64ConfigManager();

    public Map<String, String> build(boolean verbose) {
        return new LinkedHashMap<>(config.configuration(
                verbose ? Box64ConfigManager.Profile.DIAGNOSTIC : Box64ConfigManager.Profile.NORMAL));
    }

    public String describe(boolean verbose) {
        return config.format(verbose ? Box64ConfigManager.Profile.DIAGNOSTIC : Box64ConfigManager.Profile.NORMAL);
    }
}
