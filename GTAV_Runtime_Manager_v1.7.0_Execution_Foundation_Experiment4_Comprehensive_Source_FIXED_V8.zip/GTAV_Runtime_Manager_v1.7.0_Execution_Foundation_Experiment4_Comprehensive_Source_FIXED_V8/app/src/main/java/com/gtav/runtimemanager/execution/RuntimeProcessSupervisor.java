package com.gtav.runtimemanager.execution;

import android.system.Os;
import android.system.OsConstants;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;

/**
 * Tracks the complete session-owned process tree. In addition to parent/child discovery it scans
 * same-UID /proc entries for GTAV_SESSION_ID, so daemonized Wine descendants remain attributable
 * after re-parenting. PID birth ticks prevent recycled PIDs from ever being killed.
 */
public final class RuntimeProcessSupervisor {
    public static final class ProcessRecord {
        public final long pid;
        public final long parentPid;
        public final long startTicks;
        public final String command;

        public ProcessRecord(long pid, long startTicks) {
            this(pid, readParentPid(pid), startTicks, readCommand(pid));
        }

        public ProcessRecord(long pid, long parentPid, long startTicks, String command) {
            this.pid = pid;
            this.parentPid = parentPid;
            this.startTicks = startTicks;
            this.command = command == null ? "" : command;
        }

        public boolean alive() { return RuntimeProcessSupervisor.isSameProcess(pid, startTicks); }
        @Override public String toString() { return pid + "@" + startTicks + " " + command; }
    }

    public static final class CleanupResult {
        public final boolean clean;
        public final List<ProcessRecord> survivors;
        CleanupResult(boolean clean, List<ProcessRecord> survivors) {
            this.clean = clean;
            this.survivors = Collections.unmodifiableList(new ArrayList<>(survivors));
        }
    }

    private volatile Process current;
    private volatile long mainPid = -1;
    private volatile String sessionId = "";
    private final LinkedHashMap<Long, ProcessRecord> observed = new LinkedHashMap<>();

    public synchronized void beginSession(String id) {
        clear();
        sessionId = ExecutionPaths.requireSafeId(id, "sessionId");
    }

    public synchronized void attach(Process process, long pid) {
        current = process;
        mainPid = pid;
        remember(pid);
        refreshTree();
    }

    public synchronized void processFinished(Process process) {
        refreshTree();
        if (current == process) current = null;
    }

    /** Called while the direct process is alive, before daemonized descendants can be re-parented. */
    public synchronized void poll() { refreshTree(); }

    public synchronized List<Long> refreshTree() {
        if (mainPid > 0) collectChildren(mainPid, observed, 0);
        scanSessionEnvironment();
        ArrayList<Long> aliveChildren = new ArrayList<>();
        for (ProcessRecord record : observed.values()) {
            if (record.pid != mainPid && record.alive()) aliveChildren.add(record.pid);
        }
        return aliveChildren;
    }

    /** Returns every process identity ever observed in this session, alive or exited. */
    public synchronized List<ProcessRecord> records() {
        refreshTree();
        return new ArrayList<>(observed.values());
    }

    public synchronized List<ProcessRecord> liveRecords() {
        refreshTree();
        ArrayList<ProcessRecord> out = new ArrayList<>();
        for (ProcessRecord record : observed.values()) if (record.alive()) out.add(record);
        return out;
    }

    public synchronized long mainPid() { return mainPid; }

    public synchronized CleanupResult stopGracefully(long graceMs, RuntimeConsoleStore console) {
        refreshTree();
        List<ProcessRecord> processes = liveRecords();
        processes.sort(Comparator.comparingLong((ProcessRecord r) -> depthHint(r.pid)).reversed());
        for (ProcessRecord process : processes) signal(process, OsConstants.SIGTERM, console);
        if (current != null) try { current.destroy(); } catch (Throwable ignored) {}
        waitForClean(Math.max(100, graceMs));

        processes = liveRecords();
        processes.sort(Comparator.comparingLong((ProcessRecord r) -> depthHint(r.pid)).reversed());
        for (ProcessRecord process : processes) signal(process, OsConstants.SIGKILL, console);
        if (current != null) try { current.destroyForcibly(); } catch (Throwable ignored) {}
        waitForClean(800);

        List<ProcessRecord> survivors = liveRecords();
        if (console != null) {
            console.append("SYSTEM", survivors.isEmpty()
                    ? "PROCESS_CLEANUP_OK"
                    : "ORPHAN_PROCESSES=" + survivors);
        }
        return new CleanupResult(survivors.isEmpty(), survivors);
    }

    public synchronized boolean noOrphans() { return liveRecords().isEmpty(); }

    public synchronized void clear() {
        current = null;
        mainPid = -1;
        sessionId = "";
        observed.clear();
    }

    public static CleanupResult killSavedTree(List<ProcessRecord> records) {
        ArrayList<ProcessRecord> reverse = new ArrayList<>(records == null ? Collections.emptyList() : records);
        Collections.reverse(reverse);
        for (ProcessRecord record : reverse) {
            if (record.alive()) try { Os.kill((int) record.pid, OsConstants.SIGTERM); } catch (Throwable ignored) {}
        }
        sleep(500);
        for (ProcessRecord record : reverse) {
            if (record.alive()) try { Os.kill((int) record.pid, OsConstants.SIGKILL); } catch (Throwable ignored) {}
        }
        sleep(300);
        ArrayList<ProcessRecord> survivors = new ArrayList<>();
        for (ProcessRecord record : reverse) if (record.alive()) survivors.add(record);
        return new CleanupResult(survivors.isEmpty(), survivors);
    }

    /** Legacy recovery fallback for reports created before start-tick tracking. */
    public static CleanupResult killSavedTree(long main, List<Long> children) {
        LinkedHashSet<Long> all = new LinkedHashSet<>(children == null ? Collections.emptyList() : children);
        if (main > 0) all.add(main);
        ArrayList<ProcessRecord> records = new ArrayList<>();
        for (Long pid : all) {
            long ticks = readStartTicks(pid);
            if (ticks > 0) records.add(new ProcessRecord(pid, ticks));
        }
        return killSavedTree(records);
    }

    private void remember(long pid) {
        if (pid <= 1 || pid == android.os.Process.myPid() || observed.containsKey(pid)) return;
        long ticks = readStartTicks(pid);
        if (ticks > 0) observed.put(pid, new ProcessRecord(pid, ticks));
    }

    private void scanSessionEnvironment() {
        if (sessionId.isEmpty()) return;
        File[] processes = new File("/proc").listFiles(File::isDirectory);
        if (processes == null) return;
        String marker = "GTAV_SESSION_ID=" + sessionId;
        for (File process : processes) {
            long pid;
            try { pid = Long.parseLong(process.getName()); }
            catch (NumberFormatException ignored) { continue; }
            if (pid <= 1 || pid == android.os.Process.myPid() || observed.containsKey(pid)) continue;
            if (environmentContains(pid, marker)) remember(pid);
        }
    }

    private static boolean environmentContains(long pid, String marker) {
        File file = new File("/proc/" + pid + "/environ");
        if (!file.isFile()) return false;
        try (FileInputStream input = new FileInputStream(file)) {
            byte[] bytes = new byte[64 * 1024];
            int off = 0, read;
            while (off < bytes.length && (read = input.read(bytes, off, bytes.length - off)) > 0) off += read;
            String value = new String(bytes, 0, off, StandardCharsets.UTF_8);
            for (String item : value.split("\\u0000")) if (marker.equals(item)) return true;
        } catch (Throwable ignored) {}
        return false;
    }

    private static void collectChildren(long pid, LinkedHashMap<Long, ProcessRecord> out, int depth) {
        if (depth > 64) return;
        File children = new File("/proc/" + pid + "/task/" + pid + "/children");
        if (!children.isFile()) return;
        try (BufferedReader reader = new BufferedReader(new FileReader(children))) {
            String line = reader.readLine();
            if (line == null) return;
            for (String token : line.trim().split("\\s+")) {
                if (token.isEmpty()) continue;
                long child = Long.parseLong(token);
                long ticks = readStartTicks(child);
                if (ticks <= 0) continue;
                ProcessRecord old = out.putIfAbsent(child, new ProcessRecord(child, ticks));
                if (old == null || old.startTicks == ticks) collectChildren(child, out, depth + 1);
            }
        } catch (Throwable ignored) {}
    }

    private void waitForClean(long timeoutMs) {
        long deadline = android.os.SystemClock.elapsedRealtime() + timeoutMs;
        while (android.os.SystemClock.elapsedRealtime() < deadline) {
            if (liveRecords().isEmpty()) return;
            sleep(50);
        }
    }

    private static void signal(ProcessRecord process, int signal, RuntimeConsoleStore console) {
        if (!process.alive()) return;
        try { Os.kill((int) process.pid, signal); }
        catch (Throwable error) {
            if (console != null) console.append("SYSTEM",
                    "kill(" + process.pid + "@" + process.startTicks + "): " + error);
        }
    }

    static boolean isSameProcess(long pid, long expectedStartTicks) {
        return pid > 0 && expectedStartTicks > 0 && readStartTicks(pid) == expectedStartTicks;
    }

    /** Linux /proc/[pid]/stat field 22; handles spaces and ')' in process names safely. */
    static long readStartTicks(long pid) {
        if (pid <= 0) return -1;
        File stat = new File("/proc/" + pid + "/stat");
        if (!stat.isFile()) return -1;
        try (BufferedReader reader = new BufferedReader(new FileReader(stat))) {
            String line = reader.readLine();
            if (line == null) return -1;
            int endName = line.lastIndexOf(')');
            if (endName < 0 || endName + 2 >= line.length()) return -1;
            String[] rest = line.substring(endName + 2).trim().split("\\s+");
            return rest.length > 19 ? Long.parseLong(rest[19]) : -1;
        } catch (Throwable ignored) { return -1; }
    }

    static long readParentPid(long pid) {
        File status = new File("/proc/" + pid + "/status");
        try (BufferedReader reader = new BufferedReader(new FileReader(status))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.startsWith("PPid:")) return Long.parseLong(line.substring(5).trim());
            }
        } catch (Throwable ignored) {}
        return -1;
    }

    static String readCommand(long pid) {
        File cmdline = new File("/proc/" + pid + "/cmdline");
        if (!cmdline.isFile()) return "";
        try (FileInputStream input = new FileInputStream(cmdline)) {
            byte[] bytes = new byte[16 * 1024];
            int off = 0, read;
            while (off < bytes.length && (read = input.read(bytes, off, bytes.length - off)) > 0) off += read;
            return new String(bytes, 0, off, StandardCharsets.UTF_8).replace('\0', ' ').trim();
        } catch (Throwable ignored) { return ""; }
    }

    private static long depthHint(long pid) {
        long depth = 0;
        long current = pid;
        for (int i = 0; i < 64; i++) {
            long parent = readParentPid(current);
            if (parent <= 1 || parent == current) break;
            depth++;
            current = parent;
        }
        return depth;
    }

    private static void sleep(long ms) {
        try { Thread.sleep(ms); }
        catch (InterruptedException error) { Thread.currentThread().interrupt(); }
    }
}
