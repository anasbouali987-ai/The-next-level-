package com.gtav.runtimemanager.execution;

import java.util.Collections;
import java.util.EnumMap;
import java.util.Map;

/** Declares future backends without pretending that device capability equals app support. */
public final class BackendCapabilityRegistry {
    public enum Backend { DISPLAY, AUDIO, GRAPHICS, INPUT }
    public enum State { DECLARED_NOT_IMPLEMENTED, AVAILABLE, VALIDATED, ENABLED, UNAVAILABLE }

    public static final class Capability {
        public final Backend backend;
        public final State state;
        public final String reason;
        Capability(Backend backend, State state, String reason) {
            this.backend = backend;
            this.state = state;
            this.reason = reason == null ? "" : reason;
        }
    }

    private final EnumMap<Backend, Capability> capabilities = new EnumMap<>(Backend.class);

    public BackendCapabilityRegistry() {
        for (Backend backend : Backend.values()) {
            capabilities.put(backend, new Capability(backend, State.DECLARED_NOT_IMPLEMENTED,
                    "Deferred to the post-v1.7 execution-backend release"));
        }
    }

    public Map<Backend, Capability> all() { return Collections.unmodifiableMap(capabilities); }

    public String format() {
        StringBuilder out = new StringBuilder();
        for (Capability capability : capabilities.values()) {
            out.append(capability.backend.name()).append('=').append(capability.state.name());
            if (!capability.reason.isEmpty()) out.append(" — ").append(capability.reason);
            out.append('\n');
        }
        return out.toString();
    }
}
