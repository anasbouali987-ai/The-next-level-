package com.gtav.runtimemanager.execution;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

/** Minimal ELF identity reader used by preflight and build/device diagnostics. */
public final class ElfInspector {
    public static final int EM_X86_64 = 62;
    public static final int EM_AARCH64 = 183;

    public static final class Result {
        public final boolean elf;
        public final boolean is64Bit;
        public final boolean littleEndian;
        public final int machine;
        public final String description;

        Result(boolean elf, boolean is64Bit, boolean littleEndian, int machine, String description) {
            this.elf = elf;
            this.is64Bit = is64Bit;
            this.littleEndian = littleEndian;
            this.machine = machine;
            this.description = description;
        }

        public boolean isAarch64() { return elf && machine == EM_AARCH64; }
        public boolean isX8664() { return elf && machine == EM_X86_64; }
    }

    private ElfInspector() {}

    public static Result inspect(File file) throws IOException {
        if (file == null || !file.isFile()) return new Result(false, false, false, -1, "missing");
        byte[] header = new byte[64];
        try (FileInputStream input = new FileInputStream(file)) {
            int offset = 0;
            while (offset < header.length) {
                int read = input.read(header, offset, header.length - offset);
                if (read < 0) break;
                offset += read;
            }
            if (offset < 20 || header[0] != 0x7f || header[1] != 'E' || header[2] != 'L' || header[3] != 'F') {
                return new Result(false, false, false, -1, "not-elf");
            }
            boolean is64 = header[4] == 2;
            boolean little = header[5] == 1;
            int machine = little
                    ? ((header[18] & 0xff) | ((header[19] & 0xff) << 8))
                    : (((header[18] & 0xff) << 8) | (header[19] & 0xff));
            return new Result(true, is64, little, machine, machineName(machine));
        }
    }

    public static String machineName(int machine) {
        if (machine == EM_AARCH64) return "AArch64";
        if (machine == EM_X86_64) return "x86_64";
        return "ELF machine " + machine;
    }
}
