package com.gtav.runtimemanager.execution;

import com.gtav.runtimemanager.VerifiedInstalledRuntime;

public final class Box64SmokeTest {
    private final Box64Manager manager = new Box64Manager();
    public RuntimeCommand version(VerifiedInstalledRuntime runtime) { return manager.versionCommand(runtime); }
    public RuntimeCommand hello(VerifiedInstalledRuntime runtime) { return manager.smokeCommand(runtime); }
}
