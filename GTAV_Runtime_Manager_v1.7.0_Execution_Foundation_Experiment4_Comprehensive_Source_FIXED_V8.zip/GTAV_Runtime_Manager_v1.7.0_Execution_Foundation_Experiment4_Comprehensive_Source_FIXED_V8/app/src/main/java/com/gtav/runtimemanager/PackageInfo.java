package com.gtav.runtimemanager;

import android.net.Uri;

final class PackageInfo {
    final Uri uri; final String displayName; final long zipSize, modifiedAt; final RuntimeManifest manifest;
    final long payloadActualSize; final int zipEntryCount; final String reportJson;
    PackageInfo(Uri uri,String name,long zipSize,long modifiedAt,RuntimeManifest manifest,long payloadActualSize,int zipEntryCount,String reportJson){
        this.uri=uri;this.displayName=name;this.zipSize=zipSize;this.modifiedAt=modifiedAt;this.manifest=manifest;
        this.payloadActualSize=payloadActualSize;this.zipEntryCount=zipEntryCount;this.reportJson=reportJson;
    }
}
