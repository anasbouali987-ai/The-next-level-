package com.gtav.runtimemanager.execution;

public enum WinePrefixState {
    ABSENT,
    CREATING,
    INITIALIZING,
    READY,
    CORRUPTED,
    DELETING
}
