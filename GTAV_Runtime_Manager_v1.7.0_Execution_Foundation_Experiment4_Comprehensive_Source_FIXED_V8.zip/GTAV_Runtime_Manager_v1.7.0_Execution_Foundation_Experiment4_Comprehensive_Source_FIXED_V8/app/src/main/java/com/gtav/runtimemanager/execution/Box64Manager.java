package com.gtav.runtimemanager.execution;

import com.gtav.runtimemanager.VerifiedInstalledRuntime;

import java.util.Arrays;

public final class Box64Manager {
    public RuntimeCommand versionCommand(VerifiedInstalledRuntime runtime) {
        return new RuntimeCommand(runtime.box64GuestPath(), Arrays.asList("--version"), 15_000, "");
    }

    public RuntimeCommand smokeCommand(VerifiedInstalledRuntime runtime) {
        return new RuntimeCommand(runtime.box64GuestPath(),
                Arrays.asList("/mnt/gtav-session/hello-x86_64"), 30_000, "BOX64_SMOKE_TEST_OK");
    }
}
