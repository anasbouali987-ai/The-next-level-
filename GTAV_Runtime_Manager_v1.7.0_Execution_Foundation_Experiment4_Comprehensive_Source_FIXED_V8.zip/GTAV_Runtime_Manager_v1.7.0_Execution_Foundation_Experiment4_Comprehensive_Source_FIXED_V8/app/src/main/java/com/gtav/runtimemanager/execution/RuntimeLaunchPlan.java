package com.gtav.runtimemanager.execution;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class RuntimeLaunchPlan {
    public final String name;
    public final List<String> hostArgv;
    public final File workingDirectory;
    public final RuntimeEnvironment environment;
    public final long timeoutMs;
    public final String expectedOutput;

    RuntimeLaunchPlan(String name, List<String> hostArgv, File workingDirectory,
                      RuntimeEnvironment environment, long timeoutMs, String expectedOutput) {
        this.name = name;
        this.hostArgv = Collections.unmodifiableList(new ArrayList<>(hostArgv));
        this.workingDirectory = workingDirectory;
        this.environment = environment;
        this.timeoutMs = timeoutMs;
        this.expectedOutput = expectedOutput == null ? "" : expectedOutput;
    }
}
