package com.gtav.runtimemanager.execution;

import java.io.File;

public final class RuntimeBindMount {
    public enum Purpose { SESSION, TEMP, PREFIX, HOME, PROFILE, CACHE, TEST_BINARY, SYSTEM_BRIDGE, DEVICE }

    public final File hostPath;
    public final String guestPath;
    public final boolean readOnly;
    public final boolean required;
    public final Purpose purpose;

    public RuntimeBindMount(File hostPath, String guestPath, boolean readOnly, boolean required) {
        this(hostPath, guestPath, readOnly, required, Purpose.SESSION);
    }

    public RuntimeBindMount(File hostPath, String guestPath, boolean readOnly,
                            boolean required, Purpose purpose) {
        if (hostPath == null) throw new IllegalArgumentException("Host path مطلوب");
        validateGuestPath(guestPath);
        this.hostPath = hostPath;
        this.guestPath = guestPath;
        this.readOnly = readOnly;
        this.required = required;
        this.purpose = purpose == null ? Purpose.SESSION : purpose;
    }

    public String prootSpec() { return hostPath.getAbsolutePath() + ":" + guestPath; }

    public static void validateGuestPath(String path) {
        if (path == null || !path.startsWith("/") || path.indexOf('\0') >= 0 ||
                path.equals("/..") || path.contains("/../") || path.endsWith("/..")) {
            throw new IllegalArgumentException("Guest path غير صالح: " + path);
        }
    }

    @Override public String toString() {
        return hostPath.getAbsolutePath() + " -> " + guestPath +
                " [purpose=" + purpose + ", " + (readOnly ? "read-mostly" : "writable") +
                ", " + (required ? "required" : "optional") + "]";
    }
}
