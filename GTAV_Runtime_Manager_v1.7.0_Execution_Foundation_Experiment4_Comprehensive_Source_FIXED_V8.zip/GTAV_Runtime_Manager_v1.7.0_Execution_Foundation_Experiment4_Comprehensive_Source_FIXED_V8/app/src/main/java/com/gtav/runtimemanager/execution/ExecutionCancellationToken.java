package com.gtav.runtimemanager.execution;

import java.util.concurrent.atomic.AtomicReference;

/** Carries the user intent so reports distinguish cancel from graceful stop. */
public final class ExecutionCancellationToken {
    public enum Request { NONE, CANCEL, STOP }
    private final AtomicReference<Request> request = new AtomicReference<>(Request.NONE);

    public void cancel() { request.compareAndSet(Request.NONE, Request.CANCEL); }
    public void requestStop() { request.compareAndSet(Request.NONE, Request.STOP); }
    public boolean isCancelled() { return request.get() != Request.NONE; }
    public Request request() { return request.get(); }

    public void throwIfCancelled(ExecutionStage stage) throws RuntimeExecutionException {
        Request value = request.get();
        if (value == Request.NONE) return;
        throw new RuntimeExecutionException(
                value == Request.STOP ? ExecutionErrorCode.PROCESS_STOPPED : ExecutionErrorCode.PROCESS_CANCELLED,
                stage, value == Request.STOP ? "تم طلب إيقاف الجلسة" : "تم إلغاء الجلسة");
    }
}
