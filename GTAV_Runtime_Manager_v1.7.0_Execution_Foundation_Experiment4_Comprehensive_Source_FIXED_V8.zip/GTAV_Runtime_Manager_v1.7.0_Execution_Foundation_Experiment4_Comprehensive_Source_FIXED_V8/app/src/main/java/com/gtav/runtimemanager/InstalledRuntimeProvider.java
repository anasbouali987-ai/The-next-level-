package com.gtav.runtimemanager;

import android.content.Context;


import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.regex.Pattern;

/** The only supported bridge from the installation domain to execution. */
public final class InstalledRuntimeProvider {
    private static final Pattern SHA256 = Pattern.compile("[0-9a-fA-F]{64}");
    private static final Pattern SAFE_ID = Pattern.compile("[A-Za-z0-9][A-Za-z0-9._-]{2,127}");
    private final Context context;

    public InstalledRuntimeProvider(Context context) { this.context = context.getApplicationContext(); }

    public VerifiedInstalledRuntime findReady(String runtimeId) throws Exception {
        String safeId = requireSafeId(runtimeId, "runtimeId");
        InstalledRuntime installed = InstalledRuntime.find(StorageLocations.runtimesRoot(context), safeId);
        if (installed == null) throw new IllegalStateException("Runtime غير مثبت أو حالته ليست complete");
        return loadAndVerify(installed);
    }

    public VerifiedInstalledRuntime findDefaultReady() throws Exception {
        File root = StorageLocations.runtimesRoot(context);
        File[] children = root.listFiles();
        if (children == null) throw new IllegalStateException("لا يوجد Runtime مثبت");
        VerifiedInstalledRuntime only = null;
        for (File child : children) {
            if (!child.isDirectory() || child.getName().endsWith(".installing") || child.getName().endsWith(".backup")) continue;
            try { requireSafeId(child.getName(), "runtimeId"); }
            catch (IllegalArgumentException ignored) { continue; }
            InstalledRuntime installed = InstalledRuntime.find(root, child.getName());
            if (installed == null) continue;
            VerifiedInstalledRuntime candidate = loadAndVerify(installed);
            if (only != null) throw new IllegalStateException("يوجد أكثر من Runtime؛ يجب اختيار Runtime صراحةً");
            only = candidate;
        }
        if (only == null) throw new IllegalStateException("لا يوجد Runtime جاهز للتشغيل");
        return only;
    }

    private VerifiedInstalledRuntime loadAndVerify(InstalledRuntime installed) throws Exception {
        String runtimeId = requireSafeId(installed.runtimeId, "runtimeId");
        File root = StorageLocations.runtimesRoot(context).getCanonicalFile();
        File path = installed.path.getCanonicalFile();
        if (!path.getParentFile().equals(root) || !path.getName().equals(runtimeId)) {
            throw new IllegalStateException("مسار Runtime لا يطابق هويته");
        }
        if (installed.version == null || installed.version.trim().isEmpty()) throw new IllegalStateException("Runtime version مفقود");
        if (installed.schema <= 0) throw new IllegalStateException("Runtime schema غير صالح");
        if (!SHA256.matcher(installed.payloadSha == null ? "" : installed.payloadSha).matches()) {
            throw new IllegalStateException("Payload SHA-256 غير صالح");
        }

        File manifestFile = new File(path, "runtime_manifest.json");
        if (!manifestFile.isFile()) throw new IllegalStateException("Manifest المثبت مفقود");
        String manifestText = readSmallText(manifestFile, 8 * 1024 * 1024);
        JSONObject manifest = new JSONObject(manifestText);
        if (!runtimeId.equals(manifest.optString("runtime_id"))) throw new IllegalStateException("Runtime ID غير متطابق");
        if (!installed.version.equals(manifest.optString("version"))) throw new IllegalStateException("Runtime version غير متطابق");
        if (installed.schema != manifest.optInt("schema_version", -1)) throw new IllegalStateException("Schema غير متطابق");
        String hostArchitecture = manifest.optString("host_architecture", "");
        String guestArchitecture = manifest.optString("guest_architecture", "");
        String libcModel = manifest.optString("libc_model", "");
        if (!hostArchitecture.equalsIgnoreCase("arm64") && !hostArchitecture.equalsIgnoreCase("aarch64"))
            throw new IllegalStateException("Host architecture غير مدعومة: " + hostArchitecture);
        if (!guestArchitecture.equalsIgnoreCase("x86_64") && !guestArchitecture.equalsIgnoreCase("amd64"))
            throw new IllegalStateException("Guest architecture غير مدعومة: " + guestArchitecture);
        if (!libcModel.toLowerCase(Locale.US).contains("glibc"))
            throw new IllegalStateException("Runtime ليس glibc RootFS: " + libcModel);

        JSONObject components = manifest.optJSONObject("components");
        JSONObject entry = manifest.optJSONObject("entrypoints");
        String wine64 = normalize(entry == null ? "" : entry.optString("wine64"));
        String wineboot = normalize(entry == null ? "" : entry.optString("wineboot"));
        String wineserver = normalize(entry == null ? "" : entry.optString("wineserver"));
        List<String> required = new ArrayList<>();
        String box64 = "";
        JSONArray files = manifest.optJSONArray("rootfs_files");
        if (files == null || files.length() == 0) throw new IllegalStateException("rootfs_files مفقودة");
        for (int i = 0; i < files.length(); i++) {
            JSONObject item = files.optJSONObject(i);
            if (item == null || !item.optBoolean("required", false)) continue;
            String relative = normalizeRelative(item.optString("path"));
            if (relative.isEmpty()) throw new IllegalStateException("Required path غير صالح");
            required.add("/" + relative);
            verifyRequired(path, relative, item);
            if (box64.isEmpty() && "box64".equalsIgnoreCase(item.optString("component")) &&
                    "file".equalsIgnoreCase(item.optString("type", "file"))) box64 = "/" + relative;
        }
        if (box64.isEmpty()) box64 = discoverBox64(path);
        requireExecutable(path, wine64, "wine64 entrypoint");
        requireExecutable(path, wineboot, "wineboot entrypoint");
        requireExecutable(path, wineserver, "wineserver entrypoint");
        requireExecutable(path, box64, "Box64");

        return new VerifiedInstalledRuntime(path, runtimeId, installed.version, installed.schema,
                installed.payloadSha.toLowerCase(Locale.US), sha256(manifestFile), System.currentTimeMillis(),
                components == null ? "" : components.optString("box64"),
                components == null ? "" : components.optString("wine"),
                box64, wine64, wineboot, wineserver, required);
    }

    private static void verifyRequired(File rootfs, String relative, JSONObject item) throws Exception {
        File file = new File(rootfs, relative).getCanonicalFile();
        String root = rootfs.getCanonicalPath();
        if (!file.getPath().startsWith(root + File.separator)) throw new IllegalStateException("Required path escapes RootFS");
        String type = item.optString("type", "file");
        if ("symlink".equals(type)) {
            if (!Files.isSymbolicLink(file.toPath())) throw new IllegalStateException("Symlink مطلوب لكنه مفقود: " + relative);
            String expectedTarget = item.optString("link_target", "");
            if (!expectedTarget.isEmpty() && !expectedTarget.equals(Files.readSymbolicLink(file.toPath()).toString())) {
                throw new IllegalStateException("Symlink target غير متطابق: " + relative);
            }
            return;
        }
        if (!file.isFile()) throw new IllegalStateException("Required file مفقود: " + relative);
        long expectedSize = item.optLong("size_bytes", -1);
        if (expectedSize >= 0 && file.length() != expectedSize) throw new IllegalStateException("Required size غير متطابق: " + relative);
        String expectedSha = item.optString("sha256", "");
        if (SHA256.matcher(expectedSha).matches() && !expectedSha.equalsIgnoreCase(sha256(file))) {
            throw new IllegalStateException("Required SHA-256 غير متطابق: " + relative);
        }
    }

    private static String discoverBox64(File rootfs) {
        String[] candidates = {"/usr/local/bin/box64", "/usr/bin/box64", "/opt/gtav-runtime/bin/box64"};
        for (String candidate : candidates) if (new File(rootfs, candidate.substring(1)).isFile()) return candidate;
        return "/usr/local/bin/box64";
    }

    private static void requireExecutable(File rootfs, String guest, String label) throws Exception {
        if (guest == null || guest.isEmpty()) throw new IllegalStateException(label + " غير معرف");
        String relative = normalizeRelative(guest);
        File file = new File(rootfs, relative).getCanonicalFile();
        String root = rootfs.getCanonicalPath();
        if (!file.getPath().startsWith(root + File.separator)) throw new IllegalStateException(label + " يخرج عن RootFS");
        if (!file.isFile()) throw new IllegalStateException(label + " مفقود: " + guest);
        if (!file.canExecute()) throw new IllegalStateException(label + " غير قابل للتنفيذ: " + guest);
    }

    private static String normalize(String value) {
        String relative = normalizeRelative(value);
        return relative.isEmpty() ? "" : "/" + relative;
    }

    private static String normalizeRelative(String value) {
        if (value == null || value.isEmpty()) return "";
        String out = value.replace('\\', '/');
        while (out.startsWith("/")) out = out.substring(1);
        if (out.isEmpty() || out.equals("..") || out.startsWith("../") || out.contains("/../") || out.indexOf('\0') >= 0) return "";
        return out;
    }

    private static String requireSafeId(String value, String field) {
        if (value == null || !SAFE_ID.matcher(value).matches()) {
            throw new IllegalArgumentException(field + " غير صالح");
        }
        return value;
    }

    private static String sha256(File file) throws Exception {
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        try (BufferedInputStream input = new BufferedInputStream(new FileInputStream(file), 256 * 1024)) {
            byte[] buffer = new byte[256 * 1024];
            int read;
            while ((read = input.read(buffer)) != -1) digest.update(buffer, 0, read);
        }
        StringBuilder out = new StringBuilder(64);
        for (byte value : digest.digest()) out.append(String.format(Locale.US, "%02x", value));
        return out.toString();
    }

    private static String readSmallText(File file, int max) throws Exception {
        try (InputStream input = new FileInputStream(file); ByteArrayOutputStream output = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[32 * 1024];
            int total = 0, read;
            while ((read = input.read(buffer)) != -1) {
                total += read;
                if (total > max) throw new IllegalStateException("Manifest أكبر من الحد الآمن");
                output.write(buffer, 0, read);
            }
            return output.toString(StandardCharsets.UTF_8.name());
        }
    }
}
