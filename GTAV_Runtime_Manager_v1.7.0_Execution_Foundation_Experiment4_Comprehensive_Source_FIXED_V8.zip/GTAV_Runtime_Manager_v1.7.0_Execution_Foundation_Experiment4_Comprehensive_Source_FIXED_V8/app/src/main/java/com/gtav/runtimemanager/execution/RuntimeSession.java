package com.gtav.runtimemanager.execution;

import java.io.File;

/** Immutable filesystem layout and identity for one execution attempt. */
public final class RuntimeSession {
    public final String id;
    public final String runtimeId;
    public final File directory;
    public final File reportsDir;
    public final File preflightDir;
    public final File diagnosticsDir;
    public final File fsDir;
    public final File guestShareDir;
    public final File tmpDir;
    public final File prootTmpDir;
    public final File runDir;
    public final File varTmpDir;
    public final File varCacheDir;
    public final File varLogDir;
    public final File runUserDir;
    public final File homeDir;
    public final File etcDir;
    public final File devShmDir;
    public final File resolvConf;
    public final File hostsFile;
    public final File hostnameFile;
    public final File lockFile;
    public final File stateFile;
    public final File processTreeFile;
    public final File consoleFile;
    public final File summaryFile;
    public final long createdAt;

    RuntimeSession(String id, String runtimeId, File directory) {
        this.id = ExecutionPaths.requireSafeId(id, "sessionId");
        this.runtimeId = ExecutionPaths.requireSafeId(runtimeId, "runtimeId");
        this.directory = directory;
        this.reportsDir = ExecutionPaths.ensure(new File(directory, "reports"));
        this.preflightDir = ExecutionPaths.ensure(new File(reportsDir, "preflight"));
        this.diagnosticsDir = ExecutionPaths.ensure(new File(reportsDir, "diagnostics"));
        this.fsDir = ExecutionPaths.ensure(new File(directory, "fs"));
        this.guestShareDir = ExecutionPaths.ensure(new File(fsDir, "guest-share"));
        this.tmpDir = ExecutionPaths.ensure(new File(fsDir, "tmp"));
        this.prootTmpDir = ExecutionPaths.ensure(new File(fsDir, "proot-tmp"));
        this.runDir = ExecutionPaths.ensure(new File(fsDir, "run"));
        this.runUserDir = ExecutionPaths.ensure(new File(runDir, "user/0"));
        this.varTmpDir = ExecutionPaths.ensure(new File(fsDir, "var-tmp"));
        this.varCacheDir = ExecutionPaths.ensure(new File(fsDir, "var-cache"));
        this.varLogDir = ExecutionPaths.ensure(new File(fsDir, "var-log"));
        this.homeDir = ExecutionPaths.ensure(new File(fsDir, "home"));
        this.etcDir = ExecutionPaths.ensure(new File(fsDir, "etc"));
        this.devShmDir = ExecutionPaths.ensure(new File(fsDir, "dev-shm"));
        this.resolvConf = new File(etcDir, "resolv.conf");
        this.hostsFile = new File(etcDir, "hosts");
        this.hostnameFile = new File(etcDir, "hostname");
        initializeSessionEtc();
        this.lockFile = new File(directory, "session.lock.json");
        this.stateFile = new File(directory, "execution_state.json");
        this.processTreeFile = new File(directory, "process_tree.json");
        this.consoleFile = new File(directory, "execution_log.txt");
        this.summaryFile = new File(directory, "runtime_session_report.txt");
        this.createdAt = System.currentTimeMillis();
    }

    private void initializeSessionEtc() {
        try {
            java.nio.file.Files.write(resolvConf.toPath(),
                    "nameserver 8.8.8.8\nnameserver 1.1.1.1\n".getBytes(java.nio.charset.StandardCharsets.UTF_8));
            java.nio.file.Files.write(hostsFile.toPath(),
                    "127.0.0.1 localhost\n::1 localhost\n".getBytes(java.nio.charset.StandardCharsets.UTF_8));
            java.nio.file.Files.write(hostnameFile.toPath(),
                    "gtav-runtime\n".getBytes(java.nio.charset.StandardCharsets.UTF_8));
        } catch (Throwable error) {
            throw new IllegalStateException("تعذر إنشاء ملفات /etc الخاصة بالجلسة", error);
        }
    }
}
