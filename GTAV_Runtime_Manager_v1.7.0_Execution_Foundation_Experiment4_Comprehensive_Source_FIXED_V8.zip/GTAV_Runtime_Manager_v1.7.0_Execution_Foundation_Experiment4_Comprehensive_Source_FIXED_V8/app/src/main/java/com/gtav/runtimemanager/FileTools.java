package com.gtav.runtimemanager;

import android.system.ErrnoException;
import android.system.Os;
import android.system.OsConstants;

import java.io.File;
import java.io.IOException;
import java.util.ArrayDeque;
import java.util.Deque;

final class FileTools {
    private FileTools() {}

    static void deleteTree(File allowedRoot, File target) throws IOException {
        if (target == null || !existsNoFollow(target)) return;
        ensureInside(allowedRoot, target);

        Deque<File> scan = new ArrayDeque<>();
        Deque<File> directories = new ArrayDeque<>();
        scan.push(target);

        while (!scan.isEmpty()) {
            File current = scan.pop();
            if (isDirectoryNoFollow(current)) {
                directories.push(current);
                File[] children = current.listFiles();
                if (children != null) {
                    for (File child : children) scan.push(child);
                }
            } else if (!current.delete() && existsNoFollow(current)) {
                throw new IOException("تعذر حذف: " + current.getAbsolutePath());
            }
        }

        while (!directories.isEmpty()) {
            File directory = directories.pop();
            if (!directory.delete() && existsNoFollow(directory)) {
                throw new IOException("تعذر حذف المجلد: " + directory.getAbsolutePath());
            }
        }
    }

    static void deleteTreeQuietly(File allowedRoot, File target, RuntimeLogWriter log) {
        try {
            deleteTree(allowedRoot, target);
        } catch (Throwable error) {
            if (log != null) log.error("فشل تنظيف المسار " + target, error);
        }
    }

    static boolean existsNoFollow(File file) throws IOException {
        try {
            Os.lstat(file.getAbsolutePath());
            return true;
        } catch (ErrnoException error) {
            if (error.errno == OsConstants.ENOENT) return false;
            throw new IOException("تعذر فحص المسار: " + file.getAbsolutePath(), error);
        }
    }

    static boolean isDirectoryNoFollow(File file) throws IOException {
        try {
            return OsConstants.S_ISDIR(Os.lstat(file.getAbsolutePath()).st_mode);
        } catch (ErrnoException error) {
            if (error.errno == OsConstants.ENOENT) return false;
            throw new IOException("تعذر فحص المجلد: " + file.getAbsolutePath(), error);
        }
    }

    static long size(File root) {
        if (root == null) return 0;
        long size = 0;
        Deque<File> stack = new ArrayDeque<>();
        stack.push(root);
        while (!stack.isEmpty()) {
            File current = stack.pop();
            try {
                android.system.StructStat stat = Os.lstat(current.getAbsolutePath());
                if (OsConstants.S_ISREG(stat.st_mode)) {
                    size += Math.max(0, stat.st_size);
                } else if (OsConstants.S_ISDIR(stat.st_mode)) {
                    File[] children = current.listFiles();
                    if (children != null) for (File child : children) stack.push(child);
                }
            } catch (Throwable ignored) {
            }
        }
        return size;
    }

    static long count(File root) {
        if (root == null) return 0;
        long count = 0;
        Deque<File> stack = new ArrayDeque<>();
        stack.push(root);
        while (!stack.isEmpty()) {
            File current = stack.pop();
            try {
                android.system.StructStat stat = Os.lstat(current.getAbsolutePath());
                count++;
                if (OsConstants.S_ISDIR(stat.st_mode)) {
                    File[] children = current.listFiles();
                    if (children != null) for (File child : children) stack.push(child);
                }
            } catch (Throwable ignored) {
            }
        }
        return count;
    }

    private static void ensureInside(File allowedRoot, File target) throws IOException {
        File base = allowedRoot.getAbsoluteFile();
        File candidate = target.getAbsoluteFile();
        String basePath = base.getAbsolutePath();
        String targetPath = candidate.getAbsolutePath();
        if (targetPath.equals(basePath) || !targetPath.startsWith(basePath + File.separator)) {
            throw new IOException("رفض حذف مسار خارج مجلد Runtime الآمن: " + targetPath);
        }
    }
}
