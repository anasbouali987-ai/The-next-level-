package com.gtav.runtimemanager.execution;

import android.content.Context;
import android.content.Intent;

import com.gtav.runtimemanager.BuildConfig;
import com.gtav.runtimemanager.InstalledRuntimeProvider;
import com.gtav.runtimemanager.VerifiedInstalledRuntime;

import java.io.File;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

/** Coordinates the deterministic PRoot -> RootFS -> Box64 -> Wine execution gates. */
public final class RuntimeExecutionManager {
    public interface Listener { void onExecutionSnapshot(RuntimeExecutionSnapshot snapshot); }
    private enum Outcome { SUCCESS, FAILED, CANCELLED, STOPPED, TIMED_OUT }

    private static volatile RuntimeExecutionManager INSTANCE;

    public static RuntimeExecutionManager get(Context context) {
        if (INSTANCE == null) synchronized (RuntimeExecutionManager.class) {
            if (INSTANCE == null) INSTANCE = new RuntimeExecutionManager(context.getApplicationContext());
        }
        return INSTANCE;
    }

    private final Context context;
    private final ExecutorService executor = Executors.newSingleThreadExecutor(r -> {
        Thread thread = new Thread(r, "gtav-runtime-execution-owner");
        thread.setPriority(Thread.NORM_PRIORITY - 1);
        return thread;
    });
    private final CopyOnWriteArrayList<Listener> listeners = new CopyOnWriteArrayList<>();
    private final AtomicBoolean running = new AtomicBoolean(false);
    private final RuntimeSessionManager sessions;
    private final RuntimeProcessSupervisor supervisor = new RuntimeProcessSupervisor();
    private final ExecutionStateMachine stateMachine = new ExecutionStateMachine();
    private final Object snapshotLock = new Object();

    private volatile RuntimeExecutionSnapshot snapshot = RuntimeExecutionSnapshot.idle();
    private volatile RuntimeConsoleStore console;
    private volatile ExecutionCancellationToken cancellation;
    private volatile RuntimeExecutionReporter reporter;
    private volatile RuntimeExecutionStateStore stateStore;

    private RuntimeExecutionManager(Context context) {
        this.context = context;
        this.sessions = new RuntimeSessionManager(context);
    }

    public RuntimeExecutionSnapshot current() { return snapshot; }
    public RuntimeConsoleStore console() { return console; }
    public boolean isRunning() { return running.get(); }
    public void addListener(Listener listener) {
        if (listener != null) { listeners.addIfAbsent(listener); listener.onExecutionSnapshot(snapshot); }
    }
    public void removeListener(Listener listener) { listeners.remove(listener); }

    public void startFullDiagnostic(String runtimeId) {
        if (!running.compareAndSet(false, true)) return;
        cancellation = new ExecutionCancellationToken();
        Intent service = new Intent(context, RuntimeExecutionService.class)
                .setAction(RuntimeExecutionService.ACTION_START);
        try {
            if (android.os.Build.VERSION.SDK_INT >= 26) context.startForegroundService(service);
            else context.startService(service);
        } catch (Throwable error) {
            running.set(false);
            publishWithoutSession(ExecutionStage.FAILED,
                    "تعذر بدء Foreground Service: " + error,
                    ExecutionErrorCode.EXECUTION_SERVICE_START_FAILED);
            return;
        }
        executor.execute(() -> run(runtimeId));
    }

    /** Cancellation is owned by the execution thread; the UI thread never races cleanup directly. */
    public void cancel() {
        ExecutionCancellationToken token = cancellation;
        if (token != null) token.cancel();
        RuntimeConsoleStore activeConsole = console;
        if (activeConsole != null) activeConsole.append("SYSTEM", "CANCELLATION_REQUESTED");
        heartbeat("تم طلب الإلغاء؛ ستبدأ عملية التنظيف بأمان", snapshot.command,
                snapshot.pid, snapshot.exitCode, snapshot.errorCode);
    }

    public void stop() {
        ExecutionCancellationToken token = cancellation;
        if (token != null) token.requestStop();
        RuntimeConsoleStore activeConsole = console;
        if (activeConsole != null) activeConsole.append("SYSTEM", "GRACEFUL_STOP_REQUESTED");
        heartbeat("تم طلب الإيقاف المنظم؛ سيبدأ تنظيف Wine وشجرة العمليات", snapshot.command,
                snapshot.pid, snapshot.exitCode, snapshot.errorCode);
    }

    private void run(String requestedRuntimeId) {
        RuntimeSession session = null;
        VerifiedInstalledRuntime runtime = null;
        RuntimeMutationGuard mutationGuard = new RuntimeMutationGuard();
        WinePrefixManager prefixManager = new WinePrefixManager();
        WinePrefixManager.PrefixLease prefixLease = null;
        ExecutionFeatureFlags flags = null;
        RuntimeMountManager.MountPlan mounts = null;
        RuntimeEnvironment environment = null;
        RuntimeLauncher launcher = null;
        RuntimeProcessRunner runner = null;
        WineManager wine = null;
        RuntimeExecutionResult wineSmoke = null;
        Outcome outcome = Outcome.FAILED;
        Throwable failure = null;
        long started = System.currentTimeMillis();
        boolean wineStageReached = false;
        boolean mutationCaptured = false;

        try {
            InstalledRuntimeProvider provider = new InstalledRuntimeProvider(context);
            runtime = requestedRuntimeId == null || requestedRuntimeId.isEmpty()
                    ? provider.findDefaultReady() : provider.findReady(requestedRuntimeId);

            session = sessions.create(runtime.runtimeId());
            stateMachine.resetForNewSession();
            supervisor.beginSession(session.id);
            reporter = new RuntimeExecutionReporter(context, session);
            stateStore = new RuntimeExecutionStateStore(reporter);
            console = new RuntimeConsoleStore(context, session);
            publish(ExecutionStage.PREPARING, CleanupState.NOT_STARTED, true,
                    "إنشاء جلسة التشغيل", "", -1, Integer.MIN_VALUE,
                    ExecutionErrorCode.NONE, false);
            console.append("SYSTEM", "GTAV Runtime Manager v1.7.0 — Experiment 4 Comprehensive");
            console.append("SYSTEM", "Session " + session.id + " started for " + runtime.runtimeId());

            prefixLease = prefixManager.acquire(context, runtime, session);
            mutationGuard.capture(runtime);
            mutationCaptured = true;
            reporter.writeReport("runtime_immutability.txt", mutationGuard.policySummary());
            reporter.writeReport("session_metadata.txt", metadata(runtime, session));

            ExecutionComponentInstaller.Report components = new ExecutionComponentInstaller().provision(context);
            reporter.writePreflight("execution_components.txt",
                    "Provisioning: " + components.message + "\n" +
                    "PRoot: " + components.proot.getAbsolutePath() + "\n" +
                    "Loader: " + components.loader.getAbsolutePath() + "\n" +
                    "hello-x86_64 source: " + components.helloX8664.getAbsolutePath() + "\n");
            mounts = new RuntimeMountManager().build(context, runtime, session, prefixLease, components.helloX8664);
            environment = new RuntimeEnvironmentBuilder().build(context, runtime, session, mounts.winePrefix);
            reporter.writePreflight("runtime_environment.txt", environment.format());
            reporter.writePreflight("runtime_mounts.txt", RuntimeMountManager.format(mounts.mounts));

            transition(ExecutionStage.VALIDATING, CleanupState.NOT_STARTED, true,
                    "فحص PRoot وBox64 وWine", "", -1, Integer.MIN_VALUE,
                    ExecutionErrorCode.NONE, false);
            RuntimeExecutionValidator.Report preflight =
                    new RuntimeExecutionValidator().validate(context, runtime, components);
            flags = ExecutionFeatureFlags.evaluate(context, runtime, preflight);
            reporter.writePreflight("execution_preflight.txt", preflight.format());
            writeFeatureReport(flags);
            if (!preflight.ready()) throw new RuntimeExecutionException(
                    ExecutionErrorCode.EXECUTION_COMPONENTS_INVALID,
                    ExecutionStage.VALIDATING, preflight.format());

            LinuxEnvironmentEngine engine = new ProotIsolationEngine(context);
            launcher = new RuntimeLauncher(engine);
            runner = new RuntimeProcessRunner();

            transition(ExecutionStage.STARTING_PROOT, CleanupState.NOT_STARTED, true,
                    "تشخيص PRoot", "proot --version", -1, Integer.MIN_VALUE,
                    ExecutionErrorCode.NONE, false);
            RuntimeExecutionResult prootVersion = runHostCommand(components.proot,
                    Arrays.asList("--version"), 15_000, runner, session, environment);
            reporter.writeDiagnostic("proot_diagnostic.txt", resultText("proot --version", prootVersion));
            requireSuccess(prootVersion, "", ExecutionErrorCode.PROOT_START_FAILED,
                    ExecutionStage.STARTING_PROOT);

            transition(ExecutionStage.ENTERING_ROOTFS, CleanupState.NOT_STARTED, true,
                    "اختبار الدخول إلى RootFS", "/bin/true", -1, Integer.MIN_VALUE,
                    ExecutionErrorCode.NONE, false);
            runGate(runtime, session, mounts, environment, launcher, runner,
                    new RuntimeCommand("/bin/true", Collections.emptyList(), 15_000, ""),
                    ExecutionErrorCode.ROOTFS_TRUE_FAILED);
            RuntimeExecutionResult echo = runGate(runtime, session, mounts, environment, launcher, runner,
                    new RuntimeCommand("/bin/echo", Collections.singletonList("LINUX_RUNTIME_OK"),
                            15_000, "LINUX_RUNTIME_OK"), ExecutionErrorCode.ROOTFS_ECHO_FAILED);
            RuntimeExecutionResult shell = runGate(runtime, session, mounts, environment, launcher, runner,
                    new RuntimeCommand("/bin/sh", Arrays.asList("-c", "echo LINUX_RUNTIME_OK"),
                            15_000, "LINUX_RUNTIME_OK"), ExecutionErrorCode.ROOTFS_SHELL_FAILED);
            reporter.writeDiagnostic("rootfs_smoke_test.txt",
                    resultText("/bin/echo", echo) + "\n" + resultText("/bin/sh", shell));
            flags.markEnabled(ExecutionFeature.PROOT, "PRoot + RootFS gates passed");
            writeFeatureReport(flags);

            transition(ExecutionStage.RUNNING_BOX64, CleanupState.NOT_STARTED, true,
                    "تشخيص Box64", runtime.box64GuestPath(), -1, Integer.MIN_VALUE,
                    ExecutionErrorCode.NONE, false);
            reporter.writeDiagnostic("box64_environment.txt",
                    new Box64EnvironmentBuilder().describe(true));
            Box64SmokeTest box64 = new Box64SmokeTest();
            RuntimeExecutionResult boxVersion = runGate(runtime, session, mounts, environment,
                    launcher, runner, box64.version(runtime), ExecutionErrorCode.BOX64_VERSION_FAILED);
            reporter.writeDiagnostic("box64_diagnostic.txt", resultText("box64 --version", boxVersion));
            RuntimeExecutionResult boxSmoke = runGate(runtime, session, mounts, environment,
                    launcher, runner, box64.hello(runtime), ExecutionErrorCode.BOX64_SMOKE_TEST_FAILED);
            reporter.writeDiagnostic("box64_smoke_test.txt", resultText("hello-x86_64", boxSmoke));
            flags.markEnabled(ExecutionFeature.BOX64, "BOX64_SMOKE_TEST_OK");
            writeFeatureReport(flags);

            transition(ExecutionStage.STARTING_WINE, CleanupState.NOT_STARTED, true,
                    "تهيئة Wine Prefix نظيف خارج RootFS", runtime.winebootGuestPath(),
                    -1, Integer.MIN_VALUE, ExecutionErrorCode.NONE, false);
            wineStageReached = true;
            prefixManager.markInitializing(runtime);
            wine = new WineManager();
            RuntimeExecutionResult wineVersion = runGate(runtime, session, mounts, environment,
                    launcher, runner, wine.version(runtime), ExecutionErrorCode.WINE_VERSION_FAILED);
            reporter.writeDiagnostic("wine_diagnostic.txt", resultText("wine64 --version", wineVersion));
            RuntimeExecutionResult wineboot = runGate(runtime, session, mounts, environment,
                    launcher, runner, wine.wineboot(runtime), ExecutionErrorCode.WINEBOOT_FAILED);
            reporter.writeDiagnostic("wine_prefix_report.txt", resultText("wineboot", wineboot) +
                    "\nPrefix host path: " + mounts.winePrefix.getAbsolutePath() +
                    "\nPrefix state file: " + prefixLease.stateFile.getAbsolutePath() + "\n");

            transition(ExecutionStage.RUNNING, CleanupState.NOT_STARTED, true,
                    "تشغيل Windows Console Smoke Test", "cmd.exe /c echo WINE_RUNTIME_OK",
                    -1, Integer.MIN_VALUE, ExecutionErrorCode.NONE, false);
            wineSmoke = runGate(runtime, session, mounts, environment, launcher, runner,
                    wine.consoleSmoke(runtime), ExecutionErrorCode.WINE_CONSOLE_SMOKE_FAILED);
            flags.markEnabled(ExecutionFeature.WINE, "WINE_RUNTIME_OK");
            writeFeatureReport(flags);
            outcome = Outcome.SUCCESS;
        } catch (Throwable error) {
            failure = error;
            outcome = classifyOutcome(error);
            if (flags != null) {
                ExecutionFeature failedFeature = snapshot.stage == ExecutionStage.RUNNING_BOX64
                        ? ExecutionFeature.BOX64
                        : (snapshot.stage == ExecutionStage.STARTING_WINE || snapshot.stage == ExecutionStage.RUNNING)
                        ? ExecutionFeature.WINE : ExecutionFeature.PROOT;
                flags.markFailed(failedFeature, error.getClass().getSimpleName() + ": " + message(error));
                try { writeFeatureReport(flags); } catch (Throwable ignored) {}
            }
            if (console != null) console.append("SYSTEM", "EXECUTION_FAILURE: " + error);
        } finally {
            boolean cleanupClean = false;
            String immutability = "Runtime guard not executed";
            Throwable cleanupFailure = null;
            Throwable mutationFailure = null;
            Throwable evidenceFailure = null;
            if (session != null) {
                safeTransitionToStopping();
                safeTransition(ExecutionStage.CLEANING_UP, CleanupState.IN_PROGRESS,
                        "تنظيف Wine وشجرة العمليات", "", supervisor.mainPid(),
                        wineSmoke == null ? Integer.MIN_VALUE : wineSmoke.exitCode,
                        ExecutionErrorCode.NONE, false);

                try {
                    // Use a fresh cancellation token so cleanup is not suppressed by user cancellation.
                    if (wineStageReached && runtime != null && wine != null && mounts != null &&
                            environment != null && launcher != null && runner != null) {
                        runOptionalCleanup(runtime, session, mounts, environment, launcher, runner,
                                wine.waitServer(runtime), "wineserver -w");
                        runOptionalCleanup(runtime, session, mounts, environment, launcher, runner,
                                wine.killServer(runtime), "wineserver -k");
                    }
                    prefixManager.cleanTransientLocks();
                    RuntimeProcessSupervisor.CleanupResult cleanup = supervisor.stopGracefully(1500, console);
                    cleanupClean = cleanup.clean;
                    if (!cleanup.clean) throw new RuntimeExecutionException(
                            ExecutionErrorCode.ORPHAN_PROCESSES_REMAIN, ExecutionStage.CLEANING_UP,
                            "بقيت عمليات تابعة بعد التنظيف: " + cleanup.survivors, false);
                } catch (Throwable error) {
                    cleanupFailure = error;
                    cleanupClean = false;
                    if (console != null) console.append("SYSTEM", "PROCESS_CLEANUP_FAILURE: " + error);
                }

                // Evidence failures do not pretend processes survived. They fail the release gate separately.
                try { reporter.writeProcessTree(supervisor.mainPid(), supervisor.records()); }
                catch (Throwable error) {
                    evidenceFailure = error;
                    if (console != null) console.append("SYSTEM", "PROCESS_TREE_REPORT_FAILURE: " + error);
                }

                if (runtime != null && mutationCaptured) {
                    try { immutability = mutationGuard.verify(runtime); }
                    catch (Throwable error) {
                        mutationFailure = error;
                        immutability = "Runtime mutation verification failed: " + message(error);
                        if (console != null) console.append("SYSTEM", "ROOTFS_GUARD_FAILURE: " + error);
                    }
                } else {
                    immutability = "Runtime mutation guard was not captured before failure; no guest gate was trusted";
                }

                ExecutionStage finalStage;
                ExecutionErrorCode finalCode;
                String finalMessage;
                if (!cleanupClean) {
                    finalStage = ExecutionStage.RECOVERY_REQUIRED;
                    finalCode = cleanupFailure instanceof RuntimeExecutionException
                            ? ((RuntimeExecutionException) cleanupFailure).typedCode
                            : ExecutionErrorCode.PROCESS_CLEANUP_FAILED;
                    finalMessage = "فشل تنظيف شجرة العمليات وتحتاج الجلسة إلى استرداد";
                    if (runtime != null) prefixManager.markCorrupted(runtime, message(cleanupFailure));
                } else if (mutationFailure != null) {
                    finalStage = ExecutionStage.FAILED;
                    finalCode = mutationFailure instanceof RuntimeExecutionException
                            ? ((RuntimeExecutionException) mutationFailure).typedCode
                            : ExecutionErrorCode.RUNTIME_MUTATED;
                    finalMessage = "نُظفت العمليات لكن فشل إثبات ثبات RootFS";
                    if (runtime != null) prefixManager.markCorrupted(runtime, message(mutationFailure));
                } else if (outcome == Outcome.SUCCESS && wineSmoke != null && wineSmoke.success("WINE_RUNTIME_OK")) {
                    finalStage = ExecutionStage.COMPLETED;
                    finalCode = ExecutionErrorCode.NONE;
                    finalMessage = "WINE_RUNTIME_OK — اكتملت جميع البوابات دون عمليات يتيمة";
                    try { prefixManager.markReady(runtime); } catch (Throwable error) {
                        finalStage = ExecutionStage.FAILED;
                        finalCode = ExecutionErrorCode.WINE_PREFIX_INITIALIZATION_FAILED;
                        finalMessage = "نجح Wine لكن تعذر تثبيت حالة Prefix";
                        failure = error;
                    }
                } else if (outcome == Outcome.STOPPED) {
                    finalStage = ExecutionStage.CANCELLED;
                    finalCode = ExecutionErrorCode.PROCESS_STOPPED;
                    finalMessage = "أُوقفت الجلسة بطلب المستخدم ونُظفت عملياتها";
                    if (runtime != null) prefixManager.markCorrupted(runtime, "Session stopped by user");
                } else if (outcome == Outcome.CANCELLED) {
                    finalStage = ExecutionStage.CANCELLED;
                    finalCode = ExecutionErrorCode.PROCESS_CANCELLED;
                    finalMessage = "أُلغيت الجلسة ونُظفت عملياتها";
                    if (runtime != null) prefixManager.markCorrupted(runtime, "Session cancelled");
                } else if (outcome == Outcome.TIMED_OUT) {
                    finalStage = ExecutionStage.TIMED_OUT;
                    finalCode = ExecutionErrorCode.PROCESS_TIMEOUT;
                    finalMessage = "انتهت مهلة التنفيذ ونُظفت عمليات الجلسة";
                    if (runtime != null) prefixManager.markCorrupted(runtime, "Session timed out");
                } else {
                    finalStage = ExecutionStage.FAILED;
                    finalCode = failure instanceof RuntimeExecutionException
                            ? ((RuntimeExecutionException) failure).typedCode
                            : ExecutionErrorCode.INTERNAL_ERROR;
                    finalMessage = failure == null ? "فشل التنفيذ" : message(failure);
                    if (runtime != null) prefixManager.markCorrupted(runtime, finalMessage);
                }

                if (evidenceFailure != null) {
                    if (finalStage == ExecutionStage.COMPLETED) {
                        finalStage = ExecutionStage.FAILED;
                        finalCode = ExecutionErrorCode.REPORT_WRITE_FAILED;
                        finalMessage = "نجحت البوابات لكن فشل دليل شجرة العمليات";
                        if (runtime != null) prefixManager.markCorrupted(runtime, finalMessage);
                    } else {
                        finalMessage += " | تعذر حفظ جزء من أدلة العملية";
                    }
                }

                Throwable finalizationFailure = cleanupFailure != null ? cleanupFailure
                        : mutationFailure != null ? mutationFailure : evidenceFailure;
                try {
                    reporter.writeText("runtime_session_report.txt", summary(
                            runtime, session, finalStage, finalCode, finalMessage,
                            wineSmoke, cleanupClean, immutability, started, failure, finalizationFailure));
                } catch (Throwable reportError) {
                    if (finalStage == ExecutionStage.COMPLETED) {
                        finalStage = ExecutionStage.FAILED;
                        finalCode = ExecutionErrorCode.REPORT_WRITE_FAILED;
                        finalMessage = "نجحت البوابات لكن فشل التقرير النهائي";
                        if (runtime != null) prefixManager.markCorrupted(runtime, finalMessage);
                    }
                }
                try {
                    transition(finalStage, cleanupClean ? CleanupState.COMPLETED : CleanupState.FAILED,
                            false, finalMessage, "", -1,
                            wineSmoke == null ? Integer.MIN_VALUE : wineSmoke.exitCode,
                            finalCode, cleanupClean);
                } catch (Throwable finalStateError) {
                    if (finalStage == ExecutionStage.COMPLETED && runtime != null) {
                        prefixManager.markCorrupted(runtime, "Final state persistence failed");
                    }
                    finalStage = ExecutionStage.FAILED;
                    finalCode = ExecutionErrorCode.REPORT_WRITE_FAILED;
                    finalMessage = "تعذر تثبيت الحالة النهائية للجلسة";
                    publishDirect(finalStage,
                            cleanupClean ? CleanupState.COMPLETED : CleanupState.FAILED,
                            false, finalMessage, "", -1,
                            wineSmoke == null ? Integer.MIN_VALUE : wineSmoke.exitCode,
                            finalCode, cleanupClean, snapshot.lastStdout, snapshot.lastStderr);
                    try { if (stateStore != null) stateStore.save(snapshot); } catch (Throwable ignored) {}
                    try {
                        reporter.writeText("runtime_session_report.txt", summary(
                                runtime, session, finalStage, finalCode, finalMessage,
                                wineSmoke, cleanupClean, immutability, started, failure, finalStateError));
                    } catch (Throwable ignored) {}
                }
            } else {
                ExecutionErrorCode code = failure instanceof RuntimeExecutionException
                        ? ((RuntimeExecutionException) failure).typedCode
                        : ExecutionErrorCode.NO_VERIFIED_RUNTIME;
                publishWithoutSession((outcome == Outcome.CANCELLED || outcome == Outcome.STOPPED)
                                ? ExecutionStage.CANCELLED
                                : outcome == Outcome.TIMED_OUT ? ExecutionStage.TIMED_OUT : ExecutionStage.FAILED,
                        failure == null ? "تعذر إنشاء جلسة التنفيذ" : message(failure), code);
            }

            try { prefixManager.close(); } catch (Throwable ignored) {}
            try {
                if (console != null) {
                    console.append("SYSTEM", "Session finished: " + snapshot.stage);
                    console.close();
                }
            } catch (Throwable ignored) {}
            supervisor.clear();
            sessions.release();
            running.set(false);
            notifyListeners();
            Intent stop = new Intent(context, RuntimeExecutionService.class)
                    .setAction(RuntimeExecutionService.ACTION_FINISH);
            try { context.startService(stop); } catch (Throwable ignored) {}
        }
    }

    private RuntimeExecutionResult runGate(VerifiedInstalledRuntime runtime, RuntimeSession session,
                                           RuntimeMountManager.MountPlan mounts, RuntimeEnvironment environment,
                                           RuntimeLauncher launcher, RuntimeProcessRunner runner,
                                           RuntimeCommand command, ExecutionErrorCode code) throws Exception {
        cancellation.throwIfCancelled(snapshot.stage);
        heartbeat(snapshot.message, command.display(), -1, Integer.MIN_VALUE, ExecutionErrorCode.NONE.name());
        RuntimeLaunchPlan plan = launcher.plan(runtime, session, mounts, environment, command);
        RuntimeExecutionResult result = runner.run(plan, console, cancellation, observer(command));
        supervisor.refreshTree();
        reporter.writeProcessTree(supervisor.mainPid(), supervisor.records());
        heartbeat(snapshot.message, command.display(), result.pid, result.exitCode, ExecutionErrorCode.NONE.name(),
                result.stdoutTail, result.stderrTail);
        requireSuccess(result, command.expectedOutput, code, snapshot.stage);
        return result;
    }

    private RuntimeExecutionResult runHostCommand(File executable, List<String> arguments, long timeout,
                                                  RuntimeProcessRunner runner, RuntimeSession session,
                                                  RuntimeEnvironment environment) throws Exception {
        cancellation.throwIfCancelled(snapshot.stage);
        java.util.ArrayList<String> argv = new java.util.ArrayList<>();
        argv.add(executable.getAbsolutePath()); argv.addAll(arguments);
        RuntimeLaunchPlan plan = new RuntimeLaunchPlan(executable.getName(), argv, session.directory,
                environment, timeout, "");
        RuntimeExecutionResult result = runner.run(plan, console, cancellation, observer(
                new RuntimeCommand(executable.getAbsolutePath(), arguments, timeout, "")));
        reporter.writeProcessTree(supervisor.mainPid(), supervisor.records());
        heartbeat(snapshot.message, String.join(" ", argv), result.pid, result.exitCode,
                ExecutionErrorCode.NONE.name(), result.stdoutTail, result.stderrTail);
        return result;
    }

    private RuntimeProcessRunner.Observer observer(RuntimeCommand command) {
        return new RuntimeProcessRunner.Observer() {
            private long lastTreeReport;
            private long lastHeartbeat;
            @Override public void onStarted(Process process, long pid) {
                supervisor.attach(process, pid);
                heartbeat(snapshot.message, command.display(), pid, Integer.MIN_VALUE,
                        ExecutionErrorCode.NONE.name());
            }
            @Override public void onPoll() {
                supervisor.poll();
                long now = android.os.SystemClock.elapsedRealtime();
                if (now - lastTreeReport >= 500) {
                    lastTreeReport = now;
                    try { reporter.writeProcessTree(supervisor.mainPid(), supervisor.records()); }
                    catch (Throwable ignored) {}
                }
                if (now - lastHeartbeat >= 1000) {
                    lastHeartbeat = now;
                    heartbeat(snapshot.message, command.display(), supervisor.mainPid(),
                            Integer.MIN_VALUE, ExecutionErrorCode.NONE.name());
                }
            }
            @Override public void onFinished(Process process, RuntimeExecutionResult result) {
                supervisor.processFinished(process);
            }
        };
    }

    private void runOptionalCleanup(VerifiedInstalledRuntime runtime, RuntimeSession session,
                                    RuntimeMountManager.MountPlan mounts, RuntimeEnvironment environment,
                                    RuntimeLauncher launcher, RuntimeProcessRunner runner,
                                    RuntimeCommand command, String label) {
        try {
            RuntimeLaunchPlan plan = launcher.plan(runtime, session, mounts, environment, command);
            RuntimeExecutionResult result = runner.run(plan, console, new ExecutionCancellationToken(), observer(command));
            if (console != null) console.append("SYSTEM", label + " exit=" + result.exitCode);
        } catch (Throwable error) {
            if (console != null) console.append("SYSTEM", label + " cleanup warning: " + error);
        }
    }

    private static void requireSuccess(RuntimeExecutionResult result, String expected,
                                       ExecutionErrorCode code, ExecutionStage stage)
            throws RuntimeExecutionException {
        if (result.cancelled) throw new RuntimeExecutionException(
                ExecutionErrorCode.PROCESS_CANCELLED, stage, "تم إلغاء الأمر");
        if (result.timedOut) throw new RuntimeExecutionException(
                ExecutionErrorCode.PROCESS_TIMEOUT, stage, "انتهت مهلة الأمر: " + code.name());
        if (!result.success(expected)) throw new RuntimeExecutionException(code, stage,
                "Exit=" + result.exitCode + "\nstdout=" + result.stdoutTail + "\nstderr=" + result.stderrTail);
    }

    private Outcome classifyOutcome(Throwable error) {
        if (cancellation != null && cancellation.request() == ExecutionCancellationToken.Request.STOP)
            return Outcome.STOPPED;
        if (cancellation != null && cancellation.isCancelled()) return Outcome.CANCELLED;
        if (error instanceof RuntimeExecutionException &&
                ((RuntimeExecutionException) error).typedCode == ExecutionErrorCode.PROCESS_TIMEOUT) {
            return Outcome.TIMED_OUT;
        }
        return Outcome.FAILED;
    }

    private void safeTransitionToStopping() {
        ExecutionStage current = stateMachine.current();
        if (current.terminal() || current == ExecutionStage.CLEANING_UP || current == ExecutionStage.STOPPING) return;
        safeTransition(ExecutionStage.STOPPING, CleanupState.NOT_STARTED, true,
                "إيقاف الجلسة قبل التنظيف", snapshot.command, supervisor.mainPid(),
                snapshot.exitCode, ExecutionErrorCode.NONE, false);
    }

    private void transition(ExecutionStage stage, CleanupState cleanup, boolean runningNow,
                            String message, String command, long pid, int exit,
                            ExecutionErrorCode errorCode, boolean noOrphans)
            throws RuntimeExecutionException {
        stateMachine.transition(stage);
        publish(stage, cleanup, runningNow, message, command, pid, exit, errorCode, noOrphans);
    }

    private void safeTransition(ExecutionStage stage, CleanupState cleanup, String message,
                                String command, long pid, int exit,
                                ExecutionErrorCode errorCode, boolean noOrphans) {
        safeTransition(stage, cleanup, !stage.terminal(), message, command, pid, exit, errorCode, noOrphans);
    }

    private void safeTransition(ExecutionStage stage, CleanupState cleanup, boolean runningNow,
                                String message, String command, long pid, int exit,
                                ExecutionErrorCode errorCode, boolean noOrphans) {
        try { transition(stage, cleanup, runningNow, message, command, pid, exit, errorCode, noOrphans); }
        catch (Throwable error) {
            // Never leave UI stale solely because a report/state transition failed.
            publishDirect(stage, cleanup, runningNow, message + " [state warning: " + error + "]",
                    command, pid, exit, errorCode, noOrphans, snapshot.lastStdout, snapshot.lastStderr);
        }
    }

    private void publish(ExecutionStage stage, CleanupState cleanup, boolean runningNow,
                         String message, String command, long pid, int exit,
                         ExecutionErrorCode errorCode, boolean noOrphans)
            throws RuntimeExecutionException {
        publishDirect(stage, cleanup, runningNow, message, command, pid, exit, errorCode,
                noOrphans, snapshot.lastStdout, snapshot.lastStderr);
        RuntimeExecutionStateStore store = stateStore;
        if (store != null) store.save(snapshot);
    }

    private void heartbeat(String message, String command, long pid, int exit, String errorCode) {
        heartbeat(message, command, pid, exit, errorCode, snapshot.lastStdout, snapshot.lastStderr);
    }

    private void heartbeat(String message, String command, long pid, int exit, String errorCode,
                           String stdout, String stderr) {
        RuntimeExecutionSnapshot previous = snapshot;
        publishDirect(previous.stage, previous.cleanupState, previous.running,
                message, command, pid, exit, ExecutionErrorCode.from(errorCode), previous.noOrphans,
                stdout, stderr);
        try { if (stateStore != null) stateStore.save(snapshot); } catch (Throwable ignored) {}
    }

    private void publishDirect(ExecutionStage stage, CleanupState cleanup, boolean runningNow,
                               String message, String command, long pid, int exit,
                               ExecutionErrorCode errorCode, boolean noOrphans,
                               String stdout, String stderr) {
        synchronized (snapshotLock) {
            RuntimeExecutionSnapshot previous = snapshot;
            RuntimeSession active = sessions.active();
            String sessionId = active == null ? previous.sessionId : active.id;
            String runtimeId = active == null ? previous.runtimeId : active.runtimeId;
            long start = previous.startedAt > 0 ? previous.startedAt : System.currentTimeMillis();
            List<Long> children;
            try { children = supervisor.refreshTree(); } catch (Throwable ignored) { children = previous.childPids; }
            snapshot = new RuntimeExecutionSnapshot(sessionId, runtimeId, stage, cleanup, runningNow,
                    message, command, pid, children, exit, start, System.currentTimeMillis(),
                    stdout, stderr, errorCode == null ? "" : errorCode.name(), noOrphans);
        }
        notifyListeners();
    }

    private void publishWithoutSession(ExecutionStage stage, String message, ExecutionErrorCode code) {
        synchronized (snapshotLock) {
            snapshot = new RuntimeExecutionSnapshot("", "", stage, CleanupState.NOT_STARTED,
                    false, message, "", -1, Collections.emptyList(), Integer.MIN_VALUE,
                    System.currentTimeMillis(), System.currentTimeMillis(), "", "", code.name(), true);
        }
        RuntimeExecutionReporter.writeLatestText(context, "runtime_session_report.txt",
                "Result: FAILED\nCode: " + code + "\nError: " + message + "\n");
        notifyListeners();
    }

    private void writeFeatureReport(ExecutionFeatureFlags flags) throws RuntimeExecutionException {
        reporter.writeReport("feature_flags.txt",
                flags.format() + "\n" + new BackendCapabilityRegistry().format());
    }

    private void notifyListeners() {
        for (Listener listener : listeners) {
            try { listener.onExecutionSnapshot(snapshot); } catch (Throwable ignored) {}
        }
    }

    private static String metadata(VerifiedInstalledRuntime runtime, RuntimeSession session) {
        return "Schema version: 2\n" +
                "App version: " + BuildConfig.VERSION_NAME + "\n" +
                "Build variant: " + BuildConfig.EXECUTION_BUILD_VARIANT + "\n" +
                "Runtime ID: " + runtime.runtimeId() + "\n" +
                "Runtime version: " + runtime.version() + "\n" +
                "Runtime schema: " + runtime.schema() + "\n" +
                "Payload SHA-256: " + runtime.payloadSha256() + "\n" +
                "Manifest SHA-256: " + runtime.manifestSha256() + "\n" +
                "Verified at: " + runtime.verifiedAt() + "\n" +
                "Session ID: " + session.id + "\n" +
                "Android SDK: " + android.os.Build.VERSION.SDK_INT + "\n" +
                "Device ABIs: " + Arrays.toString(android.os.Build.SUPPORTED_ABIS) + "\n";
    }

    private static String summary(VerifiedInstalledRuntime runtime, RuntimeSession session,
                                  ExecutionStage finalStage, ExecutionErrorCode code,
                                  String message, RuntimeExecutionResult wineSmoke,
                                  boolean noOrphans, String immutability, long started,
                                  Throwable failure, Throwable finalizationFailure) {
        StringBuilder out = new StringBuilder();
        out.append("GTAV Runtime Manager v1.7.0 — Execution Foundation Experiment 4\n");
        out.append("Schema version: 2\n");
        out.append("Session ID: ").append(session.id).append('\n');
        out.append("Runtime ID: ").append(runtime == null ? "" : runtime.runtimeId()).append('\n');
        String resultLabel = finalStage == ExecutionStage.COMPLETED ? "SUCCESS"
                : finalStage == ExecutionStage.CANCELLED ? "CANCELLED"
                : finalStage == ExecutionStage.TIMED_OUT ? "TIMED_OUT"
                : finalStage == ExecutionStage.RECOVERY_REQUIRED ? "RECOVERY_REQUIRED" : "FAILED";
        out.append("Result: ").append(resultLabel).append('\n');
        boolean wineOk = wineSmoke != null && wineSmoke.success("WINE_RUNTIME_OK");
        out.append("WINE_RUNTIME_OK: ").append(wineOk).append('\n');
        if (wineOk) out.append("WINE_RUNTIME_OK\n");
        out.append("Exit Code: ").append(wineSmoke == null ? "N/A" : wineSmoke.exitCode).append('\n');
        out.append("Session state: ").append(finalStage.name()).append('\n');
        out.append("No orphan processes: ").append(noOrphans).append('\n');
        out.append("Error code: ").append(code.name()).append('\n');
        out.append("Message: ").append(message).append('\n');
        out.append(immutability).append('\n');
        out.append("Duration ms: ").append(System.currentTimeMillis() - started).append('\n');
        if (failure != null) out.append("Execution failure:\n").append(stack(failure)).append('\n');
        if (finalizationFailure != null) out.append("Finalization failure:\n").append(stack(finalizationFailure)).append('\n');
        return out.toString();
    }

    private static String resultText(String name, RuntimeExecutionResult result) {
        return "Command: " + name + "\nPID: " + result.pid + "\nExit Code: " + result.exitCode +
                "\nTimed out: " + result.timedOut + "\nCancelled: " + result.cancelled +
                "\nDuration ms: " + (result.finishedAt - result.startedAt) +
                "\n\nstdout\n------\n" + result.stdoutTail +
                "\n\nstderr\n------\n" + result.stderrTail + "\n";
    }

    private static String message(Throwable error) {
        return error == null ? "" : error.getMessage() == null ? error.toString() : error.getMessage();
    }

    private static String stack(Throwable error) {
        if (error == null) return "";
        java.io.StringWriter out = new java.io.StringWriter();
        error.printStackTrace(new java.io.PrintWriter(out));
        return out.toString();
    }
}
