package com.gtav.runtimemanager;

import android.content.Context;
import android.os.Build;
import android.os.Environment;
import android.system.Os;

import androidx.documentfile.provider.DocumentFile;

import com.gtav.runtimemanager.compression.zstd.ZstdHealthResult;

import org.apache.commons.compress.archivers.tar.TarArchiveInputStream;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

final class RuntimePlatformValidator {
    static final class Check {
        final String code;
        final boolean ok;
        final boolean blocking;
        final String details;

        Check(String code, boolean ok, boolean blocking, String details) {
            this.code = code;
            this.ok = ok;
            this.blocking = blocking;
            this.details = details == null ? "" : details;
        }
    }

    static final class Report {
        final List<Check> checks;
        final NativeLibraryManager.Report nativeLibraries;
        final ZstdHealthResult roundTrip;
        final ZstdHealthResult streaming;

        Report(List<Check> checks, NativeLibraryManager.Report nativeLibraries,
               ZstdHealthResult roundTrip, ZstdHealthResult streaming) {
            this.checks = checks;
            this.nativeLibraries = nativeLibraries;
            this.roundTrip = roundTrip;
            this.streaming = streaming;
        }

        boolean ready() {
            for (Check check : checks) if (check.blocking && !check.ok) return false;
            return true;
        }

        String format() {
            StringBuilder out = new StringBuilder("Runtime Platform Readiness\n==========================\n");
            for (Check check : checks) {
                out.append(check.ok ? "✅ " : check.blocking ? "❌ " : "⚠️ ")
                        .append(check.code).append(": ").append(check.details).append('\n');
            }
            out.append("Ready: ").append(ready()).append('\n');
            if (nativeLibraries != null) out.append('\n').append(nativeLibraries.format());
            return out.toString();
        }
    }

    Report validatePlatformOnly(Context context) {
        return new Report(baseChecks(context.getApplicationContext()), null, null, null);
    }

    Report validateQuick(Context context, CompressionManager compression,
                         NativeLibraryManager nativeManager) {
        Context app = context.getApplicationContext();
        List<Check> checks = baseChecks(app);
        NativeLibraryManager.Report packagingReport = nativeManager.inspect(app, "not attempted");
        checks.add(new Check("ZSTD_ABI", packagingReport.abiCompatible, true,
                packagingReport.summary()));
        checks.add(new Check("ZSTD_PACKAGED", packagingReport.hasZstd(), true,
                packagingReport.hasZstd()
                        ? packagingReport.primaryZstd().getAbsolutePath()
                        : packagingReport.nativeLibraryDir));

        ZstdHealthResult roundTrip = compression.roundTrip();
        checks.add(new Check(roundTrip.ok ? "ZSTD_ROUND_TRIP" : roundTrip.code,
                roundTrip.ok, true, roundTrip.details));
        ZstdHealthResult streaming = compression.streaming();
        checks.add(new Check(streaming.ok ? "ZSTD_STREAMING" : streaming.code,
                streaming.ok, true, streaming.details));

        String loadMessage = "roundTrip=" + (roundTrip.ok ? "PASS" : roundTrip.code) +
                ", streaming=" + (streaming.ok ? "PASS" : streaming.code);
        NativeLibraryManager.Report nativeReport = nativeManager.inspect(app, loadMessage);
        return new Report(checks, nativeReport, roundTrip, streaming);
    }

    /**
     * android.os.SELinux is not part of the public Android SDK stubs on all
     * toolchains. Use reflection when available, then fall back to the kernel
     * enforcement flag. SELinux is diagnostic-only, so failure is non-blocking.
     */
    private String readSelinuxStatus() {
        try {
            Class<?> selinuxClass = Class.forName("android.os.SELinux");
            boolean enabled = (Boolean) selinuxClass
                    .getMethod("isSELinuxEnabled")
                    .invoke(null);
            boolean enforced = (Boolean) selinuxClass
                    .getMethod("isSELinuxEnforced")
                    .invoke(null);
            return "enabled=" + enabled + ", enforced=" + enforced + ", source=reflection";
        } catch (Throwable reflectionError) {
            File enforceFile = new File("/sys/fs/selinux/enforce");
            if (!enforceFile.isFile()) {
                return "status unavailable; source=kernel-file-missing";
            }

            try (java.io.FileInputStream input =
                         new java.io.FileInputStream(enforceFile)) {
                int value = input.read();
                if (value == '1') {
                    return "enabled=true, enforced=true, source=/sys/fs/selinux/enforce";
                }
                if (value == '0') {
                    return "enabled=true, enforced=false, source=/sys/fs/selinux/enforce";
                }
                return "enabled=true, enforced=unknown, source=/sys/fs/selinux/enforce";
            } catch (Throwable fileError) {
                return "status unavailable; reflection="
                        + reflectionError.getClass().getSimpleName()
                        + ", file=" + fileError.getClass().getSimpleName();
            }
        }
    }

    private List<Check> baseChecks(Context app) {
        List<Check> checks = new ArrayList<>();
        checks.add(new Check("ANDROID_API", Build.VERSION.SDK_INT >= 26, true,
                Build.VERSION.RELEASE + " / API " + Build.VERSION.SDK_INT));
        boolean arm64 = Arrays.asList(Build.SUPPORTED_ABIS).contains(BuildConfig.REQUESTED_ABI);
        checks.add(new Check("ABI", arm64, true, Arrays.toString(Build.SUPPORTED_ABIS)));
        checks.add(new Check("JNI_RUNTIME", true, true,
                System.getProperty("java.vm.name", "Android Runtime")));
        checks.add(new Check("SELINUX", true, false, readSelinuxStatus()));
        checks.add(new Check("CONTENT_RESOLVER", app.getContentResolver() != null, true,
                app.getContentResolver() == null ? "missing" : app.getContentResolver().getClass().getName()));
        checks.add(new Check("DOCUMENT_FILE", DocumentFile.class != null, true,
                DocumentFile.class.getName()));
        boolean storageMounted = Environment.MEDIA_MOUNTED.equals(Environment.getExternalStorageState());
        checks.add(new Check("STORAGE_STATE", storageMounted || app.getFilesDir().canWrite(), true,
                "external=" + Environment.getExternalStorageState() + ", internal=" + app.getFilesDir()));

        File probeRoot = new File(app.getCacheDir(), ".platform-probe-" + System.nanoTime());
        try {
            if (!probeRoot.mkdir()) throw new IllegalStateException("mkdir failed");
            File target = new File(probeRoot, "target");
            try (FileOutputStream output = new FileOutputStream(target)) {
                output.write("platform-v1.6".getBytes(StandardCharsets.UTF_8));
                output.getFD().sync();
            }
            checks.add(new Check("TMP_WRITE_FSYNC", target.isFile(), true, target.getAbsolutePath()));

            new PermissionApplier(new PermissionApplier.AndroidOps())
                    .apply(target, 0700, InstallStage.PREFLIGHT_PLATFORM);
            checks.add(new Check("CHMOD", target.canExecute(), true, "0700 applied"));

            File link = new File(probeRoot, "link");
            Os.symlink(target.getName(), link.getAbsolutePath());
            String readLink = Os.readlink(link.getAbsolutePath());
            checks.add(new Check("SYMLINK", target.getName().equals(readLink), true, readLink));

            File renameFrom = new File(probeRoot, "rename-from");
            File renameTo = new File(probeRoot, "rename-to");
            boolean rename = renameFrom.mkdir() && renameFrom.renameTo(renameTo);
            checks.add(new Check("ATOMIC_RENAME", rename, true, probeRoot.getAbsolutePath()));
            checks.add(new Check("FILESYSTEM_SPACE", probeRoot.getUsableSpace() > 0, true,
                    "usable=" + Formatters.bytes(probeRoot.getUsableSpace())));
        } catch (RuntimeInstallException error) {
            checks.add(new Check(error.code.name(), false, true, error.getMessage()));
        } catch (Throwable error) {
            checks.add(new Check("FILESYSTEM", false, true,
                    error.getClass().getSimpleName() + ": " + error.getMessage()));
        } finally {
            FileTools.deleteTreeQuietly(app.getCacheDir(), probeRoot, null);
        }

        try (TarArchiveInputStream ignored = new TarArchiveInputStream(
                new ByteArrayInputStream(new byte[1024]))) {
            checks.add(new Check("TAR_ENGINE", true, true, "Apache Commons TAR initialized"));
        } catch (Throwable error) {
            checks.add(new Check("TAR_ENGINE", false, true, error.toString()));
        }
        return checks;
    }
}
