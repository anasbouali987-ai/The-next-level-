package com.gtav.runtimemanager;

import java.util.concurrent.atomic.AtomicBoolean;

final class CancellationToken {
    private final AtomicBoolean cancelled = new AtomicBoolean(false);

    void cancel() { cancelled.set(true); }
    boolean isCancelled() { return cancelled.get(); }

    void throwIfCancelled(InstallStage stage) throws RuntimeInstallException {
        if (cancelled.get()) {
            throw new RuntimeInstallException(
                    InstallErrorCode.CANCELLED,
                    stage,
                    "تم إلغاء التثبيت بأمان"
            );
        }
    }
}
