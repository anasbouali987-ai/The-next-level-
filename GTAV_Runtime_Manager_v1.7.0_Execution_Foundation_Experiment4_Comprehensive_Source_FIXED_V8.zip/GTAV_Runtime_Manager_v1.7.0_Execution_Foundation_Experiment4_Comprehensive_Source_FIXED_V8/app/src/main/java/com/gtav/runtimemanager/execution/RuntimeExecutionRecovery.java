package com.gtav.runtimemanager.execution;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

/** Cleans stale PRoot/Box64/Wine processes for every interrupted session, never just "latest". */
public final class RuntimeExecutionRecovery {
    private RuntimeExecutionRecovery() {}

    public static void recover(Context context) {
        File[] directories = ExecutionPaths.sessions(context).listFiles(File::isDirectory);
        if (directories == null) return;
        Arrays.sort(directories, Comparator.comparingLong(File::lastModified));
        for (File directory : directories) {
            if (!directory.getName().startsWith("exec-")) continue;
            try { recoverSession(context, directory); }
            catch (Throwable error) {
                RuntimeExecutionReporter.writeLatestText(context, "recovery_report.txt",
                        "Recovery failed for " + directory.getName() + ": " + error + "\n");
            }
        }
    }

    private static void recoverSession(Context context, File directory) throws Exception {
        File stateFile = new File(directory, "execution_state.json");
        if (!stateFile.isFile()) return;
        RuntimeExecutionSnapshot previous = RuntimeExecutionSnapshot.fromJson(new JSONObject(read(stateFile)));
        if (previous.stage.terminal() && previous.cleanupState == CleanupState.COMPLETED && previous.noOrphans) return;
        if (liveOwnerExists(new File(directory, "session.lock.json"))) return;

        List<RuntimeProcessSupervisor.ProcessRecord> records = readProcessRecords(
                new File(directory, "process_tree.json"));
        RuntimeProcessSupervisor.CleanupResult cleanup = RuntimeProcessSupervisor.killSavedTree(records);
        RuntimeSession session = new RuntimeSession(directory.getName(),
                previous.runtimeId.isEmpty() ? "unknown-runtime" : previous.runtimeId, directory);
        RuntimeExecutionReporter reporter = new RuntimeExecutionReporter(context, session);
        String report = "Recovered interrupted execution session\n" +
                "Previous stage: " + previous.stage + "\n" +
                "Tracked process identities: " + records.size() + "\n" +
                "Survivors: " + cleanup.survivors + "\n" +
                "Result: " + (cleanup.clean ? "RECOVERED" : "RECOVERY_REQUIRED") + "\n";
        reporter.writeText("recovery_report.txt", report);

        ExecutionStage stage = cleanup.clean ? ExecutionStage.FAILED : ExecutionStage.RECOVERY_REQUIRED;
        CleanupState cleanupState = cleanup.clean ? CleanupState.COMPLETED : CleanupState.FAILED;
        RuntimeExecutionSnapshot recovered = new RuntimeExecutionSnapshot(
                previous.sessionId, previous.runtimeId, stage, cleanupState, false,
                cleanup.clean ? "تم تنظيف جلسة متقطعة بعد إعادة تشغيل التطبيق" : "بقيت عمليات بعد الاسترداد",
                previous.command, -1, new ArrayList<>(), previous.exitCode,
                previous.startedAt, System.currentTimeMillis(), previous.lastStdout,
                previous.lastStderr,
                cleanup.clean ? ExecutionErrorCode.INTERRUPTED_SESSION_RECOVERED.name() :
                        ExecutionErrorCode.RECOVERY_FAILED.name(), cleanup.clean);
        reporter.writeSnapshot(recovered);
        reporter.writeProcessTree(previous.pid, records);
        File lock = session.lockFile;
        if (cleanup.clean && lock.exists()) lock.delete();
    }

    private static boolean liveOwnerExists(File lockFile) {
        if (!lockFile.isFile()) return false;
        try {
            JSONObject lock = new JSONObject(read(lockFile));
            long pid = lock.optLong("owner_pid", -1);
            long ticks = lock.optLong("owner_start_ticks", -1);
            return RuntimeProcessSupervisor.isSameProcess(pid, ticks);
        } catch (Throwable ignored) { return false; }
    }

    private static List<RuntimeProcessSupervisor.ProcessRecord> readProcessRecords(File tree) {
        ArrayList<RuntimeProcessSupervisor.ProcessRecord> records = new ArrayList<>();
        if (!tree.isFile()) return records;
        try {
            JSONObject json = new JSONObject(read(tree));
            JSONArray array = json.optJSONArray("processes");
            if (array == null) return records;
            for (int i = 0; i < array.length(); i++) {
                JSONObject item = array.optJSONObject(i);
                if (item == null) continue;
                long pid = item.optLong("pid", -1);
                long start = item.optLong("start_ticks", -1);
                long parent = item.optLong("parent_pid", -1);
                String command = item.optString("command", "");
                if (pid > 1 && start > 0) records.add(
                        new RuntimeProcessSupervisor.ProcessRecord(pid, parent, start, command));
            }
        } catch (Throwable ignored) {}
        return records;
    }

    private static String read(File file) throws Exception {
        if (file.length() > 2 * 1024 * 1024) throw new IllegalStateException("Recovery file too large");
        byte[] bytes = new byte[(int) file.length()];
        try (FileInputStream input = new FileInputStream(file)) {
            int off = 0, read;
            while (off < bytes.length && (read = input.read(bytes, off, bytes.length - off)) > 0) off += read;
            return new String(bytes, 0, off, StandardCharsets.UTF_8);
        }
    }
}
