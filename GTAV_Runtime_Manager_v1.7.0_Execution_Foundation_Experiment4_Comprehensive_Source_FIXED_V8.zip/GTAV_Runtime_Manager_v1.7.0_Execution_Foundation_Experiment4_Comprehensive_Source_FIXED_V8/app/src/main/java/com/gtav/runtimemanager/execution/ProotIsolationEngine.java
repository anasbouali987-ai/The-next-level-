package com.gtav.runtimemanager.execution;

import android.content.Context;

import com.gtav.runtimemanager.VerifiedInstalledRuntime;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/** The single PRoot implementation used by v1.7.0. */
public final class ProotIsolationEngine implements LinuxEnvironmentEngine {
    private final Context context;

    public ProotIsolationEngine(Context context) { this.context = context.getApplicationContext(); }
    @Override public String name() { return "Android PRoot (Bionic host → glibc guest)"; }

    @Override
    public RuntimeLaunchPlan buildPlan(VerifiedInstalledRuntime runtime, RuntimeSession session,
                                       RuntimeMountManager.MountPlan mounts,
                                       RuntimeEnvironment environment, RuntimeCommand command)
            throws RuntimeExecutionException {
        File proot = ExecutionPaths.proot(context);
        if (!proot.isFile() || !proot.canExecute()) throw new RuntimeExecutionException(
                ExecutionErrorCode.PROOT_NOT_EXECUTABLE, ExecutionStage.STARTING_PROOT,
                "PRoot غير موجود أو غير قابل للتنفيذ");
        List<String> argv = new ArrayList<>();
        argv.add(proot.getAbsolutePath());
        argv.add("-0");
        argv.add("-r");
        argv.add(runtime.rootfs().getAbsolutePath());
        argv.add("-w");
        argv.add("/root");
        for (RuntimeBindMount mount : mounts.mounts) {
            if (!mount.hostPath.exists()) {
                if (mount.required) throw new RuntimeExecutionException(
                        ExecutionErrorCode.EXECUTION_COMPONENTS_INVALID, ExecutionStage.PREPARING,
                        "مصدر Bind مفقود: " + mount.hostPath);
                continue;
            }
            argv.add("-b");
            argv.add(mount.prootSpec());
        }
        argv.add("/usr/bin/env");
        argv.add("-i");
        for (Map.Entry<String, String> entry : environment.guest.entrySet()) {
            argv.add(entry.getKey() + "=" + entry.getValue());
        }
        argv.add(command.executable);
        argv.addAll(command.arguments);
        return new RuntimeLaunchPlan(command.display(), argv, session.directory,
                environment, command.timeoutMs, command.expectedOutput);
    }
}
