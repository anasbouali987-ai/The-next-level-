package com.gtav.runtimemanager.compression.zstd;

import java.io.InputStream;

/** Single boundary for every direct zstd-jni operation used by the application. */
public interface ZstdEngine {
    String engineName();
    String dependencyVersion();
    String nativeVersion() throws Throwable;
    InputStream openDecompressionStream(InputStream source) throws Throwable;
    ZstdHealthResult runRoundTripTest();
    ZstdHealthResult runStreamingTest();
}
