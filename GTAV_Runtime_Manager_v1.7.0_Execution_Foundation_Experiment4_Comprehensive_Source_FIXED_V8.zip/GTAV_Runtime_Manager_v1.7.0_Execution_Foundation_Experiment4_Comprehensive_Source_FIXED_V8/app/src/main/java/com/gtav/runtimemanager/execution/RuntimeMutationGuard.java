package com.gtav.runtimemanager.execution;

import com.gtav.runtimemanager.VerifiedInstalledRuntime;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.attribute.BasicFileAttributes;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TreeMap;
import java.util.stream.Stream;

/**
 * Defensively verifies the installed base RootFS was not changed. PRoot is not a kernel mount
 * namespace, so writable guest paths are redirected outside RootFS and this guard compares the
 * complete node metadata plus SHA-256 of every execution-critical file.
 */
public final class RuntimeMutationGuard {
    private static final int MAX_NODES = 250_000;
    private File root;
    private Map<String, NodeFingerprint> treeBefore = new TreeMap<>();
    private final LinkedHashMap<String, CriticalFingerprint> criticalBefore = new LinkedHashMap<>();

    public void capture(VerifiedInstalledRuntime runtime) throws RuntimeExecutionException {
        root = runtime.rootfs();
        treeBefore = snapshotTree(root);
        criticalBefore.clear();
        addCritical(new File(root, "installed_runtime.json"));
        addCritical(new File(root, "runtime_manifest.json"));
        addGuest(runtime.box64GuestPath());
        addGuest(runtime.wine64GuestPath());
        addGuest(runtime.winebootGuestPath());
        addGuest(runtime.wineserverGuestPath());
        for (String guest : runtime.requiredFiles()) addGuest(guest);
    }

    public String verify(VerifiedInstalledRuntime runtime) throws RuntimeExecutionException {
        if (root == null || !root.equals(runtime.rootfs())) {
            throw new RuntimeExecutionException(ExecutionErrorCode.RUNTIME_CHANGED_AFTER_VERIFICATION,
                    ExecutionStage.CLEANING_UP, "Runtime identity changed during the session", false);
        }
        Map<String, NodeFingerprint> after = snapshotTree(root);
        List<String> changes = compare(treeBefore, after, 40);
        for (Map.Entry<String, CriticalFingerprint> item : criticalBefore.entrySet()) {
            CriticalFingerprint current = fingerprint(new File(item.getKey()));
            if (!item.getValue().equals(current)) changes.add("critical-content-changed: " + item.getKey());
        }
        if (!changes.isEmpty()) {
            throw new RuntimeExecutionException(ExecutionErrorCode.RUNTIME_MUTATED,
                    ExecutionStage.CLEANING_UP,
                    "تم تعديل Runtime المثبت أثناء التشغيل:\n" + String.join("\n", changes), false);
        }
        return "Runtime read-mostly guard passed — nodes=" + after.size() +
                ", critical_sha256=" + criticalBefore.size();
    }

    public String policySummary() {
        return "Installed base RootFS: immutable by policy\n" +
                "Writable roots: prefixes/, sessions/, cache/, logs/, profiles/\n" +
                "Enforcement: external writable binds + full node metadata comparison + critical SHA-256\n" +
                "Limitation: PRoot cannot provide a kernel-enforced read-only root mount.\n";
    }

    private void addGuest(String guest) throws RuntimeExecutionException {
        if (guest == null || guest.isEmpty()) return;
        addCritical(new File(root, guest.startsWith("/") ? guest.substring(1) : guest));
    }

    private void addCritical(File file) throws RuntimeExecutionException {
        if (file.isFile()) criticalBefore.put(file.getAbsolutePath(), fingerprint(file));
    }

    private static Map<String, NodeFingerprint> snapshotTree(File root)
            throws RuntimeExecutionException {
        try {
            Path rootPath = root.toPath();
            TreeMap<String, NodeFingerprint> snapshot = new TreeMap<>();
            try (Stream<Path> paths = Files.walk(rootPath)) {
                java.util.Iterator<Path> iterator = paths.iterator();
                while (iterator.hasNext()) {
                    Path path = iterator.next();
                    if (snapshot.size() >= MAX_NODES) throw new IllegalStateException("RootFS node limit exceeded");
                    BasicFileAttributes attrs = Files.readAttributes(path,
                            BasicFileAttributes.class, LinkOption.NOFOLLOW_LINKS);
                    String relative = rootPath.relativize(path).toString().replace(File.separatorChar, '/');
                    String type = attrs.isSymbolicLink() ? "symlink" : attrs.isDirectory() ? "directory" :
                            attrs.isRegularFile() ? "file" : "other";
                    String target = "";
                    if (attrs.isSymbolicLink()) {
                        try { target = Files.readSymbolicLink(path).toString(); } catch (Throwable ignored) {}
                    }
                    snapshot.put(relative, new NodeFingerprint(type, attrs.size(),
                            attrs.lastModifiedTime().toMillis(), target));
                }
            }
            return snapshot;
        } catch (Throwable error) {
            throw new RuntimeExecutionException(ExecutionErrorCode.RUNTIME_NOT_READY,
                    ExecutionStage.VALIDATING, "تعذر أخذ بصمة RootFS", error);
        }
    }

    private static List<String> compare(Map<String, NodeFingerprint> before,
                                        Map<String, NodeFingerprint> after, int limit) {
        List<String> changes = new ArrayList<>();
        for (Map.Entry<String, NodeFingerprint> item : before.entrySet()) {
            NodeFingerprint now = after.get(item.getKey());
            if (now == null) changes.add("removed: " + item.getKey());
            else if (!item.getValue().equals(now)) changes.add("metadata-changed: " + item.getKey());
            if (changes.size() >= limit) return changes;
        }
        for (String path : after.keySet()) {
            if (!before.containsKey(path)) changes.add("added: " + path);
            if (changes.size() >= limit) return changes;
        }
        return changes;
    }

    private static CriticalFingerprint fingerprint(File file) throws RuntimeExecutionException {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            try (BufferedInputStream input = new BufferedInputStream(new FileInputStream(file), 256 * 1024)) {
                byte[] buffer = new byte[256 * 1024];
                int read;
                while ((read = input.read(buffer)) != -1) digest.update(buffer, 0, read);
            }
            StringBuilder out = new StringBuilder(64);
            for (byte value : digest.digest()) out.append(String.format(Locale.US, "%02x", value));
            return new CriticalFingerprint(file.length(), file.lastModified(), out.toString());
        } catch (Throwable error) {
            throw new RuntimeExecutionException(ExecutionErrorCode.RUNTIME_NOT_READY,
                    ExecutionStage.VALIDATING, "تعذر حساب بصمة: " + file, error);
        }
    }

    private static final class NodeFingerprint {
        final String type;
        final long size;
        final long modified;
        final String linkTarget;
        NodeFingerprint(String type, long size, long modified, String linkTarget) {
            this.type = type; this.size = size; this.modified = modified;
            this.linkTarget = linkTarget == null ? "" : linkTarget;
        }
        @Override public boolean equals(Object object) {
            if (!(object instanceof NodeFingerprint)) return false;
            NodeFingerprint other = (NodeFingerprint) object;
            return size == other.size && modified == other.modified && type.equals(other.type) &&
                    linkTarget.equals(other.linkTarget);
        }
        @Override public int hashCode() { return type.hashCode() * 31 + Long.hashCode(size); }
    }

    private static final class CriticalFingerprint {
        final long size;
        final long modified;
        final String sha;
        CriticalFingerprint(long size, long modified, String sha) {
            this.size = size; this.modified = modified; this.sha = sha;
        }
        @Override public boolean equals(Object object) {
            if (!(object instanceof CriticalFingerprint)) return false;
            CriticalFingerprint other = (CriticalFingerprint) object;
            return size == other.size && modified == other.modified && sha.equals(other.sha);
        }
        @Override public int hashCode() { return sha.hashCode(); }
    }
}
