package com.gtav.runtimemanager;

interface InstallProgressSink {
    void update(InstallStage stage,
                long done,
                long total,
                long compressedDone,
                InstallStats stats,
                String currentFile,
                String zstdStatus,
                String tarStatus,
                String message,
                boolean force);
}
