package com.gtav.runtimemanager;

import com.gtav.runtimemanager.compression.zstd.AndroidZstdJniEngine;
import com.gtav.runtimemanager.compression.zstd.ZstdEngine;
import com.gtav.runtimemanager.compression.zstd.ZstdErrorClassifier;
import com.gtav.runtimemanager.compression.zstd.ZstdHealthResult;

import java.io.InputStream;
import java.util.Objects;

/** Application-facing compression facade with typed installation errors. */
final class CompressionManager {
    private final ZstdEngine engine;

    CompressionManager(ZstdEngine engine) {
        this.engine = Objects.requireNonNull(engine, "engine");
    }

    static CompressionManager createDefault() {
        return new CompressionManager(new AndroidZstdJniEngine());
    }

    String engineName() { return engine.engineName(); }
    String dependencyVersion() { return engine.dependencyVersion(); }

    String version() throws RuntimeInstallException {
        try {
            return engine.nativeVersion();
        } catch (Throwable error) {
            throw asInstallError(error, InstallStage.PREFLIGHT_ZSTD_NATIVE,
                    "تعذر قراءة إصدار مكتبة Zstandard الأصلية");
        }
    }

    InputStream openZstdStream(InputStream source, InstallStage stage)
            throws RuntimeInstallException {
        try {
            return engine.openDecompressionStream(source);
        } catch (Throwable error) {
            throw asInstallError(error, stage, "تعذر إنشاء Zstandard stream");
        }
    }

    ZstdHealthResult roundTrip() { return engine.runRoundTripTest(); }
    ZstdHealthResult streaming() { return engine.runStreamingTest(); }

    private static RuntimeInstallException asInstallError(
            Throwable error, InstallStage stage, String message) {
        String classified = ZstdErrorClassifier.classify(error);
        InstallErrorCode code;
        try {
            code = InstallErrorCode.valueOf(classified);
        } catch (IllegalArgumentException ignored) {
            code = InstallErrorCode.ZSTD_STREAM_FAILED;
        }
        return new RuntimeInstallException(
                code,
                stage,
                message + ": " + ZstdErrorClassifier.describe(error),
                error
        );
    }
}
