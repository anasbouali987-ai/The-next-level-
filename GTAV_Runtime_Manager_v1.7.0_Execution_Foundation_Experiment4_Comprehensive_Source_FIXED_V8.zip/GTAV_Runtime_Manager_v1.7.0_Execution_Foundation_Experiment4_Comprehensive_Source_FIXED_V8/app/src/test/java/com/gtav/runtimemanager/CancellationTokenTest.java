package com.gtav.runtimemanager;

import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

public final class CancellationTokenTest {
    @Test
    public void cancellationDuringExtractionStopsSafely() {
        CancellationToken token = new CancellationToken();
        token.cancel();
        try {
            token.throwIfCancelled(InstallStage.EXTRACTING);
            fail("كان يجب إيقاف الاستخراج");
        } catch (RuntimeInstallException expected) {
            assertEquals(InstallErrorCode.CANCELLED, expected.code);
            assertEquals(InstallStage.EXTRACTING, expected.stage);
        }
    }
}
