package com.gtav.runtimemanager;

import com.gtav.runtimemanager.compression.zstd.ZstdErrorClassifier;

import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

public class ZstdErrorClassifierTest {
    @Test public void classifiesNativeLoaderFailuresThroughCauseChain() {
        Throwable error = new RuntimeException("wrapper", new UnsatisfiedLinkError("dlopen failed"));
        assertEquals("ZSTD_DLOPEN_FAILED", ZstdErrorClassifier.classify(error));
        assertTrue(ZstdErrorClassifier.describe(error).contains("dlopen failed"));
    }

    @Test public void classifiesOutOfMemory() {
        assertEquals("OUT_OF_MEMORY", ZstdErrorClassifier.classify(new OutOfMemoryError("probe")));
    }
}
