package com.gtav.runtimemanager;

import com.gtav.runtimemanager.compression.zstd.NdkZstdEngine;

import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

public class ZstdArchitectureTest {
    @Test public void defaultFactorySelectsAndroidAarEngine() {
        CompressionManager manager = CompressionManager.createDefault();
        assertTrue(manager.engineName().contains("Android AAR"));
        assertEquals(BuildConfig.ZSTD_DEPENDENCY_VERSION, manager.dependencyVersion());
    }

    @Test public void futureNdkAdapterIsExplicitlyDisabled() {
        NdkZstdEngine engine = new NdkZstdEngine();
        assertFalse(engine.runRoundTripTest().ok);
        assertEquals("ZSTD_ENGINE_DISABLED", engine.runStreamingTest().code);
    }
}
