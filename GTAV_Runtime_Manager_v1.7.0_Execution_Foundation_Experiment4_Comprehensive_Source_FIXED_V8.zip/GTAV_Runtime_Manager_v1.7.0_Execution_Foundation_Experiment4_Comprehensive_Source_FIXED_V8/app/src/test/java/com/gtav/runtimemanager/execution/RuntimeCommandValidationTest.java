package com.gtav.runtimemanager.execution;

import org.junit.Test;
import java.util.Arrays;
import java.util.Collections;
import static org.junit.Assert.*;

public class RuntimeCommandValidationTest {
    @Test public void argvPreservesArgumentBoundaries() {
        RuntimeCommand command = new RuntimeCommand("/bin/echo",
                Arrays.asList("one two", "$(not-shell)"), 1000, "");
        assertEquals(3, command.argv().size());
        assertEquals("one two", command.argv().get(1));
    }
    @Test(expected = IllegalArgumentException.class)
    public void rejectsNulInExecutable() {
        new RuntimeCommand("/bin/sh\0", Collections.emptyList(), 1000, "");
    }
    @Test(expected = IllegalArgumentException.class)
    public void rejectsNulInArgument() {
        new RuntimeCommand("/bin/sh", Collections.singletonList("bad\0arg"), 1000, "");
    }
}
