package com.gtav.runtimemanager.execution;

import org.junit.Test;
import java.util.Map;
import static org.junit.Assert.assertEquals;

public final class Box64ConfigManagerTest {
    @Test public void diagnosticProfileEnablesLogsAndDynarec() {
        Map<String, String> env = new Box64ConfigManager()
                .configuration(Box64ConfigManager.Profile.DIAGNOSTIC);
        assertEquals("1", env.get("BOX64_DYNAREC"));
        assertEquals("1", env.get("BOX64_LOG"));
        assertEquals("1", env.get("BOX64_DYNAREC_LOG"));
    }
}
