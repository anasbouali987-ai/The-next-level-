package com.gtav.runtimemanager;

import org.junit.Test;

import java.io.File;
import java.io.IOException;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

public final class PermissionApplierTest {
    @Test
    public void chmodFailureIsConvertedToStructuredError() {
        PermissionApplier applier = new PermissionApplier((file, mode) -> {
            throw new IOException("chmod denied");
        });

        try {
            applier.apply(new File("required-file"), 0755, InstallStage.APPLYING_PERMISSIONS);
            fail("كان يجب تمرير فشل chmod");
        } catch (RuntimeInstallException expected) {
            assertEquals(InstallErrorCode.CHMOD_FAILED, expected.code);
            assertEquals(InstallStage.APPLYING_PERMISSIONS, expected.stage);
        }
    }
}
