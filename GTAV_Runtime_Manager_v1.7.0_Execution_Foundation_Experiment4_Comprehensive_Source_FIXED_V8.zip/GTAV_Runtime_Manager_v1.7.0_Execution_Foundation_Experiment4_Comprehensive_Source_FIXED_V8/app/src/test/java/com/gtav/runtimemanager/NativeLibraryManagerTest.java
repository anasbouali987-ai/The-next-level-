package com.gtav.runtimemanager;

import org.junit.Test;

import java.io.File;
import java.util.Arrays;
import java.util.Collections;

import static org.junit.Assert.assertTrue;

public class NativeLibraryManagerTest {
    @Test public void reportFormatsRequiredDiagnosticFields() {
        File zstd = new File("/tmp/libzstd-jni.so");
        NativeLibraryManager.Report report = new NativeLibraryManager.Report(
                "/tmp",
                Collections.singletonList(zstd),
                Collections.singletonList(zstd),
                new String[]{"arm64-v8a"},
                "arm64-v8a",
                "test-loader",
                "/tmp",
                "loaded"
        );
        String text = report.format();
        assertTrue(report.hasZstd());
        assertTrue(report.abiCompatible);
        assertTrue(text.contains("Requested APK ABI"));
        assertTrue(text.contains("Device ABIs"));
        assertTrue(text.contains("ClassLoader"));
        assertTrue(text.contains("JNI load status"));
        assertTrue(text.contains("Search path"));
        assertTrue(Arrays.asList(report.deviceAbis).contains("arm64-v8a"));
    }
}
