package com.gtav.runtimemanager.execution;

import org.junit.Test;
import static org.junit.Assert.assertEquals;

public class ExecutionPathsValidationTest {
    @Test public void acceptsStableIdentifiers() {
        assertEquals("gtav-runtime_1.7", ExecutionPaths.requireSafeId("gtav-runtime_1.7", "id"));
    }

    @Test(expected = IllegalArgumentException.class)
    public void rejectsTraversalInsteadOfSanitizingIt() {
        ExecutionPaths.requireSafeId("../runtime", "id");
    }

    @Test(expected = IllegalArgumentException.class)
    public void rejectsWhitespaceCollision() {
        ExecutionPaths.requireSafeId("runtime one", "id");
    }
}
