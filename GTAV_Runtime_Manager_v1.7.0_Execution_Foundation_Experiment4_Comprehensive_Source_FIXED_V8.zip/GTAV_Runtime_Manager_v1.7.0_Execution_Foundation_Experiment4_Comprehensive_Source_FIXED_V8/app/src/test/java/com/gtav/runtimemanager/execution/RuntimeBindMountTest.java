package com.gtav.runtimemanager.execution;

import org.junit.Test;
import java.io.File;
import static org.junit.Assert.*;

public class RuntimeBindMountTest {
    @Test public void modelKeepsRequiredReadOnlyAndPurposeState() {
        RuntimeBindMount mount = new RuntimeBindMount(new File("/tmp/source"), "/mnt/source",
                true, true, RuntimeBindMount.Purpose.TEST_BINARY);
        assertTrue(mount.readOnly);
        assertTrue(mount.required);
        assertEquals("/mnt/source", mount.guestPath);
        assertEquals(RuntimeBindMount.Purpose.TEST_BINARY, mount.purpose);
    }

    @Test(expected = IllegalArgumentException.class)
    public void rejectsGuestTraversal() {
        new RuntimeBindMount(new File("/tmp/source"), "/mnt/../etc", false, true);
    }
}
