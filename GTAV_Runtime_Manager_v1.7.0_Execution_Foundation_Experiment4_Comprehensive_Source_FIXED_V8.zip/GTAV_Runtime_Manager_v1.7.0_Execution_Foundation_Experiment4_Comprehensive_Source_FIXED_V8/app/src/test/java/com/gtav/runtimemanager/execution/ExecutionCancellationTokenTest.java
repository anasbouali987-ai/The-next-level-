package com.gtav.runtimemanager.execution;

import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

public final class ExecutionCancellationTokenTest {
    @Test
    public void cancelIsStickyAndClassified() throws Exception {
        ExecutionCancellationToken token = new ExecutionCancellationToken();
        assertFalse(token.isCancelled());
        token.cancel();
        token.requestStop();
        assertTrue(token.isCancelled());
        assertEquals(ExecutionCancellationToken.Request.CANCEL, token.request());
        assertCode(token, ExecutionErrorCode.PROCESS_CANCELLED);
    }

    @Test
    public void stopIsStickyAndClassified() throws Exception {
        ExecutionCancellationToken token = new ExecutionCancellationToken();
        token.requestStop();
        token.cancel();
        assertEquals(ExecutionCancellationToken.Request.STOP, token.request());
        assertCode(token, ExecutionErrorCode.PROCESS_STOPPED);
    }

    private static void assertCode(ExecutionCancellationToken token,
                                   ExecutionErrorCode expected) throws Exception {
        try {
            token.throwIfCancelled(ExecutionStage.RUNNING);
            fail("Expected RuntimeExecutionException");
        } catch (RuntimeExecutionException error) {
            assertEquals(expected, error.typedCode);
            assertEquals(ExecutionStage.RUNNING, error.stage);
        }
    }
}
