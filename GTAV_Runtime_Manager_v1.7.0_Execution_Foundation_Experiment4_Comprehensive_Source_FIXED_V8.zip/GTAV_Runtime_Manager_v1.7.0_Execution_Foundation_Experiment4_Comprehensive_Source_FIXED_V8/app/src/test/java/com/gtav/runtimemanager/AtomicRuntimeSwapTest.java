package com.gtav.runtimemanager;

import org.junit.Test;

import java.io.File;
import java.io.IOException;
import java.util.HashSet;
import java.util.Set;

import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

public final class AtomicRuntimeSwapTest {
    @Test
    public void backupIsRestoredWhenPromotingNewRuntimeFails() {
        File temp = new File("runtime.installing");
        File target = new File("runtime");
        File backup = new File("runtime.backup");
        FakeOps ops = new FakeOps(temp, target);

        try {
            AtomicRuntimeSwap.promote(temp, target, backup, true, ops);
            fail("كان يجب أن تفشل ترقية المجلد المؤقت");
        } catch (IOException expected) {
            assertTrue("يجب استعادة النسخة القديمة", ops.exists(target));
        }
    }

    private static final class FakeOps implements AtomicRuntimeSwap.Ops {
        private final Set<String> existing = new HashSet<>();
        private final String tempPath;
        private final String targetPath;

        FakeOps(File temp, File target) {
            tempPath = temp.getPath();
            targetPath = target.getPath();
            existing.add(tempPath);
            existing.add(targetPath);
        }

        @Override public boolean exists(File file) {
            return existing.contains(file.getPath());
        }

        @Override public boolean rename(File from, File to) {
            if (from.getPath().equals(tempPath) && to.getPath().equals(targetPath)) {
                return false;
            }
            if (!existing.remove(from.getPath())) return false;
            existing.add(to.getPath());
            return true;
        }

        @Override public void delete(File file) {
            existing.remove(file.getPath());
        }
    }
}
