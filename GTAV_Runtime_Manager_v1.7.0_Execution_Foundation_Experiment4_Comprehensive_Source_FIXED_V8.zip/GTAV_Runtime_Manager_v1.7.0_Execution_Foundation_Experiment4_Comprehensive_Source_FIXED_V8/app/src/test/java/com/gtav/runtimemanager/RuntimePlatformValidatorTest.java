package com.gtav.runtimemanager;

import org.junit.Test;

import java.util.Arrays;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

public class RuntimePlatformValidatorTest {
    @Test public void blockingFailureMakesReportNotReady() {
        RuntimePlatformValidator.Report report = new RuntimePlatformValidator.Report(Arrays.asList(
                new RuntimePlatformValidator.Check("OK", true, true, "ok"),
                new RuntimePlatformValidator.Check("FAIL", false, true, "failed")),
                null, null, null);
        assertFalse(report.ready());
    }

    @Test public void warningDoesNotBlock() {
        RuntimePlatformValidator.Report report = new RuntimePlatformValidator.Report(Arrays.asList(
                new RuntimePlatformValidator.Check("WARNING", false, false, "warning")),
                null, null, null);
        assertTrue(report.ready());
    }
}
