package com.gtav.runtimemanager;

import org.junit.Test;

public final class RuntimeStatsCompatibilityTest {
    @Test
    public void manifestFilesMayRepresentTarHardLinks() throws Exception {
        RuntimeManifest.ManifestStats expected = new RuntimeManifest.ManifestStats();
        expected.files = 3;
        expected.symlinks = 1;
        expected.fileBytes = 300;

        InstallStats actual = new InstallStats();
        actual.files = 2;
        actual.hardLinks = 1;
        actual.symlinks = 1;
        actual.writtenBytes = 200;
        actual.hardLinkLogicalBytes = 100;

        RuntimeInstallPolicy.validateStats(expected, actual);
    }
}
