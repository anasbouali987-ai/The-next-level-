package com.gtav.runtimemanager.execution;

import org.junit.Test;
import java.io.File;
import static org.junit.Assert.*;

public class ElfInspectorTest {
    @Test public void packagedSourceSmokeBinaryIsX8664WhenPresent() throws Exception {
        File binary = new File("src/main/assets/execution/hello-x86_64");
        assertTrue(binary.isFile());
        assertTrue(ElfInspector.inspect(binary).isX8664());
    }
}
