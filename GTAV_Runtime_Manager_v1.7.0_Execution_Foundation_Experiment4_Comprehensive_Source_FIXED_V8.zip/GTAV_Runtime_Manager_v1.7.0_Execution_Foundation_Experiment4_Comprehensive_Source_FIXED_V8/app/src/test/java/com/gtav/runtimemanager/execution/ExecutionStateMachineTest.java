package com.gtav.runtimemanager.execution;

import org.junit.Test;
import static org.junit.Assert.*;

public class ExecutionStateMachineTest {
    @Test public void happyPathRequiresCleanupBeforeCompleted() throws Exception {
        ExecutionStateMachine machine = new ExecutionStateMachine();
        machine.resetForNewSession();
        machine.transition(ExecutionStage.VALIDATING);
        machine.transition(ExecutionStage.STARTING_PROOT);
        machine.transition(ExecutionStage.ENTERING_ROOTFS);
        machine.transition(ExecutionStage.RUNNING_BOX64);
        machine.transition(ExecutionStage.STARTING_WINE);
        machine.transition(ExecutionStage.RUNNING);
        assertFalse(ExecutionStateMachine.canTransition(ExecutionStage.RUNNING, ExecutionStage.COMPLETED));
        machine.transition(ExecutionStage.STOPPING);
        machine.transition(ExecutionStage.CLEANING_UP);
        machine.transition(ExecutionStage.COMPLETED);
        assertTrue(machine.current().terminal());
    }

    @Test(expected = RuntimeExecutionException.class)
    public void rejectsSkippingBox64AndWine() throws Exception {
        ExecutionStateMachine machine = new ExecutionStateMachine();
        machine.resetForNewSession();
        machine.transition(ExecutionStage.VALIDATING);
        machine.transition(ExecutionStage.RUNNING);
    }

    @Test public void timeoutAndRecoveryStatesAreTerminal() {
        assertTrue(ExecutionStage.TIMED_OUT.terminal());
        assertTrue(ExecutionStage.RECOVERY_REQUIRED.terminal());
        assertFalse(ExecutionStage.CLEANING_UP.terminal());
    }
}
