package com.gtav.runtimemanager;

import com.gtav.runtimemanager.compression.zstd.ZstdEngine;
import com.gtav.runtimemanager.compression.zstd.ZstdHealthResult;

import org.junit.Test;

import java.io.InputStream;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;

public class CompressionManagerTest {
    @Test public void delegatesThroughTheEngineBoundary() throws Exception {
        ZstdEngine fake = new ZstdEngine() {
            @Override public String engineName() { return "fake"; }
            @Override public String dependencyVersion() { return "test"; }
            @Override public String nativeVersion() { return "1"; }
            @Override public InputStream openDecompressionStream(InputStream source) { return source; }
            @Override public ZstdHealthResult runRoundTripTest() { return ZstdHealthResult.success("round"); }
            @Override public ZstdHealthResult runStreamingTest() { return ZstdHealthResult.success("stream"); }
        };
        CompressionManager manager = new CompressionManager(fake);
        InputStream marker = new java.io.ByteArrayInputStream(new byte[]{1});
        assertTrue(manager.roundTrip().ok);
        assertTrue(manager.streaming().ok);
        assertEquals("fake", manager.engineName());
        assertEquals("test", manager.dependencyVersion());
        assertEquals("1", manager.version());
        assertSame(marker, manager.openZstdStream(marker, InstallStage.STARTING_ZSTD));
    }
}
