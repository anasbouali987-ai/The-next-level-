package com.gtav.runtimemanager.execution;

import org.junit.Test;
import static org.junit.Assert.*;

public class BackendCapabilityRegistryTest {
    @Test public void futureBackendsAreDeclaredButNeverAdvertisedAsReady() {
        BackendCapabilityRegistry registry = new BackendCapabilityRegistry();
        for (BackendCapabilityRegistry.Backend backend : BackendCapabilityRegistry.Backend.values()) {
            assertEquals(BackendCapabilityRegistry.State.DECLARED_NOT_IMPLEMENTED,
                    registry.all().get(backend).state);
        }
    }
}
