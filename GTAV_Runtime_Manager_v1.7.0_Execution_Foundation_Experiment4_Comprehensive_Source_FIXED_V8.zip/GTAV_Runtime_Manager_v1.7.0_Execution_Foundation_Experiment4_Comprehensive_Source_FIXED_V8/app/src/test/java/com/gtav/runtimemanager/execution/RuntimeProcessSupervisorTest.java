package com.gtav.runtimemanager.execution;

import org.junit.Test;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

public final class RuntimeProcessSupervisorTest {
    @Test
    public void processIdentityRejectsRecycledOrWrongStartTick() {
        long pid = getCurrentPid();
        long start = RuntimeProcessSupervisor.readStartTicks(pid);

        assertTrue(start > 0);
        assertTrue(RuntimeProcessSupervisor.isSameProcess(pid, start));
        assertFalse(RuntimeProcessSupervisor.isSameProcess(pid, start + 1));
    }

    private static long getCurrentPid() {
        try (BufferedReader reader = new BufferedReader(new FileReader("/proc/self/stat"))) {
            String stat = reader.readLine();
            if (stat == null) {
                throw new AssertionError("/proc/self/stat is empty");
            }

            int separator = stat.indexOf(' ');
            if (separator <= 0) {
                throw new AssertionError("Invalid /proc/self/stat format");
            }

            return Long.parseLong(stat.substring(0, separator));
        } catch (IOException | NumberFormatException error) {
            throw new AssertionError("Unable to read current PID from /proc/self/stat", error);
        }
    }
}
