package com.gtav.runtimemanager;

import org.junit.Test;

import java.io.IOException;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

public final class RuntimeInstallPolicyTest {
    @Test
    public void missingPayloadIsRejected() {
        try {
            RuntimeInstallPolicy.requirePayload(false, "Payload ناقص");
            fail("كان يجب رفض الحزمة");
        } catch (IOException expected) {
            assertEquals("Payload ناقص", expected.getMessage());
        }
    }
}
