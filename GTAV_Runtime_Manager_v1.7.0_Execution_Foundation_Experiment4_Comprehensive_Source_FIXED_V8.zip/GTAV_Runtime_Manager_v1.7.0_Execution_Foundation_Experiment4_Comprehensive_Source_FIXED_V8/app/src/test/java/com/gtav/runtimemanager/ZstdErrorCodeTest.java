package com.gtav.runtimemanager;

import org.junit.Test;
import static org.junit.Assert.*;

public class ZstdErrorCodeTest {
    @Test public void dedicatedCodesExist() {
        assertNotNull(InstallErrorCode.valueOf("ZSTD_NOT_PACKAGED"));
        assertNotNull(InstallErrorCode.valueOf("ZSTD_DLOPEN_FAILED"));
        assertNotNull(InstallErrorCode.valueOf("ZSTD_ROUND_TRIP_FAILED"));
        assertNotNull(InstallErrorCode.valueOf("ZSTD_STREAM_TEST_FAILED"));
    }
}
