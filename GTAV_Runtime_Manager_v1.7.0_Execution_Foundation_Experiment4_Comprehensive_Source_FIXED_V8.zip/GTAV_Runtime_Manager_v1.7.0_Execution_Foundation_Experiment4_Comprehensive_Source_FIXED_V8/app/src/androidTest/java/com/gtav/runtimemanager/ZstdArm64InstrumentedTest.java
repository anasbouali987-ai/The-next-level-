package com.gtav.runtimemanager;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;

import org.apache.commons.compress.archivers.tar.TarArchiveEntry;
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.io.InputStream;
import java.util.Arrays;

@RunWith(AndroidJUnit4.class)
public class ZstdArm64InstrumentedTest {
    @Test public void nativeLibraryRoundTripAndStreamingWork() {
        android.content.Context context =
                InstrumentationRegistry.getInstrumentation().getTargetContext();
        CompressionManager manager = CompressionManager.createDefault();
        NativeLibraryManager.Report nativeReport =
                new NativeLibraryManager().inspect(context, "instrumented test");
        assertTrue(Arrays.asList(android.os.Build.SUPPORTED_ABIS).contains(BuildConfig.REQUESTED_ABI));
        assertTrue(nativeReport.abiCompatible);
        assertTrue(nativeReport.hasZstd());
        assertTrue(nativeReport.primaryZstd().getAbsolutePath().toLowerCase().contains("zstd"));
        com.gtav.runtimemanager.compression.zstd.ZstdHealthResult roundTrip =
                manager.roundTrip();
        com.gtav.runtimemanager.compression.zstd.ZstdHealthResult streaming =
                manager.streaming();
        assertTrue(roundTrip.details, roundTrip.ok);
        assertTrue(streaming.details, streaming.ok);
    }

    @Test public void opensRealTarZstdSample() throws Exception {
        android.content.Context context = InstrumentationRegistry.getInstrumentation().getContext();
        CompressionManager manager = CompressionManager.createDefault();
        try (InputStream asset = context.getAssets().open("sample.tar.zst");
             InputStream zstd = manager.openZstdStream(asset, InstallStage.PREFLIGHT_TAR);
             TarArchiveInputStream tar = new TarArchiveInputStream(zstd)) {
            TarArchiveEntry entry = tar.getNextTarEntry();
            assertNotNull(entry);
            assertEquals("probe.txt", entry.getName());
        }
    }
}
