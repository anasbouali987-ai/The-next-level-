package com.gtav.runtimemanager;

import static org.junit.Assert.assertTrue;

import android.content.Context;

import androidx.test.core.app.ApplicationProvider;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import org.junit.Test;
import org.junit.runner.RunWith;

@RunWith(AndroidJUnit4.class)
public class RuntimePlatformInstrumentedTest {
    @Test public void startupPlatformReportIsReadyOnSupportedArm64Device() {
        Context context = ApplicationProvider.getApplicationContext();
        RuntimePlatformValidator.Report report = new RuntimePlatformValidator().validateQuick(
                context,
                CompressionManager.createDefault(),
                new NativeLibraryManager()
        );
        assertTrue(report.format(), report.ready());
    }
}
