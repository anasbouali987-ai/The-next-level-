package com.gtav.runtimemanager.execution;

import android.content.Context;
import androidx.test.core.app.ApplicationProvider;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import org.junit.Test;
import org.junit.runner.RunWith;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import static org.junit.Assert.*;

@RunWith(AndroidJUnit4.class)
public class ExecutionComponentsInstrumentedTest {
    @Test public void prootAndLoaderArePackagedForArm64() throws Exception {
        Context context = ApplicationProvider.getApplicationContext();
        ExecutionComponentInstaller.Report report = new ExecutionComponentInstaller().provision(context);
        assertTrue(report.proot.isFile());
        assertTrue(report.proot.canExecute());
        assertTrue(report.loader.isFile());
        assertTrue(ElfInspector.inspect(report.proot).isAarch64());
        assertTrue(ElfInspector.inspect(report.loader).isAarch64());
        assertTrue(ElfInspector.inspect(report.helloX8664).isX8664());
    }

    @Test public void prootVersionExecutesOnAndroidArm64() throws Exception {
        Context context = ApplicationProvider.getApplicationContext();
        ExecutionComponentInstaller.Report report = new ExecutionComponentInstaller().provision(context);
        ProcessBuilder builder = new ProcessBuilder(report.proot.getAbsolutePath(), "--version");
        builder.environment().put("LD_LIBRARY_PATH", new java.io.File(ExecutionPaths.usr(context), "lib").getAbsolutePath());
        Process process = builder.start();
        StringBuilder output = new StringBuilder();
        try (BufferedReader r = new BufferedReader(new InputStreamReader(process.getInputStream()))) {
            String line; while ((line = r.readLine()) != null) output.append(line).append('\n');
        }
        assertEquals(output.toString(), 0, process.waitFor());
    }
}
