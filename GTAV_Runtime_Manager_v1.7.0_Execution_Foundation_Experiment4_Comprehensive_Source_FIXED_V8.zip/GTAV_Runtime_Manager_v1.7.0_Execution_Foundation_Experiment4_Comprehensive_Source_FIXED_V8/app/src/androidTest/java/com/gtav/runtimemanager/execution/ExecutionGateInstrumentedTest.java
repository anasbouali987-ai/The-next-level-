package com.gtav.runtimemanager.execution;

import android.content.Context;
import androidx.test.core.app.ApplicationProvider;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import com.gtav.runtimemanager.InstalledRuntimeProvider;
import com.gtav.runtimemanager.VerifiedInstalledRuntime;
import org.junit.Assume;
import org.junit.Test;
import org.junit.runner.RunWith;
import java.util.Collections;
import static org.junit.Assert.*;

/** Runs on a device that already contains a verified Runtime; CI only assembles this APK. */
@RunWith(AndroidJUnit4.class)
public class ExecutionGateInstrumentedTest {
    @Test public void rootfsTrueGateWorksWhenRuntimeInstalled() throws Exception {
        Context context = ApplicationProvider.getApplicationContext();
        VerifiedInstalledRuntime runtime = null;
        try { runtime = new InstalledRuntimeProvider(context).findDefaultReady(); }
        catch (Throwable ignored) {}
        Assume.assumeTrue("A verified Runtime must be installed for this device test", runtime != null);

        ExecutionComponentInstaller.Report components = new ExecutionComponentInstaller().provision(context);
        RuntimeSessionManager sessions = new RuntimeSessionManager(context);
        RuntimeSession session = sessions.create(runtime.runtimeId());
        WinePrefixManager prefixManager = new WinePrefixManager();
        RuntimeConsoleStore console = new RuntimeConsoleStore(context, session);
        RuntimeProcessSupervisor supervisor = new RuntimeProcessSupervisor();
        supervisor.beginSession(session.id);
        try {
            WinePrefixManager.PrefixLease prefix = prefixManager.acquire(context, runtime, session);
            RuntimeMountManager.MountPlan mounts = new RuntimeMountManager().build(
                    context, runtime, session, prefix, components.helloX8664);
            RuntimeEnvironment env = new RuntimeEnvironmentBuilder().build(
                    context, runtime, session, mounts.winePrefix);
            RuntimeLaunchPlan plan = new RuntimeLauncher(new ProotIsolationEngine(context)).plan(
                    runtime, session, mounts, env,
                    new RuntimeCommand("/bin/true", Collections.emptyList(), 15_000, ""));
            RuntimeExecutionResult result = new RuntimeProcessRunner().run(plan, console,
                    new ExecutionCancellationToken(), new RuntimeProcessRunner.Observer() {
                        @Override public void onStarted(Process process, long pid) { supervisor.attach(process, pid); }
                        @Override public void onPoll() { supervisor.poll(); }
                        @Override public void onFinished(Process process, RuntimeExecutionResult result) {
                            supervisor.processFinished(process);
                        }
                    });
            assertEquals(result.stderrTail, 0, result.exitCode);
            assertTrue(supervisor.stopGracefully(500, console).clean);
        } finally {
            prefixManager.close();
            console.close();
            sessions.release();
        }
    }
}
