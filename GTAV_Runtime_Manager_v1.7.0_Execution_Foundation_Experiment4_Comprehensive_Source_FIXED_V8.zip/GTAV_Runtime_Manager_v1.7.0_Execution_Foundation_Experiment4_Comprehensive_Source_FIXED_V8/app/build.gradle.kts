import java.security.MessageDigest
import java.util.zip.ZipFile

plugins {
    id("com.android.application")
}

val zstdVersion = "1.5.7-3"
val commonsCompressVersion = "1.27.1"
val requestedAbi = "arm64-v8a"

android {
    namespace = "com.gtav.runtimemanager"
    compileSdk = 36
    buildToolsVersion = "35.0.0"

    defaultConfig {
        applicationId = "com.gtav.runtimemanager"
        minSdk = 26
        targetSdk = 36
        versionCode = 10
        versionName = "1.7.0-exp4"
        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"

        ndk { abiFilters += listOf(requestedAbi) }
        buildConfigField("String", "ZSTD_DEPENDENCY_VERSION", "\"$zstdVersion\"")
        buildConfigField("String", "REQUESTED_ABI", "\"$requestedAbi\"")
        buildConfigField("int", "EXECUTION_SCHEMA_VERSION", "2")
        buildConfigField("String", "EXECUTION_EDITION", "\"Experiment 4 Comprehensive\"")
        buildConfigField("boolean", "FEATURE_PROOT_REQUESTED", "true")
        buildConfigField("boolean", "FEATURE_BOX64_REQUESTED", "true")
        buildConfigField("boolean", "FEATURE_WINE_REQUESTED", "true")
        buildConfigField("boolean", "FEATURE_DISPLAY_REQUESTED", "false")
        buildConfigField("boolean", "FEATURE_AUDIO_REQUESTED", "false")
        buildConfigField("boolean", "FEATURE_GRAPHICS_REQUESTED", "false")
        buildConfigField("boolean", "FEATURE_DXVK_REQUESTED", "false")
        buildConfigField("boolean", "FEATURE_INPUT_REQUESTED", "false")
        buildConfigField("boolean", "FEATURE_GAME_LIBRARY_REQUESTED", "false")
    }

    buildTypes {
        debug {
            isMinifyEnabled = false
            buildConfigField("String", "EXECUTION_BUILD_VARIANT", "\"debug\"")
        }
        release {
            isMinifyEnabled = false
            buildConfigField("String", "EXECUTION_BUILD_VARIANT", "\"release\"")
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    buildFeatures { buildConfig = true }

    packaging {
        resources.excludes += setOf(
            "META-INF/DEPENDENCIES",
            "META-INF/LICENSE*",
            "META-INF/NOTICE*"
        )
        jniLibs.useLegacyPackaging = true
    }

    testOptions { unitTests.isReturnDefaultValues = true }
}

dependencies {
    implementation("org.apache.commons:commons-compress:$commonsCompressVersion")
    implementation("androidx.documentfile:documentfile:1.0.1")
    implementation("com.github.luben:zstd-jni:$zstdVersion@aar")

    // JVM unit tests need the regular JAR; the APK still consumes the Android AAR above.
    testImplementation("com.github.luben:zstd-jni:$zstdVersion")
    testImplementation("junit:junit:4.13.2")

    androidTestImplementation("androidx.test.ext:junit:1.2.1")
    androidTestImplementation("androidx.test:core:1.6.1")
    androidTestImplementation("androidx.test:runner:1.6.2")
}

fun sha256(file: File): String {
    val digest = MessageDigest.getInstance("SHA-256")
    file.inputStream().use { input ->
        val buffer = ByteArray(256 * 1024)
        while (true) {
            val read = input.read(buffer)
            if (read < 0) break
            digest.update(buffer, 0, read)
        }
    }
    return digest.digest().joinToString("") { "%02x".format(it) }
}

fun sha256(input: java.io.InputStream): String {
    val digest = MessageDigest.getInstance("SHA-256")
    input.use { stream ->
        val buffer = ByteArray(256 * 1024)
        while (true) {
            val read = stream.read(buffer)
            if (read < 0) break
            digest.update(buffer, 0, read)
        }
    }
    return digest.digest().joinToString("") { "%02x".format(it) }
}

fun findVariantApks(variant: String): List<File> {
    val outputDir = layout.buildDirectory.dir("outputs/apk/$variant").get().asFile
    return outputDir.walkTopDown().filter { it.isFile && it.extension == "apk" }.toList()
}

fun validateApk(apk: File, variant: String) {
    val entries = ZipFile(apk).use { zip ->
        zip.entries().asSequence().map { it.name }.toList()
    }
    val nativeEntries = entries.filter { it.startsWith("lib/") && it.endsWith(".so") }.sorted()
    val abiEntries = nativeEntries.filter { it.startsWith("lib/$requestedAbi/") }
    val zstdEntries = abiEntries.filter { it.substringAfterLast('/').contains("zstd", ignoreCase = true) }
    val packagedAbis = nativeEntries.mapNotNull { it.split('/').getOrNull(1) }.distinct()

    val reportDir = layout.buildDirectory.dir("reports/native-packaging/$variant").get().asFile
        .apply { mkdirs() }
    File(reportDir, "APK_NATIVE_LIBS.txt").writeText(nativeEntries.joinToString("\n", postfix = "\n"))
    File(reportDir, "BUILD_INFO.txt").writeText(buildString {
        appendLine("Application version: ${android.defaultConfig.versionName}")
        appendLine("Requested ABI: $requestedAbi")
        appendLine("Packaged ABIs: ${packagedAbis.joinToString()}")
        appendLine("Zstd dependency: $zstdVersion")
        appendLine("Variant: $variant")
        appendLine("APK: ${apk.name}")
        appendLine("Zstd entries:")
        zstdEntries.forEach { appendLine(" - $it") }
    })
    File(reportDir, "SHA256SUMS.txt").writeText("${sha256(apk)}  ${apk.name}\n")

    if (abiEntries.isEmpty()) {
        throw GradleException("BUILD FAILED: ABI_NOT_PACKAGED_$requestedAbi")
    }
    if (zstdEntries.isEmpty()) {
        logger.error("Files inside lib/$requestedAbi/:\n${abiEntries.joinToString("\n")}")
        throw GradleException("BUILD FAILED: ZSTD_NOT_PACKAGED")
    }
    logger.lifecycle("Native packaging passed for $variant: ${zstdEntries.joinToString()}")
}


fun elfMachine(bytes: ByteArray): Int {
    if (bytes.size < 20 || bytes[0] != 0x7f.toByte() || bytes[1] != 'E'.code.toByte() ||
        bytes[2] != 'L'.code.toByte() || bytes[3] != 'F'.code.toByte()) return -1
    val little = bytes[5].toInt() == 1
    val a = bytes[18].toInt() and 0xff
    val b = bytes[19].toInt() and 0xff
    return if (little) a or (b shl 8) else (a shl 8) or b
}

fun readZipPrefix(zip: ZipFile, name: String, length: Int = 64): ByteArray {
    val entry = zip.getEntry(name) ?: return byteArrayOf()
    zip.getInputStream(entry).use { input ->
        val data = ByteArray(length)
        var off = 0
        while (off < data.size) {
            val read = input.read(data, off, data.size - off)
            if (read < 0) break
            off += read
        }
        return data.copyOf(off)
    }
}

fun validateExecutionComponents(apk: File, variant: String) {
    val prootEntry = "assets/execution/usr/bin/proot"
    val helloEntry = "assets/execution/hello-x86_64"
    val loaderEntry = "assets/execution/usr/libexec/proot/loader"
    val manifestEntry = "assets/execution/EXECUTION_COMPONENTS_SHA256.txt"
    val reportDir = layout.buildDirectory.dir("reports/execution-components/$variant").get().asFile.apply { mkdirs() }
    ZipFile(apk).use { zip ->
        val executionEntries = zip.entries().asSequence().map { it.name }
            .filter { it.startsWith("assets/execution/") }.sorted().toList()
        File(reportDir, "EXECUTION_COMPONENTS.txt").writeText(executionEntries.joinToString("\n", postfix = "\n"))
        val featureText = buildString {
            appendLine("PROOT: requested=true")
            appendLine("BOX64: requested=true")
            appendLine("WINE: requested=true")
            appendLine("DISPLAY: requested=false")
            appendLine("AUDIO: requested=false")
            appendLine("GRAPHICS: requested=false")
            appendLine("DXVK: requested=false")
            appendLine("INPUT: requested=false")
            appendLine("GAME_LIBRARY: requested=false")
        }
        File(reportDir, "FEATURE_FLAGS.txt").writeText(featureText)
        if (zip.getEntry(prootEntry) == null) throw GradleException("BUILD FAILED: PROOT_NOT_PACKAGED")
        if (zip.getEntry(loaderEntry) == null) throw GradleException("BUILD FAILED: PROOT_LOADER_NOT_PACKAGED")
        if (zip.getEntry(helloEntry) == null) throw GradleException("BUILD FAILED: X86_64_TEST_NOT_PACKAGED")
        val componentManifest = zip.getEntry(manifestEntry)
            ?: throw GradleException("BUILD FAILED: EXECUTION_COMPONENT_MANIFEST_NOT_PACKAGED")
        val expected = linkedMapOf<String, String>()
        zip.getInputStream(componentManifest).bufferedReader().useLines { lines ->
            lines.filter { it.isNotBlank() }.forEach { line ->
                val split = line.indexOf("  ")
                if (split != 64 || line.length <= split + 2) {
                    throw GradleException("BUILD FAILED: EXECUTION_COMPONENT_MANIFEST_INVALID")
                }
                val relative = line.substring(split + 2)
                val hash = line.substring(0, split).lowercase()
                if (!hash.matches(Regex("[0-9a-f]{64}")) ||
                    relative.startsWith("/") || relative.contains("\\") ||
                    relative.split('/').any { it.isEmpty() || it == "." || it == ".." }) {
                    throw GradleException("BUILD FAILED: EXECUTION_COMPONENT_MANIFEST_INVALID:$relative")
                }
                if (expected.put(relative, hash) != null) {
                    throw GradleException("BUILD FAILED: EXECUTION_COMPONENT_MANIFEST_DUPLICATE:$relative")
                }
            }
        }

        val actual = executionEntries
            .filter { !it.endsWith("/") }
            .map { it.removePrefix("assets/execution/") }
            .filter { it != "EXECUTION_COMPONENTS_SHA256.txt" }
            .toSet()
        val expectedSet = expected.keys.toSet()
        if (actual != expectedSet) {
            val missing = (expectedSet - actual).sorted()
            val extra = (actual - expectedSet).sorted()
            File(reportDir, "MANIFEST_FILE_SET_MISMATCH.txt").writeText(buildString {
                appendLine("Missing from APK:")
                missing.forEach { appendLine(it) }
                appendLine("Extra in APK:")
                extra.forEach { appendLine(it) }
            })
            throw GradleException(
                "BUILD FAILED: EXECUTION_COMPONENT_FILE_SET_MISMATCH " +
                    "missing=${missing.joinToString(",")} extra=${extra.joinToString(",")}" )
        }

        expected.forEach { (relative, expectedHash) ->
            val entryName = "assets/execution/$relative"
            val entry = zip.getEntry(entryName)
                ?: throw GradleException("BUILD FAILED: EXECUTION_COMPONENT_NOT_PACKAGED:$relative")
            val actualHash = sha256(zip.getInputStream(entry))
            if (actualHash != expectedHash) {
                throw GradleException("BUILD FAILED: EXECUTION_COMPONENT_HASH_MISMATCH:$relative")
            }
        }
        val prootMachine = elfMachine(readZipPrefix(zip, prootEntry))
        val helloMachine = elfMachine(readZipPrefix(zip, helloEntry))
        if (prootMachine != 183) throw GradleException("BUILD FAILED: PROOT_WRONG_ABI machine=$prootMachine")
        if (helloMachine != 62) throw GradleException("BUILD FAILED: X86_64_TEST_WRONG_ABI machine=$helloMachine")
        File(reportDir, "BUILD_INFO.txt").appendText(buildString {
            appendLine("Execution variant: $variant")
            appendLine("PRoot entry: $prootEntry")
            appendLine("PRoot ELF machine: $prootMachine (AArch64=183)")
            appendLine("Loader entry: $loaderEntry")
            appendLine("hello-x86_64 entry: $helloEntry")
            appendLine("hello ELF machine: $helloMachine (x86_64=62)")
        })
    }
}

tasks.register("verifyZstdAarContents") {
    group = "verification"
    description = "Checks the resolved Android AAR for the requested arm64 Zstandard library."
    doLast {
        val artifacts = configurations.getByName("releaseRuntimeClasspath")
            .resolvedConfiguration.resolvedArtifacts
            .filter { it.moduleVersion.id.group == "com.github.luben" && it.name == "zstd-jni" }
        val aar = artifacts.map { it.file }.firstOrNull { it.extension == "aar" }
            ?: throw GradleException("BUILD FAILED: ZSTD_AAR_NOT_RESOLVED")
        val entries = ZipFile(aar).use { zip -> zip.entries().asSequence().map { it.name }.toList() }
        val expected = entries.filter {
            it.startsWith("jni/$requestedAbi/") && it.endsWith(".so") &&
                    it.substringAfterLast('/').contains("zstd", ignoreCase = true)
        }
        if (expected.isEmpty()) throw GradleException("BUILD FAILED: ZSTD_AAR_MISSING_$requestedAbi")
        logger.lifecycle("Resolved Zstandard AAR ${aar.name}: ${expected.joinToString()}")
    }
}

tasks.register("verifyNoDirectZstdUsage") {
    group = "verification"
    description = "Keeps all direct zstd-jni calls behind AndroidZstdJniEngine."
    doLast {
        val allowed = file(
            "src/main/java/com/gtav/runtimemanager/compression/zstd/AndroidZstdJniEngine.java"
        ).canonicalFile
        val violations = file("src").walkTopDown()
            .filter { it.isFile && it.extension in setOf("java", "kt") }
            .filter { it.canonicalFile != allowed }
            .filter { source ->
                val text = source.readText()
                Regex("import\\s+com\\.github\\.luben\\.zstd").containsMatchIn(text) ||
                        Regex("\\bnew\\s+ZstdInputStream\\b").containsMatchIn(text) ||
                        Regex("\\bZstd\\.").containsMatchIn(text)
            }.toList()
        if (violations.isNotEmpty()) {
            throw GradleException(
                "Direct Zstandard usage outside the engine:\n" +
                        violations.joinToString("\n") { it.relativeTo(projectDir).path }
            )
        }
    }
}

tasks.register("verifyExecutionSourceComponents") {
    group = "verification"
    description = "Checks PRoot AArch64 and the real x86_64 ELF smoke binary before packaging."
    doLast {
        val proot = file("src/main/assets/execution/usr/bin/proot")
        val loader = file("src/main/assets/execution/usr/libexec/proot/loader")
        val hello = file("src/main/assets/execution/hello-x86_64")
        val manifest = file("src/main/assets/execution/EXECUTION_COMPONENTS_SHA256.txt")
        if (!proot.isFile) throw GradleException("BUILD FAILED: PROOT_NOT_PACKAGED")
        if (!loader.isFile) throw GradleException("BUILD FAILED: PROOT_LOADER_NOT_PACKAGED")
        if (!hello.isFile) throw GradleException("BUILD FAILED: X86_64_TEST_NOT_PACKAGED")
        if (!manifest.isFile) throw GradleException("BUILD FAILED: EXECUTION_COMPONENT_MANIFEST_NOT_PACKAGED")
        if (elfMachine(proot.inputStream().use { it.readNBytes(64) }) != 183)
            throw GradleException("BUILD FAILED: PROOT_WRONG_ABI")
        if (elfMachine(hello.inputStream().use { it.readNBytes(64) }) != 62)
            throw GradleException("BUILD FAILED: X86_64_TEST_WRONG_ABI")
    }
}

listOf("debug", "release").forEach { variant ->
    val cap = variant.replaceFirstChar { it.uppercase() }
    tasks.register("verify${cap}NativePackaging") {
        group = "verification"
        dependsOn("assemble$cap", "verifyZstdAarContents", "verifyNoDirectZstdUsage", "verifyExecutionSourceComponents")
        doLast {
            val apks = findVariantApks(variant)
            if (apks.isEmpty()) throw GradleException("BUILD FAILED: APK_NOT_FOUND_$variant")
            apks.forEach { apk ->
                validateApk(apk, variant)
                validateExecutionComponents(apk, variant)
            }
        }
    }
}

tasks.register("validateAllNativePackaging") {
    group = "verification"
    dependsOn("verifyDebugNativePackaging", "verifyReleaseNativePackaging")
}

tasks.named("check") {
    dependsOn("verifyNoDirectZstdUsage")
}
